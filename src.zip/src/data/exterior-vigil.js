// THE OVERNIGHT VIGIL, AND THE PEOPLE STANDING IN IT.
//
// Ellery comes down at 06:00 on Thursday and twenty-four people have decided to
// be outside it until then. This is not a picket and it is not a cult: it is a
// wet municipal gathering that has been going since teatime, held together by a
// woman with a folder, and it has the composition every real one has — most of
// it ordinary, a small fringe of it certain, and no visible seam between the
// two.
//
// The whole thing is OPTIONAL. Nothing here gates the prologue, nothing here is
// on the route to the lodge, the grey door or the Get-In, and a player who walks
// from the road to the service door never has to learn that any of it happened.
//
// ── what is authored here ───────────────────────────────────────────────────
//
//   VIGIL_MESHES      the collision contract for every figure the pack builds
//   VIGIL_VOICES      six people with names, faces, stills and conversations
//   VIGIL_CROWD       eighteen background figures with kit and no dialogue
//   VIGIL_MOMENTS     three proximity-triggered, non-modal crowd moments
//   VIGIL_ENDING_INSERTS  what the vigil is doing at the end of each night
//
// ── coordinates ─────────────────────────────────────────────────────────────
//
// Everything in this file is YARD-PHYSICAL metres: the same frame as
// floorplan/conservatory.js's yard rows, with x running east into the building
// and y running south from the road. conservatory-props.js adds the yard
// island's logical origin (50, 200); nothing else needs to know that.
//
// ── the corridors this file is not allowed to stand in ──────────────────────
//
// Static people have TRUTHFUL COLLISION — you cannot walk through somebody who
// is standing in the rain, and a crowd you can walk through is not a crowd. That
// makes placement a routing problem rather than a dressing one, so the corridors
// are declared (VIGIL_CLEARANCES) instead of remembered, and the spec proves no
// figure's collision box enters one and that every named person's approach point
// is still reachable from the spawn.
//
//   arrival        y < 20, the whole width: road, lodge, gate, dock, Get-In
//   park           the park itself, so the fountain keeps its own approach
//   west-door      the cathedral's west apron and the run east off it
//   yard-spine     the north/south lane east of the park
//   south-porch    the lane down the cathedral's east flank to the porch

const freeze = (value) => Object.freeze(value);
function deepFreeze(value){
  if(!value||typeof value!=='object'||Object.isFrozen(value))return value;
  for(const child of Object.values(value))deepFreeze(child);
  return Object.freeze(value);
}

const lines=(...entries)=>entries;
const choice=(text,goto,extra={})=>({text,goto,hideWhenAsked:true,...extra});
const leave=(text)=>({text});

// The still each person is played on. One plate per face, wet, at night, from
// the media manifest (content/media/story-art.media.json).
const plate=(id,caption,status)=>freeze({id,mode:'hero',caption,status});

// A figure faces local -Z, which the prop matrix turns into (sin yaw, -cos yaw).
// So yaw 0 looks north up the yard, PI/2 looks east into the building, PI looks
// south at the cathedral. Both derived points come off that one number: the
// reticle aims at the front of the coat, and the body stands a stride clear of
// it.
// The reticle aims at the front of the coat; the body stands a stride and a half
// clear of it. 1.9 rather than a snug 1.35 because collision is continuous and
// the walkable grid is not: a point that clears the padded box by centimetres
// still rounds into a half-metre cell the prop is standing in. It stays inside
// pickProp's two-metre reach from the face point either way.
const FACE_OFFSET=0.40, APPROACH_OFFSET=1.90;
const facing=(yaw)=>({x:Math.sin(yaw),y:-Math.cos(yaw)});
export function vigilFacePoint({x,y,yaw}){
  const f=facing(yaw);
  return{x:Number((x+f.x*FACE_OFFSET).toFixed(3)),y:Number((y+f.y*FACE_OFFSET).toFixed(3))};
}
export function vigilApproachPoint({x,y,yaw}){
  const f=facing(yaw);
  return{x:Number((x+f.x*APPROACH_OFFSET).toFixed(3)),y:Number((y+f.y*APPROACH_OFFSET).toFixed(3))};
}

// ── the corridors ───────────────────────────────────────────────────────────
// Yard-physical rectangles no vigil figure's padded collision box may enter.
// Four metres is the floor, and the two cathedral exits get it in both the
// direction they open and the direction they turn.
export const VIGIL_MIN_CORRIDOR = 4.0;
export const VIGIL_CLEARANCES = freeze([
  freeze({id:'arrival',      x0:-2, x1:52, y0:-2, y1:21, note:'road, lodge, gate, dock steps and the Get-In'}),
  // The park's own two routes, not the whole park: standing on the east lawn
  // beside the railing is the vigil's best image and the paths are what the
  // fountain is reached by.
  freeze({id:'park-spine',   x0:7,  x1:14, y0:20, y1:38, note:'the way into the park and down to the basin'}),
  freeze({id:'park-cross',   x0:3,  x1:16, y0:32, y1:41, note:'the east-west path and the fountain kerb'}),
  // The forecourt is four metres of tarmac between the park hedge and the
  // cathedral's west wall, and the only way north out of it is the gap at
  // x19..25 where that hedge runs out. Nobody stands in either.
  freeze({id:'west-door',    x0:13, x1:26, y0:47, y1:56, note:"St Brendan's west door, its apron and the gap north"}),
  freeze({id:'yard-lane',    x0:20, x1:26, y0:20, y1:48, note:'the lane between the park and the service ranges'}),
  freeze({id:'south-porch',  x0:28, x1:34, y0:55, y1:83, note:"the wide lane down the cathedral's east flank"}),
  freeze({id:'porch-cross',  x0:24, x1:34, y0:66, y1:80, note:'the cross to the south porch itself'}),
]);

// ── the collision contract ──────────────────────────────────────────────────
// A person is roughly nine tenths of a metre across the shoulders in a coat.
// The kit widens them: an umbrella is a metre of nylon, a placard is a metre and
// a half of wet chipboard on a batten, a folding chair takes the depth instead.
export const VIGIL_MESHES = freeze({
  // These numbers are checked against the built geometry — every vigil mesh's
  // real bounds have to fit inside the box that collides with the player (see
  // test/exterior-vigil.spec.mjs). An umbrella you can walk through the edge of
  // is the same lie as a crowd you can walk through.
  vigil_ruth_mallory:  freeze({w:.90,d:.68,h:1.74,blocks:true}),
  vigil_leila_hart:    freeze({w:.86,d:.64,h:1.76,blocks:true}),
  vigil_owen_pryce:    freeze({w:1.06,d:.98,h:2.00,blocks:true}),
  vigil_denise_okafor: freeze({w:.88,d:.66,h:1.72,blocks:true}),
  vigil_malcolm_vey:   freeze({w:.92,d:.68,h:1.88,blocks:true}),
  vigil_kit_renshaw:   freeze({w:.96,d:.82,h:1.76,blocks:true}),
  vigil_figure_umbrella:  freeze({w:1.06,d:.98,h:2.02,blocks:true}),
  vigil_figure_placard:   freeze({w:.90,d:.66,h:2.32,blocks:true}),
  vigil_figure_flask:     freeze({w:.86,d:.64,h:1.74,blocks:true}),
  vigil_figure_seated:    freeze({w:.80,d:.90,h:1.36,blocks:true}),
  vigil_figure_pamphlets: freeze({w:.90,d:.68,h:1.76,blocks:true}),
  vigil_figure_camera:    freeze({w:.96,d:.86,h:1.86,blocks:true}),
});

// ── the six ─────────────────────────────────────────────────────────────────
//
// Each of them gets an opening, two subjects worth asking about, a clean way to
// stop, and something shorter on the way back. Nobody here is a quest giver and
// nobody here knows the plot. What they know is what people standing outside a
// building at midnight know: the schedule, the room they used to practise in,
// the bells, and the thing they are certain of and cannot support.

const RUTH='Ruth Mallory';
const LEILA='Leila Hart';
const OWEN='Owen Pryce';
const DENISE='Denise Okafor';
const MALCOLM='Malcolm Vey';
const KIT='Kit Renshaw';

// THE ONE TRUE THING MALCOLM SAYS.
//
// He is wrong about the council, wrong about the surveyors, wrong about what the
// bells are for and wrong about why he is here. He is right that Ellery Chapel
// and St Brendan's are one signal path, and he is right for no reason at all.
//
// The flag is durable and it is NOT A KEY. It does not open the tower route, it
// does not qualify anything, and a run that never meets him loses no ending. All
// it buys is recognition: the bust's offer and the crossing into the tower are
// allowed to say "he told you this" instead of introducing it cold. Absent from
// an older save it reads false, which is exactly right — that player was never
// told.
export const VIGIL_LINKED_CHAPELS_FLAG = 'vigil.linkedChapels';

export const VIGIL_VOICES = deepFreeze({
  'vigil-ruth-mallory':{
    id:'vigil-ruth-mallory',
    name:RUTH,
    role:'preservation organizer',
    label:'the woman with the folder',
    slate:'CATHEDRAL FORECOURT / THE FOLDER',
    speaker:'RUTH MALLORY',
    art:plate('vigilRuth','Cathedral forecourt / the folder','VIGIL'),
    mesh:'vigil_ruth_mallory',
    place:freeze({x:28.0,y:52.0,yaw:0.15}),
    voice:freeze({pitch:.96,rate:1.02,grain:'level'}),
    tree:{
      start:{
        speaker:'RUTH MALLORY',
        art:plate('vigilRuth','Cathedral forecourt / the folder','VIGIL'),
        lines:lines(
          {who:RUTH,text:'You are the recordist. The gate book has you at twenty-one thirty-eight, which makes you the only person tonight who is allowed inside it.'},
          {who:'direction',text:'She holds a ring binder under her coat the way other people hold a child.'},
          {who:'me',prompt:'Ask what the gathering is.',text:'What is all this?'},
          {who:RUTH,text:'Twenty-four of us, a flask rota and a demolition schedule. We are not stopping anything. We are refusing to let it happen while nobody is looking.'},
        ),
        revisitLines:lines({who:RUTH,text:'Still here. Ask me something useful, I have four hours of standing left.'}),
        choices:[
          choice('Ask about the schedule.','schedule'),
          choice('Ask who these people are.','people'),
          leave('Let her get back to the rota.'),
        ],
      },
      schedule:{
        speaker:'RUTH MALLORY',
        art:plate('vigilRuth','The demolition schedule','06:00 THURSDAY'),
        lines:lines(
          {who:'me',prompt:'Ask when the machines come.',text:'When does it actually start?'},
          {who:RUTH,text:'Six in the morning, Thursday. First strike on the 1967 wing, because it is the cheapest thing to be wrong about.'},
          {who:RUTH,text:'The notice on your gate still says fourteen days. It has said fourteen days since March. Somebody stopped changing the number and nobody stopped the date.'},
          {who:RUTH,text:'So we stand here until six, and then we watch, and then we go to work.'},
        ),
        goto:'start',
      },
      people:{
        speaker:'RUTH MALLORY',
        art:plate('vigilRuth','Cathedral forecourt / the folder','VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask who came out.',text:'Who actually turns up for something like this?'},
          {who:RUTH,text:'Two ex-students, a retired verger, the woman who runs the memory archive, and a man who believes the bells are a machine.'},
          {who:RUTH,text:'I do not vet them. If I only let in the people who agree with me about everything there would be four of us and no flasks.'},
          {who:RUTH,text:'Talk to whoever you like. Just do not tell Malcolm you record sound.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'RUTH MALLORY',
        art:plate('vigilRuth','Cathedral forecourt / the folder','VIGIL'),
        lines:lines({who:RUTH,text:'You went in and you came back out. That already makes you rarer than you think.'}),
        choices:[
          choice('Ask what happens at six.','after'),
          leave('Say goodnight.'),
        ],
      },
      after:{
        speaker:'RUTH MALLORY',
        art:plate('vigilRuth','The demolition schedule','06:00 THURSDAY'),
        lines:lines(
          {who:'me',prompt:'Ask what they do at six.',text:'And when it starts?'},
          {who:RUTH,text:'We stand at the fence. That is the entire plan and I am not embarrassed by it.'},
          {who:RUTH,text:'Somebody has to be able to say, afterwards, that it was not done quietly.'},
        ),
      },
    },
  },

  'vigil-leila-hart':{
    id:'vigil-leila-hart',
    name:LEILA,
    role:'former conservatoire student',
    label:'the woman watching the west windows',
    slate:'YARD / FACING THE PRACTICE WING',
    speaker:'LEILA HART',
    art:plate('vigilLeila','Yard / facing the practice wing','VIGIL'),
    mesh:'vigil_leila_hart',
    place:freeze({x:40.0,y:43.0,yaw:1.40}),
    voice:freeze({pitch:1.06,rate:1.05,grain:'close'}),
    tree:{
      start:{
        speaker:'LEILA HART',
        art:plate('vigilLeila','Yard / facing the practice wing','VIGIL'),
        lines:lines(
          {who:LEILA,text:'Third window along, second floor. That was mine for two years. You can still see the tape marks where I blacked out the glass.'},
          {who:'me',prompt:'Ask if she studied here.',text:'You were a student?'},
          {who:LEILA,text:'Percussion. I left in the second year. Not because of anything dramatic — because it stopped being possible to practise in there.'},
        ),
        revisitLines:lines({who:LEILA,text:'You went in. Was the third window along still taped?'}),
        choices:[
          choice('Ask why she stopped practising.','rooms'),
          choice('Ask what she came back for.','tonight'),
          leave('Leave her with the window.'),
        ],
      },
      rooms:{
        speaker:'LEILA HART',
        art:plate('vigilLeila','The practice rooms','WHAT SHE LEFT'),
        lines:lines(
          {who:'me',prompt:'Ask about the rooms.',text:'What do you mean, stopped being possible?'},
          {who:LEILA,text:'You would set a click and it would come back a beat late through the wall. Everybody blamed the ducting. The ducting was blamed for a lot in that building.'},
          {who:LEILA,text:'One night I recorded eight bars and got nine back. I did not tell anybody, because the only thing you can say out loud there is that you are tired.'},
          {who:LEILA,text:'So I am not going to tell you it was haunted. I am going to tell you I stopped trusting the room, and that was enough.'},
        ),
        goto:'start',
      },
      tonight:{
        speaker:'LEILA HART',
        art:plate('vigilLeila','Yard / facing the practice wing','VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask why she came tonight.',text:'Why stand out here for it?'},
          {who:LEILA,text:'Because I spent two years being told the problem was me, and on Thursday the evidence gets crushed.'},
          {who:LEILA,text:'That is petty. I know it is petty. I still want to see the wing go down with my own eyes.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'LEILA HART',
        art:plate('vigilLeila','Yard / facing the practice wing','VIGIL'),
        lines:lines({who:LEILA,text:'You were in there a long time for five rooms.'}),
        choices:[
          choice('Tell her the rooms are still doing it.','confirm'),
          leave('Say nothing about the rooms.'),
        ],
      },
      confirm:{
        speaker:'LEILA HART',
        art:plate('vigilLeila','The practice rooms','WHAT SHE LEFT'),
        lines:lines(
          {who:'me',prompt:'Tell her the truth about the rooms.',text:'The rooms are still doing it.'},
          {who:LEILA,text:'Right. Good. No — not good. You know what I mean.'},
          {who:LEILA,text:'Eight years of assuming I was the unreliable equipment. Thank you.'},
        ),
      },
    },
  },

  'vigil-owen-pryce':{
    id:'vigil-owen-pryce',
    name:OWEN,
    role:'retired cathedral custodian and bellringer',
    label:'the old man by the south porch',
    slate:"ST BRENDAN'S / SOUTH PORCH",
    speaker:'OWEN PRYCE',
    art:plate('vigilOwen',"St Brendan's / south porch",'VIGIL'),
    mesh:'vigil_owen_pryce',
    place:freeze({x:35.6,y:65.0,yaw:-1.45}),
    voice:freeze({pitch:.88,rate:.94,grain:'dry'}),
    tree:{
      start:{
        speaker:'OWEN PRYCE',
        art:plate('vigilOwen',"St Brendan's / south porch",'VIGIL'),
        lines:lines(
          {who:OWEN,text:'They are taking the school. They are not taking this, and everybody keeps telling me that as though it were comfort.'},
          {who:'me',prompt:'Ask who he is.',text:'You worked here?'},
          {who:OWEN,text:'Custodian, thirty-one years, and I rang the tenor for twenty-six of them. I locked that porch every night of my working life and I have not got the key.'},
        ),
        revisitLines:lines({who:OWEN,text:'Back out, then. Good. Not everybody manages that in one go.'}),
        choices:[
          choice('Ask about the bells.','bells'),
          choice('Ask about the cathedral being kept shut.','shut'),
          leave('Let him stand.'),
        ],
      },
      bells:{
        speaker:'OWEN PRYCE',
        art:plate('vigilOwen','Six bells, and one that is not rung','THE TENOR'),
        lines:lines(
          {who:'me',prompt:'Ask about the ring.',text:'How many bells are up there?'},
          {who:OWEN,text:'Six. Should be eight, was eight, two went for scrap in the sixties and nobody wrote it down properly.'},
          {who:OWEN,text:'The tenor is the one that matters. It is a heavy bell in a light frame and it has always sounded like it is arriving from further away than it is.'},
          {who:OWEN,text:'Last spring somebody heard it struck at half one in the morning. That is not vandalism. You cannot ring a bell that size by accident and you cannot ring it quietly.'},
        ),
        goto:'start',
      },
      shut:{
        speaker:'OWEN PRYCE',
        art:plate('vigilOwen',"St Brendan's / south porch",'VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask why it is closed.',text:'Why has it been shut so long?'},
          {who:OWEN,text:'Diocese calls it a fabric issue. The west door has no handle on the outside — that is not fabric, that is a decision somebody made.'},
          {who:OWEN,text:'It is a building you can leave and not enter. I have never heard a satisfying reason for that and I have asked in writing four times.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'OWEN PRYCE',
        art:plate('vigilOwen',"St Brendan's / south porch",'VIGIL'),
        lines:lines({who:OWEN,text:'You have the look of a man who has heard the tenor. Do not tell me if I am wrong.'}),
        choices:[
          choice('Ask what the tenor is for.','tenor'),
          leave('Leave him the question.'),
        ],
      },
      tenor:{
        speaker:'OWEN PRYCE',
        art:plate('vigilOwen','Six bells, and one that is not rung','THE TENOR'),
        lines:lines(
          {who:'me',prompt:'Ask what the tenor is for.',text:'What was the tenor rung for?'},
          {who:OWEN,text:'Deaths, mostly. One stroke a year of life, and a pause, and then you knew who without being told.'},
          {who:OWEN,text:'People think that is morbid. It is the opposite. It is a building doing the counting so a family does not have to.'},
        ),
      },
    },
  },

  'vigil-denise-okafor':{
    id:'vigil-denise-okafor',
    name:DENISE,
    role:'civic-memory advocate',
    label:'the woman at the park railing',
    slate:'PARK EDGE / CIVIC MEMORY',
    speaker:'DENISE OKAFOR',
    art:plate('vigilDenise','Park edge / civic memory','VIGIL'),
    mesh:'vigil_denise_okafor',
    place:freeze({x:17.6,y:27.0,yaw:1.50}),
    voice:freeze({pitch:1.0,rate:1.0,grain:'level'}),
    tree:{
      start:{
        speaker:'DENISE OKAFOR',
        art:plate('vigilDenise','Park edge / civic memory','VIGIL'),
        lines:lines(
          {who:DENISE,text:'Do you know what this park is? It is not a park. It is the footprint of the 1912 laundry, grassed over in 1974 so nobody would ask where the laundry went.'},
          {who:'me',prompt:'Ask who she is.',text:'You research this?'},
          {who:DENISE,text:'I run the borough memory archive out of a back room in the library they also closed. Eleven thousand photographs and a dehumidifier.'},
        ),
        revisitLines:lines({who:DENISE,text:'You have been inside. I have eleven thousand photographs and not one of that corridor.'}),
        choices:[
          choice('Ask what the archive has on Ellery.','archive'),
          choice('Ask what happens to the record after Thursday.','after'),
          leave('Leave her to the railing.'),
        ],
      },
      archive:{
        speaker:'DENISE OKAFOR',
        art:plate('vigilDenise','Eleven thousand photographs','THE ARCHIVE'),
        lines:lines(
          {who:'me',prompt:'Ask what she has.',text:'What have you got on this place?'},
          {who:DENISE,text:'Everything up to 1986 and almost nothing after. That is the shape of it — the moment a building starts being managed instead of used, the photographs stop.'},
          {who:DENISE,text:'I have the baths opening, the chapel dedication, four school photographs and a fire drill in 1961 where you can count the staff.'},
          {who:DENISE,text:'After that: two press releases and a demolition notice. Ninety-eight years of a building and it ends in a PDF.'},
        ),
        goto:'start',
      },
      after:{
        speaker:'DENISE OKAFOR',
        art:plate('vigilDenise','Park edge / civic memory','VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask what survives.',text:'What survives it?'},
          {who:DENISE,text:'Whatever anybody bothered to write down, and the foundation stone if the contractor is in a good mood.'},
          {who:DENISE,text:'That is why I am out here in the wet with a thermos. Not to stop it. To be a person who was present, so that the record has somebody in it.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'DENISE OKAFOR',
        art:plate('vigilDenise','Park edge / civic memory','VIGIL'),
        lines:lines({who:DENISE,text:'You have been in there with equipment. Do you know what that makes you?'}),
        choices:[
          choice('Ask what it makes him.','record'),
          leave('Decline the answer.'),
        ],
      },
      record:{
        speaker:'DENISE OKAFOR',
        art:plate('vigilDenise','Eleven thousand photographs','THE ARCHIVE'),
        lines:lines(
          {who:'me',prompt:'Ask what it makes him.',text:'Go on. What does it make me?'},
          {who:DENISE,text:'The last person to document the interior of a listed building. Your tape is the record now, whether or not you wanted the job.'},
          {who:DENISE,text:'Whoever you hand it to, keep a copy. Institutions lose things on purpose.'},
        ),
      },
    },
  },

  'vigil-malcolm-vey':{
    id:'vigil-malcolm-vey',
    name:MALCOLM,
    role:'unaffiliated gnostic',
    label:'the man in the yellow cagoule',
    slate:'FORECOURT / THE MAN WITH THE MAP',
    speaker:'MALCOLM VEY',
    art:plate('vigilMalcolm','Forecourt / the man with the map','VIGIL'),
    mesh:'vigil_malcolm_vey',
    place:freeze({x:2.22,y:52.53,yaw:1.35}),
    voice:freeze({pitch:1.02,rate:1.12,grain:'pressed'}),
    tree:{
      start:{
        speaker:'MALCOLM VEY',
        art:plate('vigilMalcolm','Forecourt / the man with the map','VIGIL'),
        lines:lines(
          {who:MALCOLM,text:'You are the one they let in. Good. Then you can settle something for me, because nobody here will.'},
          {who:'direction',text:'He has a laminated street map with two buildings ringed in marker and a line drawn between them.'},
          {who:'me',prompt:'Ask what he wants settled.',text:'Settle what?'},
          {who:MALCOLM,text:'The chapel in there and this cathedral out here are not two buildings. They are one instrument, and somebody has been playing it since 1908.'},
        ),
        revisitLines:lines({who:MALCOLM,text:'You have been in the chapel. Do not tell me what you heard. Tell me whether the line was straight.'}),
        choices:[
          choice('Ask what he means by one instrument.','line'),
          choice('Ask what he thinks is being done with it.','theory'),
          leave('Leave the man to his map.'),
        ],
      },
      // THE CORRECT BRANCH, AND IT COSTS NOTHING TO REFUSE IT.
      //
      // He is right, he cannot say why, and the flag he sets is recognition and
      // not access. A player who walks away has lost a sentence in two later
      // scenes, not a route.
      line:{
        speaker:'MALCOLM VEY',
        art:plate('vigilMalcolm','Two buildings, ringed in marker','THE LINE'),
        lines:lines(
          {who:'me',prompt:'Ask about the line on the map.',text:'One instrument how?'},
          {who:MALCOLM,text:'Ellery Chapel, 1908. St Brendan’s crossing, older. Draw the line between them and it runs through nothing — no road, no service duct, no reason.'},
          {who:MALCOLM,text:'Sound that starts in one arrives in the other. Not carries. Arrives. Ask the neighbours about the drains if you want it in an ordinary voice.'},
          {who:MALCOLM,text:'I cannot prove a word of it. I have no document, no survey and no friend in the diocese. I am telling you anyway, because on Thursday it stops being checkable.'},
        ),
        set:['vigil.linkedChapels'],
        goto:'start',
      },
      theory:{
        speaker:'MALCOLM VEY',
        art:plate('vigilMalcolm','Forecourt / the man with the map','VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask what he thinks it is for.',text:'And what is somebody playing it for?'},
          {who:MALCOLM,text:'Attention. Not the council’s — they are too stupid to be sinister — the building’s. It has been kept half-occupied for forty years by people who thought they were managing an asset.'},
          {who:MALCOLM,text:'The demolition is not a cover-up. It is a mercy, and they have arrived at it by accident, which is how mercies usually arrive.'},
          {who:'me',text:'That is a lot of certainty for a man with a laminated map.'},
          {who:MALCOLM,text:'Yes. It is.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'MALCOLM VEY',
        art:plate('vigilMalcolm','Forecourt / the man with the map','VIGIL'),
        lines:lines({who:MALCOLM,text:'Back. Still the same number of you. I did check.'}),
        choices:[
          choice('Ask what he expects at six.','six'),
          leave('Go before he starts again.'),
        ],
      },
      six:{
        speaker:'MALCOLM VEY',
        art:plate('vigilMalcolm','Two buildings, ringed in marker','THE LINE'),
        lines:lines(
          {who:'me',prompt:'Ask what he expects at six.',text:'What do you think happens at six?'},
          {who:MALCOLM,text:'They break the chapel end of it and the cathedral end goes on holding a note nobody put into it.'},
          {who:MALCOLM,text:'And then, eventually, it stops. Everything does. That is not a comfort, it is just true.'},
        ),
      },
    },
  },

  'vigil-kit-renshaw':{
    id:'vigil-kit-renshaw',
    name:KIT,
    role:'conspiracy field-recordist',
    label:'the person with the shotgun mic',
    slate:'EAST FLANK / FIELD RECORDING',
    speaker:'KIT RENSHAW',
    art:plate('vigilKit','East flank / field recording','VIGIL'),
    mesh:'vigil_kit_renshaw',
    place:freeze({x:25.6,y:58.0,yaw:-1.30}),
    voice:freeze({pitch:1.04,rate:1.08,grain:'close'}),
    tree:{
      start:{
        speaker:'KIT RENSHAW',
        art:plate('vigilKit','East flank / field recording','VIGIL'),
        lines:lines(
          {who:KIT,text:'Do not walk in front of the mic. I have been rolling since nine and I have four usable minutes.'},
          {who:'me',prompt:'Ask what they are recording.',text:'What are you getting?'},
          {who:KIT,text:'Infrasound. There is something under nineteen hertz coming off that wall and it does not stop when the plant does. I have the gain log to prove the second part.'},
        ),
        revisitLines:lines({who:KIT,text:'You had a recorder in there. Please tell me you had a recorder in there.'}),
        choices:[
          choice('Ask to see the log.','log'),
          choice('Ask what they think it is.','theory'),
          leave('Step out of the mic line.'),
        ],
      },
      // The observations are good and the reading of them is not. Both halves
      // are said in the same breath, on purpose.
      log:{
        speaker:'KIT RENSHAW',
        art:plate('vigilKit','The gain log','FOUR USABLE MINUTES'),
        lines:lines(
          {who:'me',prompt:'Ask about the log.',text:'What does the log actually show?'},
          {who:KIT,text:'Twenty-two thirty, plant shuts down, floor drops eleven dB. The low content does not move. Same level, same wandering pitch, all night.'},
          {who:KIT,text:'It wanders about a semitone over roughly forty minutes, and it comes back. That is not a fan and it is not a transformer.'},
          {who:'me',text:'It could be traffic loading the ground. It could be the river.'},
          {who:KIT,text:'It could. I have not ruled either out. I am still going to tell people it is a carrier.'},
        ),
        goto:'start',
      },
      theory:{
        speaker:'KIT RENSHAW',
        art:plate('vigilKit','East flank / field recording','VIGIL'),
        lines:lines(
          {who:'me',prompt:'Ask what they think it is.',text:'And what do you think it is?'},
          {who:KIT,text:'A deliberate signal. Something in there is transmitting and has been since at least February, and the demolition is scheduled for the week the lease on the silence runs out.'},
          {who:KIT,text:'I know how that sounds. I have a spectrogram and a bad explanation and I am aware which of those is the good half.'},
        ),
        goto:'start',
      },
      return:{
        speaker:'KIT RENSHAW',
        art:plate('vigilKit','East flank / field recording','VIGIL'),
        lines:lines({who:KIT,text:'Right. You were inside it. What was the floor doing?'}),
        choices:[
          choice('Give them the honest answer.','honest'),
          leave('Say the levels were unremarkable.'),
        ],
      },
      honest:{
        speaker:'KIT RENSHAW',
        art:plate('vigilKit','The gain log','FOUR USABLE MINUTES'),
        lines:lines(
          {who:'me',prompt:'Give the honest answer.',text:'The floor moved. Not the way a floor moves.'},
          {who:KIT,text:'Thank you. That is the first corroboration I have had that did not come from somebody who already agreed with me.'},
          {who:KIT,text:'I am going to draw completely the wrong conclusion from it. But thank you.'},
        ),
      },
    },
  },
});

// ── the eighteen ────────────────────────────────────────────────────────────
//
// Background figures. No dialogue, no interaction, real collision, and kit that
// tells you what kind of night this has been: umbrellas up since eight, placards
// gone soft at the corners, a flask rota, two folding chairs, pamphlets nobody
// is taking, and a camera on a tripod that has recorded nothing.
//
// The fringe is NOT staged as a separate group. Kit's tripod stands between the
// forecourt knot and the porch witnesses; Malcolm is inside the west knot with
// three people who think he is a nuisance. From ten metres away it is one crowd,
// which is the point.
const crowd=(id,mesh,x,y,yaw,note)=>freeze({id:`vigil-crowd-${id}`,mesh,x,y,yaw,note});

export const VIGIL_CROWD = freeze([
  // The forecourt, east of the door lane — the largest knot, facing the west
  // front with Ruth's folder in the middle of it.
  crowd('east-1','vigil_figure_placard',26.80,53.44,3.05,'SAVE ELLERY, hand-lettered twice'),
  crowd('east-2','vigil_figure_umbrella',29.80,51.40,3.00,'two people under one umbrella'),
  crowd('east-3','vigil_figure_pamphlets',30.60,53.60,2.75,'pamphlets nobody is taking'),
  crowd('east-4','vigil_figure_seated',27.37,54.95,3.17,'a folding chair against the cathedral wall'),
  // The far west end of the forecourt, where Malcolm has cornered three people.
  crowd('west-1','vigil_figure_umbrella',1.73,54.30,3.05,'umbrella up since eight'),
  crowd('west-2','vigil_figure_flask',3.40,54.80,3.12,'pouring for whoever is nearest'),
  crowd('west-3','vigil_figure_seated',7.40,53.80,2.95,'the second folding chair, turned away from him'),
  // The park's east lawn, along the railing line — a file, not a knot, because
  // that is what a queue of people who arrived separately makes.
  crowd('verge-1','vigil_figure_placard',17.60,24.40,1.55,'THE LAUNDRY WAS HERE'),
  crowd('verge-2','vigil_figure_umbrella',17.60,29.80,1.45,'facing the building, not the park'),
  crowd('verge-3','vigil_figure_flask',17.60,42.20,1.50,'the flask rota, halfway down the line'),
  crowd('verge-4','vigil_figure_pamphlets',17.60,44.80,1.55,'a folder of photocopies in a carrier bag'),
  // Facing the conservatoire's west elevation, in the open band between the
  // rehearsal annex and the baths plant.
  crowd('knot-1','vigil_figure_camera',38.20,40.60,1.50,'a tripod that has recorded nothing'),
  crowd('knot-2','vigil_figure_umbrella',41.40,45.80,1.35,'holding the umbrella for somebody else'),
  crowd('knot-3','vigil_figure_seated',43.80,41.60,1.60,'a folding chair and a blanket'),
  crowd('knot-4','vigil_figure_placard',36.40,45.80,1.45,'NINETY-EIGHT YEARS'),
  // Watching the south porch from up the flank, where the covered stores stop.
  crowd('porch-1','vigil_figure_umbrella',37.40,62.60,-1.50,'watching the porch, not the school'),
  crowd('porch-2','vigil_figure_flask',38.80,66.60,-1.40,'the last of the second flask'),
  crowd('porch-3','vigil_figure_camera',40.60,63.80,-1.55,'a camera pointed at a door nobody uses'),
]);

// ── three moments ───────────────────────────────────────────────────────────
//
// Non-modal. Nobody stops the world to say these; they are dispatched onto the
// speech band with the ordinary lease (game/speech.js), which is what makes them
// escapable and what makes them expire.
//
// Each chain is ATOMIC. Escape drops the whole thing, not the sentence on
// screen; walking out of the vigil, opening a conversation, changing render
// context or reaching a finale invalidates it and the tail never arrives on its
// own. `radius` is metres from `at`, in yard-physical.
const moment=(id,at,radius,speech)=>freeze({id,at:freeze(at),radius,lines:freeze(speech.map(freeze))});

export const VIGIL_MOMENTS = freeze([
  // Walking into the forecourt group for the first time.
  moment('vigil.forecourt',{x:28.4,y:52.6},7.5,[
    {who:'direction',text:'Somebody near the folder says the word Thursday and four people turn round, and then turn back.',delayMs:900},
    {who:'you',text:'Twenty-odd people, standing in the wet, outside a building nobody is allowed into. Including me.',gapMs:1400},
  ]),
  // The line along the park railing, seen from the spine.
  moment('vigil.railing',{x:19.6,y:28.4},7.0,[
    {who:'direction',text:'The line along the railing does not chant. It is a queue that has forgotten what it is queueing for and stayed anyway.',delayMs:1200},
    {who:'you',text:'Nobody is shouting. That is somehow worse.',gapMs:1500},
  ]),
  // The porch group, and the camera that is pointed at nothing.
  moment('vigil.porch',{x:33.6,y:64.6},7.5,[
    {who:'direction',text:'A camera on a tripod is pointed at the south porch. The tally light is on. Nothing has come out of that door in eleven years.',delayMs:1000},
    {who:'you',text:'They are recording a shut door for six hours. I have done worse for money.',gapMs:1600},
  ]),
]);

// ── the end of the night ────────────────────────────────────────────────────
//
// Twenty-four people were outside this building when the run started and the
// endings used to end as though the yard were empty. These are SAY steps for the
// ending environment timelines (data/endings.js), on the ending's own clock.
//
// Three rules, and the third is the one that matters:
//
//   · an ending that stays inside says what the vigil is doing outside it;
//   · an ending with a dawn exterior lets the player see the vigil thinned;
//   · an ending with NO STABLE EXTERIOR VIEWPOINT gets nothing.
//
// Inversion and both Contact endings are the third case. The inversion's
// forecourt is not this yard, and Contact does not return a body to a place. So
// they get no insert at all — and specifically NOT a line saying the crowd died
// or vanished, which would be the game asserting something about twenty-four
// people it has no viewpoint from which to know.
const insert=(at,who,text)=>freeze({at,who,text});

export const VIGIL_ENDING_INSERTS = freeze({
  sacrifice: freeze([
    insert(24.0,'direction','Beyond five hundred metres of brick, twenty-four people are standing at a fence in the dark, waiting for six o’clock. None of them will know you were still in here.'),
  ]),
  helped: freeze([
    insert(26.0,'you','The woman with the folder said they would stand at the fence. They will be standing at the fence.'),
  ]),
  drugged: freeze([
    insert(6.0,'direction','Through the windscreen the vigil has thinned to nine. Somebody is folding a chair. Somebody else is still holding a placard because putting it down would be a decision.'),
    insert(15.0,'you','They watched the van all night and none of them thought to knock on it.'),
  ]),
  surfaced: freeze([
    insert(22.0,'direction','The thinned dawn vigil opens without being asked. A folding chair arrives, then a coat, then somebody sensible saying the word ambulance.'),
    insert(34.0,'you','Let them. The guard has his book and his column and this is his scene, not theirs.'),
  ]),
  'tower-won': freeze([
    insert(9.0,'direction','The crowd at the south porch parts, and then stops being a crowd: hands come under the shoulders, somebody counts to three, and the weight goes off you.'),
    insert(20.0,'direction','Six o’clock passes over the fence. No horn, no plant, no first strike. Twenty-four people stand listening to a demolition not happening.'),
  ]),
  'tower-lost': freeze([
    insert(11.0,'direction','Outside, the vigil hears a full peal come off the crossing tower — six bells, complete, in order. Every one of them is looking at a tower that has not moved.'),
  ]),
});

// The endings that deliberately receive nothing, named so the spec can prove the
// omission is authored rather than forgotten.
export const VIGIL_ENDING_OMISSIONS = freeze(['inversion','contact-won','contact-lost']);

export function vigilEndingInserts(endingId){
  return VIGIL_ENDING_INSERTS[String(endingId||'')] || null;
}

// ── consumers ───────────────────────────────────────────────────────────────

export function vigilVoice(id){
  return VIGIL_VOICES[String(id||'')] || null;
}

export function vigilConversation(id,{revisited=false}={}){
  const entry=vigilVoice(id);
  if(!entry)return null;
  return{
    tree:entry.tree,
    startAt:revisited?'return':'start',
    slate:entry.slate,
    speaker:entry.speaker,
    art:entry.art,
  };
}

export function vigilMoment(id){
  return VIGIL_MOMENTS.find((entry)=>entry.id===String(id||''))||null;
}

// Every figure standing in the yard tonight, named and unnamed, in one list.
// conservatory-props.js turns these into placements; the spec walks them.
export function vigilFigures(){
  return[
    ...Object.values(VIGIL_VOICES).map((voice)=>({
      id:voice.id,mesh:voice.mesh,x:voice.place.x,y:voice.place.y,yaw:voice.place.yaw,
      talkable:true,label:voice.label,voiceId:voice.id,
      facePoint:vigilFacePoint(voice.place),approach:vigilApproachPoint(voice.place),
    })),
    ...VIGIL_CROWD.map((figure)=>({
      id:figure.id,mesh:figure.mesh,x:figure.x,y:figure.y,yaw:figure.yaw,
      talkable:false,label:null,voiceId:null,
      facePoint:vigilFacePoint(figure),approach:vigilApproachPoint(figure),
    })),
  ];
}

export const VIGIL = freeze({
  voices:VIGIL_VOICES,
  crowd:VIGIL_CROWD,
  moments:VIGIL_MOMENTS,
  meshes:VIGIL_MESHES,
  clearances:VIGIL_CLEARANCES,
  flag:VIGIL_LINKED_CHAPELS_FLAG,
});

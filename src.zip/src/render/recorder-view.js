import { drawRecorderRig } from './recorder-rig.js';
// One physical recorder in every transport state. The approved instrument owns
// the faceplate, display stack and three bottom housings; this adapter owns
// scene layout and authored content, never a second transport illustration.
import { uiFill, uiDraw, uiCellMetrics, uiCurrentScale } from './ui.js';
import { fitText } from './fit-text.js';
import { layoutTranscript, layoutTranscriptChoices, fitTranscriptChoices, transcriptChoiceText } from './transcript.js';
import { obscuredGlyphAt, obscuredShape } from '../narrative/obscured-name.js';
import { visualEffectsEnabled } from '../game/access.js';
import { drawRecorderInstrument, recorderFaceLayout, recorderDisplayPalette, drawRecorderDisplayText, drawRecorderCheckMeter } from './recorder-instrument.js';
import { registerReviewRegion } from '../game/local-text-review.js';
import { drawTraceVfdText } from './dual-trace-display.js';
import { uiBrightness } from './palette.js';

const clamp01 = value => Math.max(0, Math.min(1, Number(value) || 0));
export const TRANSPORT = Object.freeze({
  MONITOR: 'monitor', RECORD: 'record', PLAY: 'play', BROWSE: 'browse', CHECK: 'check', LISTEN: 'listen', TRACE: 'trace',
});
const LABEL = Object.freeze({ monitor: 'MONITOR', record: 'RECORD', play: 'TAPE RETURN',
  browse: 'TAKES', check: 'MIC CHECK', listen: 'LISTEN / PRE-ROLL', trace: 'TRACE' });
export function formatTakeTime(seconds = 0) {
  const whole = Math.max(0, Math.floor(Number(seconds) || 0));
  return `${String(Math.floor(whole / 60)).padStart(2, '0')}:${String(whole % 60).padStart(2, '0')}`;
}

// Physical dimensions, not a row budget inherited from the previous deck.
// Uniform shrinkage keeps the display and keys in frame above speech/letterbox.
export const RECORDER_PANEL = Object.freeze({ width: 736, height: 405, lift: 1 });
export function recorderPanelRect({ cols, rows, progress = 0, clearBottom = 0 }) {
  const { cellW, cellH } = uiCellMetrics(), scale = uiCurrentScale();
  const bar = 2 + Math.round(clamp01(progress) * 3);
  // Size the physical chassis against a viewport-owned envelope. A later
  // sentence, status or take-progress update can move its placement but must
  // not re-machine the display, keys and number artwork every frame.
  const top = 5.5, reservedBottom = 5 + RECORDER_PANEL.lift;
  const bottom = Math.max(5, clearBottom) + RECORDER_PANEL.lift;
  const availableW = Math.max(1, (cols - 2) * cellW);
  const availableH = Math.max(1, (rows - top - reservedBottom) * cellH);
  const unit = Math.min(scale, availableW / RECORDER_PANEL.width, availableH / RECORDER_PANEL.height);
  const w = RECORDER_PANEL.width * unit / cellW, h = RECORDER_PANEL.height * unit / cellH;
  return { x: (cols - w) / 2, y: Math.max(top, rows - bottom - h), w, h, bar, compact: false };
}

// The live machine stays below the sightline in slate, hold and rolling states.
// Raising it for inspection is a separate presenter; changing a live status
// must not resize the same instrument. Narrow viewports retain the full face.
export function liveTakePanelRect({cols,rows,progress=0,clearBottom=0,expanded=false}={}) {
  const normal=recorderPanelRect({cols,rows,progress,clearBottom});
  const {cellW,cellH}=uiCellMetrics();
  if(cols*cellW<960)return normal;
  const scale=Math.min(.72,cols*.49/normal.w);
  const w=normal.w*scale,h=normal.h*scale;
  return {...normal,x:1.5,y:Math.max(5.5,rows-Math.max(5,clearBottom)-RECORDER_PANEL.lift-h),w,h};
}

export function recorderButtons(rect, buttons) { return buttons ? { ...buttons, w: 0 } : null; }
export function recordingOverlayButtons({ held = false, assisted = false, rolling = false } = {}) {
  return { keys: [
    { id: 'rec', label: 'REC', lit: rolling, color: 'red', latched: true, controlId: 'recording:rec', held: held || assisted },
    { id: 'stop', label: 'STOP', color: 'white', controlId: 'recording:stop' },
    { id: 'takes', label: 'TAKES', color: 'white', controlId: 'recording:takes' },
  ] };
}
export function playbackOverlayButtons() {
  return { keys: recordingOverlayButtons().keys.map(key => ({ ...key, enabled: key.id !== 'rec', latched: false })) };
}
export function recorderControlRegions(rect, buttons = {}) {
  const layout = recorderFaceLayout(rect);
  if (!layout) return [];
  return (buttons?.keys || []).slice(0, 3).map((key, index) => ({
    kind: 'transport', id: key.id || key.controlId || String(index), index,
    controlId: key.controlId || `recorder:${key.id || index}`,
    ...layout.buttonSlots[index], enabled: key.enabled !== false,
  }));
}
// Compatibility helper: the complete aperture belongs to data, not a side bank.
export function recorderInstrumentLayout(body) {
  return { usableW: body.w, counterW: body.w * .43, bayX: body.x + body.w * .49,
    bayW: body.w * .51, channelsW: 0, channelsX: body.x + body.w };
}
export function recorderTranscriptRect(body) { return { ...body }; }
export function recorderGuideLayout(body, guide) {
  const step = Math.min(1, body.h / 9);
  const capacity = Math.max(1, Math.floor(body.h / step) - 3);
  const choices = fitTranscriptChoices(layoutTranscriptChoices(guide, body.w), capacity,
    { selectedOffset: guide?.choiceScrollOffset });
  return { choices, step, choiceY: body.y + body.h - choices.height * step,
    maxRows: Math.max(0, Math.floor(body.h / step - (choices.height ? choices.height + 1 : 0))) };
}
function takeListLayout(body, view) {
  const capacity = Math.max(1, Math.floor(body.h - 2));
  const selected = Math.max(0, Number(view.selected) || 0);
  const start = Math.max(0, Math.min(selected - capacity + 1, (view.rows?.length || 0) - capacity));
  return { ...body, y: body.y + 1.5, h: body.h - 1.5, capacity, start };
}
export function recorderHitRegions(view = {}) {
  const layout = recorderFaceLayout(view.rect);
  if (!layout) return [];
  const regions = recorderControlRegions(view.rect, view.buttons);
  if (view.mode === TRANSPORT.BROWSE) {
    const list = takeListLayout(layout.body, view);
    (view.rows || []).slice(list.start, list.start + list.capacity).forEach((take, offset) => {
      const index = list.start + offset;
      regions.push({ kind: 'take', id: take.roomId || String(index), index,
        x: list.x, y: list.y + offset, w: list.w, h: 1 });
    });
  }
  if (view.mode === TRANSPORT.LISTEN) {
    const content = layout.transcriptRect, { choices, step, choiceY } = recorderGuideLayout(content, view.guide || {});
    choices.rows.forEach((choice, index) => {
      if (choice.kind === 'choice') regions.push({ kind: 'choice', index: choice.choiceIndex,
        x: content.x + choices.lane.x, y: choiceY + index * step,
        w: choices.lane.w, h: step });
    });
    regions.push({ kind: 'guide', ...content });
  }
  return regions;
}

const write = (x, y, value, width, color = '#8fcd87', alpha = 1) =>
  drawRecorderDisplayText(x, y, value, { width, color, alpha, size: 12 });
function drawTakeList(body, view) {
  write(body.x, body.y, 'SEALED TAKES · SELECT TO LISTEN', body.w, '#b4f4e6');
  if (!view.rows?.length) { write(body.x, body.y + 2, 'NO TAPES ON THIS MACHINE', body.w); return; }
  const list = takeListLayout(body, view);
  view.rows.slice(list.start, list.start + list.capacity).forEach((row, offset) => {
    const selected = list.start + offset === view.selected, y = list.y + offset;
    if (selected) uiFill(list.x - .25, y, list.w + .5, 1, 'rgba(180,244,230,.08)');
    const statusW = Math.max(4, Math.min(17, Math.floor(list.w * .28))), nameW = Math.max(1, list.w - statusW - 7);
    write(list.x, y, `${selected ? '›' : ' '} ${row.ordinal || String(list.start + offset + 1).padStart(2, '0')}`, 5,
      selected ? '#b4f4e6' : '#8fcd87');
    write(list.x + 5, y, fitText(row.label, nameW), nameW, selected ? '#b4f4e6' : '#8fcd87');
    write(list.x + list.w - statusW, y, fitText(row.status, statusW), statusW, row.warn ? '#e4bd78' : '#8fcd87');
  });
}
function drawGuide(body, view) {
  const guide = view.guide || {}, { choices, step, choiceY, maxRows } = recorderGuideLayout(body, guide);
  const prose = (x, y, value, width, color, alpha = 1) => drawRecorderDisplayText(x, y, value,
    { width, color, alpha, lineHeight: step, size: Math.min(12, step * 16) });
  const transcript = layoutTranscript(guide, { width: body.w, maxRows, keep: 4 });
  let y = body.y, used = 0;
  for (const block of transcript.blocks || []) {
    const x = body.x + block.lane.x, color = block.role.side === 'right' ? '#e4bd78' : '#b4f4e6';
    if (block.labelRows && used < maxRows) {
      prose(x, y, block.role.speaker, block.lane.w, color, block.active ? 1 : .65); y += step; used++;
    }
    for (const row of block.rows) {
      if (used >= maxRows) break;
      let value = row.text;
      // The authored mask still supplies visible shapes/accessibility captions.
      const shape = row.mask && visualEffectsEnabled() ? obscuredShape(row.mask) : null;
      if (shape) value = Array.from({ length: Math.min(shape.length, Math.ceil((row.reveal ?? 1) * (shape.length + 2))) },
        (_, i) => obscuredGlyphAt(shape, i, row.reveal ?? 1) || ' ').join('');
      prose(x + row.x, y, value + (row.typing ? ' ▏' : ''), block.lane.w - row.x,
        block.role.side === 'center' ? '#8fcd87' : color, block.active ? 1 : .65); used++;
      if(value.trim())registerReviewRegion(row.reviewTarget,
        {x:x+row.x,y,w:Math.min(value.length,block.lane.w-row.x),h:step,active:row.active});
      y += step;
    }
    if (used < maxRows) { y += step; used++; }
  }
  choices.rows.forEach((row, i) => {
    const selected = row.kind === 'choice' && row.choiceIndex === guide.pending?.index;
    // Keep the shared selection, archive and spent semantics on the recorder's
    // own phosphor face; no borrowed physical keys inside the glass aperture.
    const color = selected ? '#e4bd78' : row.archiveSignal ? '#a9d5e1' : '#8fcd87';
    const text = transcriptChoiceText(row);
    prose(body.x + choices.lane.x, choiceY + i * step, text, choices.lane.w, color, row.spent ? .48 : 1);
    if(row.kind==='choice'&&text.trim())registerReviewRegion(row.reviewTarget,
      {x:body.x+choices.lane.x,y:choiceY+i*step,w:Math.min(text.length,choices.lane.w),h:step,selected});
  });
}
export function recorderCheckLayout(body,{cellW,cellH}=uiCellMetrics()){
  const pixels=Math.max(1,body.h*cellH),row=Math.min(20,Math.max(13,pixels*.10));
  const gap=Math.min(8,pixels*.03),meterHeight=Math.max(0,pixels-3*row-4*gap);
  const rect=(top,height)=>({x:body.x,y:body.y+top/cellH,w:body.w,h:height/cellH});
  return {prompt:rect(0,row),meter:rect(row+gap,meterHeight),
    line:rect(row+meterHeight+2*gap,row),privacy:rect(pixels-row,row),
    fontSize:Math.min(12,row*.85),cellW,cellH};
}
function drawCheck(body,view){
  const check=view.check||{},layout=recorderCheckLayout(body),colors=recorderDisplayPalette();
  const prose=(rect,value,color)=>uiDraw(({ctx,dpr,cellW,cellH})=>{
    const size=layout.fontSize,capacity=Math.max(1,Math.floor(rect.w*cellW/(size*.72+.2)));
    ctx.save();try{
      ctx.scale(dpr,dpr);
      drawTraceVfdText(ctx,fitText(value,capacity),rect.x*cellW,(rect.y+rect.h/2)*cellH,
        {fontSize:size,color,alpha:uiBrightness(),maxWidth:rect.w*cellW});
    }finally{ctx.restore();}
  });
  prose(layout.prompt,check.prompt||'SAY: “CHECK, ONE TWO”',colors.meterMark);
  drawRecorderCheckMeter(layout.meter.x,layout.meter.y,layout.meter.w,view.roomMeter,
    {height:layout.meter.h,thresholdDb:-12,sourceId:view.meterId||'room-mic',
      label:check.heard?'LEVEL OK':check.note||'ROOM MIC',nowMs:view.nowMs??performance.now()});
  prose(layout.line,check.line||'',colors.label);
  prose(layout.privacy,'NOTHING IS RECORDING. NOTHING IS KEPT.',colors.counter);
}
export function drawRecorderFace(view = {}) {
  if (!view.rect) return null;
  const mode = view.mode || TRANSPORT.RECORD;
  const special = mode === TRANSPORT.BROWSE ? drawTakeList : mode === TRANSPORT.LISTEN ? drawGuide : mode === TRANSPORT.CHECK ? drawCheck : null;
  const paint = () => drawRecorderInstrument({ ...view, label: view.label || LABEL[mode] },
    special ? { drawContent: layout => special(layout.body, view) } : {});
  const layout = recorderFaceLayout(view.rect);
  if (view.rig && drawRecorderRig(view, layout, paint)) return layout.body;
  return view.rigOnly ? null : paint();
}

//
//  bag-icons.js
//  
//
//  Created by Sebastian Suarez-Solis on 7/12/26.
//

// Code-native service-manual schematics for the field case.

import { uiDraw } from './ui.js';
import { UI_COLOR, themeRoleColor, uiBrightness, uiFlickerAlpha } from './palette.js';

function iconColor(tone, x, cols) {
  if (tone === 'complete') return UI_COLOR.green;
  if (tone === 'danger') return UI_COLOR.danger;
  if (tone === 'metadata') return UI_COLOR.blue;
  if (tone === 'dim') return UI_COLOR.secondary;
  return themeRoleColor('phosphor', x, cols);
}

function withStyle(ctx, { color, alpha, active, dpr }) {
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.globalAlpha = alpha;
  ctx.lineWidth = Math.max(1, 1.15 * dpr);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (active) {
    ctx.shadowColor = color;
    ctx.shadowBlur = 4 * dpr;
  }
}

function path(ctx, points, box, close = false) {
  if (!points.length) return;
  ctx.beginPath();
  points.forEach(([x, y], i) => {
    const px = box.x + box.w * x;
    const py = box.y + box.h * y;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  });
  if (close) ctx.closePath();
  ctx.stroke();
}

function rect(ctx, x, y, w, h, box) {
  ctx.strokeRect(box.x + box.w * x, box.y + box.h * y, box.w * w, box.h * h);
}

function circle(ctx, x, y, r, box, fill = false) {
  ctx.beginPath();
  ctx.arc(box.x + box.w * x, box.y + box.h * y, Math.min(box.w, box.h) * r, 0, Math.PI * 2);
  fill ? ctx.fill() : ctx.stroke();
}

function drawLight(ctx, box) {
  rect(ctx, .34, .28, .20, .50, box);
  path(ctx, [[.34,.34],[.20,.18],[.68,.18],[.54,.34]], box, true);
  path(ctx, [[.68,.25],[.94,.10]], box);
  path(ctx, [[.70,.36],[.98,.32]], box);
  path(ctx, [[.68,.47],[.94,.57]], box);
}

function drawRecorder(ctx, box) {
  rect(ctx, .12, .12, .76, .76, box);
  circle(ctx, .34, .42, .15, box);
  circle(ctx, .66, .42, .15, box);
  rect(ctx, .24, .68, .52, .08, box);
  for (let i = 0; i < 6; i++) {
    const x = .26 + i * .08;
    path(ctx, [[x,.72],[x+.045,.72]], box);
  }
}

function drawRadio(ctx, box) {
  path(ctx, [[.50,.06],[.50,.25],[.72,.00]], box);
  rect(ctx, .18, .24, .64, .64, box);
  for (const x of [.32,.50,.68]) circle(ctx, x, .42, .025, box, true);
  rect(ctx, .30, .62, .40, .10, box);
  path(ctx, [[.23,.82],[.77,.82]], box);
}

function drawInterface(ctx, box) {
  rect(ctx, .10, .18, .80, .66, box);
  rect(ctx, .20, .28, .34, .18, box);
  for (const x of [.24,.40,.58,.74]) circle(ctx, x, .64, .035, box, true);
  path(ctx, [[.24,.64],[.30,.52],[.58,.52],[.74,.64]], box);
  path(ctx, [[.10,.74],[.00,.88],[.18,.98]], box);
}

function drawTuningFork(ctx, box) {
  path(ctx, [[.30,.08],[.30,.46],[.38,.58],[.46,.62],[.46,.92]], box);
  path(ctx, [[.70,.08],[.70,.46],[.62,.58],[.54,.62],[.54,.92]], box);
  path(ctx, [[.42,.92],[.58,.92]], box);
  path(ctx, [[.30,.18],[.18,.10]], box);
  path(ctx, [[.70,.18],[.82,.10]], box);
}

// THE ADJUSTABLE SPANNER. An open jaw with the worm screw under it, drawn from
// the side the way a parts diagram would: the fixed jaw square, the sliding one
// stepped back, and the knurl between them. Not a hammer and not a wrench with a
// closed head — the adjustable is a specific object in this game and the icon
// has to be the one in the van.
function drawSpanner(ctx, box) {
  // The open jaw.
  path(ctx, [[.22,.10],[.22,.30],[.44,.30]], box);
  path(ctx, [[.22,.42],[.44,.42],[.44,.22]], box);
  // The knurl, and the shank running out of it.
  path(ctx, [[.34,.44],[.34,.56]], box);
  path(ctx, [[.28,.48],[.46,.48]], box);
  path(ctx, [[.28,.53],[.46,.53]], box);
  path(ctx, [[.38,.56],[.62,.92]], box);
  path(ctx, [[.30,.60],[.54,.94]], box);
}

// NERVE. Not a heart — a hand held steady: a wrist, and the trace of a pulse
// under it that has flattened out. The composure branch, drawn as the thing the
// composure branch is about.
function drawNerve(ctx, box) {
  path(ctx, [[.10,.62],[.26,.62],[.34,.34],[.44,.82],[.54,.52],[.62,.62],[.90,.62]], box);
  path(ctx, [[.16,.24],[.24,.16],[.40,.14],[.52,.18]], box);
  circle(ctx, .70, .28, .10, box);
}

function drawKeyring(ctx, box) {
  circle(ctx, .28, .38, .20, box);
  path(ctx, [[.44,.44],[.78,.78],[.88,.68]], box);
  path(ctx, [[.62,.61],[.72,.51]], box);
  path(ctx, [[.70,.69],[.80,.59]], box);
  path(ctx, [[.38,.48],[.68,.32],[.78,.42]], box);
}

function drawCoffee(ctx, box) {
  path(ctx, [[.28,.22],[.72,.22],[.64,.84],[.36,.84]], box, true);
  path(ctx, [[.24,.18],[.76,.18]], box);
  path(ctx, [[.40,.08],[.44,.00]], box);
  path(ctx, [[.55,.08],[.60,.00]], box);
}

function drawRoom(ctx, box) {
  rect(ctx, .12, .14, .76, .70, box);
  path(ctx, [[.12,.34],[.28,.34],[.38,.26],[.48,.42],[.60,.30],[.72,.38],[.88,.38]], box);
  path(ctx, [[.26,.70],[.42,.56],[.56,.70],[.72,.56]], box);
}

function drawFile(ctx, box) {
  path(ctx, [[.22,.08],[.66,.08],[.82,.26],[.82,.90],[.22,.90]], box, true);
  path(ctx, [[.66,.08],[.66,.28],[.82,.28]], box);
  path(ctx, [[.34,.46],[.70,.46]], box);
  path(ctx, [[.34,.60],[.70,.60]], box);
  path(ctx, [[.34,.74],[.58,.74]], box);
}

function drawUnknown(ctx, box) {
  rect(ctx, .18, .12, .64, .76, box);
  path(ctx, [[.36,.36],[.44,.26],[.58,.26],[.66,.34],[.64,.44],[.50,.52],[.50,.62]], box);
  circle(ctx, .50, .74, .025, box, true);
}

function drawCassette(ctx,box){
  rect(ctx,.10,.25,.80,.54,box);
  rect(ctx,.22,.32,.56,.13,box);
  circle(ctx,.34,.58,.075,box);circle(ctx,.66,.58,.075,box);
  path(ctx,[[.22,.79],[.29,.68],[.71,.68],[.78,.79]],box);
}
function drawBattery(ctx,box){
  rect(ctx,.28,.17,.44,.70,box);rect(ctx,.40,.10,.20,.07,box);
  path(ctx,[[.40,.34],[.60,.34]],box);path(ctx,[[.50,.25],[.50,.43]],box);
  path(ctx,[[.40,.72],[.60,.72]],box);
}
function drawLead(ctx,box){
  path(ctx,[[.25,.19],[.25,.45],[.35,.60],[.61,.60],[.73,.74],[.73,.85]],box);
  rect(ctx,.20,.12,.10,.17,box);rect(ctx,.68,.73,.10,.17,box);
  path(ctx,[[.25,.06],[.25,.12]],box);path(ctx,[[.73,.90],[.73,.97]],box);
}
function drawMusicBox(ctx,box){
  path(ctx,[[.18,.34],[.69,.25],[.83,.42],[.83,.73],[.31,.84],[.18,.67],[.18,.34],[.31,.51],[.83,.42]],box);
  path(ctx,[[.31,.51],[.31,.84]],box);circle(ctx,.69,.60,.045,box);
  path(ctx,[[.73,.60],[.93,.60],[.93,.52]],box);
}
function drawWedge(ctx,box){
  path(ctx,[[.15,.71],[.76,.30],[.87,.41],[.87,.76],[.15,.79],[.15,.71]],box);
  path(ctx,[[.15,.71],[.77,.68],[.76,.30]],box);
}

const DRAW = Object.freeze({
  light: drawLight,
  recorder: drawRecorder,
  radio: drawRadio,
  interface: drawInterface,
  'tuning-fork': drawTuningFork,
  spanner: drawSpanner,
  nerve: drawNerve,
  keyring: drawKeyring,
  coffee: drawCoffee,
  room: drawRoom,
  file: drawFile,
  cassette:drawCassette,
  battery:drawBattery,
  'patch-lead':drawLead,
  'music-box':drawMusicBox,
  wedge:drawWedge,
  unknown: drawUnknown,
});

export function drawBagIcon(kind, x, y, {
  w = 12,
  h = 7,
  active = false,
  state = 'active',
  alpha = 1,
  empty = false,
  // Printed on an illuminated cap instead of glowing on glass. Overrides the
  // tone entirely and suppresses both the flicker and the bloom: a silkscreened
  // symbol on plastic does neither. See presentation.js drawLampButton.
  ink = null,
} = {}) {
  uiDraw(({ ctx, dpr, cellW, cellH, cols }) => {
    const box = {
      x: x * cellW * dpr,
      y: y * cellH * dpr,
      w: w * cellW * dpr,
      h: h * cellH * dpr,
    };
    const color = ink || iconColor(empty ? 'danger' : state, x, cols);
    const flicker = ink ? 1 : uiFlickerAlpha(x, y, empty ? 'danger' : 'phosphor');

    ctx.save();
    withStyle(ctx, {
      color,
      alpha: ink
        ? Math.max(0, Math.min(1, alpha))
        : Math.max(0, Math.min(1, alpha * flicker * uiBrightness() * (empty ? .42 : 1))),
      active: ink ? false : active,
      dpr,
    });

    (DRAW[kind] || DRAW.unknown)(ctx, box);

    if (empty) {
      ctx.setLineDash([4 * dpr, 4 * dpr]);
      ctx.globalAlpha *= .55;
      ctx.strokeRect(box.x, box.y, box.w, box.h);
    }

    ctx.restore();
  });
}

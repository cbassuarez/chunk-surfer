// First-person 3D renderer — the only shipped world view.
//
// Geometry is architecture, not terrain: a flat floor at y=0, a flat ceiling
// at CEIL, and full-height wall slabs on a corridor lattice (see solidCell).
// Walls are traversed by DDA so faces are exact; floor and ceiling are planes
// solved analytically. Surfaces wear a live Gray-Scott reaction-diffusion skin
// without exposing the retired 2D world's zone-navigation palette.
//
// solidCell() is mirrored bit-for-bit in JS as r3dSolid() for collision —
// both sides use uint hashing only, since float noise diverges between GLSL
// f32 and JS f64 and the player would clip through drawn walls.
//
// Game logic stays untouched: movement is still discrete grid steps; this
// module only owns facing (N/E/S/W) and the camera.

import {createBoothTelevision} from './booth-tv.js';
import { graphicsStartupError, verifyGraphicsStartup } from './graphics-startup.js';
import {DRIVE_MEMORY_BREAK_GLSL,driveMemoryBreakUniforms} from './radio-dial-static.js';
import { assetUrl } from '../platform/paths.js';
import { filmLeakFrame } from '../game/film-leak.js';
import { FILM_LEAK_ATLAS } from '../data/film-leak-atlas.js';
import { HUSH_POSTURE_REVISION } from '../data/generated/hush-last-posture-support.js';
import { CAB_RADIO_PACK } from '../data/cab-radio.js';
import { CAB_DASH_PACK } from '../data/cab-dash.js';
import {NATATORIUM_METRIC_GLSL,NATATORIUM_METRIC_IDENTITY,normalizeNatatoriumMetric,natatoriumMetricUniform,natatoriumMetricZ} from './natatorium-metric.js';
import { recordingEmbodimentInstances,recordingEmbodimentViewPull } from './recording-embodiment.js';
import {normalizeRecordingViewPull} from './recording-view-pull.js';
import {normalizeSourceRestFaculties,sourceRestFacultyUniforms} from './source-rest-faculties.js';
import { OPENING_OVERTURE } from '../data/opening-overture.js';
import {GLASS_COURT_RAIN_GLSL} from './glass-court-weather.js';
import {RAIN_FIELD_GLSL} from './rain-field.js';
import {B3_STUDIO_PROPS_ASSET,B3_STUDIO_PROPS_MESHES} from '../data/b3-studio-props.js';
import { B3_GLASS_GLSL, createB3GlassMoment, b3FigurePanePoint, b3ClearRay, b3PaneIllumination } from './studio-b3-glass.js';
import {OUTSKIRTS_BUS_RAIN_GLSL,outskirtsBusRainUniforms,outskirtsBusInteriorLightMix} from './outskirts-bus-weather.js';
import {GLASS_COURT} from '../data/glass-court.js';
import {SOURCE_BLUEPRINT_ACQUISITION_GLSL,sourceBlueprintEnabled} from './source-blueprint-contract.js';
import {normalizeSourceFinish} from './source-material-finish.js';
import {SOURCE_REST_HORIZON_LENS_GLSL,sourceRestHorizonLensUniforms} from './source-rest-horizon-pass.js';
import {SOURCE_REST_STARS_GLSL} from './source-rest-stars.js';
import { MAIN_STAIR_WALL_PACK } from '../data/main-stair-wall-dressing.js';
import { EXTERIOR_FRONTAGE_PACK } from '../data/exterior-frontages.js';
import {EXTERIOR_STREET_FABRIC} from '../data/exterior-street-fabric.js';
import {ELLERY_PUBLIC_FRONT_PACK,ELLERY_PUBLIC_FRONT_MESHES} from '../data/ellery-public-front.js';
import { EXTERIOR_ROOFLINE_PACK } from '../data/exterior-roofline.js';
import { EXTERIOR_STATIONERS_PACK } from '../data/exterior-stationers.js';
import { ACADEMIC_CHARACTER_PACK_MESHES } from '../data/academic-society-character-design.js';
import { createStreetCrowdPackLoader } from './street-crowd-packs.js';
import { FRONT_END_PLATE_PRESETS, normalizeFrontEndPlate } from './front-end-plate.js';
import { ZONE, AMBIENT_PLACE_SCALE, BORROWED_INTERIOR_ZONE_BIT, CELL, EYE as EYE_METERS, MATERIAL, PLAN_SCALE } from '../data/floorplan/legend.js';
import * as P3 from './props3d.js';
import {STILLNESS_FACES_GLSL} from './stillness-faces.js';
import {STILLNESS_RELIEF_PROXY_GLSL} from './stillness-relief-contract.js';
import {setStillnessPresentation,stillnessPresentation,bindStillnessPresentation} from './stillness-presentation.js';
import { ACADEMIC_ATRIUM_LIGHT_GLSL, academicAtriumLightEnabled } from './academic-atrium-light.js';
import { COASTAL_MEMORY_WATER_GLSL, coastalWaterUniforms } from './coastal-memory-water.js';
import { localLightConeDescriptor, LOCAL_LIGHT_CONE_GLSL } from './local-light-cone.js';
import { DIPPED_BEAM_GLSL } from './dipped-beam.js';
import { UNRAVELLING_GLSL } from './source-unravelling-shader.js';
import * as SHORE from './source-shore3d.js';
import { normalizePixelMeshSettings } from './pixel-mesh/settings.js';
import { homeRealmAcquisition } from './realm-pocket-geometry.js';
import { PIXEL_MESH_FRAG } from './pixel-mesh/shader.js';
import { cameraBasis, DOWNWARD_LOOK_LIMIT, CAMERA_FORWARD_GLSL } from './camera-basis.js';
import { authoredCameraFrame } from './authored-camera.js';
import { cinematicTanHalfFov, createCinematicLensPass } from './cinematic-lens.js';
import { resolveTorchFrame, resolveRecorderLamp, normalizeTorchOptics, TORCH_OPTICS_GLSL } from './torch-optics.js';
import { worldLightTreatmentFrame, fineMarkFootprint, WORLD_LIGHT_TREATMENT_GLSL } from './world-light-treatment.js';
import { FIRE_ESCAPE_INK_GLSL } from './fire-escape-ink.js';
import { MISSING_MAN_MATERIAL_GLSL, MISSING_MAN_CORE_BYTE, MISSING_MAN_SMOKE_BYTE } from './missing-man-material.js';
import { ROOF_SURFACE_INK_GLSL, ROOF_GLASS_INK_GLSL } from './roof-surface-ink.js';
import { PRINTED_SURFACE_GLSL } from './printed-surface.js';
import { ST_BRENDANS_STONE_GLSL } from './st-brendans-surface.js';
import { createSourceSurfaceLetteringBaker } from './source-surface-lettering.js';
import { isScreen, screenUniforms } from './pixel-mesh/screens.js';
import {screenForWorld,targetSourceDither,advanceSourceDither} from './source-dither-routing.js';
import { MARK_FIELD_SIZE, MARK_FIELD_SOURCE, deriveMarkField } from './mark-field.js';
import { FRONT_END_GRADE, NEUTRAL_GRADE, getLookProfile } from './look-profiles.js';
import { LIGHT_KIND } from '../data/conservatory-lights.js';
import { visualEffectsEnabled } from '../game/access.js';
import { PAPER_ATLAS } from '../generated/paper-catalog.js';
import { PAPER_PIGMENT_PATH } from '../data/paper-pigment.js';
import { PAPER_WORLD_MATERIAL } from '../data/paper-world-material.js';
import { hushPoseAt, isHushBodyCue } from './hush-pose.js';
import { pressureInstances, pressureSurfaceInstances, pressureRoomAbsorptionStrength } from './pressure-volume.js';
import { createOutcomeExposureController, sampleOutcomeExposure } from './outcome-exposure.js';
import { PRESSURE_FINISH_FRAG, PRESSURE_SCENE_GLSL, PRESSURE_IDENTITY_GLSL, PRESSURE_INK_GLSL } from './pressure-composite.js';

const MAX_CHUNKS = 48;
const b3GlassMoment = createB3GlassMoment();
let b3VisibilityCache=null;
let b3GlassDiagnostic={active:false,gain:0};
export function r3dStudioB3GlassStatus(){return {...b3GlassDiagnostic,moment:b3GlassMoment.snapshot()};}
const RD_SIZE = 256;
const WATER_W = 96;
const WATER_H = 54;
// A fountain alone makes five (four falls and the jet), plus drips and a wake.
const MAX_WATER_SOURCES = 8;
// Eight authored practical slots plus three apparition emitters. Keeping the
// white bodies inside the same lighting path makes their spill hit architecture
// and props identically instead of faking a screen-space halo.
const MAX_LOCAL_LIGHTS = 12;
let RENDER_SCALE = 1;
// Optional backing-pixel density for the world canvas. The UI remains at the
// native device density; null follows the display's current devicePixelRatio.
let outputPixelRatioOverride = null;
let outputPixelRatioApplied = null;
let localLightCount=0;
const localLightPositions=new Float32Array(MAX_LOCAL_LIGHTS*4);
const localLightColors=new Float32Array(MAX_LOCAL_LIGHTS*4);
const localLightBaseIntensity=new Float32Array(MAX_LOCAL_LIGHTS);
const localLightMunicipal=new Float32Array(MAX_LOCAL_LIGHTS);
const localLightPenetrations=new Float32Array(MAX_LOCAL_LIGHTS);
const localLightEmergency=new Float32Array(MAX_LOCAL_LIGHTS);
const localLightDirections=new Float32Array(MAX_LOCAL_LIGHTS*4);
const localLightConeInner=new Float32Array(MAX_LOCAL_LIGHTS).fill(1);
let localShadowIndex=-1;
let localShadowLight=null;
let lightingAmbientColor=new Float32Array([.64,.65,.62]);
let lightingAmbientIntensity=.022;
let renderedTorchDiagnostic=null;
// The room's floor-bounce, and the live dial for it (see __probe.bounce). 0 is
// the flat-ambient behaviour that shipped, which is the A/B for black ceilings.
let lightingBounceColor=new Float32Array([.64,.65,.62]);
let lightingBounceIntensity=0;
let bounceAmount=1;
let printedSurfaceMode=3;
export function r3dSetPrintedSurfaceMode(mode=3){printedSurfaceMode=Math.max(0,Math.min(5,Math.floor(Number(mode)||0)));return printedSurfaceMode;}
let worldLightTreatment=worldLightTreatmentFrame();
export function r3dSetWorldLightTreatment(mode='complete'){worldLightTreatment=worldLightTreatmentFrame(mode);return {...worldLightTreatment};}
let bounceLampGain=2.4;
// The weather's gain. 1 is as authored; 0 turns it off, which is the A/B for
// "is the rain drawn at all, or drawn and then lost in the one-bit encode".
let rainAmount=1;
// Weather forced into a space with no sky. 0 everywhere except the source hall.
let indoorRain=0;
const RAIN_CLEAR_OF_THE_CAB=2.1;let rainClearMetres=0;
// Temporary ending light. 0 is the authored 21:30 night; positive profiles are
// cutscene-only and are cleared before the institutional coda.
let endingWorldLook=0;
let municipalLightPower=1;
// Scales the look profile's white point to the room actually being stood in. 1
// is "use the profile as authored"; a dim interior asks for a fraction of it.
let lightingWhitePointScale=1;
// The physical recorder's acquisition also needs the room's exposure. It is
// independent of VFD levels(), which full recording capture replaces.
let lightingCaptureExposure=1;
// Roof-only recovery of the far-depth sky/city after the one-bit acquisition.
// This never changes the captured geometry or the global explore profile.
let lightingRoofSkyRecovery=0;
let lightingAcademicAtriumLight=false;
let captureExposureOverride=null;
// The taste dial for the above, so the ceiling can be A/B'd live without a
// rebuild. 1 = the authored scale, 0 = the flat profile white point this shipped
// with, which is the before-picture for the whole tone-floor fix.
let whitePointZoneAmount=1;
// Set by the sweep dial only; null means the zone decides.
let whitePointScaleOverride=null;
// Which screen the room asks for, and the dial that overrules it. Both null mean
// the look profile decides, which is the ordinary case.
let lightingScreenId=null;
let screenOverrideId=null;
let sourceDitherMix=0;
let windowGeometryMotion=false;
let windowGeometryResizePending=false;
const HUSH_AMBIENT_COLOR=new Float32Array([.26,.76,.54]);
// A recovered room must be identifiable without looking healthy. This neutral,
// low exposure is Source's reconstruction light: enough architectural value to
// read the room and its props, never enough to resemble the live night's grade.
const SOURCE_REPRISE_AMBIENT_COLOR=new Float32Array([.60,.67,.65]);

export function r3dSetRenderScale(value = 1) {
  const next = Math.max(0.5, Math.min(1, Number(value) || 1));
  if (Math.abs(next - RENDER_SCALE) < 0.001) return RENDER_SCALE;
  RENDER_SCALE = next;
  if (canvas && gl) resize();
  return RENDER_SCALE;
}

export function r3dRenderScale() { return RENDER_SCALE; }

export function r3dOutputPixelRatio(){return outputPixelRatioOverride;}
export function r3dEffectiveOutputPixelRatio(){
  const native=Number(globalThis.devicePixelRatio);
  return outputPixelRatioOverride ?? (Number.isFinite(native)&&native>0?native:1);
}
export function r3dSetOutputPixelRatio(value=null){
  const numeric=Number(value);
  // Do not turn malformed or non-positive input into a surprising reset.
  if(value!==null&&(!Number.isFinite(numeric)||numeric<=0))return outputPixelRatioOverride;
  outputPixelRatioOverride=value===null?null:Math.max(.375,Math.min(4,numeric));
  // A display move can change native DPR while the configured value stays
  // null. Compare with what was actually allocated, not just the old setting.
  const next=r3dEffectiveOutputPixelRatio();
  if(canvas&&gl&&(outputPixelRatioApplied==null||Math.abs(next-outputPixelRatioApplied)>1e-6))resize();
  return outputPixelRatioOverride;
}
const FOG_TEX = 128;

const BIOME_RGB = {
  drone:     [0.33, 0.47, 0.40],
  shimmer:   [0.63, 0.63, 0.70],
  noise:     [0.53, 0.47, 0.40],
  pulse:     [0.47, 0.53, 0.47],
  resonance: [0.40, 0.53, 0.53],
};
// Zone → tint, indexed by the ZONE ids in data/floorplan/legend.js. This array
// is POSITIONAL and must cover every zone: it stopped at 13 (academic) while the
// enum had already grown to danceStudio and store, so those two sampled off the
// end of a GLSL array — undefined, and in practice whatever 13 held.
const ZONE_TINTS = new Float32Array([
  0.60, 0.60, 0.58,   // none
  0.46, 0.56, 0.74,   // loading bay: wet tarmac under a cold overcast
  0.72, 0.68, 0.62,   // foyer
  0.67, 0.74, 0.63,   // studio B3
  0.57, 0.69, 0.80,   // natatorium
  0.79, 0.66, 0.90,   // concert hall
  0.88, 0.73, 0.52,   // practice wing
  0.88, 0.92, 1.00,   // chapel
  0.55, 0.52, 0.48,   // plant room
  0.58, 0.58, 0.60,   // stairs
  0.10, 0.92, 0.24,   // source-space: executable green against the void
  0.72, 0.75, 0.78,   // outer chapel: colder, lower stone
  0.73, 0.61, 0.42,   // bell tower: timber, bronze and dust
  0.67, 0.70, 0.64,   // academic: cold plaster, oxidised metal, dead planting
  0.74, 0.70, 0.60,   // dance wing: sprung maple and mirror
  0.52, 0.50, 0.47,   // prop store: a ceiling you can touch
  0.62, 0.60, 0.55,   // the get-in: sodium and rust, as the old dock room was
  0.43, 0.49, 0.60,   // inhabited street: wet carriageway under town light
  0.58, 0.56, 0.52,   // civic pavement: pale flags darkened by rain
  0.36, 0.39, 0.43,   // service courts: old setts and patched channels
  0.78, 0.80, 0.84,   // st brendan's: limewashed stone, colder than Ellery's chapel
  0.64, 0.77, 0.80,   // roof: wet zinc and supported glass under the same city sky
  0.86, 0.73, 0.54,   // the occupied pub: timber, gilt and ordinary warm practicals
  0.78, 0.75, 0.66,   // the stationer's: paper stock and ordinary task lighting
  0.62, 0.75, 0.59,   // glasshouse: leaves, glazed iron and maintained growing lamps
  0.70, 0.76, 0.71,   // baths changing lobby: old mineral tile and dry painted plaster
]);

const WORLD_RGB = {
  main_b3:         [0.67, 0.74, 0.63],
  the_tub:         [0.57, 0.69, 0.80],
  amplifications:  [0.79, 0.66, 0.90],
  soundnoisemusic: [0.88, 0.73, 0.52],
  lux_nova:        [0.88, 0.92, 1.00],
  st_brendans:      [0.78, 0.82, 0.90],
};

const COMMON_GLSL = `#version 300 es
precision highp float;
precision highp sampler2DArray;
`;

const VERT = COMMON_GLSL + `
void main(){
  vec2 p = vec2((gl_VertexID<<1 & 2), (gl_VertexID & 2));
  gl_Position = vec4(p*2.0-1.0, 0.0, 1.0);
}`;

// ── Gray-Scott reaction-diffusion (ping-pong) ────────────────────────────────
const RD_FRAG = COMMON_GLSL + `
uniform sampler2D uPrev;
uniform float uFeed, uKill;
out vec4 o;
void main(){
  ivec2 q = ivec2(gl_FragCoord.xy);
  ivec2 sz = textureSize(uPrev, 0);
  vec2 c = texelFetch(uPrev, q, 0).rg;
  vec2 lap = -c;
  lap += 0.2 * (texelFetch(uPrev, (q+ivec2( 1, 0)+sz)%sz, 0).rg
              + texelFetch(uPrev, (q+ivec2(-1, 0)+sz)%sz, 0).rg
              + texelFetch(uPrev, (q+ivec2( 0, 1)+sz)%sz, 0).rg
              + texelFetch(uPrev, (q+ivec2( 0,-1)+sz)%sz, 0).rg);
  lap += 0.05 * (texelFetch(uPrev, (q+ivec2( 1, 1)+sz)%sz, 0).rg
               + texelFetch(uPrev, (q+ivec2(-1, 1)+sz)%sz, 0).rg
               + texelFetch(uPrev, (q+ivec2( 1,-1)+sz)%sz, 0).rg
               + texelFetch(uPrev, (q+ivec2(-1,-1)+sz)%sz, 0).rg);
  float A = c.r, B = c.g;
  float r = A * B * B;
  const float DT = 0.85;
  A += (1.0*lap.r - r + uFeed*(1.0-A)) * DT;
  B += (0.5*lap.g + r - (uKill+uFeed)*B) * DT;
  o = vec4(clamp(A,0.0,1.0), clamp(B,0.0,1.0), 0.0, 1.0);
}`;

const WATER_FRAG = COMMON_GLSL + `
uniform sampler2D uPrev;
uniform vec2 uTexel;
uniform float uDt;
uniform float uDamping;
uniform float uReduceMotion;
uniform int uSourceCount;
uniform vec4 uSources[${MAX_WATER_SOURCES}]; // u, v, strength, radius
uniform float uRainDrops;  // 0 indoors; the weather's rain amount outdoors
uniform float uRainSeed;   // advances every step so no texel is struck twice in a row
out vec4 o;
void main(){
  vec2 uv=gl_FragCoord.xy*uTexel;
  vec4 p=texture(uPrev,uv);
  float cur=p.r-.5;
  float prev=p.g-.5;
  float l=texture(uPrev,uv-vec2(uTexel.x,0.0)).r-.5;
  float r=texture(uPrev,uv+vec2(uTexel.x,0.0)).r-.5;
  float d=texture(uPrev,uv-vec2(0.0,uTexel.y)).r-.5;
  float u=texture(uPrev,uv+vec2(0.0,uTexel.y)).r-.5;
  float lap=(l+r+d+u-cur*4.0);
  float motion=mix(1.0,.18,clamp(uReduceMotion,0.0,1.0));
  float next=cur+(cur-prev)*uDamping*motion+lap*(0.42*uDt)*motion;
  for(int i=0;i<${MAX_WATER_SOURCES};i++){
    if(i>=uSourceCount)break;
    vec4 s=uSources[i];
    float dist=length((uv-s.xy)/max(vec2(.001),vec2(s.w)));
    next+=exp(-dist*dist*3.2)*s.z*motion;
  }
  // Rain: sparse strikes, each a dent three texels across that the wave
  // equation turns into its own ring. A single-texel strike only fed the
  // grid's odd/even mode and read as grit.
  if(uRainDrops>0.0){
    vec2 cellQ=floor(gl_FragCoord.xy/3.0);
    float h=fract(sin(dot(cellQ,vec2(12.9898,78.233))+uRainSeed*.6180339)*43758.5453);
    if(h<uRainDrops*.0035){
      vec2 centre=cellQ*3.0+1.5;
      float r=length(gl_FragCoord.xy-centre);
      next-=.075*exp(-r*r*.55)*motion;
    }
  }
  float edge=min(min(uv.x,1.0-uv.x),min(uv.y,1.0-uv.y));
  next*=smoothstep(0.0,0.08,edge);
  next=clamp(next,-.48,.48);
  o=vec4(next+.5,cur+.5,0.0,1.0);
}`;

// ── World raymarcher ──────────────────────────────────────────────────────────
// Shelter planes and airborne drops share the runtime cell coordinate frame.
const RAIN_GLSL = GLASS_COURT_RAIN_GLSL+OUTSKIRTS_BUS_RAIN_GLSL+RAIN_FIELD_GLSL;

export const MARCH_FRAG = COMMON_GLSL + TORCH_OPTICS_GLSL + WORLD_LIGHT_TREATMENT_GLSL + STILLNESS_FACES_GLSL + STILLNESS_RELIEF_PROXY_GLSL + NATATORIUM_METRIC_GLSL + `
uniform vec2  uRes;
uniform float uTime;
uniform vec3  uCam;          // eye (x, height, z=world y)
uniform float uYaw;
uniform float uPitch;
uniform float uCameraTanHalfFov;
uniform vec2  uTile;         // WORLD_TILE_W/H
uniform float uWorldCount;
uniform vec3  uWorldTint[5];
uniform sampler2D uRD;
uniform sampler2D uFogTex;
uniform vec2  uFogOrigin;
uniform float uAudio;        // 0..1 field energy
uniform float uLight;        // 0 = flashlight off, 1 = on
uniform vec3 uTorchColor;
uniform vec3 uTorchOrigin,uTorchForward,uTorchRight,uTorchUp;
uniform float uTorchReach;
uniform vec2 uTorchCone;
uniform float uTorchSpill;
uniform float uTorchShoulder;
uniform vec3 uAmbientColor;
uniform float uAmbientIntensity;
// How much ambient survives at distance, 0..1. Tunable live rather than
// authored, because how dark the far end of an unlit corridor should be is a
// judgement nobody can make from the source (see __probe.ambientFloor).
uniform float uAmbientFloor;
// THE BOUNCE. Light that has already hit the floor and come back up.
//
// Ambient is uniform over the sphere, so a ceiling gets exactly what a floor
// gets, and in this building that is nothing: measured raw against a black point
// at byte 1.3, the get-in's ceiling sits at 1.47 unlit and only reaches 2.45 with
// the torch ON, because the torch is a forward cone from eye height and the one
// fitting hangs at 2.1m under a 5.5m ceiling. Walls reach 11.4 in the same frame.
// So ceilings are not merely dark, they are the ONE surface no light source in
// the room can address, which is why they read as pure black everywhere.
//
// This is the return trip, weighted onto downward-facing normals and gained by
// the torch, so lighting the floor lights the ceiling above it the way it should
// have all along.
uniform vec3 uBounceColor;
uniform float uBounceIntensity;
uniform float uBounceLampGain;
// The weather's own gain, so "is it drawn at all" is answerable without a
// rebuild (see __probe.rain). 0 is no weather; 1 is as authored.
uniform float uRainAmount;
// WEATHER WHERE THERE IS NO SKY.
//
// Rain is gated on the eye standing in a cell flagged FLAG_SKY, which is right
// for the building and means the procedural spaces (uUsePlan < .5) can never
// have any. The source corridor wants exactly that and for exactly the wrong
// reason: it is not outside, it is not even a room, and the rain coming through
// it anyway is the point. Driven from the hall's own depth — see
// tickSourceSpace.
uniform float uRainIndoor;
// Strength of the baked per-cell ambient, 0..1. 0 is the old flat per-zone
// constant, which makes this the A/B (see __probe.ambientPlace).
uniform float uAmbientPlace;
uniform float uHushSense;
uniform float uOpticalEffects;
uniform float uReduceMotionOptical;
uniform float uDockHauntingFade;
uniform vec3 uElleryCaughtPrint;
// One number per run, so the night is the same night for its whole length and a
// different one next time. Drives the moon: where it sits, how full it is, and
// once in a while how close.
uniform float uNightSeed;
uniform float uEndingWorldLook;
// The occupied academic roof can see over the local terraces. Other exterior
// cells keep the original street-level skyline from the same nightSky().
uniform float uRoofView;
uniform float uGalleryTreatment;
${ACADEMIC_ATRIUM_LIGHT_GLSL}
uniform int uLocalLightCount;
uniform int uLocalShadowIndex;
uniform vec4 uLocalLightPos[${MAX_LOCAL_LIGHTS}];
uniform vec4 uLocalLightColor[${MAX_LOCAL_LIGHTS}];
uniform float uLocalLightPenetration[${MAX_LOCAL_LIGHTS}];
// 1 for a practical on the emergency circuit. Red is that circuit's word, and
// this is how the lighting pass tells the shading pass who is allowed to use it.
uniform float uLocalLightEmergency[${MAX_LOCAL_LIGHTS}];
${LOCAL_LIGHT_CONE_GLSL}
uniform int   uChunkCount;
uniform float uChunkGlowReady;
uniform vec4  uChunkA[${MAX_CHUNKS}]; // x, z, radius, activity
uniform vec3  uChunkC[${MAX_CHUNKS}]; // biome rgb
uniform vec4  uKey;          // x, z, active, -
uniform vec4  uDoor;
uniform vec4  uHush;         // x, z, absorption strength, radius in metres
uniform float uPressureGeometryReady;
uniform sampler2D uPlan;     // the authored building: R=floor G=ceil B=flags A=zone
uniform sampler2D uMat;      // R=material id
uniform sampler2D uSourceLayer; // R=source corpus layer for this runtime cell
// Source's corpus and the physical HUSH geometry are mutually exclusive.
// Share the sampler declaration as well as texture unit 13: two sampler
// uniforms on one unit still exceed D3D11's sixteen-sampler link budget.
uniform sampler2D uSourceSurface;
uniform sampler2D uPropColor;
uniform sampler2D uPropDepth;
uniform float uLitApparitions;
uniform sampler2D uPropShadow;
uniform mat4 uPropShadowMatrix;
uniform float uPropShadowReady;
uniform vec2 uPropShadowTexel;
uniform sampler2D uWaterHeight;
uniform sampler2DArray uSurfAlbedo, uSurfNormal, uSurfMaterial; // PBR: albedo, normal, and (R roughness, G relief)
// The engraving derived from each generated tile (render/mark-field.js). ONE
// array, not the live/staged pair the dream layer uses: this pass has exactly
// one spare texture unit and no more, so the staged bank's marks are folded in
// behind the live ones at a fixed offset.
uniform sampler2DArray uSurfMarks;
// The marks array uses a FIXED per-slot stride so one allocation serves any
// bank, while the dream array packs at that bank's own frame count. The two
// layer indices are therefore NOT interchangeable and are computed apart.
uniform float uMarkStride;        // layers per slot in the marks array
uniform float uMarksLiveBase;     // first layer of the live half
uniform float uMarksStageBase;    // ...and of the staged half
uniform float uMarksReady[10];    // per slot: 1 once every frame of its boil is engraved
uniform float uMarksReadyNext[10];
uniform sampler2DArray uSurfDream, uSurfDreamNext;             // current + staged generated albedo
uniform float uDreamMix[10];
uniform float uDreamReady;
uniform float uDreamNextReady;
uniform float uDreamBankBlend;
uniform float uDreamDetailGain;
uniform float uDreamChromaDrift;
uniform float uDreamFramesA;      // temporal boil frames resident in the live bank
uniform float uDreamFramesB;      // ...and in the staged one
uniform float uBoilHz;            // crossfade rate between them, before agitation
uniform float uDreamStructureMix; // how much generated RGB, not just its grain
uniform float uDreamLumaLo;
uniform float uDreamLumaHi;
uniform float uDreamLumaHold;     // how hard authored exposure is enforced
uniform float uAgitation;         // fear + onset: how hard the world is boiling
float gBoilGlow=0.0;              // self-lit churn, written by surfaceTile
// The engraving of whatever surface this fragment landed on. R density, GB the
// coherence-weighted doubled-angle grain, A coherence.
//
// R == 0 IS THE SENTINEL for "no engraving here": real material always carries
// some local contrast, so zero cannot occur naturally. It means sky, or a slot
// whose tiles are not derived yet, and the recorder falls back to its
// procedural hash there — exactly the behaviour that shipped before this.
vec4 gMark=vec4(0.0);
float gMarkBlend=0.0;
// WHICH PLANE THE GRAIN LIES IN. The tile UV is axis-aligned (see surfaceUv), so
// the surface tangent basis is one of exactly three, and naming it is all the
// recorder needs to lift a 2D tile-space line field into world space. Written
// beside gMark by architecturalSurface, which is the only place that knows both
// the surface kind and the normal.
//   0.0 = XZ (floor, ceiling): u=X v=Z
//   0.5 = ZY (wall facing X):  u=Z v=Y
//   1.0 = XY (wall facing Z):  u=X v=Y
float gMarkPlane=0.0;
uniform float uDreamRoughnessResponse;
uniform float uDreamNormalResponse;
uniform float uLocalDiffusion;
uniform float uSurfacesReady;
// Accepted work-order takes progressively replace photographed material with
// the generated surface itself. These are multipliers on the current look, so
// zero takes is bit-for-bit the authored profile that was already active.
uniform float uPropsReady;
uniform float uPropNear;
uniform float uPropFar;
uniform vec4 uSourceShoreAperture; // centre x, plane z, width, height (metres)
uniform vec2 uSourceShoreApertureState; // floor metres, room-side enabled
uniform vec2  uPlanSize;
uniform vec2  uPlanOrigin;
uniform float uPlanHeightOffset;
uniform vec4 uPlanExteriorPortal;
uniform vec3 uPlanExteriorPortalHeight;
uniform float uUsePlan;      // 0 = procedural sample-field lattice, 1 = the conservatory
uniform vec3  uZoneTint[${Math.max(...Object.values(ZONE))+1}];
uniform float uSourceReady;
uniform vec4  uWaterBounds;  // min x, min z, max x, max z in runtime cells
uniform vec4  uWaterParams;  // active, level metres, murk, reduce motion
uniform vec4  uWaterCamera;  // submerged, depth metres, soaked, reserved
layout(location=0) out vec4 o;
// The engraving leaves on a second target; see the write at the end of main.
layout(location=1) out vec4 oMark;

// Height encoding must match world/floorplan.js exactly.
const float H_MIN = -8.0;
const float H_RANGE = 32.0;
const float CELL_METERS = ${CELL.toFixed(6)};
vec3 metricCellRayPoint(vec3 ro,vec3 rd,float t){
  return natatoriumMetricRayPoint(ro*CELL_METERS,rd,t*CELL_METERS)/CELL_METERS;
}
float metricNextZ(ivec2 cell,ivec2 stp,vec3 ro,vec3 rd){
  if(abs(rd.z)<.000001)return 1e30;
  float boundary=(float(cell.y)+max(float(stp.y),0.0))*CELL_METERS;
  return (natatoriumMetricZ(boundary)-natatoriumMetricZ(ro.z*CELL_METERS))/(CELL_METERS*rd.z);
}
vec3 metricCellOffset(vec3 ro,vec3 rd,float t){return metricCellRayPoint(ro,rd,t);}

const float PROC_CEIL = ${ (3.2 / CELL).toFixed(6) };
const int FLAG_SOLID   = 1;
const int FLAG_DOOR    = 2;
const int FLAG_SKY     = 4;
const int FLAG_BRICKED = 32;
const int FLAG_CLOSED  = 64;
const int FLAG_WALLED  = 128;
const int MAT_SERVICE = ${MATERIAL.serviceConcrete};
const int MAT_ACOUSTIC = ${MATERIAL.acousticFoam};
const int MAT_POOL = ${MATERIAL.poolTile};
const int MAT_WET = ${MATERIAL.wetTile};
const int MAT_WOOD = ${MATERIAL.woodVelvet};
const int MAT_PRACTICE = ${MATERIAL.practiceFoam};
const int MAT_CHAPEL = ${MATERIAL.chapelStone};
const int MAT_METAL = ${MATERIAL.metalPlant};
const int MAT_DOOR = ${MATERIAL.doorGlassDuct};
const int MAT_SOURCE_FIELD = ${MATERIAL.sourceField};
const int MAT_SOURCE_PATH = ${MATERIAL.sourcePath};
const int MAT_SOURCE_PAGE = ${MATERIAL.sourcePage};
const int MAT_SOURCE_FAULT = ${MATERIAL.sourceFault};
const int MAT_ACADEMIC = ${MATERIAL.academicPlaster};
const int MAT_TARMAC = ${MATERIAL.wetTarmac};
const int MAT_PAVING = ${MATERIAL.wetPaving};
const int MAT_SETTS = ${MATERIAL.wetSetts};
const int MAT_GRASS = ${MATERIAL.wetGrass};
const int MAT_SOURCE_VOID = ${MATERIAL.sourceVoid};
const int MAT_ROOF_GLASS = ${MATERIAL.roofGlass};

bool isRainGroundMat(int mat){return mat==MAT_TARMAC||mat==MAT_PAVING||mat==MAT_SETTS||mat==MAT_GRASS;}

bool waterActive(){ return uWaterParams.x > 0.5 && uUsePlan > 0.5; }
bool inWaterBounds(vec2 p){
  return waterActive()
    && p.x >= uWaterBounds.x && p.x < uWaterBounds.z
    && p.y >= uWaterBounds.y && p.y < uWaterBounds.w;
}
vec2 waterUv(vec2 p){
  return clamp((p - uWaterBounds.xy) / max(vec2(0.001), uWaterBounds.zw - uWaterBounds.xy), vec2(0.0), vec2(1.0));
}
float waterHeightAt(vec2 p){
  if(!inWaterBounds(p)) return 0.0;
  if(uWaterParams.w > 0.5) return 0.0;
  float h = texture(uWaterHeight, waterUv(p)).r - 0.5;
  return h * 0.20;
}
float waterEdge(vec2 p){
  if(!inWaterBounds(p)) return 0.0;
  vec2 uv=waterUv(p);
  float d=min(min(uv.x,1.0-uv.x),min(uv.y,1.0-uv.y));
  return 1.0-smoothstep(0.012,0.090,d);
}

float hash01(float x, float y){ return fract(abs(sin(x*127.1 + y*311.7) * 43758.5)); }
float noise2(vec2 p, float s, float seed){
  vec2 q = (p + vec2(seed, seed*1.3)) * s;
  return 0.5*sin(q.x*1.7 + cos(q.y*2.3)) + 0.5*cos(q.y*1.1 + sin(q.x*1.9));
}
// REAL VALUE NOISE, because noise2 above is not noise.
//
// noise2 is a sum of two sines — a smooth, strictly PERIODIC plaid. That is
// fine for the wobble it was written for (worldIdx, the moon's maria, the
// valley), but stacking four octaves of it and thresholding gives a regular
// lattice of blobs, and a one-bit dither turns a regular lattice of blobs into
// a regular lattice of DOTS. That is what the sky's cloud deck has been: not
// weather, fireflies.
//
// Same signature and same [-1,1] range, so it drops straight into the
// 0.5 + 0.5 * n() the sky already wraps every octave in.
float vnoise(vec2 p, float s, float seed){
  vec2 q = (p + vec2(seed, seed * 1.3)) * s;
  vec2 i = floor(q), f = q - i;
  vec2 u = f * f * (3.0 - 2.0 * f);          // smoothstep fade, C1 at the lattice
  float a = hash01(i.x,       i.y      );
  float b = hash01(i.x + 1.0, i.y      );
  float c = hash01(i.x,       i.y + 1.0);
  float d = hash01(i.x + 1.0, i.y + 1.0);
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y) * 2.0 - 1.0;
}

// Integer hash — bit-identical to the JS mirror in this file (collision must
// agree exactly with what is drawn; float noise diverges between GLSL f32 and
// JS f64, so anything that decides solidity uses uint math only).
uint ihash(uint a){ a ^= a>>16; a *= 0x7feb352du; a ^= a>>15; a *= 0x846ca68bu; a ^= a>>16; return a; }
uint ihash2(int x, int y){ return ihash((uint(x)*1597334677u) ^ (uint(y)*2891336453u)); }

// ── Architecture ─────────────────────────────────────────────────────────────
// Floor: flat plane at y=0. Ceiling: flat plane at CEIL. Walls: full-height
// vertical slabs. Layout: a lattice of LANE-wide corridors on a BLOCK pitch —
// connected by construction, since every lane meets every crossing lane — with
// the interiors between them either open rooms or solid mass. Macro-zones of
// 3x3 blocks open entirely into unroofed EXPANSES.
const float CEIL = PROC_CEIL;
const int BLOCK = ${6 * PLAN_SCALE};   // corridor pitch (runtime cells)
const int LANE  = ${2 * PLAN_SCALE};   // corridor width (runtime cells)

bool isExpanse(int cx, int cz){
  int mx = int(floor(float(cx)/float(BLOCK*3)));
  int mz = int(floor(float(cz)/float(BLOCK*3)));
  return ihash2(mx+404, mz+909) % 100u < 22u;
}
bool solidCell(vec2 p){
  int cx = int(floor(p.x)), cz = int(floor(p.y));
  if(isExpanse(cx, cz)) return false;
  int bx = int(floor(float(cx)/float(BLOCK))), bz = int(floor(float(cz)/float(BLOCK)));
  int lx = cx - bx*BLOCK, lz = cz - bz*BLOCK;
  if(lx < LANE || lz < LANE) return false;      // corridor lane: always walkable
  if(ihash2(bx, bz) % 10u < 4u) return false;   // 40% of blocks are open rooms
  vec2 cc = vec2(float(cx)+0.5, float(cz)+0.5); // never entomb the key or exit
  if(uKey.z>0.5  && dot(cc-uKey.xy,  cc-uKey.xy)  < 4.0) return false;
  if(uDoor.z>0.5 && dot(cc-uDoor.xy, cc-uDoor.xy) < 4.0) return false;
  return true;
}
bool hasCeiling(vec2 p){ return !isExpanse(int(floor(p.x)), int(floor(p.y))); }

// A cell of the world. In story mode it is read from the authored floorplan
// texture — the SAME array JS collision reads, so the drawn wall and the solid
// wall cannot disagree. Developer sample-field labs use the procedural lattice.
struct Cell { bool solid; float f; float c; int flags; int zone; int mat; float place; };

// THE SHAPE OF A CELL, WITHOUT ITS MATERIAL.
//
// The march crosses up to 192 cells per pixel and tests only shape on the way:
// solid, floor, ceiling, flags, zone. The material is a second texture read, and
// only the cell the ray stops in ever needs it, so the traversal reads shape here
// and cellMaterialAtI reads the material once, after the loop. Same values as
// before; half the reads in the yard, where most rays cross the whole plan.
Cell cellShapeAtI(ivec2 p, bool enterBorrowedInterior){
  Cell r;
  r.flags = 0; r.zone = 0; r.mat = MAT_SERVICE; r.place = 1.0;
  if(uUsePlan < 0.5){
    r.solid = solidCell(vec2(p) + 0.5);
    r.f = 0.0;
    r.c = hasCeiling(vec2(p) + 0.5) ? CEIL : 90.0;
    return r;
  }
  ivec2 local = p - ivec2(uPlanOrigin);
  if(local.x < 0 || local.y < 0 || local.x >= int(uPlanSize.x) || local.y >= int(uPlanSize.y)){
    // PAST THE EDGE OF THE BUILDING THERE IS WEATHER, NOT ROCK.
    //
    // This slice is the whole physical extent, never a moving window (see
    // physicalRenderPlanFor), so a ray only gets here by leaving the building's
    // entire footprint — and every cell on the footprint's rim is an authored
    // wall, so from indoors nothing reaches this at all. It used to return
    // solid, which was invisible for as long as the only way out was a bricked
    // lift shaft. The loading bay opens west across the yard to this edge, and
    // solid made it a black cliff fifty metres out.
    //
    // Open, no floor to land on, and flagged sky: the march runs out at MAXD
    // and the ray resolves as sky.
    r.solid = false; r.f = -1000.0; r.c = 90.0 / CELL_METERS; r.flags = FLAG_SKY;
    return r;
  }
  vec4 t = texelFetch(uPlan, local, 0);
  int zoneByte = int(t.a * 255.0 + 0.5);
  bool borrowed = (zoneByte & ${BORROWED_INTERIOR_ZONE_BIT}) != 0;
  if(borrowed && !enterBorrowedInterior){
    // The exterior mesh owns this envelope. The restored interior cannot
    // cast an opaque silhouette outside its aperture.
    r.solid = false; r.f = -8.0 / CELL_METERS; r.c = 90.0 / CELL_METERS;
    r.flags = FLAG_SKY; r.zone = ${ZONE.street};
    return r;
  }
  r.flags = int(t.b * 255.0 + 0.5);
  r.solid = (r.flags & FLAG_SOLID) != 0;
  r.f = (t.r * H_RANGE + H_MIN + uPlanHeightOffset) / CELL_METERS;
  r.c = (t.g * H_RANGE + H_MIN + uPlanHeightOffset) / CELL_METERS;
  r.zone = zoneByte & ${BORROWED_INTERIOR_ZONE_BIT-1};
  // A sky cell has no ceiling to stop the ray, so its ceiling is pushed out of
  // reach. The number is only ever read by the wall test below (the ceiling and
  // header tests are both gated on FLAG_SKY), which means it is also the height
  // anything solid beside a sky cell is drawn to — ninety metres of black slab.
  //
  // That is correct out in the yard, where nothing solid stands near enough to
  // read, and inside the lift shaft, which wants to look bottomless. It is wrong
  // in a bay with walls on three sides. FLAG_WALLED is the opt-out: the ray still
  // leaves, and the walls stand at the height the glyph authored.
  if((r.flags & FLAG_SKY) != 0 && (r.flags & FLAG_WALLED) == 0) r.c = 90.0 / CELL_METERS;
  return r;
}
Cell cellShapeAtI(ivec2 p){return cellShapeAtI(p, true);}

bool rayEntersBorrowedInterior(vec3 ro, vec3 rd){
  if(uPlanExteriorPortalHeight.z < .5) return true;
  bool axisX = uPlanExteriorPortal.x > .5;
  float speed = axisX ? rd.x : rd.z;
  if(abs(speed) < 1e-5) return false;
  float travel = (uPlanExteriorPortal.y / CELL_METERS - (axisX ? ro.x : ro.z)) / speed;
  if(travel <= 0.0) return false;
  vec3 p = (ro + travel * rd) * CELL_METERS;
  float along = axisX ? p.z : p.x;
  return along >= uPlanExteriorPortal.z && along <= uPlanExteriorPortal.w
    && p.y >= uPlanExteriorPortalHeight.x && p.y <= uPlanExteriorPortalHeight.y;
}
// Off the plan, and in the procedural lab, a cell is service material at neutral
// place — the defaults cellShapeAtI already set.
void cellMaterialAtI(ivec2 p, inout Cell r){
  if(uUsePlan < 0.5) return;
  ivec2 local = p - ivec2(uPlanOrigin);
  if(local.x < 0 || local.y < 0 || local.x >= int(uPlanSize.x) || local.y >= int(uPlanSize.y)) return;
  vec2 ma = texelFetch(uMat, local, 0).rg;
  r.mat = int(ma.r * 255.0 + 0.5);
  // G is the baked per-cell ambient multiplier: how much spill this PLACE gets,
  // from its distance to an opening and how enclosed it is. AMBIENT_PLACE_SCALE
  // in world/floorplan.js is the encode; 128 is neutral 1.0.
  r.place = ma.g * ${AMBIENT_PLACE_SCALE.toFixed(1)};
  if(r.mat == 0) r.mat = MAT_SERVICE;
}
// Only the water test needs a material mid-march, and only inside the basin.
bool cellIsWet(ivec2 p, Cell c){
  cellMaterialAtI(p, c);
  return c.mat == MAT_WET;
}
// The open-ground square r3dSetPlan baked into B and A: its radius around this
// cell, and the highest floor in it, decoded exactly as cellShapeAtI decodes a
// floor. In the lab there is no promise; off the plan the answer is -1.
int cellOpenRadiusI(ivec2 p, out float floorMax){
  floorMax = 0.0;
  if(uUsePlan < 0.5) return 0;
  ivec2 local = p - ivec2(uPlanOrigin);
  if(local.x < 0 || local.y < 0 || local.x >= int(uPlanSize.x) || local.y >= int(uPlanSize.y)) return -1;
  vec4 open = texelFetch(uMat, local, 0);
  floorMax = (open.a * H_RANGE + H_MIN + uPlanHeightOffset) / CELL_METERS;
  return int(open.b * 255.0 + 0.5);
}
// THE BAKED AMBIENT, SAMPLED SMOOTHLY.
//
// cellAt() reads this byte with texelFetch, which is a NEAREST fetch — one
// value per cell, no interpolation — and ambient multiplies straight by it. So
// every cell boundary in the building was a hard step in brightness, and the
// one-bit dither did not cause the square plaid people were seeing, it merely
// made an existing staircase visible. The blocks were the cells.
//
// This is the same byte, bilinear across the four cells around a WORLD point.
// It is deliberately a separate read from cellAt's: the material id shares that
// texel and must stay nearest, because interpolating an id blends brick into
// tile and produces a material that does not exist.
float ambientPlaceAt(vec2 world){
  // Cell centres sit at +0.5, so shift by half a cell before flooring to get the
  // four cells the point actually lies between rather than the four it is inside.
  vec2 g = world - 0.5;
  vec2 base = floor(g);
  vec2 f = g - base;
  float acc = 0.0;
  for(int j = 0; j < 2; j++){
    for(int i = 0; i < 2; i++){
      ivec2 cell = ivec2(base) + ivec2(i, j) - ivec2(uPlanOrigin);
      cell = clamp(cell, ivec2(0), ivec2(uPlanSize) - ivec2(1));
      float w = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      acc += texelFetch(uMat, cell, 0).g * w;
    }
  }
  // ONE STEP OF DITHER ON THE QUANTISATION. The field is a byte, so it arrives in
  // 255 levels across a 0..AMBIENT_PLACE_SCALE range. Interpolating removes the
  // squares but leaves those levels as contour rings, which a hard dither draws
  // as thin bands instead of blocks. A per-pixel offset of about one level puts
  // the contour below the noise floor.
  float step = ${(AMBIENT_PLACE_SCALE / 255).toFixed(6)};
  float jitter = (hash01(gl_FragCoord.x, gl_FragCoord.y) - 0.5) * step;
  return max(0.0, acc * ${AMBIENT_PLACE_SCALE.toFixed(1)} + jitter);
}

float worldIdx(vec2 p){
  float wx = p.x + (noise2(p, 0.006, 17.0) + 0.5*noise2(p, 0.015, 29.0)) * (uTile.x*0.95);
  float wy = p.y + (noise2(p, 0.007, 41.0) + 0.5*noise2(p, 0.018, 53.0)) * (uTile.y*0.95);
  vec2 t = floor(vec2(wx, wy) / uTile);
  return mod(floor(hash01(t.x*13.7, t.y*91.1) * 1000000.0), uWorldCount);
}
// Flat floor (y=0) — chunk presence is expressed in light and colour, never
// in geometry, so walking is level and the camera never bobs.
float height(vec2 p){ return solidCell(p) ? CEIL : 0.0; }

float line1(float v, float scale, float width){
  float d = abs(fract(v * scale) - 0.5);
  return 1.0 - smoothstep(width, width + 0.018, d);
}
float grid2(vec2 p, float scale, float width){
  vec2 d = abs(fract(p * scale) - 0.5);
  float g = min(d.x, d.y);
  return 1.0 - smoothstep(width, width + 0.015, g);
}
// 4×3 atlas of real PBR tiles. Slots:
//   0 brick   1 stonebrick   2 wood     3 quartzite  4 pool-mosaic  5 ceramic
//   6 terrazzo 7 travertine   8 rammed-earth          9 concrete-cladding
// Texture array + REPEAT wrap: true seamless tiling with mipmaps and anisotropy,
// no atlas-edge inset needed.
vec4 dreamSlotResponse(int slot){
  // detail, chroma, roughness, normal. Material identity is authored here;
  // glazed ceramic cannot react like timber or porous masonry.
  if(slot==0)return vec4(1.00,.48,1.00,.92); // brick
  if(slot==1)return vec4(.96,.38,1.08,1.00); // stone
  if(slot==2)return vec4(.82,.34,.72,.86);   // wood grain
  if(slot==3)return vec4(.74,.28,.58,.70);   // quartzite
  if(slot==4)return vec4(.68,.56,.34,.46);   // pool mosaic glaze
  if(slot==5)return vec4(.62,.22,.24,.38);   // white ceramic
  if(slot==6)return vec4(.78,.44,.62,.68);   // terrazzo
  if(slot==7)return vec4(.84,.36,.74,.80);   // travertine
  if(slot==8)return vec4(1.06,.42,1.14,.96); // rammed earth
  return vec4(.88,.30,.96,.78);              // concrete
}
vec3 surfaceTile(int slot, vec2 worldUv, float metresPerTile){
  vec3 tc=vec3(worldUv/metresPerTile,float(slot));
  // Supply the world-space footprint explicitly. Raymarch hits arrive through
  // divergent DDA branches, where implicit texture derivatives can collapse at
  // grazing angles and make the same wall acquire a direction as the camera
  // turns. All banks share this footprint, so albedo and generated detail stay
  // registered while the texture unit performs anisotropic filtering.
  vec2 tcDx=dFdx(tc.xy),tcDy=dFdy(tc.xy);
  vec3 base=textureGrad(uSurfAlbedo,tc,tcDx,tcDy).rgb;
  vec2 hallucinationWarp=vec2(0.0);
  if(uLocalDiffusion>.001){
    // A local, material-space reaction-diffusion pass. It is sampled from
    // world UVs, not screen UVs, so the change sticks to brick, wood, concrete,
    // and tile instead of washing over the camera.
    vec2 rdUv=fract(worldUv/(metresPerTile*3.6) + vec2(float(slot)*0.071,float(slot)*0.113));
    float drift=uTime*(.012+.018*uLocalDiffusion);
    vec2 advect=vec2(
      sin(uTime*.31+worldUv.y*.17+float(slot)),
      cos(uTime*.27+worldUv.x*.19-float(slot))
    )*(.018+.028*uLocalDiffusion);
    vec3 rdA=texture(uRD,fract(rdUv+advect+vec2(drift,-drift*.71))).rgb;
    vec3 rdB=texture(uRD,fract(rdUv*1.73-advect+vec2(-drift*.43,drift*.57))).rgb;
    vec3 rd=mix(rdA,rdB,.38+.18*sin(uTime*.41+float(slot)));
    float vein=smoothstep(0.18,0.82,rd.g);
    float pit=smoothstep(0.62,0.96,rd.r-rd.g);
    vec3 oxidized=base*(0.78+0.30*vein) + vec3(0.045,0.040,0.030)*rd.g;
    vec3 etched=base*(0.92-0.18*pit);
    vec4 response=dreamSlotResponse(slot);
    base=mix(base,clamp(mix(oxidized,etched,pit),vec3(0.0),vec3(1.0)),clamp(uLocalDiffusion*response.x,0.0,1.0));
    float boil=(vein-.5)*sin(uTime*.83+rd.r*8.0+float(slot)*.7);
    base=clamp(base*(1.0+boil*.22*uLocalDiffusion*response.y),vec3(0.0),vec3(1.0));
    // Only the generated layer swims. PBR albedo and all geometry remain fixed,
    // so the wall appears to hallucinate instead of the whole camera sliding.
    hallucinationWarp=(rd.rg-.5)*(.11*uLocalDiffusion*response.y);
  }
  if(uDreamReady<.5)return base;
  // THE BOIL. Each surface holds K generated frames of itself — the same place,
  // further along its own decay — and we crossfade between consecutive frames
  // continuously. The phase is offset per texel by a hash of the world position,
  // so a wall churns unevenly across its own face instead of pulsing as one
  // flat card. That per-pixel desync is the whole difference between a texture
  // fading and a surface boiling.
  float boilPhase=0.0;
  float framesA=max(1.0,uDreamFramesA);
  if(uBoilHz>0.0001&&framesA>1.5){
    float jitter=fract(sin(dot(floor(worldUv*11.0),vec2(12.9898,78.233)))*43758.5453);
    boilPhase=uTime*uBoilHz*(1.0+uAgitation*1.4)+jitter*1.37;
  }
  float slotBase=float(slot)*framesA;
  float fa=floor(boilPhase);
  float ft=smoothstep(0.0,1.0,fract(boilPhase));
  float layerA0=slotBase+mod(fa,framesA);
  float layerA1=slotBase+mod(fa+1.0,framesA);
  vec3 dreamTcA0=vec3(tc.xy+hallucinationWarp,layerA0);
  vec3 dreamTcA1=vec3(tc.xy+hallucinationWarp,layerA1);
  vec3 dreamA=mix(
    textureGrad(uSurfDream,dreamTcA0,tcDx,tcDy).rgb,
    textureGrad(uSurfDream,dreamTcA1,tcDx,tcDy).rgb,
    ft
  );
  // The staged bank samples its own frame zero: a bank change is already a
  // crossfade, and boiling both sides of it costs texture fetches nobody sees.
  vec3 dreamTcB=vec3(tc.xy+hallucinationWarp,float(slot)*max(1.0,uDreamFramesB));
  vec3 dreamB=textureGrad(uSurfDreamNext,dreamTcB,tcDx,tcDy).rgb;
  vec3 dream=mix(dreamA,dreamB,uDreamNextReady>.5?uDreamBankBlend:0.0);
  // The engraving rides the SAME coordinates, boil phase and bank blend as the
  // material it came from. Sharing them rather than recomputing is why the
  // grain cannot slide out of register with its own wall. The arrays differ in
  // resolution (128 against 512) but not in UV, and tcDx/tcDy are normalised
  // derivatives, so one footprint filters both.
  float markBankBlend=uDreamNextReady>.5?uDreamBankBlend:0.0;
  float markSlotBase=float(slot)*uMarkStride;
  vec3 markTcA0=vec3(dreamTcA0.xy,uMarksLiveBase+markSlotBase+mod(fa,framesA));
  vec3 markTcA1=vec3(dreamTcA1.xy,uMarksLiveBase+markSlotBase+mod(fa+1.0,framesA));
  vec4 markA=mix(
    textureGrad(uSurfMarks,markTcA0,tcDx,tcDy),
    textureGrad(uSurfMarks,markTcA1,tcDx,tcDy),
    ft
  );
  vec4 markB=textureGrad(uSurfMarks,vec3(dreamTcB.xy,uMarksStageBase+markSlotBase),tcDx,tcDy);
  // Decode to a signed line field BEFORE applying readiness. The other order is
  // a trap: zeroing the stored 0..1 vector then decoding yields (-1,-1), which
  // is not "no grain" but a confident grain at 225 degrees, on every slot that
  // has not been derived yet.
  markA.gb=markA.gb*2.0-1.0;
  markB.gb=markB.gb*2.0-1.0;
  markA*=uMarksReady[slot];
  markB*=uMarksReadyNext[slot];
  gMark=mix(markA,markB,markBankBlend);
  gMarkBlend=1.0;
  // Transfer material detail, not the generated image's illumination or
  // palette. Dividing by a coarse mip extracts local grain/mortar/weathering;
  // multiplying that into the authored albedo keeps the room from becoming a
  // flat img2img wash while remaining fixed in world-space UVs.
  vec3 dreamLowA=mix(textureLod(uSurfDream,dreamTcA0,4.0).rgb,textureLod(uSurfDream,dreamTcA1,4.0).rgb,ft);
  vec3 dreamLowB=textureLod(uSurfDreamNext,dreamTcB,4.0).rgb;
  vec3 dreamLow=mix(dreamLowA,dreamLowB,uDreamNextReady>.5?uDreamBankBlend:0.0);
  vec3 detail=clamp(dream/max(dreamLow,vec3(.055)),vec3(.36),vec3(2.15));
  float baseLum=max(.035,dot(base,vec3(.2126,.7152,.0722)));
  float dreamLum=max(.035,dot(dreamLow,vec3(.2126,.7152,.0722)));
  vec3 neutralTone=vec3(baseLum);
  vec3 generatedTone=clamp(dreamLow*(baseLum/dreamLum),vec3(0.0),vec3(1.0));
  generatedTone=mix(neutralTone,generatedTone,clamp(uDreamChromaDrift,0.0,1.0));
  vec4 response=dreamSlotResponse(slot);
  vec3 detailed=clamp(base*mix(vec3(1.0),detail,clamp(uDreamDetailGain*response.x,0.0,1.7)),vec3(0.0),vec3(1.0));
  float generatedPresence=clamp((.32+uDreamChromaDrift*1.55)*uDreamMix[slot]*response.y,0.0,.76);
  detailed=mix(detailed,generatedTone,generatedPresence);
  // Past the grain: let the generated image itself onto the wall. In calm rooms
  // this is zero and the lens stays a detail pass; under agitation the model's
  // own structure arrives, which is what makes it a repaint and not a filter.
  float structure=clamp(uDreamStructureMix*(0.6+0.4*uAgitation)*response.y,0.0,0.75);
  detailed=mix(detailed,clamp(dream,vec3(0.0),vec3(1.0)),structure);
  // Exposure leash. baseLum/detailedLum is a CORRECTION that drags generated
  // luminance back onto the authored albedo — so the way to let the lens be
  // seen is to apply less of it, not to widen its bounds. uDreamLumaHold is
  // how much of that correction survives: 1.0 pins exposure exactly (quiet
  // rooms stay legible), 0.2 lets the surface burn out or go black on its own.
  // This matters more than anything else downstream: the VFD encoder buckets
  // cells by luminance, so a boil that cannot move luminance cannot be seen.
  float detailedLum=max(.025,dot(detailed,vec3(.2126,.7152,.0722)));
  float exposureFix=clamp(baseLum/detailedLum,uDreamLumaLo,uDreamLumaHi);
  detailed*=mix(1.0,exposureFix,clamp(uDreamLumaHold,0.0,1.0));
  detailed=clamp(detailed,vec3(0.0),vec3(1.0));
  // A boiling surface is doing something, and a condemned building is dark:
  // let churn contribute its own faint light so the crawl is visible on walls
  // the torch is not pointed at. Multiplied by albedo at the light sum, so it
  // reads as the material glowing rather than a wash laid over the frame.
  gBoilGlow=uAgitation*clamp(uDreamStructureMix*1.3,0.0,1.0)
    *clamp(dot(dream,vec3(.2126,.7152,.0722)),0.0,1.0)
    *uDreamMix[slot]*response.y*0.6;
  return mix(base,detailed,clamp(uDreamMix[slot]*response.x*1.12,0.0,1.0));
}
// One texture per surface, chosen by the room's material and whether we hit a
// wall or a floor. No cross-slot mixing — that is what smeared every texture
// across every surface.
void surfaceSlot(int mat,int surf,vec2 uv,out int slot,out float tileM,out float blend){
  if(surf==1){                                                  // walls — one texture per wall
    if(mat==MAT_ACOUSTIC){slot=9;tileM=1.6;blend=.84;}          // basement (studio) → concrete cladding
    else if(mat==MAT_PRACTICE){slot=8;tileM=1.8;blend=.84;}     // classroom → rammed earth
    else if(mat==MAT_WOOD){slot=2;tileM=2.2;blend=.90;}         // concert hall → dark timber panelling
    else if(mat==MAT_POOL||mat==MAT_WET){slot=5;tileM=1.0;blend=.84;} // natatorium → white ceramic
    else if(mat==MAT_METAL){slot=9;tileM=1.6;blend=.82;}        // plant → concrete cladding
    else if(mat==MAT_CHAPEL){slot=1;tileM=1.4;blend=.82;}       // chapel → split-face stone
    else if(mat==MAT_ACADEMIC){slot=7;tileM=2.2;blend=.80;}     // academic → pale worn stone/plaster
    else if(isRainGroundMat(mat)){slot=9;tileM=1.2;blend=.70;}  // exterior retaining walls → concrete
    else {slot=0;tileM=1.4;blend=.80;}                          // general → reclaimed brick
  } else {                                                      // floor (surf==2)
    if(mat==MAT_ACOUSTIC||mat==MAT_PRACTICE||mat==MAT_ACADEMIC){slot=6;tileM=1.8;blend=.88;} // teaching floors → terrazzo
    else if(mat==MAT_WOOD){slot=2;tileM=1.8;blend=.92;}         // concert hall → worn timber boards
    else if(mat==MAT_CHAPEL){slot=3;tileM=2.0;blend=.90;}       // chapel → quartzite
    else if(mat==MAT_WET){slot=4;tileM=0.9;blend=.92;}          // pool interior → blue mosaic
    else if(mat==MAT_POOL){slot=5;tileM=1.0;blend=.90;}         // pool deck → white ceramic
    else if(mat==MAT_TARMAC){slot=9;tileM=0.42;blend=.52;}      // carriageway → wet aggregate
    else if(mat==MAT_PAVING){slot=9;tileM=3.2;blend=.22;}       // pavement → stone grain under yorkstoneFlags (3 and 7 are a checkered tile)
    else if(mat==MAT_SETTS){slot=1;tileM=.46;blend=.68;}        // gutter and courts → small stone setts
    // Turf is evaluated from world metres in architecturalSurface. It has no
    // masonry-bank contribution, including while a material bank is loading.
    else if(mat==MAT_GRASS){slot=8;tileM=.42;blend=0.0;}
    else {slot=2;tileM=1.8;blend=.84;}                          // general → ash wood
  }
}
vec2 surfaceUv(int surf,vec3 p,vec3 n){
  if(surf!=1)return p.xz;
  return abs(n.x)>.5?vec2(p.z,p.y):vec2(p.x,p.y);
}
bool isSourceMaterial(int mat){
  return mat==MAT_SOURCE_FIELD||mat==MAT_SOURCE_PATH||mat==MAT_SOURCE_PAGE||mat==MAT_SOURCE_FAULT;
}
vec3 sourceSyntaxTint(int mat){
  if(mat==MAT_SOURCE_PATH)return vec3(.03,.70,1.00);
  if(mat==MAT_SOURCE_PAGE)return vec3(.86,.91,.82);
  if(mat==MAT_SOURCE_FAULT)return vec3(1.00,.10,.07);
  return vec3(.03,.92,.18);
}
float sourceGlyph(vec2 uv){
  if(uSourceReady<.5)return 0.0;
  return dot(texture(uSourceSurface,fract(uv)).rgb,vec3(.2126,.7152,.0722));
}
float sourceInkCoverage(vec2 uv){
  return uSourceReady>.5?texture(uSourceSurface,fract(uv)).a:0.0;
}
float sourceLayerAt(vec2 worldCell){
  ivec2 local=ivec2(floor(worldCell))-ivec2(uPlanOrigin);
  if(local.x<0||local.y<0||local.x>=int(uPlanSize.x)||local.y>=int(uPlanSize.y))return 0.0;
  return texelFetch(uSourceLayer,local,0).r*255.0;
}
// Botanical turf: broad uneven growth plus filtered short blade grain. The
// positions are physical metres; derivatives suppress subpixel grass instead
// of making a repeating earth texture sparkle during a walk.
vec3 foregroundTurf(vec2 uv){
  float growth=.5+.5*vnoise(uv,.68,71.0);
  float clumps=.5+.5*vnoise(uv,4.8,93.0);
  vec2 bladeUv=vec2(uv.x+uv.y*.27,uv.y)*vec2(29.0,10.0);
  float grain=.5+.5*vnoise(bladeUv,1.0,117.0);
  float footprint=max(length(dFdx(bladeUv)),length(dFdy(bladeUv)));
  grain=mix(grain,.5,smoothstep(.40,1.7,footprint));
  vec3 turf=mix(vec3(.085,.144,.083),vec3(.173,.257,.122),growth);
  return turf*(.84+.23*clumps+.19*grain);
}
${ST_BRENDANS_STONE_GLSL}
// YORKSTONE IN RANDOM-LENGTH COURSES. Leeds lays its pavements in 600 mm
// courses, every course its own flag length, every flag its own tone. The old
// flag texture carried a checkerboard that no Leeds pavement has, in its
// relief as well as its colour, and relief is what prints. The joints are cut
// into the normal instead. x: the flag's tone, y: how much joint is under this
// pixel, faded once joints go subpixel.
vec2 yorkstoneFlags(vec2 p){
  float course=floor(p.y/.6);
  float len=.62+.34*hash01(course,17.0);
  float u=p.x/len+hash01(course,3.0);
  float flag=floor(u);
  vec2 f=vec2(fract(u)*len,fract(p.y/.6)*.6);
  float tone=.74+.44*hash01(course,flag+11.0);
  float footprint=max(fwidth(p.x),fwidth(p.y));
  float width=max(.010,footprint*.6);
  float joint=1.0-min(smoothstep(0.0,width,min(f.x,len-f.x)),smoothstep(0.0,width,min(f.y,.6-f.y)));
  return vec2(tone,joint*(1.0-smoothstep(.03,.10,footprint)));
}
vec3 architecturalSurface(int mat,int surf,vec3 p,vec3 n,vec3 fallback){
  if(mat==MAT_GRASS&&surf==2){
    gMark=vec4(0.0);gMarkBlend=0.0;gMarkPlane=0.0;
    return foregroundTurf(p.xz);
  }
  if(uSurfacesReady<.001||surf==3)return fallback;
  vec2 uv=surfaceUv(surf,p,n);
  int slot; float tileM; float blend; surfaceSlot(mat,surf,uv,slot,tileM,blend);
  vec3 tinted=mix(fallback,surfaceTile(slot,uv,tileM),blend);
  // Must mirror surfaceUv exactly. If these two ever disagree the grain is
  // lifted into the wrong plane and runs across the wall instead of along it.
  gMarkPlane=surf!=1?0.0:(abs(n.x)>.5?0.5:1.0);
  // Only the blended share of that tile is on the wall; a surface barely showing
  // its generated material must not be engraved as if made entirely of it.
  gMarkBlend*=blend;
  return tinted;
}
float materialSeam(int mat, int surf, vec3 p, vec3 n){
  vec2 faceUv=surfaceUv(surf,p,n);
  if(mat == MAT_ACOUSTIC){
    return surf == 1
      ? max(line1(p.y, 1.65, 0.035), line1(faceUv.x, 0.72, 0.030)) * 0.34
      : grid2(p.xz, 0.62, 0.040) * 0.10;
  }
  if(mat == MAT_POOL || mat == MAT_WET){
    return grid2(faceUv, 1.75, 0.035) * (mat == MAT_WET ? 0.30 : 0.24);
  }
  if(mat == MAT_WOOD){
    float boards = surf == 1 ? line1(p.y, 1.25, 0.030) : line1(p.x + p.z * 0.18, 1.45, 0.030);
    return boards * 0.28;
  }
  if(mat == MAT_PRACTICE){
    return max(line1(p.y, 1.10, 0.035), line1(p.x + p.z, 0.58, 0.020)) * 0.22;
  }
  if(mat == MAT_CHAPEL){
    return max(line1(p.y, 0.52, 0.025), line1(faceUv.x, 0.38, 0.018)) * 0.26;
  }
  if(mat == MAT_METAL){
    return max(line1(p.y, 2.1, 0.030), line1(p.x - p.z, 0.42, 0.020)) * 0.30;
  }
  if(mat == MAT_DOOR){
    return max(line1(p.y, 2.7, 0.030), line1(faceUv.x, 1.1, 0.025)) * 0.38;
  }
  if(mat == MAT_TARMAC){
    // No courses and no boards. A yard has expansion joints and patches, and
    // they run a long way apart.
    return max(line1(p.x, 6.4, 0.020), line1(p.z, 7.9, 0.020)) * 0.14;
  }
  // Grass has no courses, no joints and no grid. Anything regular drawn into
  // it reads as paving that has been painted green.
  if(mat == MAT_GRASS)return 0.0;
  if(mat == MAT_PAVING)return yorkstoneFlags(p.xz).y*.22;
  if(mat == MAT_SETTS)return grid2(p.xz,.28,.032)*.30;
  return (surf == 1 ? line1(p.y, 0.72, 0.026) : grid2(p.xz, 0.55, 0.040)) * 0.18;
}
vec3 materialBase(int mat, int surf, vec3 tint, vec3 biome, float rdv){
  vec3 base = mix(vec3(0.48, 0.48, 0.46), tint, 0.22);
  if(mat == MAT_ACOUSTIC) base = vec3(0.18, 0.20, 0.18);
  else if(mat == MAT_POOL) base = vec3(0.40, 0.57, 0.62);
  else if(mat == MAT_WET) base = vec3(0.22, 0.35, 0.38);
  else if(mat == MAT_WOOD) base = vec3(0.34, 0.22, 0.16);
  else if(mat == MAT_PRACTICE) base = vec3(0.50, 0.42, 0.31);
  else if(mat == MAT_CHAPEL) base = vec3(0.60, 0.63, 0.60);
  else if(mat == MAT_METAL) base = vec3(0.34, 0.35, 0.32);
  else if(mat == MAT_DOOR) base = vec3(0.24, 0.28, 0.29);
  else if(mat == MAT_TARMAC) base = vec3(0.145, 0.156, 0.180);
  else if(mat == MAT_PAVING) base = vec3(0.34, 0.35, 0.36);
  else if(mat == MAT_SETTS) base = vec3(0.205, 0.22, 0.24);
  // Municipal grass at night in the rain is not green, it is a dark blue-green
  // that only admits to being green where a lamp reaches it. But it was DARKER
  // than the tarmac beside it and had almost no sheen, so at one bit the lawn
  // came out as the emptiest thing in shot — the park read as a hole with a
  // fountain in it. Lifted just clear of tarmac (0.145,0.156,0.180) so the
  // boundary between path and grass is a boundary, not an absence.
  else if(mat == MAT_GRASS) base = vec3(0.148, 0.204, 0.146);
  if(surf == 3) base *= 0.58;
  if(surf == 2) base = mix(base, mix(biome, tint, 0.35), 0.22);
  return base * (0.56 + 0.55 * rdv);
}
float materialSpec(int mat){
  if(mat == MAT_WET) return 0.95;
  if(mat == MAT_TARMAC) return 0.58;   // it has been raining on it all night
  if(mat == MAT_PAVING) return 0.68;
  if(mat == MAT_SETTS) return 0.61;
  // Soaked. It drinks most of the light, but a wet blade does throw some back —
  // and in a one-bit renderer that glint is the only thing that can draw the
  // texture at all, so it may not be zero.
  if(mat == MAT_GRASS) return 0.26;
  if(mat == MAT_POOL) return 0.42;
  if(mat == MAT_DOOR) return 0.48;
  if(mat == MAT_METAL) return 0.36;
  if(mat == MAT_WOOD) return 0.16;
  if(mat == MAT_CHAPEL) return 0.18;
  if(mat == MAT_ACOUSTIC) return 0.035;
  return 0.08;
}
// RED IS THE EMERGENCY CIRCUIT'S WORD, AND NOBODY ELSE IN ELLERY MAY USE IT.
//
// conservatory-lights.js calls the emergency red "the one impossible colour in
// Ellery", and the display honours that by letting chroma survive the one-bit
// encode. But the display can only see the composited pixel, so it was honouring
// red that had nothing to do with the circuit: sodium off a warm wall, a red
// material under the torch, anything whose albedo happened to be red. Everything
// shaded red before the shader came out red after it, and the emergency wash
// stopped being an event because half the building was already speaking in it.
//
// The lighting pass is the only place that knows WHO lit a fragment, so the gate
// belongs here. Redness that the emergency circuit did not pay for is pulled
// back to its own luminance; every other hue is untouched, so sodium stays
// amber, the sky stays cold, and the torch stays warm. It is a reservation of
// one hue, not a desaturation of the room.
float emergencyRedness(vec3 lit){
  return (lit.r - max(lit.g, lit.b)) / max(lit.r, 1e-4);
}
vec3 reserveEmergencyRed(vec3 shaded, float emergencyShare){
  // Amber and sodium live below .55; the authored emergency primary is .98.
  float claim = smoothstep(.55, .84, emergencyRedness(shaded));
  // A little emergency contribution justifies its own red: falloff and
  // occlusion must not make the circuit out-shout a torch to keep its colour.
  float backing = clamp(emergencyShare * 4.0, 0.0, 1.0);
  float grey = dot(shaded, vec3(.2126, .7152, .0722));
  // No residual red. The one-bit pass deliberately preserves saturated red,
  // so leaving even eighteen percent here let every red-painted surface claim
  // the alarm's ink downstream. Provenance is binary: paid for by an emergency
  // contribution, or neutral before acquisition.
  return mix(shaded, vec3(grey), claim * (1.0 - backing));
}
float propFlashShadow(vec3 world,vec3 normal,vec3 lightDir){
  if(uPropShadowReady<.5)return 1.0;
  vec4 clip=uPropShadowMatrix*vec4(world+normal*.008,1.0);if(clip.w<=0.0)return 1.0;
  vec3 q=clip.xyz/clip.w*.5+.5;if(q.x<=0.0||q.x>=1.0||q.y<=0.0||q.y>=1.0||q.z<=0.0||q.z>=1.0)return 1.0;
  float bias=max(.00018,.00115*(1.0-max(dot(normal,lightDir),0.0))),visible=0.0;
  if(uWorldLightTreatment>1.5&&uLocalShadowIndex<0){
    // The same four depth comparisons, weighted at actual texel centres.
    // Equal taps jump between five coverages while a player walks; bilinear
    // coverage moves continuously without widening the physical shadow.
    vec2 grid=q.xy/uPropShadowTexel-.5,base=floor(grid),f=fract(grid);
    for(int y=0;y<2;y++)for(int x=0;x<2;x++){
      vec2 corner=vec2(float(x),float(y)),tap=(base+corner+.5)*uPropShadowTexel;
      vec2 weight=mix(vec2(1.0)-f,f,corner);
      visible+=(q.z-bias<=texture(uPropShadow,tap).r?1.0:0.0)*weight.x*weight.y;
    }
    return mix(.20,1.0,visible);
  }
  for(int y=0;y<2;y++)for(int x=0;x<2;x++){vec2 tap=(vec2(float(x),float(y))-.5)*uPropShadowTexel;visible+=q.z-bias<=texture(uPropShadow,q.xy+tap).r?1.0:0.0;}
  return mix(.20,1.0,visible*.25);
}
${FIRE_ESCAPE_INK_GLSL}
${MISSING_MAN_MATERIAL_GLSL}
${ROOF_SURFACE_INK_GLSL}
${ROOF_GLASS_INK_GLSL}
${PRINTED_SURFACE_GLSL}
float litApparitionTag(float alpha){return 1.0-step(.025,abs(alpha-.76));}
// THE FEATHER, WHICH IS A DELIBERATELY WIDE SHADOW LOOKUP.
//
// propFlashShadow above is a 2x2 PCF: its penumbra is one texel wide. Sample the
// same map on two wide rings so the figure loses its cut-paper edge and leaves a
// low, extended fringe. This is an authored shadow field, not a second lamp.
//
// IT ASKS "IS SOMETHING STANDING WELL IN FRONT OF ME", NOT "AM I IN SHADOW".
//
// A scaled-up bias is the obvious way to stop a wide tap self-shadowing, and it
// does not work. A tap twenty texels away reads the depth of a DIFFERENT PART of
// the same receiving surface, and on anything the lamp sees at an angle that
// depth is legitimately nearer — so the surface reports itself blocked over
// whole walls, and the auditorium grew a pale rectangle the exact shape of the
// shadow map's frustum. Measured: a big soft patch where the sharp sample found
// three small silhouettes.
//
// A gap test has no such failure. Self-shadowing across a few texels of slope is
// a tiny depth difference; a body standing between this wall and the lamp is a
// large one. GAP is expressed in the map's non-linear depth and works out to
// roughly a metre at ten and a quarter of that up close — comfortably more than
// any slope and comfortably less than a figure's stand-off.
const float HALO_GAP=.00042;
float propFlashHalo(vec3 world,vec3 normal,vec3 lightDir){
  if(uPropShadowReady<.5)return 0.0;
  vec4 clip=uPropShadowMatrix*vec4(world+normal*.008,1.0);if(clip.w<=0.0)return 0.0;
  vec3 q=clip.xyz/clip.w*.5+.5;if(q.x<=0.0||q.x>=1.0||q.y<=0.0||q.y>=1.0||q.z<=0.0||q.z>=1.0)return 0.0;
  float blocked=0.0;
  for(int i=0;i<12;i++){
    float angle=float(i)*.5236,ring=i<6?8.0:18.0;
    vec2 tap=vec2(cos(angle),sin(angle))*ring*uPropShadowTexel;
    blocked+=q.z-texture(uPropShadow,q.xy+tap).r>HALO_GAP?1.0:0.0;
  }
  return blocked/12.0;
}
float legacyArchitecturalLightVisibility(vec3 fromM,vec3 toM){
  float distanceM=length(toM-fromM);int checks=int(clamp(ceil(distanceM),1.0,8.0));
  for(int i=1;i<8;i++){
    if(i>=checks)break;
    vec3 q=mix(fromM,toM,float(i)/float(checks));Cell blocker=cellShapeAtI(ivec2(floor(q.xz/CELL_METERS)));
    float qHeight=q.y/CELL_METERS;
    if(blocker.solid||qHeight<blocker.f-.05||qHeight>blocker.c+.05)return .16;
  }
  return 1.0;
}
float architecturalLightVisibility(vec3 fromM,vec3 toM){
  if(uWorldLightTreatment<1.5)return legacyArchitecturalLightVisibility(fromM,toM);
  vec3 delta=toM-fromM;float span=length(delta);if(span<.000001)return 1.0;
  // Traverse each plan span once, including its height interval. Unlike seven
  // spaced probes this cannot skip a half-metre wall or a lowered soffit.
  vec3 start=(fromM+delta/span*min(.012,span*.5))/CELL_METERS,ray=toM/CELL_METERS-start;
  ivec2 cell=ivec2(floor(start.xz)),stepCell=ivec2(sign(ray.xz));
  vec2 crossing=vec2(1e20),stride=vec2(1e20);float entered=0.0;
  if(abs(ray.x)>.00000001){stride.x=1.0/abs(ray.x);crossing.x=(float(cell.x)+(ray.x>0.0?1.0:0.0)-start.x)/ray.x;}
  if(abs(ray.z)>.00000001){stride.y=1.0/abs(ray.z);crossing.y=(float(cell.y)+(ray.z>0.0?1.0:0.0)-start.z)/ray.z;}
  for(int i=0;i<64;i++){
    float exited=min(1.0,min(crossing.x,crossing.y));Cell blocker=cellShapeAtI(cell);
    float a=start.y+ray.y*entered,b=start.y+ray.y*exited;
    if(blocker.solid||min(a,b)<blocker.f-.05||max(a,b)>blocker.c+.05)return 0.0;
    if(exited>=1.0-.0000001)return 1.0;
    bool advanceX=crossing.x<=crossing.y,advanceZ=crossing.y<=crossing.x;entered=min(crossing.x,crossing.y);
    if(advanceX){crossing.x+=stride.x;cell.x+=stepCell.x;}
    if(advanceZ){crossing.y+=stride.y;cell.y+=stepCell.y;}
  }
  // Very distant authored lamps retain their former query instead of leaking
  // through unseen geometry after the traversal budget expires.
  return legacyArchitecturalLightVisibility(fromM,toM);
}
// ── THE NIGHT ────────────────────────────────────────────────────────────────
//
// Half nine, raining, a condemned site on the edge of a northern town that still
// has its lights on. Overcast, lit from underneath: there is a city under the
// cloud base and a low deck bouncing its sodium back down, which is why a wet
// British night is never actually dark. It has to sit well above the interior
// ambient or the one opening in this building reads as another black wall.
//
// THIS IS A FUNCTION NOW, AND THAT IS THE POINT. It used to be inlined in the
// ray-left-the-building branch, so the only thing that could see the sky was a
// ray that escaped. The yard is fifty metres of WET TARMAC under all of this,
// and wet tarmac at night is not a diffuse surface with a low albedo — it is a
// bad mirror, and almost everything you can see in it is sky. Calling this with
// a reflected direction is what puts the moon and the lit deck on the ground the
// player is standing on. See the sheen in the floor branch of main().
//
// Rain is deliberately NOT in here. It is in the air between the eye and the
// thing, not a property of the sky, and a reflection of it in a puddle would be
// falling the wrong way.
// THE DAY HE KEEPS GOING BACK TO. Only ever on while the field owns the renderer
// (game/memory-field-scene.js). It has its own sun, and past a point the memory
// reuses what it has: the sky holds in blocks and slips.
uniform vec3 uMoonMeaning; // radius scale, blood, what the colour loss will take back
uniform vec4 uMemorySun;   // direction, on
uniform vec4 uMemorySky;   // time of day, sun scale, fault, cloud
vec3 memoryDaySky(vec3 dir){
  float fault=clamp(uMemorySky.z,0.0,1.0);
  if(fault>0.01){
    float cells=mix(240.0,16.0,fault*fault);
    vec3 held=normalize(floor(dir*cells+0.5)/cells+vec3(1e-4));
    dir=normalize(mix(dir,held,clamp(fault*1.5,0.0,1.0)));
    float slip=step(1.0-fault*0.42,fract(sin(floor(dir.y*34.0)*12.9898+floor(uTime*2.0)*7.3)*43758.5453));
    if(slip>0.5)dir=normalize(dir+vec3(0.14*fault,0.0,-0.10*fault));
  }
  float up=clamp(dir.y,-1.0,1.0),day=clamp(uMemorySky.x,0.0,1.0),late=smoothstep(0.55,1.0,day);
  vec3 sun=normalize(uMemorySun.xyz);
  vec3 zen=mix(mix(vec3(0.25,0.46,0.78),vec3(0.13,0.37,0.84),smoothstep(0.0,0.4,day)),vec3(0.20,0.19,0.44),late);
  vec3 hor=mix(mix(vec3(0.93,0.90,0.80),vec3(0.75,0.87,0.97),smoothstep(0.0,0.4,day)),vec3(1.0,0.56,0.26),late);
  vec3 col=mix(hor,zen,pow(smoothstep(-0.02,0.72,up),0.62));
  vec2 cp=dir.xz/max(0.18,abs(up)+0.18);
  float drift=uTime*0.008;
  float cloud=0.46*(0.5+0.5*vnoise(cp+drift,0.7,3.0))+0.27*(0.5+0.5*vnoise(cp+drift*1.4,1.6,11.0))+0.17*(0.5+0.5*vnoise(cp+drift*2.0,3.4,29.0))+0.10*(0.5+0.5*vnoise(cp+drift*3.0,7.0,47.0));
  float sd=acos(clamp(dot(dir,sun),-1.0,1.0)),sr=0.035*max(0.2,uMemorySky.y);
  // Soft-edged, and burned away near the sun: a hard cloud edge prints as a black line.
  cloud=smoothstep(0.46,0.86,cloud)*smoothstep(0.0,0.14,up)*clamp(uMemorySky.w,0.0,1.0)*smoothstep(0.08,0.5,sd);
  col=mix(col,mix(vec3(1.0,0.99,0.96),vec3(1.0,0.72,0.50),late),cloud*0.86);
  col+=mix(vec3(1.0,0.94,0.78),vec3(1.0,0.55,0.28),late)*exp(-sd/(sr*5.0))*0.9;
  col+=vec3(1.0,0.96,0.86)*exp(-sd/0.55)*0.22;
  col=mix(col,vec3(1.6,1.55,1.4),1.0-smoothstep(sr*0.92,sr*1.02,sd));
  col=mix(col,mix(vec3(0.30,0.44,0.14),vec3(0.36,0.30,0.12),late),1.0-smoothstep(-0.012,0.006,up));
  return col;
}
vec3 nightSky(vec3 dir){
  if(uMemorySun.w>0.5)return memoryDaySky(dir);
  float up = clamp(dir.y, -1.0, 1.0);
  float horizon = 1.0 - smoothstep(0.0, 0.46, abs(up));
  // A SOLID OVERCAST DOES NOT FALL AWAY THAT FAST. 0.80 put the sky at two
  // thirds of the way to "deep" by thirty degrees up, which is the whole band a
  // clamped neck can see — so the useful sky was a bright strip on the horizon
  // and then night. A lit deck stays lit overhead; it only loses the sodium.
  float zenith  = smoothstep(0.02, 1.05, up);
  // THE NIGHT IS BLUE. It is half nine, it is raining, and the light in this sky
  // is what is left of the day plus a town's worth of streetlamps on the
  // underside of the cloud. The sodium is a stain near the horizon in one
  // direction, not the colour of the sky — an earlier pass had it warm all over
  // and the shot read as a sunset, which is the wrong story and the wrong hour.
  vec3 sodium   = vec3(0.44, 0.25, 0.11);
  // Twilight, not a floodlit blue hour. The deck remains readable against the
  // roofs, but sits one small stop below the earlier almost-daylight exterior.
  vec3 ceiling  = vec3(0.194, 0.249, 0.358);
  vec3 deep     = vec3(0.048, 0.073, 0.136);
  vec3 col = mix(ceiling, deep, zenith) + sodium * horizon * horizon * 0.30;

  // CLOUD.
  //
  // Projected onto a base a little over the roofline, so it drifts with the eye
  // instead of sitting on the far plane like a painted flat. Four octaves, and
  // the amplitudes are deliberately top-heavy: a one-bit dither cannot hold a
  // gentle variation, so the big shapes have to carry it and the small ones only
  // break the edges.
  //
  // The 0.22 floor was half the firefly problem. It is a flat-deck projection, so
  // it goes singular at the horizon: at up = 0 it multiplied the sampling
  // frequency by about nine, precisely where the eye spends its time when it is
  // looking OUT of the bay. Four octaves at nine times frequency under a one-bit
  // dither is a field of sparkle, however good the noise is.
  vec2 cp = dir.xz / max(0.22, abs(up) + 0.22);
  // FAST ENOUGH TO WATCH. 0.0025 was a deck that moved about a degree a minute,
  // which is honest weather and no use at all to a man standing in a yard with
  // his head back. This is a wind, and the whole point of opening the sky was
  // that there is something up there worth stopping for.
  float drift = uTime * 0.0140;
  // THE BASE OCTAVE WAS BIGGER THAN THE SKY. At 0.34 one feature of the largest
  // octave spans about three units of cp, and the whole band a clamped neck can
  // see is barely one — so the shape that carries this deck was, from where the
  // player stands, a constant. Everything overhead was the two small octaves and
  // a dither, which is grain. These are the same four octaves an octave up.
  float cloud = 0.50 * (0.5 + 0.5 * vnoise(cp + drift * 0.6, 0.85, 3.0))
              + 0.27 * (0.5 + 0.5 * vnoise(cp + drift * 1.0, 2.00, 11.0))
              + 0.15 * (0.5 + 0.5 * vnoise(cp + drift * 1.7, 4.60, 29.0))
              + 0.08 * (0.5 + 0.5 * vnoise(cp + drift * 2.6, 9.50, 47.0));
  // THE GATE WAS ABOVE THE EYE LINE.
  //
  // This used to be smoothstep(-0.12, 0.26, up): fully faded below fifteen
  // degrees, fully present above. r3dLook clamps pitch to +-0.62rad, so the neck
  // stops at 35.5 degrees, and from the yard the sky the player actually spends
  // time in runs from the skyline to about thirty. The cloud was computed
  // correctly, four octaves of it, and then multiplied out of the only band it
  // was ever going to be seen in. Exactly the fault the moon's altitude band had,
  // and the same fix.
  //
  // AND THE REMAP WAS BIASED TOWARD CLEAR. Four octaves of value noise average
  // one half, so subtracting 0.32 and scaling by 1.32 left a mean cloud cover of
  // about a quarter — which is to say the sky was mostly the BREAK term, mixing
  // half of every pixel toward the dark. This is an overcast: the deck is the
  // default and a break in it is the event.
  cloud = clamp((cloud - 0.20) * 1.90, 0.0, 1.0) * smoothstep(-0.10, 0.05, up);

  // THE DECK IS THE BRIGHT THING, AND IT WAS THE ONE TERM MISSING.
  //
  // Cloud fed three things and every one of them took light away: the halo round
  // the moon, a thin sodium tint, and a mix toward "deep" on the thick parts.
  // Nothing anywhere added the fact that actually makes an overcast city night
  // legible — the underside of the deck is lit FROM BELOW, by the town, and it is
  // the brightest thing in the frame after the moon. Four octaves of good noise
  // were being computed and then rendered as an absence, which is why this sky
  // dithered down to a flat grain.
  //
  // Thick deck catches the sodium and goes up. A break shows the real depth
  // behind it and goes down. Both read hardest near the horizon, where the cloud
  // is edge-on and there is a town's worth of it between you and the light.
  vec3 deck = mix(ceiling * 1.11, ceiling * 1.27 + sodium * 0.27, horizon);
  col = mix(col, deck, cloud * (0.56 + 0.34 * horizon));
  col = mix(col, deep * 0.62, (1.0 - cloud) * smoothstep(0.02, 0.30, up) * 0.62);
  col += sodium * 0.22 * cloud * (1.0 - zenith);

  // THE MOON, which is behind all of it.
  //
  // Bearing, altitude and phase come from the run seed, so a given night has one
  // moon in one place for its whole length. Every so often it comes in close and
  // reads twice the size — a perigee moon, and the only thing in this game that
  // is unambiguously beautiful.
  //
  // "WEST-ISH, MOSTLY" WAS THE WHOLE CIRCLE. The bearing used to be
  // uNightSeed * 6.28318 - 2.30, which is a full turn: uniform over 360 degrees,
  // with the subtraction only deciding where the seed's zero landed. The yard
  // sees an arc of maybe 120 degrees west; everything else is behind the
  // conservatory or behind the player's own shoulder, so three nights in four the
  // moon was authored somewhere it could not be stood in front of. The ALTITUDE
  // band was narrowed for exactly this reason and the bearing was left alone,
  // which is how "there is no moon" survived that fix.
  //
  // moonDir.x is cos(mAz) and west is -x — the same axis the town glow reads as
  // "the way the bay faces" — so PI is due west, down the gate line.
  float mAz  = 3.14159 + (fract(uNightSeed * 2.71) - 0.5) * 2.10;
  // ALTITUDE HAS TO FIT UNDER THE CAMERA. r3dLook clamps pitch to +-0.62rad, so
  // the eye cannot rise past 35.5 degrees — you cannot crane your neck in this
  // game. 0.26..0.39 is 19.4 to 32.6 degrees: a moon that sits differently every
  // night and is always inside the cone the neck allows.
  float mAlt = 0.26 + 0.13 * fract(uNightSeed * 7.13);
  vec3 moonDir = normalize(vec3(cos(mAz) * (1.0 - mAlt), mAlt, sin(mAz) * (1.0 - mAlt)));
  float super = step(0.82, fract(uNightSeed * 13.77));        // roughly one run in six
  // The same moon every night, and as the night goes on there is more of it.
  // Nobody moves it and nothing says so. See game/last-minutes.js.
  float mR = mix(0.026, 0.052, super) * max(1.0, uMoonMeaning.x);
  float moonBlood = clamp(uMoonMeaning.y, 0.0, 1.0);
  // He sees less colour every hour and this is the one colour he sees more of, so it
  // is laid down strong enough to come through what POST does to everything else.
  vec3 moonGlow = mix(vec3(1.0), vec3(1.0, 0.34, 0.24), moonBlood);
  float moonLoss = max(1.0, uMoonMeaning.z);
  moonGlow = max(vec3(0.0), dot(moonGlow, vec3(.2126, .7152, .0722)) + (moonGlow - dot(moonGlow, vec3(.2126, .7152, .0722))) * moonLoss);
  float mCos = dot(dir, moonDir);
  float mD = acos(clamp(mCos, -1.0, 1.0));

  // Cloud in front of it eats it, which is what actually sells a moon on a night
  // like this — it comes and goes.
  float thinCloud = 1.0 - smoothstep(0.16, 0.72, cloud);

  // GLOW FIRST, DISC LAST. The halo was being added over the top of the moon,
  // which washed the disc out to the same value as the sky around it and left
  // nothing on screen but a faint ring where the dither happened to break. The
  // light around it has to go down before the thing itself does.
  col += vec3(0.42, 0.46, 0.56) * moonGlow * exp(-mD / (mR * 4.2)) * 0.30 * thinCloud;
  col += vec3(0.26, 0.30, 0.40) * moonGlow * exp(-mD / 0.50) * (0.16 + 0.30 * super);
  // Cloud between you and it takes the moon's light rather than the moon, so the
  // deck in front of it glows and the breaks stay dark.
  col += vec3(0.40, 0.43, 0.52) * moonGlow * cloud * exp(-mD / 0.40) * 0.70;

  // THE DISC.
  //
  // Two things made this render as an outline rather than as a moon. The maria
  // were sampled from dir.xz divided by the disc radius, which at 0.026 is a
  // frequency of about seventeen hundred — noise, not mottling, and the dither
  // turned it into a ring. And the phase and cloud terms multiplied down to under
  // a tenth on a thick night, so the fill sat at the value of the sky it was drawn
  // on and only the edge survived.
  //
  // The moon is the one thing in this game that is unambiguously beautiful. It
  // gets a floor.
  float disc = 1.0 - smoothstep(mR * 0.92, mR * 1.01, mD);
  vec3 toMoon = normalize(dir - moonDir * mCos);
  vec3 mUp = normalize(cross(moonDir, vec3(0.0, 1.0, 0.0)) + vec3(1e-4));
  vec2 face = vec2(dot(toMoon, mUp), toMoon.y) * (mD / max(mR, 1e-4));
  float phase = smoothstep(-0.85, 0.75, face.x + (fract(uNightSeed * 3.31) - 0.5) * 2.2);
  float maria = 0.88 + 0.12 * noise2(face * 1.9, 1.0, 5.0);
  float lit = disc * (0.55 + 0.45 * phase) * (0.62 + 0.38 * thinCloud);
  // Late in the night no cloud gets in front of it, and it has no dark side.
  lit = mix(lit, disc, moonBlood);
  col += vec3(0.62, 0.05, 0.03) * moonBlood * exp(-mD / 0.75) * 0.42 * moonLoss;
  vec3 moonPaint = mix(vec3(1.34, 1.33, 1.26), vec3(1.18, 0.20, 0.10), moonBlood);
  float moonPaintLum = dot(moonPaint, vec3(.2126, .7152, .0722));
  col = mix(col, max(vec3(0.0), moonPaintLum + (moonPaint - moonPaintLum) * moonLoss) * maria, lit);

  // The glow the city throws onto the cloud above it, to the west, where the bay
  // faces. Broad and shapeless: the light, not the source.
  col += vec3(0.58, 0.33, 0.13)
       * pow(clamp(-dir.x, 0.0, 1.0), 4.0) * pow(horizon, 2.2) * 0.70;

  // The roof builds its own eye-height-correct city over this same weather.
  vec3 roofWeather = col;

  // ── THE CITY ───────────────────────────────────────────────────────────────
  //
  // Distant ground is drawn as DIRECTION, not as geometry. It is kilometres out,
  // nothing about it is ever approached, and authoring it as cells was never
  // possible anyway — the sub-basement owns every ground-level cell west of the
  // bay. A skyline and a floor, which is also what this renderer is best at: a
  // one-bit dither cannot hold a subtle gradient but it holds a hard black shape
  // against a lit sky perfectly.
  //
  // IT USED TO BE A VALLEY. Hills, a treeline and a river, with a scatter of
  // sodium in the trough for "a town". That is a lovely thing to stand in and it
  // is the wrong planet: Ellery is a municipal conservatory of music with a
  // chain-link yard, a skip and a barbed-wire fence, in a northern industrial
  // city. You should be able to see what the building is on the edge OF.
  //
  // ONE SKYLINE, AND EVERYTHING UNDER IT IS GROUND. An earlier pass drew ridges
  // as separate dark bands ABOVE the horizon and left the region between them
  // dark, so the authored yard ran into a black stripe and then into a bright
  // sky. Ground does not work like that. There is one edge; below it is the city,
  // above it is weather.
  //
  // Sampled on the unit circle so it is periodic with no seam behind the player
  // at +/-pi.
  float azimuth = atan(dir.z, dir.x);
  vec2 ap = vec2(cos(azimuth), sin(azimuth));
  float west = clamp(-dir.x, 0.0, 1.0);

  // THE ROOFS. A mill town seen from a yard is not a curve, it is a long low run
  // of parallel ridges with the odd taller thing standing out of it. Two octaves
  // of gentle undulation for the ground the city is built on, then a hard square
  // wave at terrace frequency for the roofs themselves — that squared-off edge is
  // the whole difference between a skyline and a hillside.
  float ground = 0.021
    + 0.011 * noise2(ap * 1.7, 1.0, 7.0)
    + 0.005 * noise2(ap * 4.3, 1.0, 19.0);
  float terrace = 0.0125 * step(0.42, 0.5 + 0.5 * noise2(ap * 9.0, 1.0, 37.0))
                + 0.0060 * step(0.55, 0.5 + 0.5 * noise2(ap * 23.0, 1.0, 61.0));
  // Sawtooth: a weaving shed roof, north lights, the one silhouette that says
  // this town made something.
  float saw = 0.0075 * abs(fract(azimuth * 26.0) - 0.5)
            * step(0.62, 0.5 + 0.5 * noise2(ap * 3.1, 1.0, 43.0));
  // Chimney stacks and vent cowls along the ridge, in place of a treeline.
  float stacks = 0.0130 * step(0.955, hash01(floor(azimuth * 90.0), 3.0))
               + 0.0060 * step(0.910, hash01(floor(azimuth * 210.0), 9.0));
  float skyline = ground + terrace + saw + stacks;

  // THE TALL THINGS, each a hard-edged block standing off the general roofline.
  // Placed by bearing rather than by noise so a given night is always the same
  // city and the player can learn it: two post-war housing slabs, a gasholder,
  // a mill chimney and a tower crane, all clustered west and north-west where the
  // bay faces and where he drove in from.
  //
  // A "block" is a window in azimuth with its own height; ridges add, so a block
  // simply raises the skyline over its own arc.
  float blocks = 0.0;
  // slabs: wide, flat-topped, the tallest things out there
  blocks = max(blocks, 0.093 * step(abs(azimuth - 2.86), 0.052));
  blocks = max(blocks, 0.081 * step(abs(azimuth + 2.61), 0.044));
  // the gasholder: a drum, so its top is a shallow arc rather than a line
  {
    float d = (azimuth - 3.02) / 0.105;
    blocks = max(blocks, (0.050 + 0.012 * sqrt(max(0.0, 1.0 - d * d))) * step(abs(d), 1.0));
  }
  // the mill chimney: thin and the highest thing in the frame
  blocks = max(blocks, 0.118 * step(abs(azimuth + 2.93), 0.0075));
  // the tower crane: a mast, and a jib running off it one way
  blocks = max(blocks, 0.104 * step(abs(azimuth - 2.42), 0.0055));
  blocks = max(blocks, 0.101 * step(azimuth - 2.42, 0.0) * step(2.20, azimuth) * 0.985);
  skyline = max(skyline, blocks);

  // Depth below the skyline. The edge itself is the darkest thing in the frame —
  // a wet slate roof against a lit overcast is very nearly black — and it opens
  // out toward the near ground, which is catching the whole sky and has to meet
  // the authored yard's own value without a seam.
  float below = clamp((skyline - up) / 0.34, 0.0, 1.0);
  vec3 land = mix(vec3(0.020, 0.028, 0.046), vec3(0.108, 0.135, 0.188),
                  smoothstep(0.0, 1.0, below));

  // The far side of the city, hazed most of the way back to the sky. Aerial
  // perspective is the only depth cue a silhouette gets, so it is the whole
  // reason this reads as distance and not as a cut-out.
  float shoulder = 0.050
    + 0.026 * noise2(ap * 1.1, 1.0, 23.0)
    + 0.010 * noise2(ap * 3.3, 1.0, 31.0);
  col = mix(col, mix(col, vec3(0.086, 0.108, 0.152), 0.82),
            smoothstep(shoulder + 0.004, shoulder - 0.004, up));

  col = mix(col, land, smoothstep(skyline + 0.0022, skyline - 0.0022, up));

  // LIT WINDOWS, in the slabs. Not a texture — a lattice, because the one thing
  // a tower block does at night is show you which flats are still up. Sampled in
  // a grid tied to the block's own bearing so the columns stay vertical.
  vec2 wp = vec2(azimuth * 620.0, up * 900.0);
  float grid = step(0.62, fract(wp.x)) * step(0.55, fract(wp.y));
  float inSlab = step(abs(azimuth - 2.86), 0.052) + step(abs(azimuth + 2.61), 0.044);
  float windows = grid * clamp(inSlab, 0.0, 1.0)
                * step(up, skyline) * step(0.030, up)
                * step(0.72, hash01(floor(wp.x), floor(wp.y)));
  col += vec3(0.95, 0.78, 0.44) * windows * 0.75;

  // THE STREETS, in the trough under the roofline: points of sodium, never a
  // shape. You never see the city, only that something out there is still
  // switched on.
  float trough = smoothstep(skyline - 0.002, skyline + 0.008, up)
               * (1.0 - smoothstep(shoulder - 0.016, shoulder - 0.002, up));
  vec2 tp = vec2(azimuth * 460.0, (up - skyline) * 2600.0);
  float town = step(0.9800, hash01(floor(tp.x), floor(tp.y)))
             * trough * (0.18 + 0.82 * pow(west, 1.4));
  col += vec3(1.00, 0.58, 0.22) * town * 1.25;

  // THE VIADUCT. A horizontal run of arches below the roofline, catching sky in
  // the openings: the flattest, most legible piece of Victorian infrastructure
  // there is, and the one that says this town was built to move things.
  float viaY = skyline - 0.043;
  float arch = step(0.36, fract(azimuth * 62.0));
  float viaduct = (1.0 - smoothstep(0.0, 0.013, abs(up - viaY)))
                * arch * step(up, skyline)
                * smoothstep(0.35, 0.95, west);
  col += vec3(0.30, 0.34, 0.42) * viaduct * 0.42;

  // The aircraft warning light on the crane, and one on the taller slab. Slow, on
  // a schedule of their own, and the only moving thing in the distance.
  float beaconA = step(0.86, fract(uTime * 0.42))
                * (1.0 - smoothstep(0.0, 0.0055, length(vec2(azimuth - 2.42, up - 0.104))));
  float beaconB = step(0.90, fract(uTime * 0.31 + 0.5))
                * (1.0 - smoothstep(0.0, 0.0045, length(vec2(azimuth - 2.86, up - 0.093))));
  col += vec3(1.00, 0.16, 0.10) * (beaconA + beaconB) * 1.30;

  if(uRoofView > 0.5){
    // The town continues the actual 8-15m district below this 17m roof.
    // Sample two world-anchored rings beyond the real scenery, using metres
    // and eye height. Fixed positive angles previously made every terrace a
    // forty-metre tower and made the roof look trapped inside a black wall.
    col = roofWeather;
    vec2 observer = uCam.xz * CELL_METERS - vec2(85.0, 16.0);
    float eyeHeight = uCam.y * CELL_METERS;
    vec2 horizontal = normalize(dir.xz + vec2(0.000001));
    float roofRaySlope = dir.y / max(0.0001, length(dir.xz));
    float along = dot(observer, horizontal);
    float farDistance = -along + sqrt(max(1.0,
      along*along + 620.0*620.0 - dot(observer,observer)));
    float nearDistance = -along + sqrt(max(1.0,
      along*along + 225.0*225.0 - dot(observer,observer)));
    vec2 farPoint = observer + horizontal * farDistance;
    vec2 nearPoint = observer + horizontal * nearDistance;
    float farAz = atan(farPoint.y, farPoint.x);
    float nearAz = atan(nearPoint.y, nearPoint.x);
    float farHeight = eyeHeight + roofRaySlope * farDistance;
    float nearHeight = eyeHeight + roofRaySlope * nearDistance;

    // A hazed outer town: ordinary roofs, two modest post-war estates and the
    // eastern mill chimney. These bearings remain the same when we cross the
    // roof, descend the escape or return on another evening.
    float farParcel = floor((farAz + 3.14159) * 620.0 / 18.0);
    float farRoofHeight = 14.0 + 12.0 * hash01(farParcel, 71.0);
    float workshop = step(0.72, farAz) * step(farAz, 1.06);
    farRoofHeight = max(farRoofHeight, workshop *
      (20.0 + 3.0 * (1.0 - fract(farAz * 47.0))));
    float estateWest = step(abs(farAz - 2.82), 0.044);
    float estateNorth = step(abs(farAz + 2.65), 0.038);
    float farSlabHeight = max(estateWest * 45.0, estateNorth * 39.0);
    float millChimneyHeight = 52.0 * step(abs(farAz - 0.89), 0.005);
    float farTopHeight = max(max(farRoofHeight, farSlabHeight), millChimneyHeight);
    float farBody = 1.0 - smoothstep(farTopHeight - 0.65, farTopHeight + 0.65, farHeight);
    vec3 farInk = mix(vec3(0.082,0.102,0.137), vec3(0.115,0.139,0.173),
      smoothstep(0.0,farTopHeight,farHeight));
    col = mix(col, farInk, farBody * 0.94);

    // Window rows are tied to real storeys, not the screen's vertical angle.
    // Most rooms are dark. A few broad occupied windows carry human scale
    // through the low-resolution acquisition without glittering everywhere.
    vec2 farPane = vec2(farAz * 620.0 / 4.0, farHeight / 3.1);
    vec2 farFrac = fract(farPane);
    float paneRect = step(0.22,farFrac.x) * (1.0-step(0.66,farFrac.x))
      * step(0.30,farFrac.y) * (1.0-step(0.71,farFrac.y));
    float estate = max(estateWest,estateNorth);
    float livedIn = step(mix(0.94,0.69,estate),
      hash01(floor(farPane.x),floor(farPane.y)));
    float farWindows = paneRect * livedIn * step(2.0,farHeight)
      * step(farHeight,farTopHeight-2.0);
    col += vec3(0.66,0.46,0.25) * farWindows * 0.43;

    // Below the eye, unequal terraces extend the real outer-sprawl roofscape.
    // Small gaps reveal the hazier layer behind instead of closing the city
    // into one continuous silhouette. No projected copy of the nearby north
    // court is needed: its actual bridge, street and lights render in depth.
    float nearParcel = floor((nearAz + 3.14159) * 225.0 / 8.0);
    float nearUnit = fract((nearAz + 3.14159) * 225.0 / 8.0);
    float terraceHeight = 9.0 + 5.0 * hash01(nearParcel,109.0)
      + 1.6 * (1.0-abs(nearUnit*2.0-1.0));
    float nearFootprint = step(0.08,nearUnit) * step(nearUnit,0.96);
    float nearBody = (1.0-smoothstep(terraceHeight-0.25,terraceHeight+0.25,nearHeight))
      * nearFootprint;
    float pitchedRoof = smoothstep(terraceHeight-2.0,terraceHeight-1.5,nearHeight);
    vec3 nearInk = mix(vec3(0.050,0.065,0.082),vec3(0.026,0.037,0.054),pitchedRoof);
    nearInk += vec3(0.018,0.022,0.027) * (1.0-smoothstep(0.0,3.5,nearHeight));
    col = mix(col, nearInk, nearBody * 0.94);

    vec2 nearPane = vec2(nearAz * 225.0 / 3.0,nearHeight / 3.0);
    vec2 nearFrac = fract(nearPane);
    float terracePane = step(0.22,nearFrac.x) * (1.0-step(0.64,nearFrac.x))
      * step(0.28,nearFrac.y) * (1.0-step(0.73,nearFrac.y));
    float nearWindows = terracePane * nearFootprint
      * step(0.88,hash01(floor(nearPane.x),floor(nearPane.y)))
      * step(1.2,nearHeight) * step(nearHeight,terraceHeight-2.0);
    col += vec3(0.78,0.49,0.23) * nearWindows * 0.44;

    // Distant road lamps sit at column height, and the north-west viaduct at
    // its actual elevated level. Both sink in the view as the player climbs.
    float streetGap = 1.0-nearFootprint;
    float roadLights = streetGap * step(0.76,hash01(nearParcel,251.0))
      * (1.0-smoothstep(0.20,1.00,abs(nearHeight-6.1)));
    col += vec3(0.62,0.39,0.18) * roadLights * 0.42;
    float viaduct = step(2.50,farAz) * step(farAz,2.94)
      * (1.0-smoothstep(0.4,1.6,abs(farHeight-12.0)))
      * step(0.26,fract(farAz*39.0));
    col += vec3(0.10,0.13,0.17) * viaduct * 0.38;
  }

  // Six o'clock municipal dawn: a cold wet deck with a pale eastern floor.
  // Sodium is no longer tinting the sky; ordinary daylight is arriving without
  // becoming picturesque. Van and cathedral variants use the same exterior
  // hour and let their geometry/rain distinguish the frame.
  if(uEndingWorldLook > 0.5){
    float dawnHorizon=1.0-smoothstep(-0.04,0.34,abs(up));
    vec3 dawnDeep=vec3(0.135,0.185,0.265);
    vec3 dawnDeck=vec3(0.42,0.49,0.56);
    vec3 dawn= mix(dawnDeck,dawnDeep,smoothstep(0.02,0.92,up));
    dawn += vec3(0.20,0.18,0.15)*dawnHorizon*0.18;
    col=mix(col,dawn,0.86);
  }

  return col;
}

`+RAIN_GLSL+`
// Sparse rings in the wet aggregate. This is surface response, not a second
// particle system: one deterministic impact lives in some metre-wide cells,
// expands, dies, and leaves the existing night-sky reflection to do the actual
// lighting. The pattern is world anchored so it cannot swim under the player.
float rainImpactRings(vec2 worldM,float amount){
  if(amount<=.001)return 0.0;
  float clock=uTime*mix(1.0,.36,uReduceMotionOptical);
  vec2 q=worldM*.92,id=floor(q),p=fract(q)-.5;
  float seed=hash01(id.x+17.0,id.y-43.0);
  float present=step(1.0-.68*clamp(amount,0.0,1.0),hash01(id.x-61.0,id.y+23.0));
  vec2 center=vec2(
    hash01(id.x+5.0,id.y+79.0),
    hash01(id.x-37.0,id.y+11.0)
  )*.48-.24;
  float phase=fract(clock*mix(1.55,2.82,seed)+seed);
  float radius=phase*mix(.10,.21,seed);
  float ring=1.0-smoothstep(.008,.026,abs(length(p-center)-radius));
  float life=smoothstep(.01,.06,phase)*(1.0-smoothstep(.52,.88,phase));
  float strike=(1.0-smoothstep(.025,.105,length(p-center)))
              *(1.0-smoothstep(.018,.12,phase));
  // The crown throws two brief beads back off the tarmac. Analytic discs are
  // substantially cheaper than another particle field and give the impact a
  // visible upward/bounce beat before the spreading ring takes over.
  vec2 gust=normalize(vec2(hash01(id.x+8.0,id.y-2.0)-.5,hash01(id.x-4.0,id.y+6.0)-.5)+vec2(.001));
  float hop=sin(min(phase/.34,1.0)*3.14159)*.20;
  float beadLife=1.0-smoothstep(.10,.38,phase);
  float beadA=1.0-smoothstep(.018,.052,length(p-center-gust*hop));
  float beadB=1.0-smoothstep(.016,.046,length(p-center+gust.yx*hop*.72));
  return present*(ring*life+strike*.88+(beadA+beadB)*beadLife*.48)*mix(1.0,.14,uReduceMotionOptical);
}

${PRESSURE_SCENE_GLSL}

${SHORE.SOURCE_SHORE_APERTURE_GLSL}

${CAMERA_FORWARD_GLSL}

// ── WATER AS WATER ───────────────────────────────────────────────────────────
//
// The surface was an opaque murky skin with a torch glint on it. Water does
// three things that skin did not: it mirrors what stands over it, it shows what
// lies under it, and the balance between the two turns on the angle it is seen
// at. Both directions take a short second walk through the same plan, shaded
// cheaply (material, ambient, the lamps and the torch, no shadows), because
// only water pixels pay for it and the ripples break the result up anyway.
struct WaterRay{ bool hit; float t; int surf; vec3 n; ivec2 cell; bool sky; };
WaterRay waterWalk(vec3 ro, vec3 rd, int steps){
  WaterRay h; h.hit=false; h.t=0.0; h.surf=0; h.n=vec3(0.0,1.0,0.0); h.cell=ivec2(floor(ro.xz)); h.sky=false;
  ivec2 cell=ivec2(floor(ro.xz));
  vec2 drd=1.0/max(abs(rd.xz),vec2(1e-5));
  ivec2 stp=ivec2(rd.x<0.0?-1:1, rd.z<0.0?-1:1);
  vec2 sideT=(vec2(cell)+max(vec2(stp),0.0)-ro.xz)/(rd.xz+1e-9);
  if(natatoriumMetricActive())sideT.y=metricNextZ(cell,stp,ro,rd);
  bool enterBorrowedInterior = rayEntersBorrowedInterior(ro, rd);
  Cell cur=cellShapeAtI(cell, enterBorrowedInterior);
  float tEnter=0.0;
  for(int i=0;i<48;i++){
    if(i>=steps) break;
    bool xSide=sideT.x<sideT.y;
    float tExit=min(sideT.x,sideT.y);
    if(!cur.solid){
      if(rd.y<-1e-4){
        float tf=(cur.f-ro.y)/rd.y;
        if(tf>=tEnter&&tf<=tExit){h.hit=true;h.t=tf;h.surf=2;h.n=vec3(0.0,1.0,0.0);h.cell=cell;h.sky=(cur.flags&FLAG_SKY)!=0;return h;}
      }
      if(rd.y>1e-4&&(cur.flags&FLAG_SKY)==0){
        float tc=(cur.c-ro.y)/rd.y;
        if(tc>=tEnter&&tc<=tExit){h.hit=true;h.t=tc;h.surf=3;h.n=vec3(0.0,-1.0,0.0);h.cell=cell;return h;}
      }
    }
    ivec2 nxt=xSide?ivec2(cell.x+stp.x,cell.y):ivec2(cell.x,cell.y+stp.y);
    Cell nc=cellShapeAtI(nxt, enterBorrowedInterior);
    float yB=ro.y+rd.y*tExit;
    bool wall=nc.solid?(yB>=cur.f-.001&&yB<=cur.c+.001):(yB<nc.f||(yB>nc.c&&(nc.flags&FLAG_SKY)==0));
    if(wall){
      h.hit=true;h.t=tExit;h.surf=1;h.n=xSide?vec3(float(-stp.x),0.0,0.0):vec3(0.0,0.0,float(-stp.y));
      h.cell=nc.solid?cell:nxt;h.sky=((nc.solid?cur.flags:nc.flags)&FLAG_SKY)!=0;return h;
    }
    cell=nxt;cur=nc;tEnter=tExit;
    if(xSide)sideT.x+=drd.x;else sideT.y=natatoriumMetricActive()?metricNextZ(cell,stp,ro,rd):sideT.y+drd.y;
  }
  return h;
}
// Light arriving at a point the water shows: the room's ambient, every lamp in
// reach and the torch, with no shadow walk.
vec3 waterSeenLight(vec3 pM, vec3 n, bool sky, float place){
  // The same falling ambient the eye's own surfaces get, measured over the
  // whole path from the eye, so a tile under water is no brighter than its
  // dry neighbour.
  float reach=sky?400.0:mix(3.5,9.0,clamp(uAmbientIntensity*place*26.0,0.0,1.0));
  float fall=1.0/(1.0+length(pM-uCam*CELL_METERS)/max(.75,reach));
  vec3 light=uAmbientColor*(uAmbientIntensity*place*mix(uAmbientFloor,1.0,fall*fall));
  for(int li=0;li<${MAX_LOCAL_LIGHTS};li++){
    if(li>=uLocalLightCount)break;
    vec3 delta=uLocalLightPos[li].xyz-pM;
    float d=length(delta),radius=max(.01,uLocalLightPos[li].w);
    float att=pow(clamp(1.0-d/radius,0.0,1.0),2.0)*localEmitterCone(li,-delta);
    float lam=max(dot(n,delta/max(d,1e-4)),0.0);
    if(att<=0.0||lam<=0.0)continue;
    // The basin walls stand between the deck lamps and the bottom of the bath.
    float vis=mix(architecturalLightVisibility(pM,uLocalLightPos[li].xyz),1.0,clamp(uLocalLightPenetration[li],0.0,1.0));
    light+=uLocalLightColor[li].rgb*uLocalLightColor[li].w*att*lam*vis;
  }
  vec3 toLamp=uTorchOrigin-pM;
  float beam=torchAngular(-toLamp,uTorchForward,uTorchRight,uTorchUp,uTorchCone,uTorchSpill)*uLight;
  light+=uTorchColor*torchReceive(max(dot(n,normalize(toLamp)),0.0)*torchFalloff(length(toLamp),uTorchReach)*3.0*beam,uTorchShoulder);
  if(sky)light+=vec3(0.092,0.110,0.150)*(0.34+0.66*clamp(n.y*.5+.5,0.0,1.0));
  return light;
}
// The pool hall's broken ceiling: above the fallen tiles is the slab's wet
// underside, crossed by the joists that carried the grid, and a raw plaster
// edge where the surviving tiles stop.
bool natatoriumSlabExposed(int zone, vec3 pM, int surf){
  return zone==${ZONE.natatorium}&&(surf==3||surf==1)&&pM.y>9.56;
}
vec3 natatoriumSlab(vec3 pM, int surf){
  float stain=vnoise(pM.xz*1.7,1.0,21.0);
  vec3 c=mix(vec3(.085,.09,.085),vec3(.15,.15,.14),stain);
  if(surf==3){
    float joist=1.0-smoothstep(.05,.11,abs(fract(pM.x/1.2)-.5)*1.2);
    c=mix(c,vec3(.035),joist);
  }else{
    c=mix(vec3(.34,.33,.31),c,smoothstep(9.58,9.72,pM.y));
  }
  return c;
}
// Where the ripples gather light and where they spread it, from the curvature
// of the same height field the surface is drawn with. Crests focus, troughs
// scatter: the moving netting on a pool floor.
float waterCaustic(vec2 p){
  if(!inWaterBounds(p))return 1.0;
  // Two texels apart: a one-texel stencil reads the wave equation's odd/even
  // texel mode, which is invisible as height but becomes a fine checker of
  // light the moment its curvature is amplified.
  vec2 uv=waterUv(p),tx=2.0*vec2(1.0/${WATER_W.toFixed(1)},1.0/${WATER_H.toFixed(1)});
  float c=texture(uWaterHeight,uv).r;
  float lap=texture(uWaterHeight,uv-vec2(tx.x,0.0)).r+texture(uWaterHeight,uv+vec2(tx.x,0.0)).r
           +texture(uWaterHeight,uv-vec2(0.0,tx.y)).r+texture(uWaterHeight,uv+vec2(0.0,tx.y)).r-4.0*c;
  float k=clamp(1.0-lap*28.0,.45,1.6);
  return k*k;
}
vec3 waterShadeSeen(WaterRay h, vec3 ro, vec3 rd){
  vec3 p=metricCellRayPoint(ro,rd,h.t),pM=p*CELL_METERS;
  Cell c=cellShapeAtI(h.cell);c.mat=MAT_SERVICE;c.place=1.0;cellMaterialAtI(h.cell,c);
  vec3 albedo=architecturalSurface(c.mat,h.surf,pM,h.n,materialBase(c.mat,h.surf,vec3(.62),vec3(.30,.36,.36),.5));
  // The same material bank tile the dry neighbour wears.
  if(h.surf!=3&&uSurfacesReady>.001){
    int sl;float tm,bl;vec2 suv=surfaceUv(h.surf,pM,h.n);
    surfaceSlot(c.mat,h.surf,suv,sl,tm,bl);
    albedo=mix(albedo,surfaceTile(sl,suv,tm),bl*uSurfacesReady);
  }
  if(natatoriumSlabExposed(c.zone,pM,h.surf))albedo=natatoriumSlab(pM,h.surf);
  // Outdoors a wall the water sees is a building face at night: a silhouette.
  if(h.sky&&h.surf==1)albedo=vec3(.07,.075,.08);
  return albedo*waterSeenLight(pM,h.n,h.sky,c.place);
}
// What the surface mirrors. A ray that leaves through open sky gets the same
// night the eye gets; indoors there is always a ceiling to find.
vec3 waterReflection(vec3 wp, vec3 R, bool sky){
  vec3 origin=metricCellOffset(wp,R,.02);
  WaterRay h=waterWalk(origin,R,40);
  if(!h.hit)return sky?nightSky(normalize(R)):vec3(0.0);
  return waterShadeSeen(h,origin,R);
}
// What lies under it, lit through the water and gathered by the ripples.
vec3 waterRefraction(vec3 wp, vec3 T, out float pathM){
  vec3 ro=metricCellOffset(wp,T,.02);
  WaterRay h=waterWalk(ro,T,24);
  if(!h.hit){pathM=4.0;return vec3(0.0);}
  pathM=h.t*CELL_METERS;
  vec3 canonicalHit=metricCellRayPoint(ro,T,h.t);
  vec3 pM=canonicalHit*CELL_METERS;
  float depthM=max(0.0,uWaterParams.y-pM.y);
  float absorb=mix(.35,2.6,clamp(uWaterParams.z,0.0,1.0));
  float caustic=mix(waterCaustic(canonicalHit.xz),1.0,uWaterParams.w);
  return waterShadeSeen(h,ro,T)*exp(-depthM*absorb)*mix(1.0,caustic,.85);
}
// Each lamp in the room, seen in the water: a tight bright image the ripples
// tear into streaks. The image of a lamp is the lamp, so it does not fade with
// the lamp's own reach, only with whether a wall stands between.
vec3 waterGlints(vec3 wpM, vec3 R){
  vec3 g=vec3(0.0);
  for(int li=0;li<${MAX_LOCAL_LIGHTS};li++){
    if(li>=uLocalLightCount)break;
    vec3 delta=uLocalLightPos[li].xyz-wpM;
    float s=pow(max(dot(R,normalize(delta)),0.0),220.0);
    if(s<.002)continue;
    g+=uLocalLightColor[li].rgb*uLocalLightColor[li].w*s*architecturalLightVisibility(wpM,uLocalLightPos[li].xyz)*1.6;
  }
  return g;
}
// Light that strikes the water and comes back up: the netting on the ceiling
// and walls over a lit pool. Mostly the torch, which is the light that moves.
vec3 waterBounceLight(vec3 pM, vec3 n){
  vec2 pc=pM.xz/CELL_METERS;
  if(!inWaterBounds(pc)||pM.y<uWaterParams.y+.05||uWaterCamera.x>.5)return vec3(0.0);
  vec3 wM=vec3(pM.x,uWaterParams.y,pM.z);
  vec3 toLamp=uTorchOrigin-wM;
  float beam=torchAngular(-toLamp,uTorchForward,uTorchRight,uTorchUp,uTorchCone,uTorchSpill)*uLight;
  float lit=beam*torchFalloff(length(toLamp),uTorchReach)*max(normalize(toLamp).y,0.0);
  vec3 incoming=uTorchColor*lit*1.4+waterSeenLight(wM,vec3(0.0,1.0,0.0),false,1.0)*.35;
  float caustic=mix(waterCaustic(pc),1.0,uWaterParams.w);
  float spread=1.0/(1.0+(pM.y-uWaterParams.y)*.30);
  return incoming*max(caustic-.55,0.0)*.30*spread*(.35+.65*clamp(-n.y*.5+.5,0.0,1.0));
}

${B3_GLASS_GLSL}
void main(){
  vec2 uv = (gl_FragCoord.xy / uRes) * 2.0 - 1.0;
  uv.x *= uRes.x / uRes.y;
  float cy = cos(uYaw), sy = sin(uYaw);
  vec3 fwd = cameraForward(uYaw,uPitch);
  vec3 rgt = normalize(vec3(cy, 0.0, sy));
  vec3 up  = normalize(cross(rgt, fwd));
  // FOV. Anything tighter than this and a real building feels like a coffin:
  // you cannot see the floor at your feet or the ceiling above you at once.
  vec3 rd = normalize(fwd + uv.x*rgt*uCameraTanHalfFov + uv.y*up*uCameraTanHalfFov);
  vec3 ro = uCam;
  bool enterBorrowedInterior = rayEntersBorrowedInterior(ro, rd);

  // SECTOR TRAVERSAL. Each cell carries its own floor and ceiling height, so a
  // stair is a run of cells whose floors climb, and the chapel is a cell whose
  // ceiling is eleven metres up. Doom solved this in 1993; the DDA below is the
  // same idea with the ray clipped against the current cell's two planes, plus
  // three kinds of wall at each boundary:
  //
  //   full  — the next cell is rock
  //   riser — the next floor is above the ray (a step up, a stage, a kerb)
  //   header— the next ceiling is below the ray (a lintel, a low duct)
  //
  // Wall normals come from the DDA's entry face, never from fract(pos): that
  // was the salt-and-pepper flicker.
  float MAXD = (natatoriumMetricActive()?320.0:90.0) / CELL_METERS;
  float tHit = -1.0;
  int surf = 0;                 // 1 wall · 2 floor · 3 ceiling
  int hitZone = 0;
  int hitMat = MAT_SERVICE;
  // The baked ambient of the cell the ray actually lands in, captured with the
  // hit like zone and material rather than re-fetched during shading.
  float hitPlace = 1.0;
  // Whether the surface we ended up on stands under open sky. Ambient falloff is
  // an indoor model and has to be switched off out there — see below.
  bool  hitSky = false;
  bool sourceApertureSky = false;
  vec3 n = vec3(0.0, 1.0, 0.0);

  ivec2 cell = ivec2(floor(ro.xz));
  Cell eyeCell=cellShapeAtI(cell, enterBorrowedInterior);
  // SKY on the camera cell is the floorplan's semantic statement that the
  // player is standing in the weather. It gates full-frame rain to the road,
  // yard and open apron without leaking it into the chapel's broken pane or an
  // interior skylight merely because this particular ray happens to see sky.
  // Pub SKY belongs only to its mesh render underlay; its actual room is dry.
  bool cameraInWeather=uUsePlan>.5&&(eyeCell.flags&FLAG_SKY)!=0&&eyeCell.zone!=${ZONE.pub}&&eyeCell.zone!=${ZONE.stationers};
  vec2 drd = 1.0 / max(abs(rd.xz), vec2(1e-5));
  ivec2 stp = ivec2(rd.x < 0.0 ? -1 : 1, rd.z < 0.0 ? -1 : 1);
  vec2 sideT = (vec2(cell) + max(vec2(stp), 0.0) - ro.xz) / (rd.xz + 1e-9);
  if(natatoriumMetricActive())sideT.y=metricNextZ(cell,stp,ro,rd);

  Cell cur = eyeCell;
  float tEnter = 0.0;
  // Where the ray stopped, so its material can be read once after the loop.
  ivec2 hitCell = cell;
  bool hitLeaf = false;

  // The step count is explicit because the open-ground walk below spends steps
  // too: the 192-cell budget, and so the picture, are exactly what they were.
  int marchStep = 0;
  ivec2 eyeLocal = cell - ivec2(uPlanOrigin);
  bool eyeOnPlan = uUsePlan > 0.5 && eyeLocal.x >= 0 && eyeLocal.y >= 0
    && eyeLocal.x < int(uPlanSize.x) && eyeLocal.y < int(uPlanSize.y);
  for(int guard = 0; guard < 192; guard++){
    if(marchStep >= 192 || tEnter > MAXD) break;
    // A Source aperture borrows Ellery's plan but opens onto no town or sky.
    // Retain that boundary only for rays which actually enter its sky cells.
    if(!cur.solid && (cur.flags & FLAG_SKY) != 0 && cur.zone == ${ZONE.sourceSpace}) sourceApertureSky = true;
    // ACROSS OPEN GROUND WITHOUT LOOKING.
    //
    // Inside an open square (planSkipField), a ray that stays above its highest
    // floor, and below its ceiling when it has one, can hit nothing: no floor, no
    // ceiling, no riser, no header, no wall, no water. So it takes those steps
    // with the very same DDA arithmetic and none of the reads or tests, for as
    // long as it stays clear, and the cell it stops in is read and tested as
    // usual. The margin is half a millimetre, far wider than the rounding in
    // the tests it stands in for. Rays that start near the floor at the feet are
    // left alone; they stop long before this would pay.
    float openFloor = 0.0;
    int openRadius = marchStep >= 2 ? cellOpenRadiusI(cell, openFloor) : 0;
    // OFF THE PLAN THERE IS NOTHING LEFT TO MEET. A ray that set out on the plan
    // and has left its rectangle cannot come back, and out there every cell is
    // open sky over a floor a kilometre down — reachable only by a ray so steep
    // it could never have crossed a cell to get there inside MAXD.
    if(openRadius < 0 && eyeOnPlan) break;
    bool openSky = (cur.flags & FLAG_SKY) != 0;
    float yNow = ro.y + rd.y * tEnter;
    if(openRadius > 0 && yNow > openFloor + 1e-3 && (openSky || yNow < cur.c - 1e-3)){
      ivec2 sqLo = cell - ivec2(openRadius), sqHi = cell + ivec2(openRadius);
      // Where the ray would come within the margin of this square's floor or
      // ceiling. A cell is only crossed blind if the ray leaves it before then.
      float tClear = 1e30;
      if(rd.y < 0.0) tClear = (openFloor + 1e-3 - ro.y) / rd.y;
      else if(rd.y > 0.0 && !openSky) tClear = (cur.c - 1e-3 - ro.y) / rd.y;
      bool walked = false;
      for(int k = 0; k < 192; k++){
        bool xs = sideT.x < sideT.y;
        ivec2 ahead = xs ? ivec2(cell.x + stp.x, cell.y) : ivec2(cell.x, cell.y + stp.y);
        if(any(lessThan(ahead, sqLo)) || any(greaterThan(ahead, sqHi))) break;
        if(min(sideT.x, sideT.y) >= tClear) break;
        tEnter = min(sideT.x, sideT.y);
        cell = ahead;
        if(xs) sideT.x += drd.x; else sideT.y=natatoriumMetricActive()?metricNextZ(cell,stp,ro,rd):sideT.y+drd.y;
        walked = true;
        marchStep++;
        if(marchStep >= 192 || tEnter > MAXD) break;
      }
      if(marchStep >= 192 || tEnter > MAXD) break;
      if(walked) cur = cellShapeAtI(cell, enterBorrowedInterior);
    }
    bool xSide = sideT.x < sideT.y;
    float tExit = min(sideT.x, sideT.y);

    if(!cur.solid){
      if(inWaterBounds(vec2(cell) + 0.5) && cellIsWet(cell, cur) && abs(rd.y) > 1e-4){
        float waterY = (uWaterParams.y / CELL_METERS) + waterHeightAt(vec2(cell) + 0.5);
        float tw = (waterY - ro.y) / rd.y;
        // Standing water only stands where the floor is below it: rainwater in
        // a sloping sump feathers out instead of floating over the dry tiles.
        if(waterY > cur.f + 1e-3 && tw >= tEnter && tw <= tExit){
          vec3 wp = metricCellRayPoint(ro,rd,tw);
          if(inWaterBounds(wp.xz)){
            tHit = tw; surf = 4; n = vec3(0.0, ro.y<waterY?-1.0:1.0, 0.0); hitZone = cur.zone; hitCell = cell; hitSky = (cur.flags & FLAG_SKY) != 0; break;
          }
        }
      }
      // the floor of the cell you are crossing
      if(rd.y < -1e-4){
        float tf = (cur.f - ro.y) / rd.y;
        if(tf >= tEnter && tf <= tExit){
          tHit = tf; surf = 2; n = vec3(0.0, 1.0, 0.0); hitZone = cur.zone; hitCell = cell; hitSky = (cur.flags & FLAG_SKY) != 0; break;
        }
      }
      // and its ceiling, unless it is open to the dark
      if(rd.y > 1e-4 && (cur.flags & FLAG_SKY) == 0){
        float tc = (cur.c - ro.y) / rd.y;
        if(tc >= tEnter && tc <= tExit){
          tHit = tc; surf = 3; n = vec3(0.0, -1.0, 0.0); hitZone = cur.zone; hitCell = cell; hitSky = (cur.flags & FLAG_SKY) != 0; break;
        }
      }
    }

    ivec2 nxt = xSide ? ivec2(cell.x + stp.x, cell.y) : ivec2(cell.x, cell.y + stp.y);
    Cell nc = cellShapeAtI(nxt, enterBorrowedInterior);
    float yB = ro.y + rd.y * tExit;
    vec3 wn = xSide ? vec3(float(-stp.x), 0.0, 0.0) : vec3(0.0, 0.0, float(-stp.y));

    // Door collision remains in the logical grid, but the visible leaf is a
    // textured mesh in the depth pass. Treating CLOSED as architecture made a
    // one-cell masonry slab appear in front of that model, with walkable-looking
    // slots at both jambs.
    bool closedLeaf = false;
    bool wall = false;
    if(nc.solid || closedLeaf){
      wall = (yB >= cur.f - 0.001 && yB <= cur.c + 0.001);
    } else {
      if(yB < nc.f) wall = true;                                      // riser
      else if(yB > nc.c && (nc.flags & FLAG_SKY) == 0) wall = true;   // header
    }
    if(wall && tExit <= MAXD){
      tHit = tExit; surf = 1; n = wn;
      hitZone = nc.solid ? cur.zone : nc.zone;
      // A wall belongs to the room you are standing in, not the rock behind it.
      hitCell = nc.solid ? cell : nxt;
      hitLeaf = closedLeaf;
      hitSky = ((nc.solid ? cur.flags : nc.flags) & FLAG_SKY) != 0;
      break;
    }

    cell = nxt; cur = nc; tEnter = tExit;
    if(xSide) sideT.x += drd.x; else sideT.y=natatoriumMetricActive()?metricNextZ(cell,stp,ro,rd):sideT.y+drd.y;
    marchStep++;
  }
  if(surf != 0){
    Cell hitCellMaterial = cur;
    hitCellMaterial.mat = MAT_SERVICE; hitCellMaterial.place = 1.0;
    cellMaterialAtI(hitCell, hitCellMaterial);
    hitMat = hitLeaf ? MAT_DOOR : hitCellMaterial.mat;
    hitPlace = hitCellMaterial.place;
  }

  // The native relief supplies geometry, not a painted head. Retain the
  // actual receiving wall's material coordinates and sample its new depth
  // before light, reflection, shadow or acquisition are evaluated.
  float receiverTHit=tHit;
  vec3 receiverNormal=n,reliefNormal=n;
  bool anatomicalRelief=false;
  if(uStillnessState.x>.00001&&uStillnessTreatment>.5&&uStillnessTreatment<1.5&&uPropsReady>.5&&tHit>=0.0&&surf==1&&!hitLeaf){
    ivec2 pixel=ivec2(gl_FragCoord.xy);
    vec4 proxy=texelFetch(uPropColor,pixel,0),proxyData=texelFetch(uPropDepth,pixel,0);
    if(stillnessReliefProxyTag(proxy.a)>.5&&int(floor(proxyData.a*255.0+.5))==hitMat){
      float d=unpackPropWorldDepth(proxyData.rgb),ndc=d*2.0-1.0;
      float viewM=(2.0*uPropNear*uPropFar)/(uPropFar+uPropNear-ndc*(uPropFar-uPropNear));
      float cosine=max(.001,dot(rd,fwd));
      float wallView=tHit*CELL_METERS*cosine;
      if(d<.999999&&viewM<=wallView+.008&&wallView-viewM<.65){
        reliefNormal=stillnessReliefDecodeNormal(proxy.rgb);
        if(dot(reliefNormal,receiverNormal)<0.0)reliefNormal=-reliefNormal;
        tHit=viewM/(CELL_METERS*cosine);anatomicalRelief=true;
      }
    }
  }

  vec3 col;
  float academicRoofPaneTransmission=0.0;
  // Stable sensor grain. The previous time-offset hash made stationary walls
  // sparkle even when no authored effect was changing.
  float grain = hash01(gl_FragCoord.x, gl_FragCoord.y);
  if(tHit < 0.0){
    // THE RAY LEFT THE BUILDING.
    //
    // For most of this game's life that could only happen over a bricked lift
    // shaft, so it returned a two-stop black and the comment said "nothing to
    // see up there", which was true. The loading bay opens west onto the yard,
    // and it is the first time anything here looks outward — so this is now a
    // sky, and it is the one in the cold open: half nine at night, raining, a
    // condemned site on the edge of a town that still has its lights on.
    //
    // Source Space and the procedural sample field keep the void. They are not
    // outdoors; they are nowhere, and a horizon would say the wrong thing.
    if(uUsePlan < 0.5){
      float g = clamp(rd.y * 0.5 + 0.5, 0.0, 1.0);
      col = mix(vec3(0.040, 0.043, 0.050), vec3(0.010, 0.010, 0.014), g);
      col += texture(uRD, rd.xz * 0.4 + uTime * 0.004).g * 0.012;
    } else {
      // ONE CALL. Everything that used to be inlined here — the deck, the
      // moon, the skyline, the streets — lives in nightSky() now, so the wet
      // ground can ask for the same sky it is reflecting. See the sheen below.
      vec3 dir = normalize(rd);
      col = sourceApertureSky ? vec3(0.0) : nightSky(dir);

    }
  } else {
    vec3 pos = metricCellRayPoint(ro,rd,tHit);
    vec3 posM = pos * CELL_METERS;
    vec3 receiverPlanePoint=metricCellRayPoint(ro,rd,receiverTHit)*CELL_METERS;
    vec3 receiverPosM=anatomicalRelief?posM-receiverNormal*dot(posM-receiverPlanePoint,receiverNormal):posM;
    vec3 roM = ro * CELL_METERS;
    bool brendanStone=uUsePlan>.5&&hitZone==${ZONE.church}&&hitMat==MAT_CHAPEL&&surf!=4;
    bool sourceMaterial=isSourceMaterial(hitMat);
    bool sourceVoidMaterial=hitMat==MAT_SOURCE_VOID;
    bool ordinaryLightTreatment=uWorldLightTreatment>1.5&&!sourceMaterial&&!sourceVoidMaterial&&surf!=4;
    // Architecture is differentiated by material and light, never by the old
    // zone-navigation colors. The procedural audio lab may keep its world tint.
    vec3 tint = (uUsePlan > 0.5) ? vec3(0.62) : uWorldTint[int(worldIdx(pos.xz))];

    // The biome reaches the picture only through the fallback floor material;
    // water, walls, Source glyphs and roof glass do not use it. Chunk glow is
    // independent and still reaches every non-water material when active.
    vec3 biome = vec3(0.30, 0.36, 0.36);
    float bw = 0.0;
    vec3 glow = vec3(0.0);
    bool needBiome=surf==2&&!sourceMaterial&&!sourceVoidMaterial&&hitMat!=MAT_ROOF_GLASS&&!brendanStone;
    bool needChunkGlow=surf!=4&&uChunkGlowReady>.5;
    if(needBiome||needChunkGlow){
      for(int i = 0; i < ${MAX_CHUNKS}; i++){
        if(i >= uChunkCount) break;
        if(!needBiome&&uChunkA[i].w==0.0)continue;
        vec2 d = pos.xz - uChunkA[i].xy;
        float dd = dot(d,d);
        if(needBiome){
          float w = exp(-dd / max(uChunkA[i].z*uChunkA[i].z, 1.0));
          biome += uChunkC[i] * w; bw += w;
        }
        if(needChunkGlow&&uChunkA[i].w != 0.0)
          glow += uChunkC[i] * exp(-(dd * CELL_METERS * CELL_METERS) * 0.09) * uChunkA[i].w * (0.9 + 0.4 * sin(uTime * 1.7 + float(i) * 1.3));
      }
      if(needBiome)biome /= (1.0 + bw);
    }

    // reaction-diffusion skin, planar-mapped per surface so the crawl never
    // smears into streaks: floors/ceilings by xz, wall faces by their own plane.
    // Walls sample at low frequency (their UVs are magnified up close, and the
    // Gray-Scott field is pixel-fine — sampling it tight is pure salt-and-pepper).
    // The authored conservatory has real surface textures. Reaction-diffusion
    // belongs to the sample-field lab; on architecture it reads as rolling fog bands.
    float rdv=.5, rim=0.0;
    if(uUsePlan<=.5){
      vec2 rdUv = (surf == 1)
        ? vec2(mix(posM.z, posM.x, abs(n.z)), posM.y) * 0.030
        : posM.xz * 0.05;
      rdv = texture(uRD, rdUv).g;
      float rdv2 = texture(uRD, rdUv * 0.28 + uTime * 0.002).g;
      rdv = max(rdv, rdv2 * 0.85);
      if(surf == 1) rdv = mix(0.5, rdv, 0.45);   // mottling on walls, not marble
      rim = smoothstep(0.16, 0.32, rdv) - smoothstep(0.32, 0.58, rdv);
    }

    // Procedural courses are fallback geometry only. Drawing them over real
    // PBR mortar/board joints produces the wireframe bands visible at grazing
    // angles.
    float seam = 0.0;

    // PBR surface relief: perturb the face normal by the surface's normal map so
    // brick mortar, wood grain and tile bevels catch the flashlight, and take the
    // per-texel roughness for the specular term. Sampled BEFORE lighting so the
    // Lambert term below sees the bumped normal.
    float surfRough = -1.0, surfaceOcclusion=1.0;
    vec3 stillnessSubstrateNormal=n;
    bool pbrReady=false;int pbrSlot=0;float pbrTile=1.0,pbrBlend=0.0;vec2 pbrUv=vec2(0.0);
    vec3 toEye = ro - pos;
    vec3 toEyeM = roM - posM;
    float sourceHeight=0.0;
    if(sourceMaterial){
      // Only Source's glyph material consumes this layer. Avoid a plan-texture
      // fetch and its UV work on every ordinary wall and floor pixel.
      vec2 sourceUv=surfaceUv(surf,receiverPosM,receiverNormal)*vec2(.34,.46);
      float sourceLayer=clamp(sourceLayerAt(pos.xz)-1.0,0.0,7.0);
      sourceUv=vec2(sourceUv.x,fract(sourceUv.y)/8.0+sourceLayer/8.0);
      sourceHeight=sourceGlyph(sourceUv);
      gMark=vec4(0.0);gMarkBlend=0.0;
      gMarkPlane=printedSurfaceTag(sourceInkCoverage(sourceUv),2.0);
      float eps=1.0/2048.0;
      vec2 grad=vec2(
        sourceGlyph(sourceUv+vec2(eps,0.0))-sourceGlyph(sourceUv-vec2(eps,0.0)),
        sourceGlyph(sourceUv+vec2(0.0,eps))-sourceGlyph(sourceUv-vec2(0.0,eps))
      );
      vec3 T=(surf==1)?normalize(vec3(-n.z,0.0,n.x)):vec3(1.0,0.0,0.0);
      vec3 B=(surf==1)?vec3(0.0,1.0,0.0):vec3(0.0,0.0,1.0);
      n=normalize(n+T*grad.x*1.8+B*grad.y*1.8);
      surfRough=mix(.96,.48,smoothstep(.08,.82,sourceHeight));
      surfaceOcclusion=mix(.58,1.0,sourceHeight);
    } else if(!sourceVoidMaterial && !brendanStone && hitMat!=MAT_ROOF_GLASS && uSurfacesReady > 0.001 && surf != 3 && surf != 4){
      int sslot; float stile, sblend;
      vec2 suv = surfaceUv(surf,receiverPosM,receiverNormal);
      // Read off the SAME normal surfaceUv just used. The normal map perturbs n
      // below, and a plane chosen from the perturbed one would disagree with the
      // UVs the grain was measured in.
      gMarkPlane=surf!=1?0.0:(abs(receiverNormal.x)>.5?0.5:1.0);
      surfaceSlot(hitMat, surf, suv, sslot, stile, sblend);
      vec3 sc = vec3(suv / stile, float(sslot));
      // Texture coordinates remain fixed to the authoritative world plane.
      // Height still supplies occlusion and reinforces the normal response,
      // but it must not slide the material under the camera: that made a wall
      // change direction and texture density merely because the player turned.
      vec3 T = (surf == 1) ? normalize(vec3(-n.z, 0.0, n.x)) : vec3(1.0, 0.0, 0.0);
      if(dot(T, T) < 0.01) T = vec3(1.0, 0.0, 0.0);
      vec3 B = (surf == 1) ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0);
      vec2 scDx=dFdx(sc.xy),scDy=dFdy(sc.xy);
      vec2 material=textureGrad(uSurfMaterial,sc,scDx,scDy).rg;
      float h0=material.g;
      vec3 nm = textureGrad(uSurfNormal,sc,scDx,scDy).rgb * 2.0 - 1.0;
      surfRough = material.r;
      if(hitMat==MAT_PAVING&&surf==2){
        // The stone's own relief is grain; the flag joints are 4 mm grooves.
        const float e=.008;
        float j0=yorkstoneFlags(posM.xz).y;
        vec2 slope=vec2(yorkstoneFlags(posM.xz+vec2(e,0.0)).y-j0,yorkstoneFlags(posM.xz+vec2(0.0,e)).y-j0)/e;
        nm.xy=nm.xy*.35+slope*.004;
      }
      // The native reaction field and generated detail participate in the
      // physical response, not only in albedo. Geometry remains a flat,
      // authoritative collision plane; only micro-normal and roughness move.
      vec4 slotResponse=dreamSlotResponse(sslot);
      vec2 materialRdUv=fract(suv/(stile*3.6)+vec2(float(sslot)*.071,float(sslot)*.113));
      float materialRd=texture(uRD,materialRdUv).g-.5;
      // RELIEF IS THE REAL CHANNEL. Albedo changes are luminance-pinned upstream
      // and then point-sampled away by the VFD cell grid, but a change in the
      // surface NORMAL changes how the torch strikes it — which moves shading,
      // which moves edges, and edges are what this display is built to draw.
      // So the generated tile is read as a height field and differentiated.
      //
      // The layer index must follow the boil layout (slot*K + frame); reading
      // float(sslot) here sampled a different material's tile entirely.
      float dFrames=max(1.0,uDreamFramesA);
      float dPhase=0.0;
      if(uBoilHz>0.0001&&dFrames>1.5){
        float dJit=fract(sin(dot(floor(suv*11.0),vec2(12.9898,78.233)))*43758.5453);
        dPhase=uTime*uBoilHz*(1.0+uAgitation*1.4)+dJit*1.37;
      }
      float dBase=float(sslot)*dFrames;
      float dLayer=dBase+mod(floor(dPhase),dFrames);
      vec3 dc=vec3(sc.xy,dLayer);
      vec2 dtex=vec2(1.0/512.0,0.0);
      float dl=dot(textureGrad(uSurfDream,dc-vec3(dtex.x,0.0,0.0),scDx,scDy).rgb,vec3(.2126,.7152,.0722));
      float dr=dot(textureGrad(uSurfDream,dc+vec3(dtex.x,0.0,0.0),scDx,scDy).rgb,vec3(.2126,.7152,.0722));
      float dd=dot(textureGrad(uSurfDream,dc-vec3(0.0,dtex.x,0.0),scDx,scDy).rgb,vec3(.2126,.7152,.0722));
      float du=dot(textureGrad(uSurfDream,dc+vec3(0.0,dtex.x,0.0),scDx,scDy).rgb,vec3(.2126,.7152,.0722));
      vec2 dreamSlope=vec2(dr-dl,du-dd);
      // Agitation deepens the relief rather than merely tinting it: a boiling
      // wall should catch the light differently, not just read a shade darker.
      float reliefGain=uDreamNormalResponse*(1.0+uAgitation*2.2)*(1.0+uDreamStructureMix*1.6);
      nm.xy+=dreamSlope*reliefGain*slotResponse.w*14.0*uSurfacesReady;
      nm.xy+=materialRd*uLocalDiffusion*uDreamNormalResponse*slotResponse.w*uSurfacesReady;
      // Generated detail also roughens and polishes the surface, so the torch's
      // specular lobe crawls across it as the boil advances.
      float dreamRough=(dr+dl+du+dd)*.25-.5;
      surfRough=clamp(surfRough
        +(dreamRough*uDreamRoughnessResponse*(1.0+uAgitation*1.8)*slotResponse.z*2.2
        +materialRd*uLocalDiffusion*uDreamRoughnessResponse*slotResponse.z)*uSurfacesReady,0.04,1.0);
      n = normalize(n + (T * nm.x + B * nm.y) * 0.58);
      surfaceOcclusion=mix(1.0,mix(.68,1.0,smoothstep(.12,.88,h0)),uSurfacesReady);
      // THE RAMP IS THE BLEND. At 0 this leaves pbrBlend at zero and the albedo
      // below is exactly the procedural fallback; at 1 it is exactly the bank.
      // Only the journey between them is new.
      pbrReady=true;pbrSlot=sslot;pbrTile=stile;pbrBlend=sblend*uSurfacesReady;pbrUv=sc.xy*stile;
    }
    if(surf == 4){
      vec2 wuv=waterUv(pos.xz);
      // Two texels either side: the slope of the waves, not of the grid's
      // odd/even mode, which a one-texel difference turned into glitter grit.
      vec2 texel=2.0*vec2(1.0/${WATER_W.toFixed(1)},1.0/${WATER_H.toFixed(1)});
      float hL=texture(uWaterHeight,clamp(wuv-vec2(texel.x,0.0),vec2(0.0),vec2(1.0))).r;
      float hR=texture(uWaterHeight,clamp(wuv+vec2(texel.x,0.0),vec2(0.0),vec2(1.0))).r;
      float hD=texture(uWaterHeight,clamp(wuv-vec2(0.0,texel.y),vec2(0.0),vec2(1.0))).r;
      float hU=texture(uWaterHeight,clamp(wuv+vec2(0.0,texel.y),vec2(0.0),vec2(1.0))).r;
      float waterSide=uWaterCamera.x>.5?-1.0:1.0;
      n=normalize(vec3(-(hR-hL)*1.6,waterSide,-(hU-hD)*1.6));
    }
    if(!pbrReady&&!sourceMaterial&&!brendanStone)seam=materialSeam(hitMat,surf,posM,n);
    if(brendanStone)surfRough=.94;
    if(anatomicalRelief)n=normalize(reliefNormal+(n-receiverNormal));

    // Surface-bound relief participates in the existing light and acquisition.
    // Water/glazing and the supported collision planes retain their own form.
    vec4 stillFace=vec4(0.0);
    if(uStillnessTreatment<.5&&uStillnessState.x>.001&&surf!=3&&surf!=4&&hitMat!=MAT_ROOF_GLASS){
      stillFace=stillnessFaceRelief(posM,stillnessSubstrateNormal);
      n=normalize(mix(n,stillnessSubstrateNormal,smoothstep(.06,.75,stillFace.w)));
      stillnessFaceNormal(n,posM,stillFace);
    }
    // Distances and view reflection remain camera-relative. Illumination and
    // shadow projection use the same carried emitter in world metres.
    float dist=length(toEyeM);
    vec3 toLamp=uTorchOrigin-posM,ldir=normalize(toLamp);
    float lambert=max(dot(n,ldir),0.0);
    float falloff=torchFalloff(length(toLamp),uTorchReach);
    float axis=dot(normalize(-toLamp),uTorchForward);
    float cone=smoothstep(uTorchCone.x,uTorchCone.y,axis);
    float beam=torchAngular(-toLamp,uTorchForward,uTorchRight,uTorchUp,uTorchCone,uTorchSpill)*uLight;
    float propShadow=(beam>0.0&&uLocalShadowIndex<0)?propFlashShadow(posM,n,ldir):1.0;
    float lamp=torchReceive(lambert*falloff*3.0*beam*propShadow,uTorchShoulder);
    // THE FIGURES MUST BLOCK THE WHOLE RED FIELD, NOT ONE LAMP OF FIVE.
    //
    // The shadow map belongs to a single hero practical, and the silhouette used
    // to be applied only to that lamp's own contribution. In the concert hall
    // five emergency lamps overlap, so removing one of five was a twenty-percent
    // dip — the apparitions were being submitted, the shadow pass was running,
    // and there was simply nothing on screen to see. Measured: figures 3,
    // shadow.active true, and no visible body.
    //
    // One shadow map, sampled once, applied to every emergency contribution. It
    // is not what five lamps would really do, but the room only has one red in
    // it and a body standing in that red blocks it. Nothing else is touched, so
    // ordinary fittings and the torch keep their honest single-source shadows.
    //
    float heroShadow=1.0,apparitionBody=0.0,apparitionHalo=0.0;
    if(uLocalShadowIndex>=0){
      vec3 heroDir=normalize(uLocalLightPos[uLocalShadowIndex].xyz-posM);
      // The ordinary 2x2 sample supplies a coherent core. Most of the field
      // comes from wide taps, so the body's outer several texels recede into
      // the wall instead of describing a hard, lit human cutout.
      float heroLit=clamp((propFlashShadow(posM,n,heroDir)-.20)/.80,0.0,1.0);
      float sharpBody=1.0-heroLit;
      float wideBody=propFlashHalo(posM,n,heroDir);
      apparitionBody=mix(sharpBody,wideBody,.72);
      heroShadow=1.0-.985*apparitionBody;
      apparitionHalo=max(wideBody-sharpBody,0.0);
    }
    vec3 localLight=academicAtriumSurfaceLight(posM,n);
    vec3 emergencyLight=vec3(0.0);
    // What the red WOULD have delivered here with nothing standing in the way.
    // The cool veil below is gated by this and by nothing else: no lamp
    // reaching a surface means no cast presence on that surface.
    vec3 emergencyReach=vec3(0.0);
    for(int li=0;li<${MAX_LOCAL_LIGHTS};li++){
      if(li>=uLocalLightCount)break;
      vec3 delta=uLocalLightPos[li].xyz-posM;
      float localDistance=length(delta),radius=max(.01,uLocalLightPos[li].w);
      float attenuation=pow(clamp(1.0-localDistance/radius,0.0,1.0),2.0)*localEmitterCone(li,-delta);
      float localLambert=max(dot(n,normalize(delta)),0.0);
      // A lamp out of reach, or behind the surface, adds exactly nothing here,
      // so it does not need the walk below that asks whether a wall is in the
      // way. That walk is up to seven plan reads per lamp per pixel.
      if(attenuation<=0.0||localLambert<=0.0)continue;
      float emergency=clamp(uLocalLightEmergency[li],0.0,1.0);
      float localShadow=max(float(li==uLocalShadowIndex),emergency)>.5?heroShadow:1.0;
      float architecturalShadow=(ordinaryLightTreatment&&emergency<.5)?architecturalLightVisibility(posM,uLocalLightPos[li].xyz):legacyArchitecturalLightVisibility(posM,uLocalLightPos[li].xyz);
      architecturalShadow=mix(architecturalShadow,1.0,clamp(uLocalLightPenetration[li],0.0,1.0));
      vec3 unshadowed=uLocalLightColor[li].rgb*uLocalLightColor[li].w*attenuation*localLambert*architecturalShadow;
      vec3 contribution=unshadowed*localShadow;
      localLight+=contribution;
      emergencyLight+=contribution*emergency;
      emergencyReach+=unshadowed*emergency;
    }
    // The red field loses energy over the wide shadow; a restrained cool veil
    // gives that absence shape on dark receiving surfaces. Keep it fractional
    // and below the lamp, so the final one-bit capture sees an eminence rather
    // than turning the body back into a white cutout. Reach is a gate: a body
    // cannot appear as a decal on a surface the emergency circuit never lit.
    float apparitionReach=max(max(emergencyReach.r,emergencyReach.g),emergencyReach.b);
    float apparitionLit=smoothstep(.06,.40,apparitionReach);
    // Fractional occlusion stays fractional. The former .45 power promoted
    // even a one-texel edge to almost-full white.
    float apparitionInk=pow(apparitionBody,1.10);
    vec3 apparitionVeil=vec3(.67,.72,.78)*apparitionInk*apparitionLit*.46;
    vec3 apparitionGlow=vec3(.60,.67,.75)*pow(apparitionHalo,.75)*apparitionLit*.24;
    // The unlit floor is deliberately lifted. With the torch off — or taken — a
    // dark-adapted eye still resolves a room: you are not blind, you simply
    // cannot see WELL. A black screen is not horror, it is a bug you cannot play.
    //
    // BUT IT HAS TO FALL OFF, OR IT IS NOT LIGHT. This was a bare constant, so
    // a wall one metre away and one thirty metres down a corridor received the
    // same ambient — and with the torch off that leaves no depth cue at all,
    // only silhouettes. The room read as wireframe: everything equally visible,
    // nothing receding. Dark adaptation lets you resolve what is NEAR you; it
    // does not show you the far end of an unlit building.
    //
    // Falls to a floor rather than to zero, so the original promise holds: the
    // near room is still legible with no torch at all.
    //
    // AND IT IS A PROPERTY OF PLACE. The distance term above shapes ambient
    // within one view; hitPlace decides how much this cell had to begin with,
    // baked from its distance to an opening and how enclosed it is (see
    // bakeAmbientField). Ambient IS spill from the openings, so a room four
    // metres under the atrium skylight should not be lit like a corridor
    // eighteen metres inside the building — which is what one number per zone
    // did. uAmbientPlace is the strength: 0 restores the flat per-zone value.
    // Sampled smoothly at the hit rather than taken from the cell the ray ended
    // in — see ambientPlaceAt. hitPlace is still what the march carries, and is
    // still the right value for anything that needs one number per cell.
    float place = mix(1.0, ambientPlaceAt(pos.xz), uAmbientPlace);
    // AMBIENT FALLS OFF INDOORS AND DOES NOT FALL OFF OUTDOORS.
    //
    // The reach below is an interior model, and a good one: it is what makes an
    // unlit room recede instead of reading as wireframe. It is also squared, so
    // by nine metres a surface keeps a quarter of its ambient and by thirty it
    // keeps a twentieth.
    //
    // That is wrong under open sky, where the source is not a lamp in the room —
    // it is the whole hemisphere, and it is no dimmer over the far end of the
    // yard than over the near end. Applied out there it made fifty metres of
    // authored ground render as a black band under a bright horizon, which is
    // the one arrangement a night sky never produces.
    float ambientReach = mix(3.5, 9.0, clamp(uAmbientIntensity * place * 26.0, 0.0, 1.0));
    if(hitSky) ambientReach = 400.0;
    float ambientFall = 1.0 / (1.0 + dist / max(0.75, ambientReach));
    float ambient = uAmbientIntensity * place * mix(1.0,1.12,uLight)
                  * mix(uAmbientFloor, 1.0, ambientFall * ambientFall);
    // n.y = +1 is a floor and gets least (it is the source, not the receiver);
    // 0 is a wall; -1 is a ceiling and gets all of it. Gained by the torch so the
    // return trip grows when the player actually lights the floor.
    float bounceFacing = mix(0.22, 1.0, clamp(-n.y * 0.5 + 0.5, 0.0, 1.0));
    float bounce = uBounceIntensity * place * bounceFacing
                 * mix(uAmbientFloor, 1.0, ambientFall)
                 * (1.0 + lamp * uBounceLampGain);

    if(surf == 4){
      vec2 wuv=waterUv(pos.xz);
      float waterTime=uTime*(1.0-uWaterParams.w);
      float film=texture(uRD,wuv*1.8+vec2(waterTime*.006,-waterTime*.004)).g;
      float slow=sin((wuv.x*2.7+wuv.y*1.9+waterTime*.11)*6.28318)*.5+.5;
      float scum=waterEdge(pos.xz);
      vec3 deep=vec3(0.010,0.026,0.018);
      vec3 mold=vec3(0.045,0.092,0.050);
      vec3 skin=mix(deep,mold,clamp(film*.75+slow*.18+scum*.52,0.0,1.0));
      float fres=pow(1.0-clamp(dot(normalize(toEye),n),0.0,1.0),3.0);
      float glitter=pow(clamp(dot(reflect(normalize(-toEye),n),normalize(fwd+vec3(0.0,.15,0.0))),0.0,1.0),34.0);
      float murk=clamp(uWaterParams.z,0.0,1.0);
      // The body's own colour: the murky skin, lit where it stands.
      vec3 bodyCol=skin*(uAmbientColor*ambient*.82+uTorchColor*lamp*.34)
        + vec3(.035,.070,.045)*scum*(.45+.35*film);
      if(uWaterCamera.x>.5){
        // From underneath, the old skin still stands in for the surface.
        col=bodyCol
          + uTorchColor*vec3(.36,.48,.42)*glitter*beam*(1.0-uWaterParams.w*.65)
          + uTorchColor*vec3(.09,.16,.13)*fres*(.22+lamp*.22);
        col=mix(col,deep,murk*.34);
      }else{
        // Mirror and window, weighted by Fresnel on the rippled normal.
        vec3 V=normalize(rd);
        float fresnel=.02+.98*pow(1.0-clamp(dot(-V,n),0.0,1.0),5.0);
        vec3 R=reflect(V,n);R.y=max(R.y,.02);R=normalize(R);
        vec3 mirrored=waterReflection(pos,R,hitSky);
        float pathM=4.0;
        vec3 seen=waterRefraction(pos,refract(V,n,1.0/1.333),pathM);
        float trans=exp(-pathM*mix(.35,2.6,murk));
        vec3 under=seen*trans+bodyCol*(1.0-trans);
        col=mix(under,mirrored,fresnel)
          + waterGlints(posM,R)*(1.0-uWaterParams.w*.5)
          + uTorchColor*vec3(.36,.48,.42)*glitter*beam*(1.0-uWaterParams.w*.65);
      }
    } else {
      vec3 albedo;
      if(sourceVoidMaterial){
        albedo=vec3(1.0);
      }else if(sourceMaterial){
        vec3 ink=sourceSyntaxTint(hitMat);
        albedo=ink*(.06+1.18*smoothstep(.035,.46,sourceHeight));
      }else if(hitMat==MAT_ROOF_GLASS){
        // Supported, rain-dark roof glazing. Keep it out of the general wood
        // fallback and generated wall grain; the iron ribs are real meshes.
        albedo=vec3(.075,.155,.175);
        surfRough=.12;
      }else{
        gBoilGlow=0.0;
        gMark=vec4(0.0);gMarkBlend=0.0;
        albedo=materialBase(hitMat, surf, tint, biome, rdv);
        // The fallback is ALWAYS the base now. It used to be an either/or with
        // the generated tile, which is why arrival was a switch rather than a
        // fade: there was nothing underneath to arrive over.
        albedo=brendanStone?brendanStoneSurface(surf,receiverPosM,anatomicalRelief?receiverNormal:n):architecturalSurface(hitMat,surf,receiverPosM,anatomicalRelief?receiverNormal:n,albedo);
        if(pbrReady){
          albedo=mix(albedo,surfaceTile(pbrSlot,pbrUv,pbrTile),pbrBlend);
          gMarkBlend*=pbrBlend;
        }
        if(hitMat==MAT_PAVING&&surf==2){vec2 flag=yorkstoneFlags(posM.xz);albedo*=flag.x*(1.0-.5*flag.y);}
        if(natatoriumSlabExposed(hitZone,posM,surf))albedo=natatoriumSlab(posM,surf);
      }
      albedo=stillnessFaceAlbedo(albedo,stillFace);
      gMarkBlend*=1.0-smoothstep(.06,.65,stillFace.w);
      if(sourceMaterial&&stillFace.w>.0001)
        gMarkPlane=printedSurfaceTag(stillnessFacePigment(printedSurfaceCoverage(gMarkPlane),2.0,stillFace),2.0);
      // Roughness drives the highlight: a wet/polished tile (low roughness) throws
      // a tight bright spec; brick and wood stay matte. Tighten the lobe as it
      // smooths, so marble and ceramic actually glint under the torch.
      float gloss = (surfRough >= 0.0) ? (1.0 - surfRough) : 0.0;
      float specStr = (surfRough >= 0.0) ? (0.04 + 0.9 * gloss * gloss) : materialSpec(hitMat);
      float spec = specStr * pow(clamp(lambert, 0.0, 1.0), mix(6.0, 48.0, gloss)) * lamp;
      if(ordinaryLightTreatment){
        // View, source and the actual material normal meet in the highlight.
        // This is reflected incident light: an off/depleted torch stays zero.
        vec3 halfSum=ldir+normalize(toEyeM),halfway=halfSum/max(.000001,length(halfSum));
        spec=specStr*pow(max(0.0,dot(n,halfway)),mix(6.0,48.0,gloss))*lamp;
      }

      float emis = (surf == 2) ? 0.55 : (surf == 1 ? 0.30 : 0.12);
      // Existing spill, luminance preserved. No extra constant or emitter is
      // introduced, and Source/emergency authored light keeps its own language.
      vec3 ambientTint=ordinaryLightTreatment?reflectedLightColor(uAmbientColor):uAmbientColor;
      vec3 bounceTint=ordinaryLightTreatment?reflectedLightColor(uBounceColor):uBounceColor;
      vec3 incident = ambientTint*ambient*surfaceOcclusion + bounceTint*bounce*surfaceOcclusion + uTorchColor*lamp + localLight + gBoilGlow
        + (waterActive()?waterBounceLight(posM,n):vec3(0.0));
      col = albedo * incident
          + uTorchColor * vec3(0.55, 0.60, 0.62) * spec
          + rim * tint * (0.22 + uAudio * 0.45) * emis
          + glow * emis
          - seam * 0.30 * (uAmbientColor*ambient + uTorchColor*lamp);
      // Measured against the light that arrived, not against the shaded pixel:
      // a red wall reflects red whatever lit it, and albedo must not be able to
      // buy the circuit's colour.
      col = reserveEmergencyRed(col, dot(emergencyLight, vec3(.2126,.7152,.0722))
        / max(dot(incident, vec3(.2126,.7152,.0722)), 1e-4));
      // Added AFTER the reservation and mostly outside albedo. Both are on
      // purpose: the reservation must judge the red the circuit actually
      // delivered rather than a pixel already veiled, and the apparition is not
      // light landing on a wall — it is the figure, standing where the wall is.
      // A third of the albedo is kept so it takes the surface's grain and does
      // not read as a sticker laid over the room.
      col += mix(vec3(1.0), albedo, .34) * (apparitionVeil + apparitionGlow);

      // THE GROUND UNDER OPEN SKY REFLECTS THE SKY.
      //
      // Everything above is a lamp model: a source somewhere in the room, an
      // occlusion term, a falloff. None of it describes standing outside, where
      // the source is the entire hemisphere and the yard is bright for the same
      // reason the cloud is. Routed through the zone ambient it kept arriving as
      // an attenuated point light and fifty metres of tarmac stayed black under
      // a white horizon.
      //
      // So: a hemispherical term, weighted by how much sky the surface faces —
      // full for the ground, half for a wall — and deliberately immune to
      // distance, because the sky does not get further away as you look further
      // out. Held under the horizon's own value so the ground never out-reads
      // the opening it is lit by.
      if(hitSky){
        float facingSky = 0.34 + 0.66 * clamp(n.y * 0.5 + 0.5, 0.0, 1.0);
        col += albedo * vec3(0.092, 0.110, 0.150) * facingSky;

        // AND WHEN IT IS WET, IT REFLECTS IT PROPERLY.
        //
        // The hemispherical term above is the diffuse half, and on tarmac — five
        // per cent albedo, in the rain — the diffuse half is almost nothing.
        // What you actually see standing in a yard at night is the sky LYING ON
        // IT: the moon, the lit deck, the one sodium lamp on the column, all
        // smeared out by the water. That is a grazing specular reflection, not a
        // brighter floor, and no amount of raising the ambient was ever going to
        // produce it — the yard stayed a black band under a white horizon
        // through three passes of trying.
        //
        // This is why nightSky() is a function. The reflected ray gets the same
        // deck, the same moon and the same skyline the eye gets, so everything
        // authored up there arrives down here for nothing.
        vec3 vDir = normalize(pos - ro);
        vec3 refl = reflect(vDir, n);
        // Only the sky half of the hemisphere. A reflected ray pointing into the
        // ground has nothing to fetch — there is no second bounce here — so it is
        // folded back up and damped rather than sampling the city upside down.
        refl.y = abs(refl.y) * 0.85 + 0.02;
        float fres = pow(1.0 - clamp(dot(-vDir, n), 0.0, 1.0), 4.0);
        // Rain roughens it: a smear, not a mirror, breaking up where the water
        // is moving. Tarmac has been rained on all night; a wall has not.
        float impacts=(isRainGroundMat(hitMat)&&surf==2)
          ?rainImpactRings(posM.xz,uRainAmount)*uOpticalEffects
          :0.0;
        float ripple = 0.72 + 0.28 * vnoise(posM.xz * 0.9 + vec2(0.0, uTime * 0.55), 1.0, 13.0)
                     + impacts*.26;
        float wetness = hitMat==MAT_ROOF_GLASS?1.35:isRainGroundMat(hitMat) ? (surf == 2 ? 1.0 : 0.30) : 0.22;
        col += nightSky(refl) * (0.05 + 0.60 * fres) * wetness * ripple;
        // An impact only catches enough deck light to articulate the ring. It
        // never becomes a glowing decal, and reduced/off optical effects leave
        // the wet material and its static reflection intact.
        col += vec3(.13,.18,.24)*impacts*(.30+.70*fres);
      }
      if(uRoofView > 0.5 && hitMat == MAT_ROOF_GLASS && surf == 2){
        // The occupied roof is the lid of the academic atrium, not an opaque
        // cyan landing pad. This slice cannot raymarch a second stacked floor
        // below its own collision floor, so project the known gallery at +10m
        // and dry garden at grade through the supported pane. All positions
        // match the existing atrium rail, basin and suspended lantern props.
        // The glass keeps its wet sky reflection at grazing angles; looking
        // down reveals the actual depth of the building instead of a decal.
        vec2 glassLocal=posM.xz-vec2(84.0,14.5);
        // The same glazing runs on over the open courts (x 77-94, z 15-27).
        vec2 courtGlass=glassLocal-vec2(1.5,6.5);
        float innerPane=max((1.0-smoothstep(4.30,4.83,abs(glassLocal.x)))
                           *(1.0-smoothstep(5.80,6.28,abs(glassLocal.y))),
                            (1.0-smoothstep(7.97,8.50,abs(courtGlass.x)))
                           *(1.0-smoothstep(5.47,6.00,abs(courtGlass.y))));
        // A settled sitter initially looks toward the skyline. As their gaze
        // drops through the glazing, the roof gives way to the gallery below.
        float lookThrough=innerPane*smoothstep(0.035,0.30,-rd.y)*0.94;
        academicRoofPaneTransmission=lookThrough;
        float descent=1.0/max(0.23,-rd.y);
        vec2 atGallery=posM.xz+rd.xz*(6.4*descent);
        vec2 atGarden=posM.xz+rd.xz*(16.5*descent);
        vec2 galleryLocal=atGallery-mix(vec2(84.25,14.5),vec2(84.0,14.5),uGalleryTreatment);
        vec2 gardenLocal=atGarden-vec2(84.25,14.5);
        // The recovered gallery's atrium floor stops at the court wall.
        float gardenInside=(1.0-smoothstep(4.7,5.6,abs(gardenLocal.x)))
                          *(1.0-smoothstep(5.8,6.7,abs(gardenLocal.y)))
                          *mix(1.0,1.0-smoothstep(14.6,15.4,atGarden.y),uGalleryTreatment);
        // The atrium itself stays deep. Only the surviving masonry, rail and
        // lamps rise above the recorder's one-bit threshold, making the eye
        // read a space below the zinc instead of an illuminated flat panel.
        vec3 beneath=mix(vec3(.008,.018,.027),vec3(.09,.12,.13),gardenInside*.75);
        float galleryX=(1.0-smoothstep(.04,.22,abs(abs(galleryLocal.x)-mix(5.75,5.16,uGalleryTreatment))))
                       *(1.0-smoothstep(6.35,6.65,abs(galleryLocal.y)));
        float galleryZ=(1.0-smoothstep(.04,.22,abs(abs(galleryLocal.y)-mix(6.50,6.66,uGalleryTreatment))))
                       *(1.0-smoothstep(5.55,5.85,abs(galleryLocal.x)));
        // The recovered gallery rails the whole void: the atrium's run, then the
        // court's wider one (GLASS_COURT.upperGuards). Its south lantern is gone.
        vec2 voidNorth=abs(atGallery-vec2(84.0,12.5))-vec2(5.0,4.5);
        vec2 voidCourt=abs(atGallery-vec2(85.5,21.0))-vec2(8.5,6.0);
        float voidEdge=min(length(max(voidNorth,0.0))+min(max(voidNorth.x,voidNorth.y),0.0),
                           length(max(voidCourt,0.0))+min(max(voidCourt.x,voidCourt.y),0.0));
        float recoveredRail=1.0-smoothstep(.04,.22,abs(voidEdge-.14));
        float recoveredWalk=smoothstep(.25,.95,voidEdge)*(1.0-smoothstep(1.6,2.4,voidEdge));
        beneath+=vec3(.55,.67,.62)*mix(max(galleryX,galleryZ),recoveredRail,uGalleryTreatment)*.94;
        // The vines fall just inside that rail, in broken strands.
        float vineFringe=smoothstep(-.70,-.20,voidEdge)*(1.0-smoothstep(-.02,.12,voidEdge))
                        *step(.52,fract(sin(floor((atGallery.x+atGallery.y)*3.1)*12.9898)*43758.5453));
        beneath+=vec3(.30,.62,.32)*vineFringe*uGalleryTreatment*.9;
        float walkwayX=smoothstep(5.05,5.75,abs(galleryLocal.x))
                       *(1.0-smoothstep(6.3,7.1,abs(galleryLocal.x)))
                       *(1.0-smoothstep(7.1,7.8,abs(galleryLocal.y)));
        float walkwayZ=smoothstep(5.8,6.5,abs(galleryLocal.y))
                       *(1.0-smoothstep(7.1,7.8,abs(galleryLocal.y)))
                       *(1.0-smoothstep(6.3,7.1,abs(galleryLocal.x)));
        beneath+=vec3(.20,.26,.26)*mix(max(walkwayX,walkwayZ),recoveredWalk,uGalleryTreatment)*.85;
        float basin=1.0-smoothstep(.07,.28,
          abs(length(atGarden-vec2(83.6,14.6))-1.35));
        beneath+=vec3(.67,.78,.75)*basin*gardenInside*.96;
        // The greenhouse stands lit between the courts (x 82-86, z 15-27): its
        // ridge and glazing bars at 5.2m, its four fluorescent runs at 3.25m.
        vec2 atHouse=posM.xz+rd.xz*(11.8*descent)-vec2(84.0,21.0);
        float house=(1.0-smoothstep(1.92,2.08,abs(atHouse.x)))
                   *(1.0-smoothstep(5.92,6.08,abs(atHouse.y)));
        float houseBars=max(1.0-smoothstep(.02,.09,abs(atHouse.x)),
                            1.0-smoothstep(.03,.10,abs(mod(atHouse.y+6.0,1.5)-.75)));
        vec2 atTubes=posM.xz+rd.xz*(13.75*descent)-vec2(84.0,21.0);
        float tubes=(1.0-smoothstep(.05,.16,abs(atTubes.x)))
                   *(1.0-smoothstep(.50,.62,abs(mod(atTubes.y+5.5,3.0)-1.5)))
                   *(1.0-smoothstep(5.9,6.0,abs(atTubes.y)));
        beneath=mix(beneath,vec3(.10,.17,.15),house*.85);
        beneath+=vec3(.55,.67,.62)*houseBars*house*.70+vec3(.82,.94,1.0)*tubes*.85;
        vec2 atLantern=posM.xz+rd.xz*(11.5*descent);
        float lanternNorth=1.0-smoothstep(.18,1.03,length(atLantern-vec2(83.6,10.2)));
        float lanternSouth=1.0-smoothstep(.18,1.03,length(atLantern-vec2(83.6,18.7)));
        beneath+=vec3(.95,.74,.47)*max(lanternNorth,lanternSouth*(1.0-uGalleryTreatment))*.89;
        col=mix(col,beneath,lookThrough);
        // The real mesh pane's opaque raster face is bypassed at compositing
        // below. Reconstruct only its measured 2m / 13/6m iron support rhythm
        // on this same world plane, with no collision or image-space sticker.
        float glassRibX=1.0-smoothstep(.025,.080,
          abs(mod(glassLocal.x+6.0,2.0)-1.0));
        float ribPitch=13.0/6.0;
        float glassRibZ=1.0-smoothstep(.025,.075,
          abs(mod(glassLocal.y+6.5+ribPitch*.5,ribPitch)-ribPitch*.5));
        float support=max(glassRibX,glassRibZ)*innerPane;
        col=mix(col,vec3(.035,.065,.070),support*(.70+.24*lookThrough));
        // The reconstructed support and the actual raised mesh use the same
        // charcoal ink. The wet pane keeps a separate material identity so
        // its reflection/depth survives acquisition without bright grid lines.
        gMarkPlane=support>.40?FIRE_ESCAPE_INK_TAG:ROOF_GLASS_INK_TAG;
      }
      // HUSH does not carry a lamp. Its playable room-read is a low, static
      // acoustic relief: boundaries and material seams gather density while
      // the architecture remains dark. This is tied to the explicit camera
      // sensory profile, so the story camera keeps its authored lighting.
      float acousticDistance=1.0-smoothstep(4.0,35.0,length(posM-uCam));
      float acousticGrazing=pow(1.0-abs(dot(n,normalize(toEye))),2.0);
      float acousticBand=.5+.5*sin(length(posM-uCam)*3.2+float(hitMat)*.71);
      float acousticRelief=uHushSense*(.34+seam*.92+rim*.28+acousticGrazing*.46+acousticBand*.06+abs(rdv-.5)*.14);
      col+=vec3(.045,.42,.285)*acousticRelief*(.60+.40*acousticDistance);
      col+=albedo*vec3(.09,.28,.20)*uHushSense*(.30+acousticGrazing*.32);
      if(waterActive() && surf == 1 && hitMat == MAT_WET){
        float caustic=(sin(posM.x*9.0+uTime*.9)+sin(posM.z*7.0-uTime*.7))*.5+.5;
        col+=vec3(.05,.08,.07)*caustic*lamp*.18*(1.0-uWaterParams.w*.75);
      }
    }
    col=stillnessFaceOcclusion(col,stillFace);
    col = col / (1.0 + col * 0.30);  // filmic-ish rolloff, tames the near field
    // The white sea is not a brightly lit material. It is the absence of a
    // scene, so it remains paper-white regardless of ambient, torch or tone map.
    // Mesh props composite later and can still resolve as the distant island.
    if(sourceVoidMaterial) col=vec3(1.0);

    // A handful of dust catches only the lit cone. Quantized movement keeps it
    // from reading as snowfall; reduced motion holds the same sparse field.
    float moteTime=mix(floor(uTime*.35),0.0,uReduceMotionOptical);
    vec2 moteCell=floor(gl_FragCoord.xy*.08);
    float moteHash=hash01(moteCell.x+moteTime*13.0,moteCell.y-moteTime*7.0);
    float mote=step(.9991,moteHash)*smoothstep(.22,.82,beam)*uOpticalEffects;
    col+=uTorchColor*mote*uLight*.045;

    // No exploration fog and no distance haze. Darkness now comes only from
    // actual lighting, occlusion and material response, so doorways and the far
    // side of an atrium remain readable before the player crosses them.
  }

  // Shared ground-plane ray for volumetric effects below. Keys and exits remain
  // real objects with map/edge guidance; they must not project world-space light
  // columns. At long range those unbounded columns read as a beacon punched
  // through the opening horizon, before the player has earned any destination.
  vec2 ro2 = ro.xz, rd2 = normalize(rd.xz + vec2(1e-5));
  float span = (tHit > 0.0 ? tHit : 110.0 / CELL_METERS) * length(rd.xz) / max(length(rd), 1e-4);
  // Mesh props were rasterised with the exact same camera before this pass.
  // Reconstruct their view-space depth and compare it to the sector hit: a
  // piano behind a wall stays behind the wall, while a desk in front of it is
  // part of the same conditioning image the diffusion lens receives.
  // The metres to whatever this pixel actually hit. We have marched for it
  // already; before now we threw it away. ControlNet wants it.
  float zView = tHit < 0.0 ? uPropFar : tHit * CELL_METERS * max(0.001, dot(rd, fwd));

  if(uPropsReady > 0.5){
    vec2 propUv = gl_FragCoord.xy / uRes;
    ivec2 propPixel=ivec2(gl_FragCoord.xy);
    vec4 prop=texelFetch(uPropColor,propPixel,0);
    vec4 propData=texelFetch(uPropDepth,propPixel,0);
    float depth=unpackPropWorldDepth(propData.rgb);
    float litBody=litApparitionTag(prop.a);
    if(prop.a > 0.5 && depth < 0.999999){
      float ndc = depth * 2.0 - 1.0;
      float propView = (2.0 * uPropNear * uPropFar) /
        (uPropFar + uPropNear - ndc * (uPropFar - uPropNear));
      float archView = zView;
      // The glazing mesh carries an opaque raster material so it can keep
      // ordinary iron ribs in the shared dither. Its pane tops are effectively
      // coplanar with the floorplan's roof glass; let the world's through-pane
      // view win those pixels, while raised ribs, repairs and every nearer
      // object still use their real mesh depth.
      // Only the actual roof and seat pane primitives carry this identity.
      // Inferring glass from RGB failed under a close torch: its pale cyan
      // highlight became "opaque" and covered the entire view below. Ribs,
      // repairs, brass and Ren retain their own ordinary depth ownership.
      bool wiredPane=roofGlassInkTag(prop.a)>.5;
      bool paneTop=uRoofView>0.5 && hitMat==MAT_ROOF_GLASS && surf==2 && wiredPane;
      if(propView < archView + 0.015 && !paneTop && litBody<.5&&stillnessReliefProxyTag(prop.a)<.5){
        academicRoofPaneTransmission=0.0; // real ribs, lead, bodies and nearer props still win
        col = texture(uPropColor,propUv).rgb; zView = propView;
        // The mesh has replaced this architectural surface. Its untextured
        // material cannot inherit the hidden wall's grain and hatch direction.
        gMark=vec4(0.0);gMarkBlend=0.0;
        // The exact material tag rides through the winning mesh depth only.
        // This uses the existing colour fetch, leaving the sampler budget and
        // hidden architecture's grain unchanged.
        gMarkPlane=fireEscapeInkTag(prop.a)>.5?FIRE_ESCAPE_INK_TAG:
          roofSurfaceInkTag(prop.a)>.5?ROOF_SURFACE_INK_TAG:0.0;
        if(printedSurfaceKind(propData.a)>.5)gMarkPlane=propData.a;
        if(missingManCoreTag(prop.a)>.5)gMarkPlane=MISSING_MAN_CORE_TAG;
        if(missingManSmokeTag(prop.a)>.5)gMarkPlane=MISSING_MAN_SMOKE_TAG;
      }
    }
    // Feather the BLACK mesh silhouette itself, on BOTH sides of its edge.
    // The old inside-only blend left the adjacent room pixel untouched, while
    // the mesh depth snapped from figure to wall in a single pixel. The .76
    // material tag isolates the lit bodies from ordinary props and from their
    // sparse emergency-off/unlit variants. Exact texels avoid interpreting an
    // ordinary opaque prop's bilinear alpha edge as an apparition.
    if(uLitApparitions>.5||litBody>.5){
      float maskWeight=litBody*4.0;
      vec3 bodyColor=prop.rgb*maskWeight;
      float bodyDepth=0.0;
      if(litBody>.5){
        float ndc=depth*2.0-1.0;
        bodyDepth=((2.0*uPropNear*uPropFar)/(uPropFar+uPropNear-ndc*(uPropFar-uPropNear)))*maskWeight;
      }
      float featherScale=clamp(uRes.y/800.0,.35,1.5);
      for(int ai=0;ai<16;ai++){
        float angle=float(ai%8)*.785398;
        float radius=(ai<8?4.0:14.0)*featherScale;
        float weight=ai<8?1.0:.75;
        ivec2 offset=ivec2(round(vec2(cos(angle),sin(angle))*radius));
        ivec2 tapPixel=clamp(propPixel+offset,ivec2(0),ivec2(uRes)-1);
        vec4 tap=texelFetch(uPropColor,tapPixel,0);
        float ink=litApparitionTag(tap.a)*weight;
        if(ink>0.0){
          float tapDepth=unpackPropWorldDepth(texelFetch(uPropDepth,tapPixel,0).rgb);
          float ndc=tapDepth*2.0-1.0;
          float tapView=(2.0*uPropNear*uPropFar)/(uPropFar+uPropNear-ndc*(uPropFar-uPropNear));
          maskWeight+=ink;bodyColor+=tap.rgb*ink;bodyDepth+=tapView*ink;
        }
      }
      if(maskWeight>0.0){
        float coverage=pow(clamp(maskWeight/18.0,0.0,1.0),.85);
        float figureView=bodyDepth/maskWeight;
        // zView includes any ordinary prop already composited at this pixel.
        // A wall panel behind the figure receives the feather; a chair or
        // railing in front still wins by depth.
        float receiverView=zView;
        if(figureView<receiverView+.015){
          col=mix(col,bodyColor/maskWeight,coverage);
          zView=mix(receiverView,figureView,coverage);
          // Carry actual coverage, not just a yes/no tag, into the one-bit
          // display. Its black ink needs the same graded penumbra as the scene.
          gMark=vec4(0.0);gMarkBlend=0.0;gMarkPlane=.70+.14*coverage;
        }
      }
    }
  }

  // The B3 window is a two-way transparent plane. Its optional impossible
  // reflected occupant is confined to the pane and cannot occlude objects
  // nearer than the pane. It participates in the ordinary world dither.
  b3Glass(col,ro*CELL_METERS,rd,fwd,zView);

  // Fixed roof-aperture transport, clipped to the nearest composed surface.
  // Only the already accepted through-pane roof view can extend air depth;
  // this does not fabricate another actor pass or make opaque props transparent.
  if(uAcademicAtriumLight>.5){
    float academicRayEnd=zView/max(.001,dot(rd,fwd));
    if(academicRoofPaneTransmission>.001){
      float transmittedEnd=academicAtriumRoofRayEnd(ro*CELL_METERS,rd);
      if(transmittedEnd>0.0)academicRayEnd=mix(academicRayEnd,transmittedEnd,academicRoofPaneTransmission);
    }
    float academicAir=academicAtriumSkyVolume(ro*CELL_METERS,rd,academicRayEnd);
    col=mix(col,AAL_VOLUME_COLOR,academicAir);
  }

  // BELOW THE COPING. Apply the volume after mesh compositing so props and the
  // height field live in the same water. Red dies first, green-black survives,
  // and reduced motion holds both caustics and particulate perfectly still.
  if(uWaterCamera.x>.5){
    float murk=clamp(uWaterParams.z,0.0,1.0);
    float travel=max(0.0,zView);
    vec3 transmission=exp(-travel*mix(vec3(.17,.085,.13),vec3(.34,.14,.22),murk));
    vec3 deepWater=vec3(.006,.025,.017);
    float absorption=1.0-exp(-travel*(.055+murk*.075));
    col=col*transmission+deepWater*absorption*(.62+murk*.30);
    float heldTime=uTime*(1.0-uWaterParams.w);
    float caustic=(sin(gl_FragCoord.x*.095+heldTime*.72)+sin(gl_FragCoord.y*.071-heldTime*.53))*.5+.5;
    caustic*=smoothstep(.05,.65,abs(rd.y))*(1.0-smoothstep(7.0,28.0,travel));
    col+=vec3(.025,.072,.045)*caustic*.18;
    vec2 particleCell=floor(gl_FragCoord.xy/vec2(6.0,8.0));
    float particle=step(.9925,hash01(particleCell.x+floor(heldTime*.7)*3.0,particleCell.y-floor(heldTime*.5)*5.0));
    col+=vec3(.16,.20,.15)*particle*(.025+.035*murk);
  }

  // Exterior humidity is a shallow, low-contrast veil in the distance, not the
  // exploration fog deliberately excluded from the interior. It thickens at
  // grazing angles and leaves nearby doors, kerbs and props crisp.
  if(cameraInWeather){
    float mug=smoothstep(8.0,34.0,zView)*(1.0-smoothstep(.28,.72,abs(rd.y)));
    col=mix(col,vec3(.085,.108,.145),mug*(.065+.065*smoothstep(1.0,5.0,uRainAmount)*uOpticalEffects));
  }

  // Rain sees the composed prop and architecture depth in the same units as
  // its ray, then contributes to acquisition RGB before HUSH and the print.
  float rainGain=clamp(uRainAmount,0.0,8.0)*(cameraInWeather?1.0:clamp(uRainIndoor,0.0,1.0));
  if((cameraInWeather||uRainIndoor>.0)&&uOpticalEffects>.0&&rainGain>.0){
    float rainEnd=zView/(CELL_METERS*max(.001,dot(rd,fwd)));
    float pixelSlope=uCameraTanHalfFov/max(1.0,uRes.y);
    vec4 rain=traceRainField(ro,rd,rainEnd,pixelSlope,rainGain);
    if(rain.x>.001){
      vec3 dropM=(ro+rd*rain.z)*CELL_METERS;
      vec3 airLight=vec3(.34,.39,.46);
      vec3 fromTorch=dropM-uTorchOrigin;
      float torch=torchAngular(fromTorch,uTorchForward,uTorchRight,uTorchUp,uTorchCone,uTorchSpill)
        *torchFalloff(length(fromTorch),uTorchReach)*uLight;
      airLight+=uTorchColor*torch*.38;
      // Light the strongest streak once, using the same lamp reach and
      // directional emitters as architecture. The drop loop stays bounded.
      for(int li=0;li<${MAX_LOCAL_LIGHTS};li++){
        if(li>=uLocalLightCount)break;
        vec3 delta=dropM-uLocalLightPos[li].xyz;
        float radius=max(.01,uLocalLightPos[li].w);
        float nearLight=clamp(1.0-length(delta)/radius,0.0,1.0);
        if(nearLight<=.0)continue;
        float level=nearLight*nearLight*localEmitterCone(li,delta)*uLocalLightColor[li].w;
        airLight+=uLocalLightColor[li].rgb*min(.50,level*.62);
      }
      float contrast=1.0-.62*clamp(dot(col,vec3(.2126,.7152,.0722)),0.0,1.0);
      col+=airLight*rain.y*contrast*uOpticalEffects;
      col=mix(col,col*vec3(.92,.96,1.0),rain.x*.13);
    }
  }

  // The HUSH is not a dark decal on the walls; it is a volume in which light
  // stops arriving. Apply the absence after the prop composite so furniture,
  // practical highlights and architecture all disappear into the
  // same shadow. Reduced/off effects hold the edge still but never relight it.
  if(uHush.z > 0.001){
    // Clip the volume to the closest composed surface. A HUSH behind a road
    // case may eat the case's rim light; one twenty metres behind it may not
    // paint a silhouette through the case just because the wall is farther.
    float surfaceSpan=min(span,(zView/max(.001,dot(rd,fwd)))*length(rd.xz)/CELL_METERS);
    float s = clamp(dot(uHush.xy - ro2, rd2), 0.0, surfaceSpan);
    vec2 nearest=ro2+rd2*s;
    float d = length(nearest-uHush.xy) * CELL_METERS;
    float radius=max(3.0,uHush.w);
    vec2 hushDelta=uHush.xy-nearest;
    vec2 pullDir=normalize(hushDelta+vec2(.0001));
    vec2 stillUv=fract(nearest*.05);
    vec2 movingUv=fract(nearest*.05+uTime*.01);
    float stillChurn=texture(uRD,stillUv).g;
    float movingChurn=texture(uRD,movingUv).g;
    float pulledChurn=texture(uRD,fract(movingUv+pullDir*.035)).g;
    float churn=mix(stillChurn,mix(movingChurn,pulledChurn,.42),uOpticalEffects);
    float edgeWarp=(churn-.5)*radius*.22;
    float body=1.0-smoothstep(radius*.40+edgeWarp,radius+edgeWarp,d);
    float core=1.0-smoothstep(radius*.05,radius*.34,d);
    float absorption=clamp((body*.78+core*.38)*uHush.z,0.0,.995);
    col*=1.0-absorption;
  }

  // The Scene Dock room disappears before the body card is composed.  Applying
  // this to the finished frame would erase the HUSH too, turning an authored
  // approach into an indiscriminate screen fade.
  col*=1.0-clamp(uDockHauntingFade,0.0,.995);

  // A short close exposure separates the nearest material planes. It lands on
  // the depth-winning room or prop, falls to zero beyond the immediate room,
  // and reaches acquisition before any dither is chosen. The remaining black
  // area closes from one side if the impact has no available subject.
  if(uElleryCaughtPrint.x>.001&&zView<uPropFar-.1){
    float reach=1.0-smoothstep(.65,7.0,zView);
    float range=length(vec2(uv.x*.52,uv.y*.68));
    float aperture=1.0-smoothstep(.24,1.09,range);
    float face=surf==1?.84:surf==2?1.15:.69;
    float grainM=1.0+clamp(gMark.r,-.30,.30)*.74;
    vec3 receiver=clamp(col*2.6,0.0,1.0);
    vec3 gain=mix(vec3(.24,.25,.18)*face*grainM,vec3(.25,.26,.23),receiver);
    col+=gain*(uElleryCaughtPrint.x*reach*aperture);
    float side=sign(uElleryCaughtPrint.z);
    float edge=side*(uv.x+uv.y*.22);
    float obstruction=smoothstep(.04,.53,edge)*uElleryCaughtPrint.y;
    col*=1.0-obstruction*.92;
  }

  // Both articulated volumes share the depth-tested geometry target.
  if(uPressureGeometryReady>.5)compositePressureVolume(col,zView);

  if(uWaterCamera.z>.5){
    float edge=smoothstep(.28,.76,length(uv));
    col=mix(col,col*vec3(.66,.82,.76),edge*.10);
    float damp=hash01(floor(gl_FragCoord.x/19.0),floor(gl_FragCoord.y/23.0));
    col*=1.0-step(.972,damp)*edge*.045;
  }

  col += (grain - 0.5) * 0.035;             // film grain
  // The expressive post pass owns the fear vignette. A second fixed vignette
  // here used to halve the corners before fear was even applied.

  // From the remembered room the FOH opening admits only white absence.
  // Compare against the nearest fully composed surface, including the actual
  // moving leaf and room props: nothing in front of the plane is washed out.
  float shoreApertureView=sourceShoreApertureView(ro*CELL_METERS,rd,fwd,
    uSourceShoreAperture,uSourceShoreApertureState);
  if(shoreApertureView>0.0&&shoreApertureView+.015<zView){
    col=vec3(1.0);zView=shoreApertureView;gMark=vec4(0.0);gMarkBlend=0.0;gMarkPlane=0.0;
  }

  // DEPTH RIDES IN THE ALPHA CHANNEL. The post pass reads .rgb and writes 1.0,
  // so nothing on screen can see this; the diffusion lens resolves it back out
  // (see r3dDepthInto). Stored as INVERSE depth — near is bright — because that
  // is the convention every SD depth ControlNet was trained on (MiDaS), and
  // handing a depth ControlNet a linear far-is-bright map inverts the room.
  o = vec4(clamp(col,0.0,1.0), 1.0 / (1.0 + zView * 0.14));
  // THE ENGRAVING LEAVES ON A SECOND TARGET. It cannot ride the first — RGB is
  // the image, alpha already carries depth — and it cannot be recovered later:
  // surface UV and slot exist only here, inside the march. The recorder must be
  // handed it in screen space or draw with a procedural hash instead.
  // Blend is applied to the SIGNED line field, before the bias — not to the
  // stored byte afterwards. Scaling the biased value is what the previous write
  // did, and it is wrong in a way that only shows up once anything reads these
  // channels: a half-blended fragment with no grain at all stores 0.25, which
  // decodes to -0.5, a confident grain out of nothing. Alpha now carries the
  // tangent plane, which is an identity rather than a quantity and must not be
  // scaled by anything.
  float markBlend = clamp(gMarkBlend,0.0,1.0);
  oMark = vec4(gMark.r*markBlend, gMark.gb*markBlend*0.5+0.5, gMarkPlane);
}`;

// ── Depth resolve ───────────────────────────────────────────────────────────
// Pulls the depth back out of the scene texture's alpha as a grey image. This
// is the whole reason a raymarcher beats a screenshot: we do not have to
// *estimate* depth with MiDaS like everyone else, we already know it exactly.
const DEPTH_FRAG = COMMON_GLSL + `
uniform sampler2D uSrc;
uniform vec2 uRes;
out vec4 o;
void main(){
  float d = texture(uSrc, gl_FragCoord.xy / uRes).a;
  o = vec4(vec3(d), 1.0);
}`;

// ── Post: upscale with slight chromatic drift ────────────────────────────────
// Fear is not a number on a bar; it is what the room starts doing to you. It
// tightens a vignette (tunnel vision), pulls the colour out (a frightened man
// stops seeing in colour), and pushes the chromatic split — the picture stops
// holding itself together. Recording grain is a separate acquisition layer:
// fine, luma-shaped, black-protected, and phase-held rather than animated snow.
// The grain of a recorded medium, shared by the two passes that need one: the
// VFD's post stack and the horizon's projector. It lived inside POST_FRAG,
// which is why the projection pass referencing it failed to compile in
// silence — a bad program leaves the previously bound one in place, so the
// horizon kept presenting through the plain copy and looked untouched.
const GRAIN_GLSL = `
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float grainClock(float time, float hz, float reduceMotion){
  return time * max(0.0, hz) * (1.0 - clamp(reduceMotion, 0.0, 1.0));
}
float phaseGrain(vec2 p, float phase){
  // Neighbouring pixels share taps, introducing the slight spatial correlation
  // of a recorded medium without softening the architectural image itself.
  vec2 q=p+vec2(phase*37.0,phase*73.0);
  float fine=h21(q);
  float correlated=(
    h21(q)+
    h21(q+vec2(1.0,0.0))+
    h21(q+vec2(0.0,1.0))+
    h21(q+vec2(1.0,1.0))
  )*.25;
  return mix(fine,correlated,.58);
}
float correlatedGrain(vec2 p, float clock, float temporalSmear){
  float phase=floor(clock);
  float phaseMix=smoothstep(0.0,1.0,fract(clock))*clamp(temporalSmear,0.0,1.0);
  return mix(phaseGrain(p,phase),phaseGrain(p,phase+1.0),phaseMix);
}
`;

const POST_FRAG = COMMON_GLSL + GRAIN_GLSL + `
${DRIVE_MEMORY_BREAK_GLSL}
uniform float uDriveMemoryRaw;
uniform sampler2D uSrc;
uniform sampler2D uMissingManMarks;
uniform float uMissingManMarksReady;
uniform sampler2D uUnravellingScene;
uniform float uUnravellingColour;
uniform vec2 uRes;
uniform float uFear;      // 0..1
uniform float uTimeP;
uniform float uGlassStrength;
uniform float uGlassFringe;
uniform float uGlassBloom;
uniform float uGlassGrain;
uniform float uRecordingPostGrain;
uniform float uRecordingLumaGrain;
uniform float uRecordingTemporalHz;
uniform float uRecordingTemporalSmear;
uniform float uReduceFlash;
uniform float uReduceMotion;
uniform float uSourceEmergency;
uniform float uSourceWhiteout;
uniform float uSourceTorchMode;
uniform float uSourceTorchPower;
uniform float uFrontEndAmount;
uniform float uFrontEndDetailRetention;
uniform float uFrontEndChromaRetention;
uniform float uFrontEndExposureStops;
uniform float uFrontEndShoulder;
uniform float uFrontEndToe;
uniform float uFrontEndPrint;
uniform vec4 uPerception;   // chroma, contrast, narrowing, lift
uniform vec4 uPerceptionAt; // where the narrowing closes on (uv), lids
uniform vec4 uLeak;         // leak, white, clock, seed
uniform vec4 uLeakWave;     // origin (uv), front radius, band
uniform vec4 uLeakLens;     // focus gone, after-image, after-image at (uv)
uniform float uLeakShimmer;
uniform sampler2D uLeakPlate;  // scanned Super 8 fog, one cell per frame (game/film-leak.js)
uniform vec4 uLeakPlateFog;    // cell, next cell, between them (Reduce Flash), exposure
uniform vec4 uLeakPlateBurn;   // the same, for the burned-through frames
uniform vec4 uLeakPlateGrid;   // cols, rows, mirrored, grain step
uniform float uLeakFilmOnly;
out vec4 o;
float leakHash(vec2 p){p=fract(p*vec2(127.1,311.7));p+=dot(p,p+34.5);return fract(p.x*p.y);}
float leakNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(leakHash(i),leakHash(i+vec2(1,0)),f.x),mix(leakHash(i+vec2(0,1)),leakHash(i+vec2(1,1)),f.x),f.y);}
// One scanned frame as exposure. The scan was levelled so unexposed film is 0 and burned-
// through film is 1, so -log(1-x) is how much light reached it.
vec3 leakPlateExposure(float cell,vec2 q){
  vec2 grid=uLeakPlateGrid.xy,at=vec2(mod(cell,grid.x),floor(cell/grid.x)),texel=grid/vec2(textureSize(uLeakPlate,0));
  q=clamp(q,texel,1.0-texel);
  vec3 p=texture(uLeakPlate,vec2((at.x+q.x)/grid.x,(grid.y-at.y-1.0+q.y)/grid.y)).rgb;
  return -log(1.0-.995*pow(p,vec3(2.2)));
}
vec3 leakPlateRun(vec4 run,vec2 q){
  if(run.w<.0001)return vec3(0.0);
  return mix(leakPlateExposure(run.x,q),leakPlateExposure(run.y,q),run.z)*run.w;
}
// leakHash repeats every ten cells, which tiles at grain scale. This one doesn't.
float leakGrainHash(vec2 p){
  uvec2 v=uvec2(ivec2(floor(p))+ivec2(65536));
  v=v*1664525u+1013904223u;v.x+=v.y*1664525u;v.y+=v.x*1664525u;v^=v>>16u;
  v.x+=v.y*1664525u;v.y+=v.x*1664525u;v^=v>>16u;
  return float(v.x&0xffffffu)/16777215.0;
}
float leakGrain(vec2 p){
  vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
  return mix(mix(leakGrainHash(i),leakGrainHash(i+vec2(1,0)),f.x),mix(leakGrainHash(i+vec2(0,1)),leakGrainHash(i+vec2(1,1)),f.x),f.y);
}
// The fog's exposure here. Grain is in the emulsion, so it shows only where the fog is
// partly developed: nothing where no light came, nothing where it burned through.
vec3 leakFilm(vec2 uv){
  vec2 q=vec2(mix(uv.x,1.0-uv.x,uLeakPlateGrid.z),uv.y);
  vec3 e=leakPlateRun(uLeakPlateFog,q)+leakPlateRun(uLeakPlateBurn,q);
  vec2 shift=vec2(173.0,311.0)*uLeakPlateGrid.w;
  float grain=(leakGrain(gl_FragCoord.xy/2.3+shift)-.5)+(leakGrain(gl_FragCoord.xy/1.1+shift*1.7)-.5)*.6;
  return e*(1.0+grain*.5);
}
${PRESSURE_IDENTITY_GLSL}
uniform sampler2D uPressureInk;
uniform float uPressureInkReady;
uniform vec2 uCatchFlash;
${PRESSURE_INK_GLSL}
${MISSING_MAN_MATERIAL_GLSL}
void main(){
  // Keep replacement opaque even when post glare, pressure or memory would
  // otherwise reintroduce light, and when the acquisition pass is disabled.
  if(uDriveMemoryBreak.x>=.99999){o=vec4(0.0,0.0,0.0,1.0);return;}
  vec2 uv = gl_FragCoord.xy / uRes;
  float f = clamp(uFear, 0.0, 1.0);
  float glass=clamp(uGlassStrength,0.0,1.0);
  // Phosphor behind thick instrument glass: restrained RGB separation rather
  // than a generic full-frame glitch.
  vec2 cd = (uv - 0.5) * ((0.0012*uGlassFringe) + f * 0.0075);
  vec3 c = vec3(
    texture(uSrc, uv + cd).r,
    texture(uSrc, uv).g,
    texture(uSrc, uv - cd).b);
  vec2 py=vec2(0.0,1.5/uRes.y);
  vec3 halo=(texture(uSrc,uv+py).rgb+texture(uSrc,uv-py).rgb)*0.5;
  float haloLum=dot(halo,vec3(.2126,.7152,.0722));
  c+=halo*haloLum*uGlassBloom*(1.0-uReduceFlash*.65)*.18;
  // A very fine aperture/grille modulation. It should read as hardware only
  // after the selective cell pass has already established the image.
  float grille=.985+.015*sin(gl_FragCoord.y*3.14159265);
  c*=mix(1.0,grille,glass);
  float reflection=pow(clamp(1.0-length((uv-vec2(.28,.08))*vec2(.72,1.8)),0.0,1.0),6.0);
  c+=vec3(.12,.24,.22)*reflection*glass*.055;
  // tunnel vision
  float d = length(uv - 0.5);
  c *= 1.0 - smoothstep(0.34 - f * 0.16, 0.80 - f * 0.30, d) * (0.25 + f * 0.65);
  // a frightened man stops seeing in colour
  float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(c, vec3(lum), f * 0.55);
  // Fine acquisition grain belongs to the signal, not a translucent overlay.
  // True black stays black; midtones carry most of the texture; highlights
  // retain their silhouettes instead of dissolving into white snow.
  float lumForGrain=dot(c,vec3(0.2126,0.7152,0.0722));
  float blackProtect=smoothstep(0.003,0.045,lumForGrain);
  float midtone=
    smoothstep(0.04,0.36,lumForGrain)*
    (1.0-smoothstep(0.76,1.0,lumForGrain));
  float flashSafe=mix(1.0,0.45,clamp(uReduceFlash,0.0,1.0));
  float grainMask=blackProtect*mix(1.0,midtone,clamp(uRecordingLumaGrain,0.0,1.0));
  // Hold the correlated field on one phase so it reads as recorded texture,
  // not a full-frame layer flashing independently of the room.
  float heldClock=7.35;
  float g=correlatedGrain(
    gl_FragCoord.xy,
    heldClock,
    uRecordingTemporalSmear
  )-0.5;
  float recordingAmp=
    clamp(uRecordingPostGrain,0.0,0.08)*
    flashSafe*
    grainMask*
    (1.0+f*0.55);
  // Glass grain remains a quiet instrument/eye texture. It can no longer
  // overwhelm the recorded medium or lift an unlit room.
  float eyeAmp=(0.003*uGlassGrain+f*0.012)*flashSafe*blackProtect;
  c+=g*(recordingAmp+eyeAmp);
  // The FOH aperture and its white sea take the exposure before the emergency
  // circuit arrives. Red is applied after this, so the delayed wash can truly
  // replace white rather than tinting a dark room underneath it.
  vec3 pressureInstrument=c;
  c=mix(c,vec3(1.0),clamp(uSourceWhiteout,0.0,1.0));
  // SOURCE'S FLASHLIGHT IS A SCREEN OPERATION. The physical cone already lit
  // the surfaces in the march, but Source's x-ray must invert the finished
  // picture (props included), and its red beam must remain visible in the white
  // sea, which is deliberately not a lit material. A crisp oval with a narrow
  // feather reads as the same handheld lens without turning into a vignette.
  vec2 sourceTorchUv=(uv-vec2(.5,.48))*vec2(uRes.x/uRes.y,1.0);
  float sourceTorchCone=1.0-smoothstep(.285,.365,length(sourceTorchUv));
  float sourceTorchRim=(1.0-smoothstep(.365,.405,length(sourceTorchUv)))-sourceTorchCone;
  float sourceTorchMask=clamp((sourceTorchCone+sourceTorchRim*.42)*uSourceTorchPower,0.0,1.0);
  if(uSourceTorchMode>.5&&uSourceTorchMode<1.5){
    c=mix(c,vec3(1.0)-c,sourceTorchMask*.94);
  }else if(uSourceTorchMode>1.5){
    vec3 torchRed=vec3(max(.88,c.r*1.12+.16),c.g*.018,c.b*.008);
    c=mix(c,torchRed,sourceTorchMask*.90);
  }
  // The Scene Dock side of Source still uses the ordinary VFD chain. Apply
  // the wash after fear, glass and acquisition grain so it cannot be erased by
  // the same post stack that previously swallowed the raw emergency light.
  float ePhase=mod(uTimeP,3.2);
  float ePulse=uReduceFlash>.5?.78:(ePhase<.18?1.0:ePhase<.42?.48:ePhase<.64?.92:ePhase<.92?.56:.46+.04*sin((ePhase-.92)*2.4));
  float eLuma=dot(c,vec3(.2126,.7152,.0722));
  float eMask=(.78+.22*(1.0-eLuma))*(.88+.12*smoothstep(.02,.92,uv.y));
  float eWash=clamp(uSourceEmergency*ePulse*eMask,0.0,.94);
  vec3 emergencyRed=vec3(max(.82,c.r*1.18+.18),c.g*.025,c.b*.012);
  c=mix(c,emergencyRed,eWash);
  c=mix(c,pressureInstrument,pressureIdentityMask(uv));

  // THE NEGATIVE OF THE FINISHED FRAME. Luminance turns over and each pixel keeps
  // its own hue, so black stands as paper, the lit contours and dots as ink, and
  // the palette is still this display's palette rather than its complement.
  float printNeg=clamp(uFrontEndPrint,0.0,1.0);
  if(printNeg>0.0001){
    float printLum=dot(c,vec3(.2126,.7152,.0722));
    c=mix(c,clamp(c+vec3(1.0-2.0*printLum),0.0,1.0),printNeg);
  }

  // FRONT-END DENSITY PLATE. This is deliberately content-driven: no radial
  // vignette and no UI-position glow. At amount zero it is a strict identity.
  float fe=clamp(uFrontEndAmount,0.0,1.0);
  if(fe>0.0001){
    float centerLum=dot(c,vec3(.2126,.7152,.0722));
    vec2 texel=1.0/uRes;
    float neighborLum=(
      dot(texture(uSrc,uv+vec2(texel.x,0.0)).rgb,vec3(.2126,.7152,.0722))+
      dot(texture(uSrc,uv-vec2(texel.x,0.0)).rgb,vec3(.2126,.7152,.0722))+
      dot(texture(uSrc,uv+vec2(0.0,texel.y)).rgb,vec3(.2126,.7152,.0722))+
      dot(texture(uSrc,uv-vec2(0.0,texel.y)).rgb,vec3(.2126,.7152,.0722))
    )*.25;
    neighborLum=mix(neighborLum,1.0-neighborLum,printNeg);
    float low=mix(centerLum,neighborLum,.45);
    float detail=centerLum-low;
    float targetLum=low+detail*mix(1.0,clamp(uFrontEndDetailRetention,0.0,1.0),fe);
    c*=targetLum/max(centerLum,.0001);
    c*=exp2(uFrontEndExposureStops*fe);
    c=c/(vec3(1.0)+c*max(0.0,uFrontEndShoulder)*fe);
    float y=dot(c,vec3(.2126,.7152,.0722));
    float shadowZone=smoothstep(.015,.13,y)*(1.0-smoothstep(.13,.34,y));
    c+=vec3(shadowZone*max(0.0,uFrontEndToe)*fe);
    float y2=dot(c,vec3(.2126,.7152,.0722));
    vec3 grey=vec3(y2);
    float chroma=length(c-grey);
    float practicalProtect=smoothstep(.16,.42,chroma)*.18;
    float retention=clamp(mix(1.0,uFrontEndChromaRetention,fe)+practicalProtect*fe,0.0,1.0);
    c=mix(grey,c,retention);
  }
  // Colour leaks through the same street progressively; changing render modes
  // at the tape seam must not announce a new level.
  float unravellingAmount=clamp(uUnravellingColour,0.0,1.0);
  if(unravellingAmount>0.0){
    c=mix(c,texture(uUnravellingScene,uv).rgb,unravellingAmount*(1.0-pressureIdentityMask(uv)));
  }
  // Preserve acquired cosmic marks (or the human reference's sealed black
  // core) through glass, emergency colour and the negative plate.
  if(uPressureInkReady>.5)c=pressurePreserveRecordedCosmos(c,texture(uSrc,uv).rgb,texture(uPressureInk,uv));
  // The informant's negative interior is an opaque world material. Exact
  // depth-winning marks keep optical glass from drawing a reflection on it;
  // nearer Pressure geometry keeps its existing physical priority.
  if(uMissingManMarksReady>.5){
    ivec2 missingPixel=clamp(ivec2(uv*vec2(textureSize(uMissingManMarks,0))),ivec2(0),textureSize(uMissingManMarks,0)-1);
    float missingCore=missingManCoreTag(texelFetch(uMissingManMarks,missingPixel,0).a);
    c*=1.0-missingCore*(1.0-pressureIdentityMask(uv));
  }
  // WHAT ARRIVES OF IT. Nothing in the world changed; less of it gets to him, or
  // for a moment far more. Strict identity at (1,1,0,0). See game/last-minutes.js.
  // Colour goes before form, and a closing field is the last thing to come. When it
  // comes it closes on whatever is bright. Sun through shut eyelids is the only warm
  // thing this pass can do.
  float seen=dot(c,vec3(.2126,.7152,.0722));
  c=max(mix(vec3(seen),c,uPerception.x),vec3(0.0))*uPerception.y*(1.0+.2*uPerception.w);
  vec2 closing=(uv-uPerceptionAt.xy)*vec2(uRes.x/uRes.y,1.0);
  float closingAt=length(closing),closed=clamp(uPerception.z,0.0,1.0);
  if(closed>.001)c*=1.0-smoothstep(mix(1.15,.03,closed),mix(1.7,.34,closed),closingAt);
  float lids=clamp(uPerceptionAt.z,0.0,1.0);
  if(lids>.001)c=mix(c,vec3(1.0,.34,.13)*(.34+.66*exp(-closingAt*1.35)),lids);
  // LIGHT IN THE CAMERA. game/neural-transition.js says when; game/film-leak.js says which
  // piece of film is in the gate. The fog is scanned Super 8, added to the frame's
  // exposure rather than laid over it, so it lifts the dark first and leaves what was
  // already bright. It sits on top of the print, unprinted, because it was never anything
  // in the room: it happened to the film, or the lens, or the eye, and nothing says which.
  float leakAmount=clamp(uLeak.x,0.0,1.0),blinding=clamp(uLeak.y,0.0,1.0),lensGoing=clamp(uLeakLens.x,0.0,1.0),afterSun=clamp(uLeakLens.y,0.0,1.0);
  if(leakAmount>.001||blinding>.001||uLeakWave.z>.001||lensGoing>.001||afterSun>.001){
    // The transition's reduced white alone cannot tame the independent flare,
    // highlight multiplier and lens bloom. Apply the existing flash policy to
    // every contribution from this effect; ordinary scene exposure is untouched.
    float cameraLightGain=mix(1.0,.25,clamp(uReduceFlash,0.0,1.0));
    blinding*=cameraLightGain;lensGoing*=cameraLightGain;afterSun*=cameraLightGain;
    if(uLeakFilmOnly>.5){
      // Film only. The fog and its own burn carry the whole crossing, and the picture's
      // exposure goes up the way a camera's first frames do: what is bright clips first.
      vec3 exposed=pow(clamp(c,0.0,1.0),vec3(2.2));
      vec3 e=-log(max(1.0-exposed,vec3(1e-4)))*(1.0+blinding*blinding*6.0)+leakFilm(uv)*cameraLightGain;
      c=pow(1.0-exp(-e),vec3(1.0/2.2));
    }else{
    // With the lens: the same fog, inside the lens going soft, the flare and the after-image.
    float leakAspect=uRes.x/uRes.y,leakSeed=uLeak.w;
    // A camera with a hand on it. Whatever happens to the film happens at twelve frames
    // a second. Reduce Flash runs it smooth.
    float leakClock=mix(uLeak.z,floor(uLeak.z*12.0)/12.0,uLeakShimmer);
    // The lens goes first: everything soft, every highlight swelling, and the same frame
    // exposed twice, a little out of register, the way an in-camera double exposure is.
    float melt=max(blinding,lensGoing);
    if(melt>.001){
      vec3 soft=vec3(0.0);
      float spread=.002+.034*melt,softWeightSum=0.0;
      for(int k=0;k<12;k++){
        float angle=float(k)*2.39996+leakSeed*6.0,reach=sqrt((float(k)+.5)/12.0)*spread;
        vec3 tap=texture(uSrc,uv+vec2(cos(angle)/leakAspect,sin(angle))*reach).rgb;
        float softWeight=1.0+dot(tap,vec3(.2126,.7152,.0722))*3.2*melt;
        soft+=tap*softWeight;softWeightSum+=softWeight;
      }
      c=mix(c,soft/mix(12.0,max(.001,softWeightSum),clamp(uReduceFlash,0.0,1.0)),smoothstep(.0,.3,melt));
      vec2 slip=vec2(sin(leakSeed*91.0+leakClock*3.7),cos(leakSeed*37.0+leakClock*2.9))*.022*melt;
      c=max(c,texture(uSrc,uv+slip).rgb*.72*melt);
    }
    // Overexposed, not faded: what is already bright clips first, and the room burns out.
    c*=1.0+blinding*blinding*7.0;
    if(uLeakPlateFog.w>.0001){
      // The film fogging from the edge of the gate: crimson at its reach, a cool white
      // where it is worst, on the frame's exposure like any other light.
      vec3 exposed=pow(clamp(c,0.0,1.0),vec3(2.2));
      exposed=1.0-(1.0-exposed)*exp(-leakFilm(uv)*cameraLightGain);
      c=pow(exposed,vec3(1.0/2.2));
    }
    if(uLeakWave.z>.001){
      // Light through the lens from one place, swelling. Each colour is focused a little
      // differently, so its edge fringes the way a cheap lens does.
      float front=uLeakWave.z,band=max(.01,uLeakWave.w);
      vec2 leakQ=(uv-uLeakWave.xy)*vec2(leakAspect,1.0);
      float leakR=length(leakQ),edge=(leakNoise(vec2(atan(leakQ.y,leakQ.x)*1.7+leakSeed,leakClock*.8))-.5)*.2*(.3+leakR);
      vec3 flare=1.0-smoothstep(vec3(front-band),vec3(front),vec3(leakR-.022,leakR,leakR+.03)+edge);
      c=mix(c,vec3(1.0,.97,.90),flare*.94*cameraLightGain);
      c+=vec3(.75,.14,.03)*smoothstep(front-band*1.7,front-band*.6,leakR+edge)*(1.0-smoothstep(front-band*.6,front+band*.3,leakR+edge))*.55*cameraLightGain;
    }
    c=mix(c,vec3(1.0,.985,.93),smoothstep(.5,1.0,blinding));
    if(afterSun>.001){
      // The sun, still on his eye, in the complement. It stays where he isn't looking.
      float away=length((uv-uLeakLens.zw)*vec2(leakAspect,1.0));
      float disc=exp(-pow(away/.13,4.0)),ring=exp(-pow((away-.15)/.05,2.0));
      c=mix(c,c*vec3(.42,.52,1.0)+vec3(.02,.03,.13),disc*afterSun);
      c+=vec3(.34,.05,.42)*ring*afterSun*.34;
    }
    } // with the lens
  }
  // THE CATCH. A flash photograph of the real body: the room blown white behind it,
  // then the same frame negative. On the finished frame, because the print stage
  // would draw a flat white field as nothing at all.
  if(uCatchFlash.x>.001||uCatchFlash.y>.001){
    float catchBody=step(.018,pressureIdentityMask(uv));
    c=mix(c,vec3(1.0-catchBody),uCatchFlash.x);
    c=mix(c,vec3(catchBody),uCatchFlash.y);
  }
  if(uDriveMemoryRaw>.5)c=driveMemoryBreakAcquire(c,gl_FragCoord.xy);
  o=vec4(c,1.0);
}`;

// Source Space is a deliberately separate proof: transparent glyph geometry
// over a clear void. It must not inherit the VFD cell mesh, halftone, glass,
// fear or material stack used by the physical building. This legacy compositor
// remains for the early passages; Source proper now uses shared acquisition.
const TEXT_SPACE_FRAG = COMMON_GLSL + `
uniform sampler2D uText;
uniform sampler2D uOpeningMask;
uniform float uOpeningMaskReady;
uniform vec2 uRes;
uniform float uSunrise;
uniform float uSourceChroma;
uniform float uPaper;
uniform float uTime;
uniform float uNightSeed;
uniform float uRain;
uniform float uLeaves;
uniform float uReducedMotion;
uniform float uSourceEmergency;
uniform float uSourceWhiteout;
uniform float uSourceTorchMode;
uniform float uSourceTorchPower;
uniform vec2 uView;
uniform vec2 uMoonCloud;
out vec4 o;
float sourceHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){
  vec2 uv=gl_FragCoord.xy/uRes;
  float shift=(1.0+2.4*uSourceChroma)/uRes.x;
  vec4 center=texture(uText,uv);
  vec4 left=texture(uText,uv-vec2(shift,0.0));
  vec4 right=texture(uText,uv+vec2(shift,0.0));
  float glyphAlpha=max(center.a,max(left.a,right.a));
  vec3 glyph=mix(center.rgb,vec3(right.r,center.g,left.b),uSourceChroma);
  vec3 voidColor=mix(vec3(.0015,.003,.004),vec3(.014,.020,.031),smoothstep(.08,.92,uv.y));
  float cloudPhase=uNightSeed*91.7+uTime*.006*(1.0-uReducedMotion);
  float cloudBand=sin(uv.x*9.0+cloudPhase)+sin(uv.x*17.0-uv.y*5.0+cloudPhase*.7);
  float clouds=smoothstep(1.0,1.68,cloudBand+sourceHash(floor(uv*vec2(24.0,9.0)))*.7)
    *smoothstep(.34,.62,uv.y)*.13;
  voidColor+=vec3(.055,.064,.083)*clouds*uMoonCloud.y;
  float moonBearing=.785398+(uNightSeed-.5)*.24;
  float moonDelta=atan(sin(moonBearing-uView.x),cos(moonBearing-uView.x));
  vec2 moonCenter=vec2(.5+moonDelta/2.2,.76+fract(uNightSeed*7.1)*.08-uView.y*.45);
  float moon=1.0-smoothstep(.029,.038,length((uv-moonCenter)*vec2(uRes.x/uRes.y,1.0)));
  voidColor=mix(voidColor,vec3(.72,.77,.80),moon*.86*uMoonCloud.x);
  vec3 darkScene=glyph+voidColor*(1.0-glyphAlpha);
  if(uRain>.001){
    vec2 rainUv=uv*vec2(94.0,38.0);
    rainUv.y+=uTime*38.0*(1.0-uReducedMotion);
    rainUv.x+=rainUv.y*.19;
    vec2 rainCell=floor(rainUv),rainLocal=fract(rainUv);
    float admitted=step(.82,sourceHash(rainCell+floor(uNightSeed*101.0)));
    float streak=(1.0-smoothstep(.025,.12,abs(rainLocal.x-.5)))*smoothstep(.0,.16,rainLocal.y)*(1.0-smoothstep(.58,1.0,rainLocal.y));
    darkScene=mix(darkScene,vec3(.34,.43,.54),streak*admitted*uRain*.34);
  }
  // LEAVES, IN A FIELD THAT HAS NO DEPTH.
  //
  // Source is a flat composited image, so leaves here cannot be objects the way
  // the yard's are — there is nothing for them to pass behind. Making them OF
  // the field rather than in front of it is the honest reading: this place is a
  // recording, and what blows through it belongs to the recording.
  //
  // Two drifting cell layers so they do not march in step, each cell holding at
  // most one leaf. The tumble is the trick: scaling the cell's x by |cos| of a
  // per-leaf clock makes the shape narrow to a line and open out again, which is
  // the only part of a leaf that reads at this size.
  if(uLeaves>.001){
    for(int layer=0;layer<2;layer++){
      float depth=layer==0?1.0:1.7;
      vec2 leafUv=uv*vec2(13.0,7.0)*depth;
      // Across the frame on the wind, sagging as they go, and parallaxed
      // against the head so the near layer slides over the far one.
      float drift=uTime*(0.22+float(layer)*0.15)*(1.0-uReducedMotion);
      leafUv.x+=drift-uView.x*(0.7+float(layer));
      leafUv.y+=sin(leafUv.x*0.7+drift*2.1)*0.20-uView.y*0.5;
      vec2 cell=floor(leafUv),local=fract(leafUv)-0.5;
      float pick=sourceHash(cell+floor(uNightSeed*67.0)+float(layer)*31.0);
      if(pick>0.90){
        float clock=uTime*(1.6+pick*3.4)*(1.0-uReducedMotion)+pick*19.0;
        // Edge-on it is a line; broadside it is a blade. Floored so it never
        // vanishes completely between turns.
        float face=max(0.16,abs(cos(clock)));
        float lean=sin(clock*0.6)*0.9;
        vec2 p=vec2(local.x*cos(lean)-local.y*sin(lean),local.x*sin(lean)+local.y*cos(lean));
        p.x/=face;
        float leaf=1.0-smoothstep(0.10,0.24,length(p*vec2(1.0,2.6)));
        // Warm and dry against a cold field, dimmer on the far layer.
        darkScene=mix(darkScene,vec3(.42,.32,.17),leaf*uLeaves*(layer==0?.62:.34));
      }
    }
  }
  vec3 paper=vec3(.965,.925,.835);
  vec3 paperScene=mix(paper,vec3(.012,.010,.009),smoothstep(.02,.72,glyphAlpha));
  float lightMix=clamp(max(uSunrise,uPaper*.72),0.0,1.0);
  vec3 composed=mix(darkScene,paperScene,lightMix);
  composed=mix(composed,vec3(1.0),clamp(uSourceWhiteout,0.0,1.0));
  // Text Space bypasses the physical post pass, so it consumes the same Source
  // torch contract here. This also means toggling the real carried flashlight
  // remains visible after the renderer handoff instead of silently becoming an
  // always-on white prop light.
  vec2 sourceTorchUv=(uv-vec2(.5,.48))*vec2(uRes.x/uRes.y,1.0);
  float sourceTorchCone=1.0-smoothstep(.285,.365,length(sourceTorchUv));
  float sourceTorchRim=(1.0-smoothstep(.365,.405,length(sourceTorchUv)))-sourceTorchCone;
  float sourceTorchMask=clamp((sourceTorchCone+sourceTorchRim*.42)*uSourceTorchPower,0.0,1.0);
  if(uSourceTorchMode>.5&&uSourceTorchMode<1.5){
    composed=mix(composed,vec3(1.0)-composed,sourceTorchMask*.94);
  }else if(uSourceTorchMode>1.5){
    vec3 torchRed=vec3(max(.88,composed.r*1.12+.16),composed.g*.018,composed.b*.008);
    composed=mix(composed,torchRed,sourceTorchMask*.90);
  }
  // Text Space bypasses the ordinary pixel mesh. Preserve the emergency
  // circuit after paper, chroma and HUSH have resolved so downstream grading
  // cannot turn the only impossible colour back into grey.
  float ePhase=mod(uTime,3.2);
  float ePulse=uReducedMotion>.5?.78:(ePhase<.18?1.0:ePhase<.42?.48:ePhase<.64?.92:ePhase<.92?.56:.46+.04*sin((ePhase-.92)*2.4));
  float eLuma=dot(composed,vec3(.2126,.7152,.0722));
  float eMask=(.80+.20*(1.0-eLuma))*(.88+.12*smoothstep(.02,.92,uv.y));
  float eWash=clamp(uSourceEmergency*ePulse*eMask,0.0,.94);
  vec3 emergencyRed=vec3(max(.84,composed.r*1.18+.18),composed.g*.022,composed.b*.010);
  composed=mix(composed,emergencyRed,eWash);
  // A door's absence is material identity, not dark ink. Its separately
  // depth-tested mask survives paper, x-ray and the red circuit. Pressure still
  // resolves afterwards, so the figure can stand visibly in front of a hole.
  float doorAbsence=texture(uOpeningMask,uv).r*uOpeningMaskReady;
  composed=mix(composed,vec3(0.0),doorAbsence);
  o=vec4(composed,1.0);
}`;

// Source proper is built from the same surviving materials and lights as the
// conservatoire. This pass only adapts the prop targets to the recording pass's
// colour/depth/mark contract. It does not infer materials from hue or alpha.
// The rest's flood uses the coastal crash's existing water optics and actual
// opaque depth, adapted to this acquisition shader's sampler/view names.
const SOURCE_ROOM_COAST_GLSL=`
uniform float uReduceMotionOptical;
uniform vec3 uRestEye;
// Source acquisition is already linear; unlike the coast's display adapter it
// must not decode and encode the same material again.
vec3 restCoastDisplayColour(vec3 linear){return linear;}
vec3 restCoastAcquisitionColour(vec3 linear){return linear;}
float restCoastHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5);}
float restCoastNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(restCoastHash(i),restCoastHash(i+vec2(1,0)),f.x),mix(restCoastHash(i+vec2(0,1)),restCoastHash(i+vec2(1,1)),f.x),f.y);}
`+COASTAL_MEMORY_WATER_GLSL.replaceAll('uDepth','uPropDepth').replaceAll('uYaw','uRestView.x').replaceAll('uPitch','uRestView.y')
  .replaceAll('acquisitionColour','restCoastAcquisitionColour').replaceAll('displayColour','restCoastDisplayColour').replaceAll('vnoise','restCoastNoise');
const SOURCE_ROOM_ACQUISITION_FRAG = COMMON_GLSL + `
${SOURCE_BLUEPRINT_ACQUISITION_GLSL}
uniform sampler2D uProps,uPropDepth,uPropMarks,uHull,uHullDepth,uHullMarks;
uniform vec2 uRes,uNearFar,uHullNearFar;
uniform float uMarksReady,uHullReady,uBlueprint;
uniform vec2 uRestSky,uRestView,uRestClouds;
uniform vec4 uRestSunset; // strength, sun bearing, altitude, storm cover
${SOURCE_ROOM_COAST_GLSL}
${SOURCE_REST_STARS_GLSL}
layout(location=0) out vec4 o;
layout(location=1) out vec4 oMark;
float sourceViewDepth(float depth,vec2 range){
  float ndc=depth*2.0-1.0;
  return 2.0*range.x*range.y/max(.0001,range.y+range.x-ndc*(range.y-range.x));
}
void main(){
  vec2 uv=gl_FragCoord.xy/uRes;
  if(uCoastSea.x>.5&&uRestEye.y<uCoastSea.y&&uReduceMotionOptical<.5){
    vec2 screen=(uv*2.0-1.0)*vec2(uRes.x/uRes.y*.95,.95);
    vec3 forward=vec3(sin(uRestView.x)*cos(uRestView.y),sin(uRestView.y),-cos(uRestView.x)*cos(uRestView.y));
    vec3 right=vec3(cos(uRestView.x),0.0,sin(uRestView.x)),up=cross(right,forward);
    vec3 ray=normalize(forward+screen.x*right+screen.y*up);
    float originalDepth=sourceViewDepth(texture(uPropDepth,uv).r,uNearFar);
    vec3 waterPoint=(uCoastInverse*vec4(uRestEye+ray*min(16.0,originalDepth),1.0)).xyz;
    vec2 refracted=clamp(uv+coastNormal(waterPoint.xz).xz*.004,vec2(.001),vec2(.999));
    float candidateDepth=sourceViewDepth(texture(uPropDepth,refracted).r,uNearFar);
    // The world depth prevents a foreground hand/frame from being smeared
    // into the distant wreck. Marks travel with the same refracted sample.
    if(abs(candidateDepth-originalDepth)<max(.16,originalDepth*.10))uv=refracted;
  }
  vec4 material=texture(uProps,uv);
  float viewMetres=sourceViewDepth(texture(uPropDepth,uv).r,uNearFar);
  vec4 hull=texture(uHull,uv);
  float hullMetres=sourceViewDepth(texture(uHullDepth,uv).r,uHullNearFar);
  bool useHull=uHullReady>.5&&hull.a>.001&&(material.a<=.001||hullMetres+.015<viewMetres);
  if(useHull){material=hull;viewMetres=hullMetres;}
  // Glyph RGB is already premultiplied, while physical surfaces are opaque.
  // Compositing both over unlit absence preserves their actual light values.
  vec3 acquired=clamp(material.rgb,0.0,1.0);
  if(uBlueprint>.5){
    vec2 pixel=1.0/uRes;
    vec4 neighbours=vec4(
      sourceViewDepth(texture(uPropDepth,uv+vec2(pixel.x,0)).r,uNearFar),
      sourceViewDepth(texture(uPropDepth,uv-vec2(pixel.x,0)).r,uNearFar),
      sourceViewDepth(texture(uPropDepth,uv+vec2(0,pixel.y)).r,uNearFar),
      sourceViewDepth(texture(uPropDepth,uv-vec2(0,pixel.y)).r,uNearFar));
    float contour=useHull?0.0:sourceBlueprintDepthContour(viewMetres,neighbours);
    acquired=sourceBlueprintResolve(material.rgb,material.a,viewMetres,contour,uv.y);
  }
  // Only empty space receives the sheltered rest horizon. The real window,
  // stairs, bodies and black door cores retain their depth and material.
  if(uRestSky.x>.001&&material.a<.001){
    float bearing=uRestView.x+(uv.x-.5)*2.2;
    float drift=uRestSky.y*.012;
    float banks=sin(bearing*3.0+drift)+.5*sin(bearing*7.0+uv.y*2.0-drift*.7);
    float shade=smoothstep(-.5,1.1,banks);
    float horizon=exp(-pow((uv.y-.46+uRestView.y*.45)*4.5,2.0));
    vec3 clearSky=mix(vec3(.012,.027,.047),vec3(.17,.21,.23),horizon);
    vec3 cloudBank=mix(vec3(.018,.029,.042),vec3(.09,.13,.15),horizon)*(.46+.54*shade);
    vec3 overcast=mix(clearSky,cloudBank,clamp(uRestClouds.x,0.0,1.0));
    // The same bearing/pitch convention as Source's existing moon. It stays
    // behind actual geometry and grows perceptible only when the bank clears.
    float delta=atan(sin(.785398-uRestView.x),cos(.785398-uRestView.x));
    vec2 moonCentre=vec2(.5+delta/2.2,.78-uRestView.y*.45);
    float moon=1.0-smoothstep(.029,.038,length((uv-moonCentre)*vec2(uRes.x/uRes.y,1.0)));
    overcast=mix(overcast,vec3(.58,.66,.69),moon*uRestClouds.y*(1.0-uRestClouds.x*.85));
    if(uRestSunset.x>.001){
      vec2 screen=(uv*2.0-1.0)*vec2(uRes.x/uRes.y*.95,.95);
      vec3 forward=vec3(sin(uRestView.x)*cos(uRestView.y),sin(uRestView.y),-cos(uRestView.x)*cos(uRestView.y));
      vec3 right=vec3(cos(uRestView.x),0.0,sin(uRestView.x)),up=cross(right,forward),ray=normalize(forward+screen.x*right+screen.y*up);
      vec3 sun=vec3(sin(uRestSunset.y)*cos(uRestSunset.z),sin(uRestSunset.z),-cos(uRestSunset.y)*cos(uRestSunset.z));
      float line=exp(-pow((ray.y-.015)*5.5,2.0)),glow=pow(max(0.0,dot(ray,sun)),18.0),
        disc=smoothstep(cos(.039),cos(.030),dot(ray,sun)),veil=clamp(uRestSunset.w,0.0,1.0);
      vec3 dusk=mix(vec3(.035,.020,.062),vec3(.54,.155,.035),line);
      dusk+=vec3(.28,.085,.012)*glow;
      dusk=mix(dusk,vec3(.012,.017,.028)+vec3(.075,.043,.040)*line,veil*.86);
      dusk=mix(dusk,vec3(.95,.48,.105),disc*(1.0-veil*.94));
      float starReveal=.18+.82*(1.0-smoothstep(-.025,.065,uRestSunset.z));
      dusk+=sourceRestStars(ray,starReveal,uRestClouds.x,veil);
      overcast=mix(overcast,dusk,clamp(uRestSunset.x,0.0,1.0));
    }
    acquired=mix(acquired,overcast,clamp(uRestSky.x,0.0,1.0));
  }
  if(uCoastSea.x>.5){
    vec2 screen=(uv*2.0-1.0)*vec2(uRes.x/uRes.y*.95,.95);
    vec3 forward=vec3(sin(uRestView.x)*cos(uRestView.y),sin(uRestView.y),-cos(uRestView.x)*cos(uRestView.y));
    vec3 right=vec3(cos(uRestView.x),0.0,sin(uRestView.x)),up=cross(right,forward);
    vec3 ray=normalize(forward+screen.x*right+screen.y*up);
    acquired=coastalWaterComposite(uRestEye,ray,viewMetres/max(.001,dot(ray,forward)),material.a,acquired,0.0);
  }
  o=vec4(acquired,1.0/(1.0+viewMetres*.14));
  // The exact production sentinel has no derived grain. Never read marks left
  // by a preceding overworld frame when this surface has no authored marks.
  oMark=useHull?texelFetch(uHullMarks,ivec2(uv*uRes),0):
    uMarksReady>.5?texelFetch(uPropMarks,ivec2(uv*uRes),0):vec4(0.0,.5,.5,1.0);
}`;

// Exact door absence after POST, preserving real geometry in front of it.
const SOURCE_IDENTITY_FRAG = COMMON_GLSL + `
uniform sampler2D uOpeningMask,uHushBodyTex,uPropDepth;
uniform float uOpeningMaskReady,uPressureReady;
uniform vec2 uRes,uNearFar;
out vec4 o;
void main(){
 vec2 uv=gl_FragCoord.xy/uRes;vec4 g=texture(uHushBodyTex,uv);
 float d=dot(g.rg,vec2(65280.0,255.0))*uNearFar.y/65535.0;
 float z=texture(uPropDepth,uv).r*2.0-1.0;
 float front=2.0*uNearFar.x*uNearFar.y/(uNearFar.y+uNearFar.x-z*(uNearFar.y-uNearFar.x));
 float cover=g.a*step(d,front+.022)*uPressureReady;
 float absence=clamp(texture(uOpeningMask,uv).r*uOpeningMaskReady,0.0,1.0);
 o=vec4(0.0,0.0,0.0,absence*(1.0-cover));
}`;

const COPY_FRAG = COMMON_GLSL + `
uniform sampler2D uSrc;
uniform vec2 uRes;
out vec4 o;
void main(){o=texture(uSrc,gl_FragCoord.xy/uRes);}`;

// The instrument's moving face is fixed to the actual booth back wall. Empty
// canvas pixels leave the physical enclosure and the road visible, and the
// whole face enters the same acquisition pass as the surrounding ironwork.
const TABLEAU_FRAG = COMMON_GLSL + `
uniform sampler2D uTableau,uPropDepth;
uniform vec2 uRes,uNearFar,uPlaneSize;
uniform vec3 uEye,uForward,uCameraRight,uCameraUp;
uniform vec3 uPlaneOrigin,uPlaneRight,uPlaneUp;
uniform float uGain,uSpatial;
layout(location=0) out vec4 o;
layout(location=1) out vec4 oMark;
void main(){
  vec2 screenUv=gl_FragCoord.xy/uRes,uv=screenUv;
  float viewDepth=.6;
  if(uSpatial>.5){
    vec2 screen=(screenUv*2.0-1.0)*vec2(uRes.x/uRes.y*.95,.95);
    vec3 ray=normalize(uForward+screen.x*uCameraRight+screen.y*uCameraUp);
    vec3 normal=cross(uPlaneRight,uPlaneUp);
    float denominator=dot(ray,normal);
    if(denominator>=-.00001)discard;
    float distanceM=dot(uPlaneOrigin-uEye,normal)/denominator;
    if(distanceM<=.01)discard;
    vec3 hit=uEye+ray*distanceM-uPlaneOrigin;
    uv=vec2(dot(hit,uPlaneRight)/uPlaneSize.x,-dot(hit,uPlaneUp)/uPlaneSize.y);
    if(any(lessThan(uv,vec2(0.0)))||any(greaterThan(uv,vec2(1.0))))discard;
    viewDepth=distanceM*dot(ray,uForward);
    float z=texture(uPropDepth,screenUv).r*2.0-1.0;
    float front=2.0*uNearFar.x*uNearFar.y/(uNearFar.y+uNearFar.x-z*(uNearFar.y-uNearFar.x));
    if(front+.022<viewDepth)discard;
    uv.y=1.0-uv.y;
  }
  vec4 c=texture(uTableau,uv);
  if(c.a<.5)discard;
  o=vec4(pow(c.rgb,vec3(2.2))*uGain,1.0/(1.0+viewDepth*.14));
  oMark=vec4(0.0,.5,.5,1.0);
}`;

// The outskirts and bell field are physical objects in empty space, not text
// projected through the instrument. Preserve their GLB materials and prop-pass
// depth. In particular a black metal surface is still opaque: alpha, never
// luminance, decides whether the void behind it is visible.
const SOURCE_VOID_PHYSICAL_FRAG = COMMON_GLSL + `
uniform sampler2D uProps, uDepth;
uniform sampler2D uPropMarks;
uniform sampler2D uOpeningMask;
uniform float uOpeningMaskReady;
uniform vec2 uRes, uNearFar;
uniform vec4 uDriveSky;
uniform sampler2D uDriveLandMap;
uniform vec4 uDriveLand;    // strength, fog
uniform vec3 uDriveLandEye; // metres in the road's frame
uniform float uPitch;
uniform float uVoidDawn;
uniform vec4 uBeacon;
uniform float uEntryMetres;
uniform float uYaw;
uniform vec4 uTorch;
uniform vec3 uTorchColor;
uniform vec4 uUnravelling; // amount, street retention, loss, active
uniform vec3 uUnravelOrigin; // physical seam x, ground y, seam z
uniform float uRain;
uniform float uTime, uReduceMotionOptical, uOpticalEffects, uFlash, uOvercast;
uniform vec3 uEyeCells;
// Stable material/weather coordinates across a floating-origin road rebase.
// Geometry, depth, lamps and door pools continue to use the physical eye.
uniform vec3 uWorldPatternOffset;
uniform vec4 uDoorA[3]; // threshold x, z (m); facing x, z
uniform vec4 uDoorB[3]; // colour, strength
uniform vec4 uDoorC[3]; // width (m), open, pool
uniform vec3 uEyeGround; // eye x, z (m); eye height above that ground
uniform sampler2D uReflection; // the scene mirrored under the road (props3d reflection pass)
uniform vec4 uReflectEye;      // eye x, z (m); eye height above the road; active
uniform vec4 uPuddle;          // the pool under the last light: x, z, radius (m); how wet the road is
uniform float uReflectDebug;    // 1: show the mirrored pass everywhere (probe)
layout(location=0) out vec4 o;
layout(location=1) out vec4 oMark;
${PRINTED_SURFACE_GLSL}
vec3 displayColour(vec3 linear){
  vec3 low=linear*12.92;
  vec3 high=1.055*pow(max(linear,vec3(0.0)),vec3(1.0/2.4))-.055;
  return mix(low,high,step(vec3(.0031308),linear));
}
vec3 acquisitionColour(vec3 display){
  vec3 low=display/12.92;
  vec3 high=pow(max((display+.055)/1.055,vec3(0.0)),vec3(2.4));
  return mix(low,high,step(vec3(.04045),display));
}
// hash01 as the march has it, spelled without a screen-space fract.
float hash01(float x, float y){ float h=abs(sin(x*127.1 + y*311.7) * 43758.5); return h-floor(h); }
float vnoise(vec2 p){
  // Spelled with floor rather than the fractional-part builtin, which this shader's spec bans.
  vec2 i=floor(p),f=p-floor(p);f=f*f*(3.0-2.0*f);
  float a=hash01(i.x,i.y),b=hash01(i.x+1.0,i.y),c=hash01(i.x,i.y+1.0),d=hash01(i.x+1.0,i.y+1.0);
  return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);
}
// WHERE THE ROAD HOLDS WATER: patches that spread as the road gets wetter, and the
// one pool that is always there, under the last light.
float puddleMask(vec2 p){
  vec2 patternP=p+uWorldPatternOffset.xz;
  float n=vnoise(patternP*.32)*.6+vnoise(patternP*.9+13.1)*.3+vnoise(patternP*2.3-7.7)*.1;
  float threshold=mix(.8,.55,clamp(uPuddle.w,0.0,1.0));
  float patches=smoothstep(threshold,threshold+.05,n);
  float pool=uPuddle.z>.01?1.0-smoothstep(uPuddle.z*.7,uPuddle.z,length(p-uPuddle.xy)):0.0;
  return max(patches,pool);
}

uniform mat4 uDriveCabinInverse,uDriveVolumeShadowMatrix,uDriveReturnBodyInverse;
uniform vec4 uDriveReturnMin,uDriveReturnMax;
uniform vec4 uDriveWeather,uDrivePane,uDrivePaneSlope,uDriveWeatherExtra,uDriveStorm,uDriveRainRoof,uDriveLoad,uDriveAirLayer,uDriveImpossibleWeather;
uniform vec4 uDriveFogLamp0,uDriveFogLamp1;
uniform sampler2D uDriveWetness,uDriveVolumeShadow;
uniform float uDriveVolumeShadowReady;
float driveDepth(vec2 q){float z=texture(uDepth,q).r*2.0-1.0;return 2.0*uNearFar.x*uNearFar.y/max(.0001,uNearFar.y+uNearFar.x-z*(uNearFar.y-uNearFar.x));}
float driveCabinExit(vec3 p,vec3 d){
 vec3 safe=sign(d)*max(abs(d),vec3(.00001));safe=mix(vec3(.00001),safe,step(vec3(.00001),abs(d)));
 vec3 face=mix(vec3(-.95,.6,-1.08),vec3(.95,2,.9),step(vec3(0.0),d));
 vec3 t=(face-p)/safe;return max(0.0,min(t.x,min(t.y,t.z)));
}
float driveFogShadow(vec3 p){if(uDriveVolumeShadowReady<.5)return 1.0;vec4 clip=uDriveVolumeShadowMatrix*vec4(p,1.0);if(clip.w<=0.0)return 1.0;vec3 q=clip.xyz/clip.w*.5+.5;if(any(lessThanEqual(q,vec3(0.0)))||any(greaterThanEqual(q,vec3(1.0))))return 1.0;return q.z-.00035<=texture(uDriveVolumeShadow,q.xy).r?1.0:.04;}
${DIPPED_BEAM_GLSL}
// The same UK dipped beam that lights the surfaces, in the rain and fog: the hot zone
// just under the cut-off glows down the road and the kick-up lifts on the nearside.
float driveLampBeam(vec3 p,vec4 lamp){vec3 r=p-lamp.xyz;float along=dot(r,vec3(sin(uDriveWeatherExtra.x),0.0,-cos(uDriveWeatherExtra.x)));return lamp.w*1.80*ukDippedBeam(r,uDriveWeatherExtra.x,uDriveWeatherExtra.y)*min(2.0,pow(18.0/(10.0+max(0.0,along)),2.0));}
vec4 driveAir(vec3 eye,vec3 rd,float begin,float end){
 float lengthM=clamp(end-begin,0.0,220.0),transmission=1.0;vec3 scattered=vec3(0.0);
 // The rain-laden air occupies the actual raised carriageway, not sea level.
 // Broad sheets advect in world space; their density loads with the same front
 // as the water and tissue instead of using another decorative animation clock.
 // Quadratic metre intervals retain nearby billows when the depth target is
 // a distant cliff or empty sky. A coarse equal march missed the near fog and
 // made it appear to be a flat boundary across the carriageway.
 for(int i=0;i<12;i++){float a=float(i)/12.0,b=float(i+1)/12.0,stepM=(b*b-a*a)*lengthM;vec3 p=eye+rd*(begin+(a*a+b*b)*.5*lengthM);vec2 drift=uDriveWeatherExtra.zw*uDriveWeather.z*.035;
  float broad=vnoise(p.xz*.035-drift),pocket=.64+.36*broad,low=exp(-max(0.0,p.y-uDriveAirLayer.x-.3)*.20);
  vec2 billowSpace=p.xz*.095-drift*2.1+vec2(p.y*.13,-p.y*.08);
  float billow=.56*vnoise(billowSpace)+.29*vnoise(billowSpace*2.3+13.8)+.15*vnoise(billowSpace*4.7-7.1);
  float bank=smoothstep(.25,.76,billow),squall=.40+.60*smoothstep(.20,.75,vnoise(p.xz*.055-drift*3.2));
  float beta=uDriveWeather.y*pocket*(.30+.70*low)+uDriveImpossibleWeather.x*(.010+.055*bank)+uDriveImpossibleWeather.z*(.016+.070*squall);
  // The first few metres stay a finite sightline at a crawl. Lamp backscatter
  // can obscure the distant lane without replacing the picture with a card.
  beta*=mix(.30,1.0,smoothstep(.7,5.0,length(p-eye)));
  float t=exp(-beta*stepM),lamps=(driveLampBeam(p,uDriveFogLamp0)+driveLampBeam(p,uDriveFogLamp1))*driveFogShadow(p);
  vec3 daylight=mix(vec3(.007,.009,.012),vec3(.075,.086,.100),uDriveImpossibleWeather.z);
  vec3 backscatter=vec3(1.0,.89,.72)*lamps*(.018+.065*uDriveImpossibleWeather.x+.12*uDriveImpossibleWeather.z);
  scattered+=transmission*(1.0-t)*(daylight+backscatter);transmission*=t;}
 return vec4(scattered,transmission);
}
vec3 driveDrop(vec3 ro,vec3 rd,vec2 cell,float end){
 float seed=hash01(cell.x+19.0,cell.y-7.0),occupancy=(.46+.12*uDriveAirLayer.z)*sqrt(clamp(uDriveWeather.x,0.0,1.0));if(uDriveWeather.x<=.001||seed<1.0-occupancy)return vec3(0.0);
 float clock=uDriveWeather.z*mix(1.0,.38,uReduceMotionOptical),fall=mix(5.5,8.5,seed),span=9.0;
 // Select the world-anchored vertical repeat containing this ray. The old
 // absolute −3..6m band lay below the elevated road, so the climb lost its rain.
 float age=mod(seed*span+clock*fall,span),top=6.0+ro.y-mod(age+ro.y,span),streak=mix(.23,.43,seed)*mix(1.0,.4,uReduceMotionOptical);
 vec2 wind=uDriveWeatherExtra.zw,drift=wind*(age/fall)*.18;
 vec3 a=vec3((cell.x+hash01(cell.x+3.0,cell.y))*1.1+drift.x,top,(cell.y+hash01(cell.x,cell.y+9.0))*1.1+drift.y),b=a+vec3(wind.x*.18,-1.0,wind.y*.18)*streak,v=b-a,w=ro-a;
 float B=dot(rd,v),C=dot(v,v),D=dot(rd,w),E=dot(v,w),den=C-B*B;
 float along=den>.000001?(B*E-C*D)/den:0.0,t=clamp((E+B*max(0.0,along))/max(.000001,C),0.0,1.0);along=max(0.0,dot(a+v*t-ro,rd));
 if(along<=.02||along>=end)return vec3(0.0);float distanceM=length(ro+rd*along-a-v*t),radius=.006+.004*seed,pixelRadius=along*.65/uRes.y,aa=max(.001,pixelRadius);
 float coverage=(1.0-smoothstep(max(0.0,radius-aa),radius+aa,distanceM))*min(1.0,radius/max(.001,pixelRadius))*(1.0-smoothstep(end*.85,end,along));if(coverage<=.001)return vec3(0.0);
 vec3 hit=ro+rd*along;
 // The real upper bridge deck blocks falling drops beneath it. This is a
 // world-space shelter, so rain beyond its mouths remains visible.
 vec2 roofDelta=hit.xz-uDriveRainRoof.xz;float cr=cos(uDriveRainRoof.w),sr=sin(uDriveRainRoof.w);
 if(uDriveRainRoof.y>0.0&&hit.y<uDriveRainRoof.y&&abs(dot(roofDelta,vec2(cr,sr)))<6.9&&abs(dot(roofDelta,vec2(-sr,cr)))<8.0)return vec3(0.0);
 float lamps=(driveLampBeam(hit,uDriveFogLamp0)+driveLampBeam(hit,uDriveFogLamp1))*driveFogShadow(hit);
 // Rain controls how many world drops exist, not the brightness of each one.
 // A detected drop reflects a dim sky plus its actual bounded lamp exposure.
 return coverage*(vec3(.040,.050,.065)+vec3(1.0,.89,.72)*min(.24,lamps*.085));
}
vec3 driveRain(vec3 ro,vec3 rd,float end){
 float horizontal=length(rd.xz);if(horizontal<.001||end<=.02)return vec3(0.0);vec2 pos=ro.xz/1.1,cell=floor(pos),dir=rd.xz/horizontal,stp=sign(dir),safe=max(abs(dir),vec2(.00001)),delta=1.0/safe;
 vec2 boundary=cell+max(stp,vec2(0.0)),next=abs(boundary-pos)/safe;vec3 acc=driveDrop(ro,rd,cell,end);
 for(int i=0;i<10;i++){float travelled;if(next.x<next.y){travelled=next.x;next.x+=delta.x;cell.x+=stp.x;}else{travelled=next.y;next.y+=delta.y;cell.y+=stp.y;}if(travelled*1.1/horizontal>min(end,14.0))break;acc=max(acc,driveDrop(ro,rd,cell,end));}
 return acc;
}
vec3 driveSnowCell(vec3 ro,vec3 rd,vec2 cell,float end,float spacing,float layer){
 float seed=hash01(cell.x+71.0+layer*13.0,cell.y-37.0),amount=uDriveImpossibleWeather.y;
 if(seed>amount*.86)return vec3(0.0);
 float clock=uDriveWeather.z*mix(1.0,.38,uReduceMotionOptical),span=9.0+layer*5.0,fall=.45+seed*.8;
 vec2 wind=uDriveWeatherExtra.zw*(.32+.26*uDriveImpossibleWeather.z),advection=wind*clock;
 float age=mod(clock*fall+seed*span,span),top=ro.y+span*.5-mod(age+ro.y,span);
 vec3 a=vec3((cell.x+hash01(cell.x+4.0,cell.y))*spacing+advection.x,top,(cell.y+hash01(cell.x,cell.y+6.0))*spacing+advection.y);
 // World flakes have the saved wind direction. Sidelight reveals them crossing
 // the carriageway; turning one's head cannot rotate a rain/snow overlay.
 a.xz+=vec2(sin(clock*.73+seed*31.0),cos(clock*.49+seed*23.0))*(.06+.11*layer);
 vec3 v=vec3(wind.x,-fall,wind.y)*(.025+.035*seed),w=ro-a;
 float B=dot(rd,v),C=dot(v,v),D=dot(rd,w),E=dot(v,w),den=C-B*B;
 float along=den>.000001?(B*E-C*D)/den:0.0,t=clamp((E+B*max(0.0,along))/max(.000001,C),0.0,1.0);along=max(0.0,dot(a+v*t-ro,rd));
 if(along<=.08||along>=end)return vec3(0.0);
 float distanceM=length(ro+rd*along-a-v*t),radius=(.010+.020*seed)*(1.0+.4*layer),pixelRadius=along*.65/uRes.y,aa=max(.001,pixelRadius);
 float coverage=(1.0-smoothstep(max(0.0,radius-aa),radius+aa,distanceM))*min(1.0,radius/max(.001,pixelRadius))*(1.0-smoothstep(end*.8,end,along));
 if(coverage<=.001)return vec3(0.0);vec3 hit=ro+rd*along;
 vec2 roofDelta=hit.xz-uDriveRainRoof.xz;float cr=cos(uDriveRainRoof.w),sr=sin(uDriveRainRoof.w);
 if(uDriveRainRoof.y>0.0&&hit.y<uDriveRainRoof.y&&abs(dot(roofDelta,vec2(cr,sr)))<6.9&&abs(dot(roofDelta,vec2(-sr,cr)))<8.0)return vec3(0.0);
 float lamps=(driveLampBeam(hit,uDriveFogLamp0)+driveLampBeam(hit,uDriveFogLamp1))*driveFogShadow(hit);
 return coverage*(vec3(.095,.110,.130)+vec3(1.0,.91,.79)*min(.65,lamps*.22));
}
vec3 driveSnowField(vec3 ro,vec3 rd,float end,float spacing,float layer){
 float horizontal=length(rd.xz);if(horizontal<.001||end<=.02)return vec3(0.0);
 float clock=uDriveWeather.z*mix(1.0,.38,uReduceMotionOptical);vec2 advection=uDriveWeatherExtra.zw*(.32+.26*uDriveImpossibleWeather.z)*clock;
 vec2 pos=(ro.xz-advection)/spacing,cell=floor(pos),dir=rd.xz/horizontal,stp=sign(dir),safe=max(abs(dir),vec2(.00001)),delta=1.0/safe;
 vec2 boundary=cell+max(stp,vec2(0.0)),next=abs(boundary-pos)/safe;vec3 acc=driveSnowCell(ro,rd,cell,end,spacing,layer);
 for(int i=0;i<11;i++){float travelled;if(next.x<next.y){travelled=next.x;next.x+=delta.x;cell.x+=stp.x;}else{travelled=next.y;next.y+=delta.y;cell.y+=stp.y;}if(travelled*spacing/horizontal>min(end,32.0))break;acc=max(acc,driveSnowCell(ro,rd,cell,end,spacing,layer));}
 return acc;
}
// THE M62 COUNTRY. A height field in the road's frame (m62-land.js), marched from the
// eye and only where nothing solid is in the way. A one-bit print can't hold a
// gradient but it holds a black edge against lit cloud, so the near ground goes
// black, and each ridge further off hazes back toward the sky. Display values.
vec4 driveLandAt(vec2 p){
  vec2 q=clamp(p/16000.0,-1.0,1.0);
  return textureLod(uDriveLandMap,.5+.5*sign(q)*sqrt(abs(q)),0.0);
}
vec3 driveLandShade(vec3 dir,vec3 sky){
  vec2 flatDir=normalize(dir.xz+vec2(1e-5));
  float rise=max(dir.y,0.0);
  // The underside of the cloud is lit from below all round, most of all over the town.
  float townward=pow(max(dot(flatDir,vec2(.62,-.78)),0.0),3.0);
  vec3 lit=sky+displayColour(vec3(.0058,.0072,.0098)*exp(-rise*14.0)+vec3(.024,.014,.0058)*townward*exp(-rise*11.0));
  vec3 col=lit;
  vec3 eye=uDriveLandEye;
  float hitT=-1.0;
  if(dir.y<.2){
    float t=14.0,last=t;
    float end=dir.y>.001?min(15000.0,(420.0-eye.y)/dir.y):15000.0;
    for(int i=0;i<72&&t<end;i++){
      vec3 p=eye+dir*t;
      if(p.y<=driveLandAt(p.xz).r){hitT=t;break;}
      last=t;t+=max(3.0,t*.07);
    }
    if(hitT>0.0){
      float a=last,b=hitT;
      for(int i=0;i<6;i++){float m=(a+b)*.5;vec3 p=eye+dir*m;if(p.y<=driveLandAt(p.xz).r)b=m;else a=m;}
      hitT=b;
      vec3 p=eye+dir*hitT;vec4 s=driveLandAt(p.xz);
      float e=max(5.0,hitT*.012);
      vec3 n=normalize(vec3(driveLandAt(p.xz-vec2(e,0.0)).r-driveLandAt(p.xz+vec2(e,0.0)).r,2.0*e,driveLandAt(p.xz-vec2(0.0,e)).r-driveLandAt(p.xz+vec2(0.0,e)).r));
      float ground=s.g*(.2+.8*n.y*n.y);
      // Drystone walls, as dark lines on the improved ground lower down. Each row of
      // fields is shifted against the next: they were enclosed a field at a time.
      if(s.a>.02&&hitT<2400.0){
        vec2 g=p.xz/vec2(124.0,92.0);
        g.x+=.37*sin(floor(g.y)*2.3);g.y+=.21*sin(floor(g.x)*1.9);
        vec2 edge=abs(fract(g)-.5);
        float wide=clamp(hitT*.0012/92.0,.012,.05);
        ground*=1.0-.92*smoothstep(.5-wide*1.7,.5-wide*.5,max(edge.x,edge.y))*s.a*(1.0-smoothstep(1500.0,2400.0,hitT));
      }
      vec3 land=displayColour(vec3(.040,.048,.064)*ground);
      // Still water takes the sky and gives it back, paler than anything round it.
      if(s.b>.5)land=mix(displayColour(vec3(.03,.038,.052)),lit,.45);
      float haze=1.0-exp(-hitT*(1.0+uDriveLand.y*18.0)/5200.0);
      col=mix(land,lit*.92,haze);
    }
    // The transmitter tower: one concrete line on the skyline, tall enough to show
    // over everything, with its red lights in the far-light pass.
    vec2 toTower=vec2(4800.0,-3400.0)-eye.xz;
    float range=length(toTower),along=dot(toTower,flatDir);
    if(along>0.0&&(hitT<0.0||hitT>range)){
      float across=abs(flatDir.x*toTower.y-flatDir.y*toTower.x),climb=dir.y/max(.0001,length(dir.xz));
      float h=(eye.y+climb*range-300.0)/330.0;
      float half_=max(range*.00042,h<.66?15.0-h*14.0:2.2);
      if(h>0.0&&h<1.0&&across<half_)col=mix(vec3(.02),lit,.3);
    }
  }
  return col;
}
vec3 driveSnow(vec3 ro,vec3 rd,float end){
 if(uDriveImpossibleWeather.y<=.001)return vec3(0.0);
 return max(driveSnowField(ro,rd,end,.85,0.0),driveSnowField(ro,rd,end,2.1,1.0));
}
`+RAIN_GLSL+UNRAVELLING_GLSL+COASTAL_MEMORY_WATER_GLSL+`
void main(){
  vec2 uv=gl_FragCoord.xy/uRes;
  vec2 screen=(uv*2.0-1.0)*vec2(uRes.x/uRes.y,1.0)*(uDriveSky.a>.5?.65:.95);
  float rayY=(screen.y*cos(uPitch)+sin(uPitch))/sqrt(1.0+dot(screen,screen));
  float below=1.0-smoothstep(-.045,.025,rayY);
  vec3 empty=mix(vec3(.007,.010,.013),vec3(.017,.021,.023),below);
  float driveHorizon=exp(-pow((rayY+.015)*10.0,2.0));
  empty=mix(empty,displayColour(vec3(.0035,.0045,.006)+uDriveSky.rgb*driveHorizon),uDriveSky.a);
  empty+=vec3(.007,.008,.008)*exp(-pow(rayY/.018,2.0));
  // THE FIELD'S PAPER, going out. At the field's edge the empty ground is still
  // the paper the field was printed on; across the outskirts it goes to black.
  empty=mix(empty,mix(vec3(.965,.925,.835),vec3(.80,.77,.70),below),clamp(uVoidDawn,0.0,1.0));
  // UNDER THE STORM there is cloud: a low, lit overcast the hedges and the trees
  // stand black against, brightest toward the horizon. The ground stays dark.
  empty=mix(empty,vec3(.050,.057,.072)*(1.0-.55*smoothstep(.0,.5,rayY)),clamp(uOvercast,0.0,1.0)*(1.0-below));
  // THE PICTURE, AHEAD. Short of the tape its head stands on the horizon as a lit
  // screen at the size it really is from here: somewhere to walk to. Props in
  // front of it still hide it.
  if(uBeacon.w>.001){
    float azimuth=uYaw+atan(screen.x);
    float offset=atan(sin(azimuth-uBeacon.x),cos(azimuth-uBeacon.x));
    float across=1.0-smoothstep(uBeacon.y*.92,uBeacon.y,abs(offset));
    float up=smoothstep(-.004,.004,rayY)*(1.0-smoothstep(uBeacon.z*.9,uBeacon.z,rayY));
    vec3 picture=mix(vec3(.80,.78,.10),vec3(.04,.82,.70),step(0.0,offset));
    float halo=exp(-pow(max(0.0,abs(offset)-uBeacon.y)/.04,2.0))*exp(-pow(rayY/max(.01,uBeacon.z),2.0));
    empty=mix(empty,picture,across*up*uBeacon.w);
    empty+=picture*halo*.35*uBeacon.w;
  }
  // LIGHT OUT OF THE DOORS. A world behind a door lights the ground in front of
  // it: a wide pool through an open doorway, a thin bright line under a shut one.
  vec3 dv=normalize(vec3(screen.x,screen.y,1.0));
  float cp=cos(uPitch),sp=sin(uPitch);
  dv=vec3(dv.x,dv.y*cp+dv.z*sp,-dv.y*sp+dv.z*cp);
  vec3 wd=vec3(dv.x*cos(uYaw)+dv.z*sin(uYaw),dv.y,dv.x*sin(uYaw)-dv.z*cos(uYaw));
  if(uCoastSea.x>.5&&uDriveSky.a<.5)empty=displayColour(coastSky(mat3(uCoastInverse)*wd));
  if(uDriveWeather.w>.5){
    // Large cloud volumes move in world direction, not with the driver's head.
    // Their quiet backlight makes an ordinary weather baseline before the
    // impossible water and thorax arrive; no flash or screen-space rain card.
    vec2 skyPoint=wd.xz/max(.16,wd.y+.24)*3.6-uDriveWeatherExtra.zw*uDriveWeather.z*.004;
    // Before the first bone, a torn directional cloud bank picks up the same
    // long strakes as the water. Domain changes blend over the whole approach.
    float pulled=clamp(uDriveLoad.y*.65+uDriveLoad.z*.35,0.0,1.0);
    vec2 scud=skyPoint*vec2(1.0+pulled*.85,1.0-pulled*.24);
    scud+=vec2(vnoise(skyPoint*.73+4.8)-.5,vnoise(skyPoint*.61-9.3)-.5)*(.55+uDriveLoad.x*.8);
    float cloud=.58*vnoise(scud)+.28*vnoise(scud*2.1+13.4)+.14*vnoise(scud*4.3-7.1);
    float billow=smoothstep(.28,.77,cloud),horizonGlow=exp(-pow((wd.y+.025)*5.5,2.0));
    vec3 skyLight=mix(vec3(.0045,.007,.012),vec3(.075,.094,.12),billow)*(1.0-.22*uDriveLoad.x)+vec3(.012,.015,.020)*horizonGlow;
    empty=mix(empty,displayColour(skyLight),smoothstep(-.05,.12,wd.y)*uDriveStorm.x);
  }
  if(uDriveLand.x>0.0){
    float landNdc=texture(uDepth,uv).r*2.0-1.0;
    float landZ=2.0*uNearFar.x*uNearFar.y/max(.0001,uNearFar.y+uNearFar.x-landNdc*(uNearFar.y-uNearFar.x));
    // Anything solid nearer than the far-plane haze would only paint over it.
    if(landZ>uNearFar.y*.58)empty=mix(empty,driveLandShade(wd,empty),uDriveLand.x);
  }
  if(uUnravelling.w>.5&&wd.y<-.001){
    float roadT=(uEyeCells.y*.5-uUnravelOrigin.y)/-wd.y;
    vec2 road=uEyeCells.xz*.5+wd.xz*roadT;
    vec2 roadPattern=road+uWorldPatternOffset.xz;
    float grit=vnoise(roadPattern*2.1)*.65+vnoise(roadPattern*.31)*.35;
    vec3 asphalt=vec3(.115,.123,.120)*(.78+grit*.35);
    float worn=1.0-smoothstep(4.0,7.0,abs(road.x-uUnravelOrigin.x)+(vnoise(roadPattern*.12)-.5)*1.4);
    asphalt+=vec3(.027,.025,.016)*worn;
    float roadFade=(1.0-smoothstep(38.0,100.0,roadT))
      *(1.0-smoothstep(-8.0,58.0,uEntryMetres));
    // A broad continuous footing remains when the walls and picture fail.
    // Its quiet texture gives speed without rails, sleepers or a narrow lane.
    empty=mix(empty,asphalt,roadFade*smoothstep(0.0,.12,uUnravelling.x));
  }
  // THE TORCH, WHERE THERE IS NOTHING TO LAND ON. Add this after the road's
  // unlit material, otherwise that material paints over the beam at ground level.
  if(uTorch.x>.001){
    float axis=1.0/sqrt(1.0+dot(screen,screen));
    float cone=smoothstep(uTorch.y-.05,uTorch.z,axis);
    float groundT=1.6/max(.004,-rayY);
    float pool=cone*(1.0-smoothstep(-.004,.02,rayY))/(1.0+pow(groundT/(9.0*max(.35,uTorch.w)),2.0));
    // At the recording head the torch can still catch real road and metal,
    // but its invented pool on empty air is swallowed by the void.
    float hollow=1.0-smoothstep(-18.0,-1.0,uEntryMetres);
    empty+=uTorchColor*(pool*.62+cone*.035)*uTorch.x*hollow;
  }
  if(uDoorB[0].w+uDoorB[1].w+uDoorB[2].w>.001){
    if(wd.y<-.001){
      vec2 hit=uEyeGround.xy+wd.xz*(uEyeGround.z/-wd.y);
      for(int k=0;k<3;k++){
        if(uDoorB[k].w<=.001)continue;
        vec2 rel=hit-uDoorA[k].xy;
        vec2 n=uDoorA[k].zw;
        float along=dot(rel,n);
        float across=abs(rel.x*n.y-rel.y*n.x);
        if(uDoorC[k].z>.5){
          // A LAMP'S POOL on the road: round, brightest under the head.
          float r=length(rel)/max(.5,uDoorC[k].x);
          empty+=uDoorB[k].rgb*uDoorB[k].w*(1.0-smoothstep(.15,1.0,r))*(1.0-smoothstep(.15,1.0,r))*.55;
          continue;
        }
        float openness=uDoorC[k].y;
        float spread=uDoorC[k].x*.5+max(along,0.0)*mix(.02,.35,openness);
        float reach=mix(.45,7.0,openness);
        float lit=(1.0-smoothstep(spread*.85,spread*1.05,across))*smoothstep(-.05,.05,along)*(1.0-smoothstep(reach*.6,reach,along));
        float fall=exp(-max(along,0.0)/mix(.18,3.2,openness));
        empty+=uDoorB[k].rgb*uDoorB[k].w*lit*fall*mix(1.4,.55,openness);
      }
    }
  }
  // The entry develops in the world-anchored tape fragments. A camera-space
  // vapour wash here stayed attached to the view throughout the approach.
  vec4 body=texture(uProps,uv);
  float ndc=texture(uDepth,uv).r*2.0-1.0;
  float distanceM=2.0*uNearFar.x*uNearFar.y/max(.0001,uNearFar.y+uNearFar.x-ndc*(uNearFar.y-uNearFar.x));
  // At the prop pass's true far plane the material resolves into nothing,
  // instead of the ninety-metre clip drawing a hard ring around the player.
  float haze=smoothstep(uNearFar.y*.58,uNearFar.y*.99,distanceM);
  vec3 material=displayColour(clamp(body.rgb,0.0,1.0));
  material=mix(material,empty,haze*.98);
  // The cliff has its own maritime air, rather than the yard shader's bright
  // fixed-distance fog. Nearby wood and paper retain their actual contrast.
  if(uCoastSea.x>.5&&uDriveSky.a<.5){
    float air=1.0-exp(-max(0.0,distanceM-8.0)*.0034);
    material=displayColour(mix(acquisitionColour(material),coastSky(mat3(uCoastInverse)*wd),air));
  }
  float coverage=clamp(body.a,0.0,1.0);
  if(uUnravelling.w>.5){
    vec3 fwd=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    vec3 hit=uEyeCells*.5+wd*(distanceM/max(.001,dot(wd,fwd)));
    float keep=unravelKeep(hit-uUnravelOrigin,uUnravelling.x);
    // The last real road loses its silhouette across travelled distance.
    // Keeping every curb at full contrast until it is behind the camera made
    // the blackness read as a doorway framed by a perfectly straight road.
    coverage*=keep*(1.0-smoothstep(-10.0,50.0,uEntryMetres));
    float broken=smoothstep(.12,.70,uUnravelling.x)*(1.0-keep);
    // Surviving chunks retain their material and silhouette before their
    // colour separates into the same cold/warm packets as the recording.
    material=mix(material,material.brg,broken*.45);
  }
  vec3 colour=mix(empty,material,coverage);
  // THE WET ROAD. Where the ray reaches the road with nothing standing in front of
  // it, and the road holds water there, the scene shows in it mirrored, trembling
  // with the rain. It is the only place the double is drawn.
  if(uReflectDebug>.5&&uReflectEye.w>.5){
    vec4 m=texture(uReflection,vec2(uv.x,1.0-uv.y));
    colour=mix(vec3(.25,0.0,.25),displayColour(clamp(m.rgb,0.0,1.0))+vec3(.15),clamp(m.a,0.0,1.0));
  } else if(uReflectEye.w>.5&&wd.y<-.002){
    float tRoad=uReflectEye.z/-wd.y;
    vec3 fwd=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    float roadDepth=tRoad*dot(wd,fwd);
    bool onRoad=body.a<.02||abs(distanceM-roadDepth)<.25+roadDepth*.015;
    if(onRoad&&tRoad<60.0){
      vec2 hit=uReflectEye.xy+wd.xz*tRoad;
      float mask=puddleMask(hit);
      if(mask>.001){
        vec2 patternHit=hit+uWorldPatternOffset.xz;
        vec2 ripple=vec2(sin(patternHit.x*7.0+uTime*3.1+vnoise(patternHit*2.0)*6.0),sin(patternHit.y*7.0+uTime*2.6+vnoise(patternHit*2.0+4.0)*6.0))*.0035*uRain*(1.0-uReduceMotionOptical);
        vec4 mirrored=texture(uReflection,vec2(uv.x,1.0-uv.y)+ripple);
        float held=clamp(mirrored.a,0.0,1.0);
        // Where nothing is mirrored the water only darkens the road a little: a sheen.
        // Where something is, standing water gives it back almost whole.
        vec3 sheen=mix(colour,empty*.5,.55);
        // Night water gives things back darker than they stand, and only the bright
        // points (a lamp head, a lit window) hold up: the mids go down, so a figure
        // standing in a lit pool reads as a dark shape in it.
        vec3 given=displayColour(clamp(mirrored.rgb,0.0,1.0));
        given=min(vec3(1.0),given*given*1.25);
        vec3 seen=mix(sheen,given,held);
        float fresnel=mix(.3,.85,pow(1.0-clamp(-wd.y,0.0,1.0),3.0));
        float fade=1.0-smoothstep(35.0,60.0,tRoad);
        colour=mix(colour,seen,mask*fade*mix(fresnel,.95,held));
      }
    }
  }
  // Source's corridor rain uses the same drop field. The drive owns its own
  // air and pane treatment, so only one system can supply airborne rain.
  if(uRain>.001&&uOpticalEffects>.0&&uDriveWeather.w<.5){
    vec3 rainForward=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    float rainEnd=distanceM/(.5*max(.001,dot(wd,rainForward)));
    vec4 rain=traceRainField(uEyeCells+uWorldPatternOffset/.5,wd,rainEnd,.95/max(1.0,uRes.y),clamp(uRain,0.0,1.0));
    if(rain.x>.001){
      vec3 dropM=uEyeCells*.5+wd*(rain.z*.5);
      vec3 light=vec3(.31,.36,.43);
      for(int i=0;i<3;i++){
        if(uDoorB[i].w<=.001)continue;
        float nearLight=1.0-smoothstep(.4,max(.6,uDoorC[i].x*1.4),length(dropM.xz-uDoorA[i].xy));
        light+=uDoorB[i].rgb*nearLight*min(.55,uDoorB[i].w*.42);
      }
      float contrast=1.0-.62*clamp(dot(colour,vec3(.2126,.7152,.0722)),0.0,1.0);
      colour+=light*rain.y*contrast*uOpticalEffects;
    }
  }
  // THE STORM, when the night's storm strikes (main.js stormFlashStrength): the
  // sky and the open ground lift; lit things are already lifted by the prop pass.
  if(uFlash>.001){
    colour+=vec3(.42,.46,.56)*uFlash*mix(.45,1.0,1.0-below)*(1.0-clamp(body.a,0.0,1.0)*.7);
  }

  if(uCoastSea.x>.5){
    vec3 coastEye=uEyeCells*.5;
    vec3 coastForward=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    float coastEnd=distanceM/max(.001,dot(wd,coastForward)),cabinExit=0.0;
    if(uDriveWeather.w>.5)cabinExit=driveCabinExit((uDriveCabinInverse*vec4(coastEye,1.0)).xyz,mat3(uDriveCabinInverse)*wd);
    colour=coastalWaterComposite(coastEye,wd,coastEnd,coverage,colour,cabinExit);
  }
  if(uDriveWeather.w>.5){
    vec3 fwd=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    float viewDot=max(.001,dot(wd,fwd)),surfaceT=distanceM/viewDot;vec3 eye=uEyeCells*.5;
    vec3 cabEye=(uDriveCabinInverse*vec4(eye,1.0)).xyz,cabRay=mat3(uDriveCabinInverse)*wd;
    float slope=uDrivePaneSlope.y,den=cabRay.z-slope*cabRay.y;
    float paneT=abs(den)>.00001?(uDrivePaneSlope.x+slope*(cabEye.y-uDrivePane.z)-cabEye.z)/den:-1.0;
    vec3 paneHit=cabEye+cabRay*paneT;
    bool throughPane=paneT>.0&&paneHit.x>uDrivePane.x&&paneHit.x<uDrivePane.y&&paneHit.y>uDrivePane.z&&paneHit.y<uDrivePane.w;
    float outside=throughPane?paneT:driveCabinExit(cabEye,cabRay);float end=body.a>.001?surfaceT:min(surfaceT,220.0);
    vec4 air=vec4(0.0,0.0,0.0,1.0);
    if(end>outside+.025){
      air=driveAir(eye,wd,outside+.025,end);vec3 linearColour=acquisitionColour(colour);linearColour=linearColour*air.a+air.rgb;
      linearColour+=driveRain(eye+wd*(outside+.025),wd,end-outside-.025)+driveSnow(eye+wd*(outside+.025),wd,end-outside-.025);colour=displayColour(linearColour);
    }
    if(throughPane&&surfaceT>paneT+.012){
      vec2 paneUv=vec2((paneHit.x-uDrivePane.x)/(uDrivePane.y-uDrivePane.x),(paneHit.y-uDrivePane.z)/(uDrivePane.w-uDrivePane.z));
      vec2 paneDeposit=texture(uDriveWetness,paneUv).rg;float wet=paneDeposit.r,snowDeposit=paneDeposit.g;
      vec2 metres=vec2(paneHit.x,(paneHit.y-uDrivePane.z)*sqrt(1.0+slope*slope)),dropP=metres*vec2(28.0,34.0)+vec2(0.0,uDriveWeather.z*.11),cell=floor(dropP),local=dropP-cell;
      float seed=hash01(cell.x+uDrivePaneSlope.z,cell.y),occupancy=hash01(cell.x+97.13,cell.y-21.97+uDrivePaneSlope.z),present=step(1.0-clamp(wet*.55,0.0,.85),occupancy);vec2 centre=vec2(.19+.62*hash01(cell.x+4.0,cell.y),.18+.64*hash01(cell.x,cell.y+8.0));
      vec2 q=(local-centre)/vec2(.08+.16*seed,.12+.28*hash01(cell.x+9.0,cell.y+6.0));float radius=length(q),drop=(1.0-smoothstep(.72,1.0,radius))*present;
      if(drop>.001){
        vec2 bend=clamp(q,-1.0,1.0)*drop*vec2(4.2,6.4)/uRes,shiftedUv=clamp(uv+bend,vec2(.001),vec2(.999));vec4 shifted=texture(uProps,shiftedUv);float shiftedDepth=driveDepth(shiftedUv);
        if(shifted.a>.001&&shiftedDepth>paneT*viewDot+.015){vec3 refracted=shifted.rgb*air.a+air.rgb;colour=mix(colour,displayColour(refracted),drop*.65);}
        vec3 normalCab=normalize(vec3(q.x*.8,-slope+q.y*.85,1.0)),normalWorld=normalize(transpose(mat3(uDriveCabinInverse))*normalCab),reflected=reflect(wd,normalWorld);
        float fresnel=.020+.980*pow(1.0-clamp(abs(dot(normalWorld,-wd)),0.0,1.0),5.0),skyVisible=smoothstep(-.03,.35,reflected.y);
        vec3 sky=vec3(.014,.017,.021)*(.45+.55*exp(-pow(reflected.y*.65,2.0)));
        colour=displayColour(acquisitionColour(colour)+sky*fresnel*skyVisible*drop);
      }
      // Film trails bend the transmitted world and scatter a little sky. The
      // physical wiper reservoir clears this response along the actual arcs.
      float runX=metres.x*53.0+sin(metres.y*8.0+uDrivePaneSlope.z)*.3;
      float run=pow(max(0.0,sin(runX)),18.0)*wet*wet;
      vec2 flowUv=clamp(uv+vec2(sin(runX)*run*3.0,run*5.0)/uRes,vec2(.001),vec2(.999));
      vec4 flowed=texture(uProps,flowUv);float flowDepth=driveDepth(flowUv);
      vec3 linearColour=acquisitionColour(colour);
      if(flowed.a>.001&&flowDepth>paneT*viewDot+.015)linearColour=mix(linearColour,flowed.rgb*air.a+air.rgb,run*.45);
      linearColour=linearColour*(1.0-wet*.10)+vec3(.006,.008,.010)*wet*.32;
      // Frozen grains live on the physical pane and survive a held stop, a
      // reverse and a checkpoint. The real blades cut transparent arcs.
      float iceGrain=.58+.42*vnoise(metres*vec2(137.0,151.0)+uDrivePaneSlope.z);
      float ice=clamp(snowDeposit*(.76+.24*iceGrain),0.0,.92);
      linearColour=mix(linearColour,vec3(.105,.123,.145)*(.68+.32*iceGrain),ice);colour=displayColour(linearColour);
      // Transmitted opaque geometry retains its depth. Treating transparent
      // beads as opaque near silhouettes made the final edge stage draw rings.
    }
  }
  // The return leaves the remembered world while the SAME physical van
  // remains for the camera's outward dolly. Recover its actual depth hit in
  // rigid body space; screen position never decides what survives. Zero is
  // the default for every ordinary drive and all other presentations.
  if(uDriveReturnMin.w>.0){
    vec3 fwd=vec3(sin(uYaw)*cos(uPitch),sin(uPitch),-cos(uYaw)*cos(uPitch));
    vec3 hit=uEyeCells*.5+wd*(distanceM/max(.001,dot(wd,fwd)));
    vec3 bodyHit=(uDriveReturnBodyInverse*vec4(hit,1.0)).xyz;
    bool vehicle=coverage>.001&&all(greaterThanEqual(bodyHit,uDriveReturnMin.xyz-vec3(.035)))&&all(lessThanEqual(bodyHit,uDriveReturnMax.xyz+vec3(.035)));
    colour*=1.0-uDriveReturnMin.w*(vehicle?0.0:1.0);
  }
  colour=mix(colour,vec3(0.0),texture(uOpeningMask,uv).r*uOpeningMaskReady);
  // Ordinary acquisition uses the same packed view depth as the building.
  // A constant alpha flattened every person's silhouette into the road's
  // hatch plane. Only the splat overlap owns coverage in this channel.
  float acquiredDepth=1.0/(1.0+distanceM*.14);
  // This compositor historically presented display RGB directly. The ordinary
  // recorder instead measures linear light; retain display RGB only where the
  // existing splat overlap consumes that separate display/coverage contract.
  vec3 acquiredColour=acquisitionColour(colour);
  if(uCoastSea.x>.5&&uDriveSky.a<.5)acquiredColour=coastCameraResponse(acquiredColour);
  o=vec4(mix(acquiredColour,colour,uUnravelling.w),mix(acquiredDepth,coverage,uUnravelling.w));
  vec4 propMark=texelFetch(uPropMarks,ivec2(gl_FragCoord.xy),0);
  // Portals may replace the prop targets after the material pass. Their nearer
  // hardware depth must reject a printed mark left behind by a hidden object.
  float markDepth=unpackPropWorldDepth(propMark.rgb);
  bool printWins=printedSurfaceKind(propMark.a)>.5&&body.a>.5&&
    abs(markDepth-texture(uDepth,uv).r)<2.0/16777215.0&&texture(uOpeningMask,uv).r*uOpeningMaskReady<.5;
  oMark=vec4(0.0,.5,.5,printWins?propMark.a:0.0);
}`;

export function r3dSourceVoidPhysicalShader(){ return SOURCE_VOID_PHYSICAL_FRAG; }
export function r3dPostShader(){ return POST_FRAG; }
let driveMemoryBreak=new Float32Array(4),driveMemoryAcquired=false;
export function r3dSetDriveMemoryBreak(value=null){driveMemoryBreak=driveMemoryBreakUniforms(value);return Array.from(driveMemoryBreak);}

// THE HORIZON IS PROJECTED, NOT DISPLAYED.
//
// Everywhere else in the game the image reaches the screen through the VFD —
// halftone, palette, persistence, the whole instrument. The horizon is
// deliberately the one place that is in colour, and the halftone would take
// that straight back off it. But it was going out through a raw bilinear blit,
// which is not the same decision: it meant the one sequence in the game with no
// optical character at all, a flat texture copy of a float buffer.
//
// So it gets a pass of its own, and the vocabulary is FILM rather than
// electronics — because what the body is walking through is a projection of a
// recording, not a readout of a signal:
//
//   HALATION    bright fields bleed warm and wide into their surroundings, the
//               way emulsion blooms around a hot highlight. Not the vertical
//               aperture-grille halo POST_FRAG uses; that is a CRT artefact and
//               this is not a CRT.
//   GATE WEAVE  a sub-pixel drift and a hair of rotation on a slow irregular
//               clock. One cue, and the strongest one available: nothing reads
//               as "projected" faster than a frame that will not sit still.
//   EMULSION    density-dependent grain, heaviest in the midtones and protected
//               in the blacks, reusing correlatedGrain from GRAIN_GLSL rather
//               than inventing a second grain in the same renderer.
//   DITHER      ordered 4x4, because the tape is almost entirely large smooth
//               gradients and an 8-bit present bands them visibly. This is the
//               cheapest win in the pass.
//   BURN        the edges fall off the way a projected frame does, without the
//               hard circular vignette of a lens.
// Shared live renderer state; independent of the retired projection pass.
let gl = null, canvas = null;
let progRD, progWater, progMarch, progPost, progDepth, progPixelMesh, progDatamosh, progTextSpace, progCopy, progSourceVoidPhysical;
let progSourceRoomAcquisition,progSourceIdentity;
// How frightened he is, 0..1. main.js owns the number; the post pass spends it.
let fearLevel = 0;
let nightSeed=0.37;
// THE NIGHT IS DECIDED ONCE PER RUN, NOT PER FRAME.
//
// Everything the sky varies — the moon's bearing, its altitude, its phase and
// whether this is the run where it comes in close — hangs off this. It must be
// stable for the length of a run or the moon walks across the sky between
// loads, and it must differ between runs or nobody ever sees the other nights.
// ── the storm ───────────────────────────────────────────────────────────────
// A lightning flash is not a white rectangle over the frame: it is the room
// briefly being lit, which in this renderer means moving the two dials that
// decide what "lit" means. Ambient intensity raises the actual incident light,
// so surfaces face-on to it brighten and the geometry keeps its shading; the
// halftone's white point comes DOWN at the same time, so the dither saturates
// and the frame goes to solid ink the way an over-exposed frame does.
//
// Driving only ambient gives a brighter dither and no drama; driving only the
// white point gives a flat white-out with no shape in it. Both together is a
// photograph.
//
// The caller decides how hard: full under open sky, a fraction of it indoors,
// where the flash should light the room through an aperture rather than blow
// the frame (see main.js stormFlashStrength).
let stormFlash=0;
let stormLightBearing=0;
export function r3dSetStormFlash(v=0,bearing=stormLightBearing){stormFlash=Math.max(0,Math.min(1,Number(v)||0));stormLightBearing=Number.isFinite(bearing)?bearing:0;P3.setStormLight?.(stormFlash,stormLightBearing);return stormFlash;}
export function r3dStormFlash(){return stormFlash;}

export function r3dSetNightSeed(v=0.37){nightSeed=Number.isFinite(+v)?((+v%1)+1)%1:0.37;return nightSeed;}
export function r3dNightSeed(){return nightSeed;}
export function r3dSetFear(v) { fearLevel = Math.max(0, Math.min(1, v || 0)); }
export const r3dSetStillnessDread=setStillnessPresentation;
export const r3dStillnessDreadStatus=stillnessPresentation;

export function r3dSetLocalLights(lights=[]){
  // Aperture transport replaces only this old unbounded skylight bulb.
  if(lightingAcademicAtriumLight&&Array.isArray(lights))lights=lights.filter(light=>light?.id!=='academic-skylight-spill');
  P3.setPracticalLightFrame(lights);
  localLightPositions.fill(0);localLightColors.fill(0);localLightBaseIntensity.fill(0);localLightMunicipal.fill(0);localLightPenetrations.fill(0);localLightEmergency.fill(0);localLightDirections.fill(0);localLightConeInner.fill(1);
  localShadowIndex=-1;localShadowLight=null;
  localLightCount=Math.min(MAX_LOCAL_LIGHTS,Array.isArray(lights)?lights.length:0);
  for(let i=0;i<localLightCount;i++){
    const light=lights[i]||{},p=i*4,color=light.color||[1,.78,.52],cone=localLightConeDescriptor(light);
    localLightDirections.set([...cone.direction,cone.outer],p);localLightConeInner[i]=cone.inner;
    localLightPositions[p]=Number(light.x)||0;localLightPositions[p+1]=Number(light.y)||0;localLightPositions[p+2]=Number(light.z)||0;localLightPositions[p+3]=Math.max(.01,Number(light.radius)||4);
    localLightColors[p]=Number(color[0])||0;localLightColors[p+1]=Number(color[1])||0;localLightColors[p+2]=Number(color[2])||0;
    localLightBaseIntensity[i]=Math.max(0,Number(light.intensity)||0);
    const lightId=String(light.id||'');
    localLightMunicipal[i]=lightId.includes('sodium')||/^district-.*-lamp-/.test(lightId)?1:0;
    localLightColors[p+3]=localLightBaseIntensity[i]*(localLightMunicipal[i]>.5?municipalLightPower:1);
    localLightPenetrations[i]=Math.max(0,Math.min(1,Number(light.penetration)||0));
    // Authored kind, never inferred from the colour: a warm lamp and the
    // emergency circuit are both red-dominant and only the rig knows which.
    localLightEmergency[i]=light.kind===LIGHT_KIND.EMERGENCY?1:0;
    if(localShadowIndex<0&&light.castsShadow){
      localShadowIndex=i;
      localShadowLight={x:localLightPositions[p],y:localLightPositions[p+1],z:localLightPositions[p+2],shadowYaw:Number.isFinite(light.shadowYaw)?light.shadowYaw:0,shadowPitch:Number.isFinite(light.shadowPitch)?light.shadowPitch:0};
    }
  }
  return localLightCount;
}

// WHAT THE RENDERER IS ACTUALLY HOLDING, not what the caller believes it sent.
// Every Source lighting bug this session has been a disagreement between those
// two, and there was no way to read the second one.
export function r3dRecorderLighting(){
  return {tanHalfFov:activeCameraTanHalfFov,torchPower:renderedTorchDiagnostic?.power||0,ambient:lightingAmbientIntensity};
}
export function r3dLightingDebug(){
  const lights=[];
  for(let i=0;i<localLightCount;i++){
    const p=i*4;
    lights.push({
      x:localLightPositions[p],y:localLightPositions[p+1],z:localLightPositions[p+2],
      radius:localLightPositions[p+3],
      color:[localLightColors[p],localLightColors[p+1],localLightColors[p+2]],
      intensity:localLightColors[p+3],
      emergency:localLightEmergency[i],
      direction:[...localLightDirections.slice(p,p+3)],coneOuterCos:localLightDirections[p+3],coneInnerCos:localLightConeInner[i],
    });
  }
  return {
    localLightCount,
    worldLightTreatment:{...worldLightTreatment},
    ambientColor:[...lightingAmbientColor],
    ambientIntensity:lightingAmbientIntensity,
    whitePointScale:whitePointScaleOverride??lightingWhitePointScale,
    captureExposure:captureExposureOverride??lightingCaptureExposure,
    roofSkyRecovery:lightingRoofSkyRecovery,
    academicAtriumLight:{enabled:lightingAcademicAtriumLight},
    sourceEmergency:sourceEmergencyStrength,
    sourceVoidPhysical:sourceVoidPhysicalActive,
    torch:renderedTorchDiagnostic?{...renderedTorchDiagnostic,color:[...renderedTorchDiagnostic.color]}:null,
    sourceShore:SHORE.sourceShoreDebug(),
    lights,
  };
}

export function r3dSetMunicipalLightPower(value=1){
  const next=Number(value);
  municipalLightPower=Number.isFinite(next)?Math.max(0,Math.min(1,next)):1;
  for(let i=0;i<localLightCount;i++){
    localLightColors[i*4+3]=localLightBaseIntensity[i]*(localLightMunicipal[i]>.5?municipalLightPower:1);
  }
  return municipalLightPower;
}
export function r3dMunicipalLightPower(){return municipalLightPower;}
export function r3dSetLightingContext(context={}){
  lightingAcademicAtriumLight=academicAtriumLightEnabled(context);
  const color=Array.isArray(context.ambientColor)?context.ambientColor:[.64,.65,.62];
  lightingAmbientColor=new Float32Array([
    Math.max(0,Number(color[0])||0),Math.max(0,Number(color[1])||0),Math.max(0,Number(color[2])||0),
  ]);
  // The ceiling used to be .12, which is generous for a room and silently ate
  // anything authored for the outdoors — the loading bay asked for .155 and got
  // .12 without a word, so raising the number in conservatory-lights.js did
  // nothing at all. Rooms in this building run .014-.043; the bay is the sky.
  lightingAmbientIntensity=Math.max(.006,Math.min(.45,Number(context.ambientIntensity)||.022));
  // The room's own ceiling for the halftone (see zoneWhitePointScale). Absent or
  // nonsense leaves the look profile's authored white point alone, so a space
  // that never sets one behaves exactly as it did before this existed.
  const scale=Number(context.whitePointScale);
  lightingWhitePointScale=Number.isFinite(scale)&&scale>0?Math.max(.05,Math.min(4,scale)):1;
  const captureExposure=Number(context.captureExposure);
  lightingCaptureExposure=Number.isFinite(captureExposure)?Math.max(1,Math.min(12,captureExposure)):1;
  const wasRoofView=lightingRoofSkyRecovery>0;
  const roofSkyRecovery=Number(context.roofSkyRecovery);
  lightingRoofSkyRecovery=Number.isFinite(roofSkyRecovery)?Math.max(0,Math.min(1,roofSkyRecovery)):0;
  if(wasRoofView && lightingRoofSkyRecovery<=0 && pitchTarget<-.62) pitchTarget=-.62;
  lightingScreenId=isScreen(context.screen)?context.screen:null;
  const bounceColor=Array.isArray(context.bounce?.color)?context.bounce.color:color;
  lightingBounceColor=new Float32Array([
    Math.max(0,Number(bounceColor[0])||0),Math.max(0,Number(bounceColor[1])||0),Math.max(0,Number(bounceColor[2])||0),
  ]);
  const bounce=Number(context.bounce?.intensity);
  lightingBounceIntensity=Number.isFinite(bounce)?Math.max(0,Math.min(.6,bounce)):0;
  return{ambientColor:[...lightingAmbientColor],ambientIntensity:lightingAmbientIntensity,
    whitePointScale:lightingWhitePointScale,captureExposure:lightingCaptureExposure,screen:lightingScreenId,
    roofSkyRecovery:lightingRoofSkyRecovery,
    bounceIntensity:lightingBounceIntensity};
}
let lookFrom = getLookProfile('explore');
let lookTarget = lookFrom;
let lookStartedAt = 0;
let lookTransitionMs = 0;

function blendLayer(a, b, t) {
  const out = {};
  for (const key of new Set([...Object.keys(a || {}), ...Object.keys(b || {})])) {
    const av = a?.[key], bv = b?.[key];
    out[key] = Number.isFinite(av) && Number.isFinite(bv) ? av + (bv - av) * t : (t < 1 ? av : bv);
  }
  return out;
}

function lookNowMs(override) {
  if (Number.isFinite(override)) return Number(override);
  return globalThis.performance?.now?.() ?? Date.now();
}

function currentLook(nowMs = lookNowMs()) {
  if (!lookTransitionMs || lookFrom === lookTarget) return lookTarget;
  const t = Math.max(0, Math.min(1, (nowMs - lookStartedAt) / lookTransitionMs));
  if (t >= 1) { lookFrom = lookTarget; lookTransitionMs = 0; return lookTarget; }
  return {
    ...lookTarget,
    material: blendLayer(lookFrom.material, lookTarget.material, t),
    vfd: blendLayer(lookFrom.vfd, lookTarget.vfd, t),
    recording: blendLayer(lookFrom.recording, lookTarget.recording, t),
    glass: blendLayer(lookFrom.glass, lookTarget.glass, t),
  };
}

export function r3dSetLookProfile(id = 'explore', options = {}) {
  const now = lookNowMs(options.nowMs);
  const next = getLookProfile(id);
  const active = currentLook(now);
  const changed = next.id !== lookTarget.id;
  const transitionMs = Math.max(0, Number(options.transitionMs ?? next.transitionMs) || 0);

  // Scene-stack synchronization and completed material-bank uploads can both
  // reaffirm the current profile. Treat that as idempotent: restarting the
  // transition here can otherwise leave the compositor permanently between
  // two profiles. An explicit zero duration still acts as a useful snap/reset.
  if (!changed) {
    if (Object.hasOwn(options, 'transitionMs') && transitionMs === 0) {
      lookFrom = next;
      lookTarget = next;
      lookStartedAt = now;
      lookTransitionMs = 0;
    }
    if (options.resetMemory) r3dResetVfdMemory();
    return r3dLookStatus(now);
  }

  lookFrom = active;
  lookTarget = next;
  lookStartedAt = now;
  lookTransitionMs = transitionMs;
  if (changed || options.resetMemory) r3dResetVfdMemory();
  return r3dLookStatus(now);
}

export function r3dLookStatus(nowMs) {
  const profile = currentLook(lookNowMs(nowMs));
  return { id: lookTarget.id, bankId: lookTarget.bankId, transitioning: lookTransitionMs > 0, profile };
}

export function r3dSetPixelMesh(settings = {}) {
  pixelMeshSettings = normalizePixelMeshSettings({ ...pixelMeshSettings, ...settings });
  if (Number.isFinite(Number(settings.forceSignalUntil))) {
    pixelMeshStatus.forceSignalUntil = Math.max(pixelMeshStatus.forceSignalUntil, Number(settings.forceSignalUntil));
  }
  if (Number.isFinite(Number(settings.forceSignalMs))) {
    pixelMeshStatus.forceSignalUntil = Math.max(pixelMeshStatus.forceSignalUntil, pixelMeshNow() + Number(settings.forceSignalMs) / 1000);
  }
  pixelMeshStatus.enabled = true;
  return pixelMeshSettings;
}
export function r3dPixelMeshSettings() { return pixelMeshSettings; }
export function r3dPulsePixelMesh(ms = 1800) {
  pixelMeshStatus.forceSignalUntil = pixelMeshNow() + Math.max(250, Number(ms) || 1800) / 1000;
  pixelMeshStatus.enabled = true;
  return r3dPixelMeshStatus();
}
export function r3dPixelMeshStatus() {
  return {
    ...pixelMeshStatus,
    settings: pixelMeshSettings,
    forced: pixelMeshStatus.forceSignalUntil > pixelMeshNow(),
    bypassedByTextSpace: textSpaceActive && !sourceLook.roomMemoryActive,
    sourceRoomMemoryActive: textSpaceActive && !!sourceLook.roomMemoryActive,
  };
}
let rdTexA, rdTexB, rdFboA, rdFboB, rdFlip = false, rdWarm = 0;
let waterTexA, waterTexB, waterFboA, waterFboB, waterFlip = false, waterWasActive = false;
let driveLandField=null,driveLandTex=null,driveLandLast=null;
let sceneTex, sceneFbo, sceneDepthRb, fogTexture, surfaceTexture=null;
let cinematicLensPass=null,activeCameraTanHalfFov=.95;
export function r3dCinematicLensStatus(){return cinematicLensPass?.status()||{active:false,frames:0,error:null};}
// Screen-space engraving, written beside the scene by the march (see oMark).
let markTex=null;
let meshTexA=null, meshTexB=null, meshFboA=null, meshFboB=null, meshFlip=false;
let datamoshSourceTex=null,datamoshSourceFbo=null,datamoshTexA=null,datamoshTexB=null,datamoshFboA=null,datamoshFboB=null,datamoshFlip=false;
let datamoshActive=false,datamoshProgress=0,datamoshReducedMotion=false,lastPostSourceFbo=null;
let sourceRestFaculties=normalizeSourceRestFaculties(null);
export function r3dSetSourceRestFaculties(value=null){sourceRestFaculties=normalizeSourceRestFaculties(value);return{...sourceRestFaculties};}
export function r3dSourceRestFacultyStatus(){return{...sourceRestFaculties};}
// Source II's Ophanim horizon. The lens pass runs only while a frame is set;
// the same frame drives the per-vertex infall of released props.
let sourceRestHorizon=null,progSourceRestHorizon=null,sourceRestHorizonTex=null,sourceRestHorizonMarkTex=null,sourceRestHorizonFbo=null;
const sourceRestHorizonUniformCache=new Map(),sourceRestHorizonStatus={active:false,drawn:false,error:null};
export function r3dSetSourceRestHorizon(frame=null){
  sourceRestHorizon=frame?.active?frame:null;sourceRestHorizonStatus.active=!!sourceRestHorizon;
  P3.setSourceRestHorizonTide?.(sourceRestHorizon);return sourceRestHorizonStatus.active;
}
export function r3dSourceRestHorizonStatus(){return{...sourceRestHorizonStatus,programReady:!!progSourceRestHorizon};}
let surfAlbedoTex=null, surfNormalTex=null, surfMaterialTex=null, surfDreamTex=null, surfDreamStageTex=null, anisoExt=null, anisoMax=1;
// The engraving, derived from each generated tile as it arrives (see
// render/mark-field.js). It is a strict parallel of the dream arrays — same
// layer layout, same staging, same swap points — and it is deliberately managed
// INSIDE the dream lifecycle functions rather than through an API of its own,
// because a caller who could update one without the other would desync the
// engraving from the material it was derived from.
let surfMarkTex=null;
let markDeriveMs=0, markDeriveCount=0, markLastMs=0;
// Derivation is amortised across frames, and that is not an optimisation.
// Measured: the tensor costs ~6ms and tiles arrive in BURSTS — a bank streams
// ten slots and several land in one frame, which took the worst frame from a
// baseline 9.3ms to 49.2ms. Anything over 33ms disables the lens for the
// session, so a burst of arrivals would have switched the whole layer off.
//
// Only the pixel capture has to happen at arrival, because the caller closes
// the ImageBitmap the moment applySurface returns (see diffusion.js). The
// tensor can lag freely: the staging texture is not sampled until commit.
const markQueue=[];
let markEpoch=0;
const MARK_FRAME_BUDGET_MS=8;
const SURFACE_LAYERS=10,SURFACE_TILE=512;
// Which slots actually have an engraving yet, counted per slot across its
// frames. A slot that is not ready is drawn by the procedural hash — which is
// precisely the behaviour that shipped before this existed, so a queue that has
// not caught up degrades to the old look rather than to wrong data.
//
// This is what makes the flush unnecessary. Deriving every pending tile at the
// commit that makes a bank visible just moved the burst: ten tiles in the one
// frame took the worst frame to 56ms. Now a bank can become visible with its
// engraving still arriving, slot by slot, over the following few frames.
let markLiveBase=0;               // which half the shader reads as live
const markReady=new Uint8Array(SURFACE_LAYERS);
const markStageReady=new Uint8Array(SURFACE_LAYERS);
let hushBodyReady=false,hushBodyLoadError=null,hushBodyPackLoad=null,hushBodyPackBase=null;
const pubStatus={characters:false,props:false,error:null};
let pubHospitalityLoadGeneration=0,pubHospitalityError=null;
let basePropPackLoad=null,authoredPropPackLoad=null;
let busStudioAssetState={bus:false,studio:false,errors:[]};
async function loadBusStudioPacks(status){
  for(const [key,path]of [['bus','assets/bus-refinement.glb'],['studio',B3_STUDIO_PROPS_ASSET]]){
    try{await P3.addPropPack(assetUrl(path));status[key]=true;}
    catch(error){status.errors.push({pack:key,error:String(error?.message||error)});console.warn('Optional bus/studio model pack unavailable; retaining base props',path,error);}
  }
}

export function r3dBusStudioAssetsStatus(){
  const meshes=new Set(P3.propMeshCatalog());
  return{...busStudioAssetState,errors:[...busStudioAssetState.errors],
    studioMeshes:Object.keys(B3_STUDIO_PROPS_MESHES).filter(name=>meshes.has(name)),
    busMeshes:['ambient_late_bus','outskirts_bus','outskirts_bus_passage'].filter(name=>meshes.has(name))};
}

let hallChandelierReady=false;
export function r3dHallChandelierReady(){return hallChandelierReady;}
export async function r3dBasePropsReady(){
  const pending=basePropPackLoad;if(!pending)return false;
  await pending;
  return pending===basePropPackLoad?true:r3dBasePropsReady();
}
const busBodyPacks=Object.freeze([
  {kind:'character',url:'assets/bus-body-passage.glb',meshes:['bus_body_passage_left','bus_body_passage_right']},
  {kind:'character',url:'assets/bus-body-throat.glb',meshes:['bus_body_throat_lining','bus_body_throat_strands']},
  {kind:'character',url:'assets/source-drive/geometry/wheel-hands.glb',meshes:['drive_right_hand','drive_right_forearm']},
  {kind:'character',url:'assets/source-drive/cut/cut-living.glb',meshes:['cut_fascia','cut_membrane']},
  {kind:'character',url:'assets/source-drive/cut/cut-landscape.glb',meshes:['cut_thoracic_bone','cut_costal_glands','cut_lungs']},
  {kind:'prop',url:'assets/source-drive/cut/cut-roadside.glb',meshes:['cut_inspection_lamp']},
]);
let busBodyPackLoad=null,busBodyPackBase=null,busBodyAssetStage='idle';
export function r3dBusBodyAssetStatus(){return{ready:r3dBusBodyAssetsReady(),stage:busBodyAssetStage};}
export function r3dBusBodyAssetsReady(){
  const characters=new Set(P3.characterStats().meshes),props=new Set(P3.propMeshCatalog());
  return busBodyPacks.every(p=>p.meshes.every(name=>(p.kind==='character'?characters:props).has(name)));
}
export function r3dPrepareBusBodyAssets(){
  if(r3dBusBodyAssetsReady())return Promise.resolve(true);
  if(busBodyPackLoad&&busBodyPackBase===basePropPackLoad)return busBodyPackLoad;
  busBodyPackBase=basePropPackLoad;
  busBodyPackLoad=(async()=>{
    busBodyAssetStage='street';
    if(!await r3dBasePropsReady())throw Error('The street renderer is not ready.');
    for(const p of busBodyPacks){busBodyAssetStage=p.url;await(p.kind==='character'?P3.addCharacterPack(assetUrl(p.url)):P3.addPropPack(assetUrl(p.url)));}
    if(!r3dBusBodyAssetsReady())throw Error('The body passage assets did not install.');
    busBodyAssetStage='ready';return true;
  })().catch(error=>{busBodyAssetStage='failed: '+String(error?.message||error);busBodyPackLoad=null;throw error;});
  return busBodyPackLoad;
}
// Borrowed Ellery scenes retain architecture from the authored extension
// packs, not only the procedural base. Keep ordinary early-entry readiness
// quick while giving those scenes the complete current-generation contract.
export async function r3dAuthoredPropsReady(){
  const pending=authoredPropPackLoad;if(!pending)return false;
  await pending;
  return pending===authoredPropPackLoad?true:r3dAuthoredPropsReady();
}
let openingOvertureLoad=null,openingOvertureBase=null;
const openingOvertureStatus={ready:false,error:null};
export function r3dOpeningOvertureStatus(){return{...openingOvertureStatus};}
export function r3dPrepareOpeningOverture(){
  if(openingOvertureLoad&&openingOvertureBase===basePropPackLoad)return openingOvertureLoad;
  openingOvertureBase=basePropPackLoad;openingOvertureStatus.ready=false;openingOvertureStatus.error=null;
  openingOvertureLoad=(async()=>{
    if(!await r3dBasePropsReady())throw Error('Opening world is not resident.');
    await Promise.all([r3dAuthoredPropsReady(),P3.addPropPack(assetUrl('assets/opening-overture.glb'))]);
    const names=new Set(P3.propMeshCatalog());
    if(!OPENING_OVERTURE.requiredMeshes.every(name=>names.has(name)))throw Error('Opening geometry is incomplete.');
    openingOvertureStatus.ready=true;return true;
  })().catch(error=>{openingOvertureStatus.error=String(error?.message||error);return false;});
  return openingOvertureLoad;
}
export function r3dPubStatus(){return {...pubStatus,hospitality:P3.propMeshCatalog().includes('pub_warm_interior'),hospitalityError:pubHospitalityError};}
const streetCrowdPacks=createStreetCrowdPackLoader({props:P3,resolveAsset:assetUrl,onError:(error,kind)=>console.warn('street crowd '+kind+' unavailable; retaining authored figures',error)});
export function r3dStreetCrowdStatus(){return streetCrowdPacks.status();}
let exteriorPeopleLoadGeneration=0;
let exteriorPeopleStatus={boothProps:false,boothCharacter:false,ambientProps:false,errors:[]};
export function r3dExteriorPeopleStatus(){return{...exteriorPeopleStatus,errors:[...exteriorPeopleStatus.errors],boothReady:exteriorPeopleStatus.boothProps&&exteriorPeopleStatus.boothCharacter};}
let costumeExchangeAssetError=null,costumeExchangeLoadGeneration=0;
let heldNoteAssetError=null,heldNoteLoadGeneration=0;
export function r3dCostumeExchangeStatus(){
  const loaded=new Set(P3.characterStats().meshes);
  return{ready:['costume_exchange_body','costume_exchange_features','costume_exchange_attachments','costume_exchange_cover'].every(mesh=>loaded.has(mesh)),error:costumeExchangeAssetError};
}
export function r3dHeldNoteStatus(){
  const loaded=new Set(P3.characterStats().meshes);
  return{ready:['held_note_body','held_note_faces','held_note_anatomy'].every(mesh=>loaded.has(mesh)),error:heldNoteAssetError};
}
let streetPilotReady=false;
let openingStreetReady=false;
let glassCourtReady=false;
let streetFabricReady=false;
let yardJardinsBoundaryReady=false;
let elleryPublicFrontReady=false;
let chapelTapeDemandReady=false,chapelTapeDemandError=null,chapelTapeDemandLoadGeneration=0;
export function r3dChapelTapeDemandReady(){return chapelTapeDemandReady;}
export function r3dChapelTapeDemandStatus(){return{ready:chapelTapeDemandReady,error:chapelTapeDemandError};}
let academicGalleryReady=false,academicGalleryError=null;
let progPressureFinish=null,pressureFinishTex=null,pressureFinishFbo=null,pressureIdentityTex=null;
let filmLeakTex=null;
let pressureFinishReady=false;
let pressureSceneDepthReady=false;
const pressureFinishUniformCache=new Map();
let hushBodyMode='live';
const outcomeExposure=createOutcomeExposureController();
export function r3dSetOutcomeExposure(value=null){return outcomeExposure.set(value);}
let catchFlash=0,catchNegative=0,catchZoom=1;
export function r3dSetCatchFlash(flash=0,negative=0){catchFlash=Math.max(0,Math.min(1,Number(flash)||0));catchNegative=Math.max(0,Math.min(1,Number(negative)||0));}
export function r3dSetCatchZoom(zoom=1){catchZoom=Math.max(1,Math.min(1.6,Number(zoom)||1));}
export function r3dOutcomeExposureStatus(){
  const state=outcomeExposure.snapshot();
  return {state,sample:sampleOutcomeExposure(state,{reduceFlash:!!pixelMeshSettings.reduceFlash}),
    asset:HUSH_BODY_ASSET,ready:hushBodyReady,pipeline:'pressure-geometry-before-final-dither'};
}
const BLUE_NOISE_SIZE=64;
let blueNoiseTex=null;
// A mid-grey 1x1 stands in until the mask decodes. Without it the first frames
// would threshold against an undefined sampler, which on some drivers is black —
// i.e. everything on, a white screen, at exactly the moment the player boots.
function ensureBlueNoise(gl){
  if(blueNoiseTex) return blueNoiseTex;
  blueNoiseTex=gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D,blueNoiseTex);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.R8,1,1,0,gl.RED,gl.UNSIGNED_BYTE,new Uint8Array([128]));
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
  const img=new Image();
  img.onload=()=>{
    gl.bindTexture(gl.TEXTURE_2D,blueNoiseTex);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.R8,gl.RED,gl.UNSIGNED_BYTE,img);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
  };
  img.src=assetUrl('assets/blue-noise-64.png').href||String(assetUrl('assets/blue-noise-64.png'));
  return blueNoiseTex;
}

let hushBodyManifestation=0;
let hushBodySecondaryManifestation=0;
// HOW FAR THE GENERATED MATERIAL HAS ARRIVED, 0..1.
//
// This used to be the boolean `surfAlbedoTex && surfNormalTex && surfMaterialTex`
// written straight into uSurfacesReady, which meant that on the frame the third
// bank texture appeared EVERY surface in the building changed shading model at
// once — albedo, normal map, roughness and occlusion together. That is the snap
// between an unlit room and a lit one that has nothing to do with the torch.
//
// Same exponential approach the hush body uses below, for the same reason: the
// thing should arrive rather than appear.
let surfacesManifestation=0;
let hushBodyLast={x:0,y:0,strength:.9,heightM:1.83,widthM:.58,glow:null,mode:null};
let hushBodySecondaryLast={x:0,y:0,strength:.9,heightM:1.83,widthM:.58,glow:null,mode:null};
// Explicit DEV motion-study submissions never own root, hearing or contact.
// The dev flag reads at module scope so VM-extracted functions stay evaluable;
// plain node imports have no Vite env, and read as production.
const HUSH_MOTION_STUDY_DEV=!!(import.meta.env&&import.meta.env.DEV);
let hushMotionStudyInstance=null;
export function r3dSetHushMotionStudyInstance(instance=null){
  if(HUSH_MOTION_STUDY_DEV)hushMotionStudyInstance=instance;
}
const HUSH_BODY_ASSET='assets/hush-density.glb';
const HUSH_BODY_ASSET_REV=HUSH_POSTURE_REVISION;
const HUSH_BODY_MESHES=['hush_density_core','hush_density_return','hush_density_volume','pressure_body'];
// Borrowed scenes whose local controller can resolve a capture must await the
// same real body used by ordinary Presence. Coalesce with the optional host
// load and recheck residency after a prop-context replacement.
export function r3dHushBodyReady(){
  const meshes=P3.characterStats().meshes;
  return hushBodyReady&&HUSH_BODY_MESHES.every(name=>meshes.includes(name));
}
export function r3dPrepareHushBody(){
  if(r3dHushBodyReady())return Promise.resolve(true);
  if(hushBodyPackLoad&&hushBodyPackBase===basePropPackLoad)return hushBodyPackLoad;
  const generation=basePropPackLoad;hushBodyPackBase=generation;
  hushBodyPackLoad=(async()=>{
    if(!await r3dBasePropsReady())throw Error('The pressure renderer is not ready.');
    await P3.addCharacterPack(assetUrl(HUSH_BODY_ASSET));
    // The offered-hand encounter still borrows a recorded human outline.
    // It has its own namespace and never becomes the ordinary HUSH body.
    await P3.addCharacterPack(assetUrl('assets/pressure-character.glb'));
    if(generation!==basePropPackLoad||!HUSH_BODY_MESHES.every(name=>P3.characterStats().meshes.includes(name)))
      throw Error('The pressure body did not install in the current renderer.');
    hushBodyReady=true;hushBodyLoadError=null;return true;
  })().catch(error=>{
    if(generation===hushBodyPackBase){hushBodyReady=false;hushBodyLoadError=String(error?.message||error);hushBodyPackLoad=null;}
    throw error;
  }).finally(()=>{if(generation===hushBodyPackBase)hushBodyPackLoad=null;});
  return hushBodyPackLoad;
}
// Alan is a human continuation of the chapel performance, using the same
// skinned opaque material, depth, shadow and final dither path as other people.
const RECORDIST_RELEASE_MESHES=['recordist_release_alan','recordist_release_rig_hand','recordist_release_fork_hand','recordist_release_rig_seated'];
let recordistReleaseLoad=null,recordistReleaseGeneration=null;
export function r3dRecordistReleaseReady(){
  const resident=P3.characterStats().meshes;
  return RECORDIST_RELEASE_MESHES.every(name=>resident.includes(name));
}
export function r3dPrepareRecordistRelease(){
  if(r3dRecordistReleaseReady())return Promise.resolve(true);
  if(recordistReleaseLoad&&recordistReleaseGeneration===basePropPackLoad)return recordistReleaseLoad;
  const generation=basePropPackLoad;recordistReleaseGeneration=generation;
  recordistReleaseLoad=(async()=>{
    if(!await r3dBasePropsReady())throw Error('The human character renderer is not ready.');
    await P3.addCharacterPack(assetUrl('assets/alan-recordist.glb'),{allowedMeshes:RECORDIST_RELEASE_MESHES});
    if(generation!==basePropPackLoad||!r3dRecordistReleaseReady())throw Error('Alan could not be installed in the current world renderer.');
    return true;
  })().finally(()=>{if(generation===recordistReleaseGeneration)recordistReleaseLoad=null;});
  return recordistReleaseLoad;
}
export const HUSH_BODY_MODES=Object.freeze(['live','core','glow','off']);

export function r3dSetHushBodyMode(mode='live'){
  hushBodyMode=HUSH_BODY_MODES.includes(mode)?mode:'live';
  return hushBodyMode;
}

// THE HUSH ANSWERS WITH ITS BODY. One cue at a time, eased in and relaxed back
// (hush-pose.js), evaluated from the simulation-owned captured cue elapsed.
let hushPoseCue=null,pressureCueSink=null;
export function r3dSetPressureCueSink(callback){pressureCueSink=typeof callback==='function'?callback:null;}
export function r3dHushPose(cue){
  if(!isHushBodyCue(cue))return false;
  pressureCueSink?.(cue);
  hushPoseCue=cue;
  return true;
}
export function r3dHushPoseStatus(){
  const p=hushBodyLast.performance,cue=p?.cue;
  return{cue:cue?.name||null,requested:hushPoseCue,pose:hushPoseAt(cue?.name,0,cue?.elapsed??-1,{reducedMotion:p?.reducedMotion??!!pixelMeshSettings.reduceMotion})};
}

export function r3dHushBodyStatus(){
  return{
    ready:r3dHushBodyReady(),
    mode:hushBodyMode,
    manifestation:hushBodyManifestation,
    secondaryManifestation:hushBodySecondaryManifestation,
    asset:HUSH_BODY_ASSET,
    revision:HUSH_BODY_ASSET_REV,
    error:hushBodyLoadError,
    geometry:P3.pressureTargets(),
    character:P3.characterStats(),
    body:{...hushBodyLast},
    projection:sourceHushProjection(),
  };
}
// Five temporal frames of ten 512² surfaces, live plus staged, is the ceiling
// the texture budget allows. WebGL2 guarantees 256 array layers, so the limit
// here is memory, not the API.
const MAX_DREAM_FRAMES=5;
const MARK_HALF_LAYERS=SURFACE_LAYERS*MAX_DREAM_FRAMES;
// How hard the material's own density pulls the recorder's threshold. This is
// the first number in the engraving that is taste rather than measurement, so
// it is tunable live from the probe rather than authored into look-profiles
// before anybody has looked at it on a wall.
let markDensityGain=0.55;
// How hard the stipple follows the grain direction. 0 restores the isotropic
// hash, which is the A/B for phase 3b.
let markGrainGain=0.70;
const markReadyScratch=new Float32Array(SURFACE_LAYERS);
// A slot counts as engraved only once every frame of its boil is derived, so a
// crossfade never blends a derived frame against an empty one. Anything short
// of that reads as 0 and the recorder draws that slot with its procedural hash.
//
// AND IT ARRIVES OVER A THIRD OF A SECOND, NOT IN ONE FRAME.
//
// This returned a hard 0-or-1, so the instant a slot finished engraving its mark
// snapped in whole. Downstream that moves two things at once: markDensity jumps
// off the 0.22 sentinel and formStipple shifts the global threshold with it, and
// markGrain jumps from "no grain" to a real direction so screenDir rotates the
// screen pattern. Which is exactly the reported fault — every couple of seconds
// the dither snapped to a different density, or held its density and moved.
// Slots finish one at a time, and the live/staged bank swap does the whole field
// at once, which is the couple-of-seconds cadence.
//
// A ramp is safe here only because the surface pass decodes gb to SIGNED before
// it multiplies by this (see the note beside markA.gb in the shader): scaling a
// signed grain toward zero fades its coherence and preserves its direction. On
// the raw 0..1 encoding the same multiply would decode to a confident grain at
// 225 degrees, which is the trap that comment is about.
//
// Readiness itself stays all-or-nothing — a slot is engraved or it is not, and a
// partial boil must never be blended against an empty frame. Only its ARRIVAL is
// smoothed, from the moment it first reports complete.
const MARK_FADE_MS=340;
const markFadeStartLive=new Float32Array(SURFACE_LAYERS).fill(-1);
const markFadeStartStage=new Float32Array(SURFACE_LAYERS).fill(-1);
function markReadyUniform(counts,frames,started,now=performance.now()){
  const k=Math.max(1,Math.min(MAX_DREAM_FRAMES,frames||1));
  for(let i=0;i<SURFACE_LAYERS;i++){
    if(counts[i]<k){ started[i]=-1; markReadyScratch[i]=0; continue; }
    if(started[i]<0) started[i]=now;
    markReadyScratch[i]=Math.min(1,(now-started[i])/MARK_FADE_MS);
  }
  return markReadyScratch;
}
let surfDreamFrames=1,surfDreamStageFrames=1,dreamAgitation=0;
const surfDreamMix=new Float32Array(SURFACE_LAYERS);
let localDiffusionAvailability = 1;
let surfDreamReady=false,surfDreamNextReady=false,surfDreamTransitionStart=0,surfDreamTransitionMs=0;
let surfDreamActiveBank=null,surfDreamPendingBank=null;
let pixelMeshSettings = normalizePixelMeshSettings();
let lastPixelMeshAt = 0;
let vfdMovement = 0;
let vfdPreviousX = null, vfdPreviousZ = null;
let textSpaceActive = false;
let sourceVoidPhysicalActive = false;
let sourceLook = { sunrise: 0, chroma: 1, paper: 0 };
let sourceEmergencyStrength = 0;
let sourceWhiteoutStrength = 0;
let sourceShoreState = null;
export function r3dSetSourceShore(frame = null) {
  sourceShoreState = frame?.active || frame?.visible ? frame : null;
  SHORE.sourceShoreStats.active = SHORE.sourceShoreRenderActive(sourceShoreState);
  return !!sourceShoreState;
}
export function r3dSourceShoreDebug(options={}) {
  return { ...SHORE.sourceShoreDebug(options), frame: sourceShoreState };
}

// THE HORIZON. Set by main.js from the runtime's horizonFrame(); the renderer
// never works out where on the tape the body is, it is told.
let sourceWeather = { rain: 0, moon: 1, clouds: 1, leaves: 0 };
const pixelMeshUniformCache = new Map();
const postUniformCache = new Map();
const textSpaceUniformCache = new Map();
const sourceRoomUniformCache = new Map();
const sourceIdentityUniformCache = new Map();
const rdUniformCache = new Map();
const waterUniformCache = new Map();
// Hoisted sampler bindings and scratch buffers: per-frame array literals and
// typed-array allocations in the frame loop cost real milliseconds on weak
// CPUs and pressure the GC into pause spikes, so these are reused instead.
const SURF_SAMPLER_UNITS = [['uSurfAlbedo',6],['uSurfNormal',7],['uSurfMaterial',8],['uSurfDream',9],['uSurfDreamNext',11],['uSurfMarks',10]];
const chunkScratchA = new Float32Array(MAX_CHUNKS * 4);
const chunkScratchC = new Float32Array(MAX_CHUNKS * 3);
const waterPackedScratch = new Float32Array(MAX_WATER_SOURCES * 4);
let cachedWorldTints = null;
let cachedWorldTintsFlat = new Float32Array(0);
function worldTintsFlat(tints){
  const list = Array.isArray(tints) ? tints : [];
  if (cachedWorldTints && cachedWorldTints.length === list.length) {
    let same = true;
    for (let i = 0; i < list.length; i += 1) {
      const a = cachedWorldTints[i], b = list[i];
      if (a === b) continue;
      if (!a || !b || a[0] !== b[0] || a[1] !== b[1] || a[2] !== b[2]) { same = false; break; }
    }
    if (same) return cachedWorldTintsFlat;
  }
  if (cachedWorldTintsFlat.length !== list.length * 3) cachedWorldTintsFlat = new Float32Array(Math.max(3, list.length * 3));
  for (let i = 0; i < list.length; i += 1) {
    const c = list[i] || [0, 0, 0];
    cachedWorldTintsFlat[i * 3] = c[0];
    cachedWorldTintsFlat[i * 3 + 1] = c[1];
    cachedWorldTintsFlat[i * 3 + 2] = c[2];
  }
  cachedWorldTints = list;
  return cachedWorldTintsFlat;
}
const GL_ERROR_AUDIT_FRAMES = 60;
const pixelMeshStatus = {
  supported: false,
  shaderReady: false,
  enabled: false,
  framesSeen: 0,
  framesRendered: 0,
  lastProfile: 'explore',
  lastError: null,
  lastGlError: 0,
  forceSignalUntil: 0,
  sceneWidth: 0,
  sceneHeight: 0,
};
function pixelMeshNow() {
  return (globalThis.performance?.now?.() || Date.now()) / 1000;
}

export function r3dResetVfdMemory() {
  if (!gl || !meshFboA || !meshFboB) return false;
  const previous = gl.getParameter(gl.FRAMEBUFFER_BINDING);
  gl.clearColor(0, 0, 0, 0);
  for (const fbo of [meshFboA, meshFboB]) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.clear(gl.COLOR_BUFFER_BIT);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, previous);
  meshFlip = false;
  return true;
}
// Load a vertical strip PNG/JPG (one tile per layer) as a WebGL2 texture array:
// mipmaps, REPEAT wrap and anisotropy — the quality an atlas cannot give a
// tiled surface. sRGB decode for colour, linear for normal/roughness.
function loadTextureArray(url, { srgb=false }={}){
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>{
      const size=img.width, layers=Math.round(img.height/size);
      const cv=document.createElement('canvas'); cv.width=size; cv.height=img.height;
      const cx=cv.getContext('2d'); cx.drawImage(img,0,0);
      const data=new Uint8Array(cx.getImageData(0,0,size,img.height).data.buffer);
      const t=gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
      gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,srgb?gl.SRGB8_ALPHA8:gl.RGBA8,size,size,layers,0,gl.RGBA,gl.UNSIGNED_BYTE,data);
      gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);
      if(anisoExt) gl.texParameterf(gl.TEXTURE_2D_ARRAY,anisoExt.TEXTURE_MAX_ANISOTROPY_EXT,anisoMax);
      resolve(t);
    };
    img.onerror=reject; img.src=url.href||String(url);
  });
}
// Roughness and relief are each ONE CHANNEL sampled at the SAME coordinates,
// three lines apart, and each was costing a whole texture unit. Packing them
// into one array — R roughness, G relief — frees a unit, and this pass has none
// left: an M4 Pro reports MAX_TEXTURE_IMAGE_UNITS 16 and all sixteen are bound.
//
// That freed unit is what lets the engraving reach the recorder at all. The
// alternative was folding the two dream arrays together, which would have meant
// a fixed worst-case layer stride and turned a one-frame calm bank from 21MB of
// texture into 105MB.
//
// Merged here rather than in the surface build so the authored assets stay two
// legible greyscale maps that a person can open and look at.
function loadPackedMaterialArray(roughUrl, heightUrl){
  const plane=(url)=>new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>{
      const size=img.width;
      const cv=document.createElement('canvas');cv.width=size;cv.height=img.height;
      cv.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0);
      resolve({size,layers:Math.round(img.height/size),
        data:cv.getContext('2d',{willReadFrequently:true}).getImageData(0,0,size,img.height).data});
    };
    img.onerror=reject;img.src=url.href||String(url);
  });
  return Promise.all([plane(roughUrl),plane(heightUrl)]).then(([rough,height])=>{
    if(rough.size!==height.size||rough.layers!==height.layers){
      throw new Error(`roughness and relief atlases disagree: ${rough.size}x${rough.layers} vs ${height.size}x${height.layers}`);
    }
    const texels=rough.size*rough.size*rough.layers;
    const packed=new Uint8Array(texels*4);
    for(let i=0;i<texels;i++){
      packed[i*4]=rough.data[i*4];       // roughness
      packed[i*4+1]=height.data[i*4];    // relief
      packed[i*4+3]=255;
    }
    const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
    gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,gl.RGBA8,rough.size,rough.size,rough.layers,0,gl.RGBA,gl.UNSIGNED_BYTE,packed);
    gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);
    if(anisoExt)gl.texParameterf(gl.TEXTURE_2D_ARRAY,anisoExt.TEXTURE_MAX_ANISOTROPY_EXT,anisoMax);
    return t;
  });
}
// A dream bank is SURFACE_LAYERS surfaces × K temporal frames, laid out as
// layer = slot*K + frame. K is authored per look profile; one frame is the old
// still behaviour, five is a surface visibly cooking.
function makeSurfaceDreamTexture(frames=1){
  const k=Math.max(1,Math.min(MAX_DREAM_FRAMES,Math.floor(frames)||1));
  const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
  gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,gl.SRGB8_ALPHA8,SURFACE_TILE,SURFACE_TILE,SURFACE_LAYERS*k,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);
  if(anisoExt)gl.texParameterf(gl.TEXTURE_2D_ARRAY,anisoExt.TEXTURE_MAX_ANISOTROPY_EXT,anisoMax);
  gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
  return t;
}
// The mark array mirrors the dream array's layer layout exactly, at a quarter
// the side. A mark field is low-frequency by nature — where marks clot and
// which way they run — so 128px carries it, and the whole six-bank set costs
// about a sixteenth of what the albedo does.
//
// NOT sRGB. The dream tiles are SRGB8_ALPHA8 because they are colour; this is
// data. Density and a doubled-angle direction vector pushed through a gamma
// decode would come out silently wrong in a way that looks plausible.
// ONE texture for both halves, because the pass has exactly one spare unit.
// Live occupies layers [0, MARK_HALF_LAYERS), staged [MARK_HALF_LAYERS, 2x), and
// the swap flips which base the shader reads rather than exchanging textures.
// A fixed stride wastes layers for a one-frame bank, which at 128px costs about
// 3MB in total — the same trick on the 512px dream arrays would have cost 84MB.
function makeSurfaceMarkTexture(){
  const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
  gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,gl.RGBA8,MARK_FIELD_SIZE,MARK_FIELD_SIZE,MARK_HALF_LAYERS*2,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);
  if(anisoExt)gl.texParameterf(gl.TEXTURE_2D_ARRAY,anisoExt.TEXTURE_MAX_ANISOTROPY_EXT,anisoMax);
  gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
  return t;
}
function initSurfaceDream(){
  surfDreamTex=makeSurfaceDreamTexture(1);surfDreamStageTex=makeSurfaceDreamTexture(1);
  surfMarkTex=makeSurfaceMarkTexture();markLiveBase=0;
  surfDreamFrames=1;surfDreamStageFrames=1;
}
export function r3dBeginSurfaceDreamBank(bankId=null,frames=1){
  if(!gl)return false;
  // A lens switched back on after a no-SD baseline writes into real arrays.
  if(surfDreamReleased)r3dRestoreSurfaceDream();
  if(surfDreamStageTex)gl.deleteTexture(surfDreamStageTex);
  const k=Math.max(1,Math.min(MAX_DREAM_FRAMES,Math.floor(Number(frames))||1));
  surfDreamStageTex=makeSurfaceDreamTexture(k);
  // Anything still queued was staged for the texture just deleted.
  markQueue.length=0;markEpoch+=1;markStageReady.fill(0);
  if(!surfDreamStageTex)return false;
  surfDreamStageFrames=k;
  surfDreamPendingBank=bankId;
  surfDreamNextReady=false;
  surfDreamTransitionMs=0;
  return true;
}
export function r3dSetSurfaceDream(slot,frame,image,mix=.68){
  if(!gl||!surfDreamStageTex||slot<0||slot>=SURFACE_LAYERS||!image)return false;
  const k=Math.max(1,surfDreamStageFrames);
  const f=Math.max(0,Math.min(k-1,Math.floor(Number(frame))||0));
  const cv=document.createElement('canvas');cv.width=SURFACE_TILE;cv.height=SURFACE_TILE;
  cv.getContext('2d').drawImage(image,0,0,SURFACE_TILE,SURFACE_TILE);
  // Match loadTextureArray's orientation so generated mortar/grain lands on
  // the exact source texels it was conditioned from.
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
  gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfDreamStageTex);
  gl.texSubImage3D(gl.TEXTURE_2D_ARRAY,0,0,0,slot*k+f,SURFACE_TILE,SURFACE_TILE,1,gl.RGBA,gl.UNSIGNED_BYTE,cv);
  surfDreamMix[slot]=Math.max(0,Math.min(.98,Number(mix)||0));
  stageMarkField(image,slot,f);
  return true;
}
// Derive the engraving from the tile that just arrived.
//
// Deliberately from a MARK_FIELD_SOURCE-sized copy rather than the 512 canvas
// above: at full resolution this costs ~28ms, and material-mutation.js kills
// the whole lens for the session if generation overlaps a frame longer than
// 33ms. The measurement behind that number, and what survives the downsample,
// is documented on MARK_FIELD_SOURCE.
function stageMarkField(image,slot,frame){
  if(!surfMarkTex||!image)return false;
  try{
    // The only part that cannot wait: the bitmap is closed by the caller as
    // soon as this returns.
    const cv=document.createElement('canvas');cv.width=MARK_FIELD_SOURCE;cv.height=MARK_FIELD_SOURCE;
    const ctx=cv.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(image,0,0,MARK_FIELD_SOURCE,MARK_FIELD_SOURCE);
    markQueue.push({
      pixels:ctx.getImageData(0,0,MARK_FIELD_SOURCE,MARK_FIELD_SOURCE).data,
      slot,frame,epoch:markEpoch,
    });
  }catch(err){
    // A tile without an engraving is drawn by the procedural hash, which is
    // exactly the behaviour that shipped before this existed. Never fatal.
    console.warn('[r3d] mark field capture failed',err);
    return false;
  }
  return true;
}
function deriveQueuedMark(entry){
  // A bank that began while this was queued deleted the texture it was staged
  // for; its tile belongs to a material nobody is looking at any more.
  if(entry.epoch!==markEpoch||!surfMarkTex)return false;
  const started=globalThis.performance?.now?.()||Date.now();
  try{
    const field=deriveMarkField(entry.pixels,MARK_FIELD_SOURCE,MARK_FIELD_SOURCE);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
    gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfMarkTex);
    // Always into the half that is NOT live, so an arriving bank never rewrites
    // the engraving currently on the walls.
    const stageBase=markLiveBase?0:MARK_HALF_LAYERS;
    const layer=stageBase+entry.slot*MAX_DREAM_FRAMES+entry.frame;
    gl.texSubImage3D(gl.TEXTURE_2D_ARRAY,0,0,0,layer,field.size,field.size,1,gl.RGBA,gl.UNSIGNED_BYTE,field.data);
    // A slot is only engraved once every frame of its boil is, or the crossfade
    // would blend a derived frame against an empty one.
    const k=Math.max(1,surfDreamStageFrames);
    if(entry.slot>=0&&entry.slot<SURFACE_LAYERS){
      markStageReady[entry.slot]=Math.min(k,markStageReady[entry.slot]+1);
    }
  }catch(err){
    console.warn('[r3d] mark field derivation failed',err);
    return false;
  }
  markLastMs=(globalThis.performance?.now?.()||Date.now())-started;
  markDeriveMs+=markLastMs;markDeriveCount+=1;
  return true;
}
// Drained from the frame loop under a time budget, so a ten-tile arrival costs
// ten quiet frames instead of one that kills the lens.
// Exported because the banks stream during the opening credits and the menu,
// when r3dFrame is not being called at all — the world is not being rendered
// yet. Without a tick that runs regardless, every engraving for the first bank
// sits in the queue until the player reaches gameplay.
export function r3dDrainMarkFields(budgetMs=MARK_FRAME_BUDGET_MS){return drainMarkQueue(budgetMs);}
function drainMarkQueue(budgetMs=MARK_FRAME_BUDGET_MS){
  if(!markQueue.length)return 0;
  const started=globalThis.performance?.now?.()||Date.now();
  let done=0;
  while(markQueue.length){
    deriveQueuedMark(markQueue.shift());done+=1;
    if(((globalThis.performance?.now?.()||Date.now())-started)>=budgetMs)break;
  }
  return done;
}
export function r3dCommitSurfaceDream(mix=.68,options={}){
  if(!gl||!surfDreamStageTex)return false;
  gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfDreamStageTex);
  gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
  if(surfMarkTex){gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfMarkTex);gl.generateMipmap(gl.TEXTURE_2D_ARRAY);}
  surfDreamMix.fill(Math.max(0,Math.min(.98,Number(mix)||0)));
  const bankId=options.bankId??surfDreamPendingBank;
  const transitionMs=Math.max(0,Number(options.transitionMs)||0);
  if(!surfDreamReady||transitionMs<=0){
    [surfDreamTex,surfDreamStageTex]=[surfDreamStageTex,surfDreamTex];
    markLiveBase=markLiveBase?0:MARK_HALF_LAYERS;
    markReady.set(markStageReady);markStageReady.fill(0);
    [surfDreamFrames,surfDreamStageFrames]=[surfDreamStageFrames,surfDreamFrames];
    surfDreamReady=true;surfDreamNextReady=false;surfDreamActiveBank=bankId;surfDreamPendingBank=null;
    surfDreamTransitionMs=0;
  }else{
    surfDreamNextReady=true;surfDreamPendingBank=bankId;
    surfDreamTransitionStart=globalThis.performance?.now?.()||Date.now();
    surfDreamTransitionMs=transitionMs;
  }
  return true;
}
export function r3dSetSurfaceDreamMix(mix=.68){
  surfDreamMix.fill(Math.max(0,Math.min(.98,Number(mix)||0)));
}
export function r3dClearSurfaceDream(){surfDreamMix.fill(0);surfDreamReady=false;surfDreamNextReady=false;surfDreamActiveBank=null;surfDreamPendingBank=null;}
// THE NO-SD BASELINE (the God menu's STABLE DIFFUSION switch). Clearing the
// dream only zeroes its mix: the arrays stay resident, tens of megabytes of them
// at five frames a bank. Releasing gives every generated texture back, keeps the
// shader's dream branch off (uDreamReady stays 0, so neither the dream nor the
// mark field is sampled) and leaves 1×1 stand-ins on units 9–11 so the samplers
// are never unbound. Restoring rebuilds the full-size arrays before the lens
// writes into them again.
let surfDreamReleased=false;
function makeStandInArray(){
  const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
  gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,gl.RGBA8,1,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array(4));
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  return t;
}
export function r3dSurfaceDreamMemory(){
  const mip=4/3,tile=SURFACE_TILE*SURFACE_TILE*4,mark=MARK_FIELD_SIZE*MARK_FIELD_SIZE*4;
  if(surfDreamReleased)return{released:true,dreamBytes:0,stageBytes:0,markBytes:0,burstBytes:burstTex?burstW*burstH*4:0};
  return{released:false,
    dreamBytes:surfDreamTex?Math.round(tile*SURFACE_LAYERS*surfDreamFrames*mip):0,
    stageBytes:surfDreamStageTex?Math.round(tile*SURFACE_LAYERS*surfDreamStageFrames*mip):0,
    markBytes:surfMarkTex?Math.round(mark*MARK_HALF_LAYERS*2*mip):0,
    burstBytes:burstTex?burstW*burstH*4:0};
}
export function r3dReleaseSurfaceDream(){
  if(!gl)return{released:false,freedBytes:0};
  const before=r3dSurfaceDreamMemory();
  r3dClearSurfaceDream();
  markQueue.length=0;markEpoch+=1;markReady.fill(0);markStageReady.fill(0);
  burstTarget=0;burstMix=0;
  if(!surfDreamReleased){
    for(const t of [surfDreamTex,surfDreamStageTex,surfMarkTex])if(t)gl.deleteTexture(t);
    surfDreamTex=makeStandInArray();surfDreamStageTex=makeStandInArray();surfMarkTex=makeStandInArray();
    surfDreamFrames=1;surfDreamStageFrames=1;markLiveBase=0;surfDreamReleased=true;
  }
  if(burstTex){gl.deleteTexture(burstTex);burstTex=null;burstW=0;burstH=0;}
  return{released:true,freedBytes:before.dreamBytes+before.stageBytes+before.markBytes+before.burstBytes};
}
export function r3dRestoreSurfaceDream(){
  if(!gl||!surfDreamReleased)return false;
  for(const t of [surfDreamTex,surfDreamStageTex,surfMarkTex])if(t)gl.deleteTexture(t);
  initSurfaceDream();surfDreamReleased=false;
  return true;
}
export function r3dSetLocalDiffusionLevel(v=1){localDiffusionAvailability=Math.max(0,Math.min(1,Number(v)||0));}
// How hard the world is boiling right now: dread, the coffee onset, and battle
// impacts all push here. It scales the boil rate, how much generated structure
// reaches the wall, and phosphor excitation in the VFD pass.
// 1 restores the flat constant this shipped with — the A/B for the falloff.
let ambientFloor=0.18;
export function r3dSetAmbientFloor(v=0.18){ambientFloor=Math.max(0,Math.min(1,Number(v)||0));return ambientFloor;}
export function r3dAmbientFloor(){return ambientFloor;}
let ambientPlace=1;
export function r3dWorldYaw(){return yaw+planYaw;}
export function r3dSetAmbientPlace(v=1){ambientPlace=Math.max(0,Math.min(1,v==null?1:Number(v)));return ambientPlace;}
export function r3dAmbientPlace(){return ambientPlace;}
export function r3dSetAgitation(v=0){dreamAgitation=Math.max(0,Math.min(1,Number(v)||0));}
// How hard the generated material's density pulls the recorder's threshold.
// 0 is exactly the procedural hash this game shipped with, which makes it the
// A/B: set it to zero and the walls go back to being drawn by noise.
export function r3dSetMarkDensityGain(v=0.55){markDensityGain=Math.max(0,Math.min(2,Number(v)||0));return markDensityGain;}
export function r3dMarkDensityGain(){return markDensityGain;}
export function r3dSetMarkGrainGain(v=0.70){markGrainGain=Math.max(0,Math.min(2,Number(v)||0));return markGrainGain;}
export function r3dMarkGrainGain(){return markGrainGain;}
// 0 restores the flat per-profile white point every room used to share, which is
// the A/B for the tone floor: does a room lit to .028 read as an engraving, or
// as sparse dust.
export function r3dSetWhitePointZoneAmount(v=1){whitePointZoneAmount=Math.max(0,Math.min(1,Number(v)??1));return whitePointZoneAmount;}
export function r3dWhitePointZoneAmount(){return whitePointZoneAmount;}
export function r3dWhitePointScale(){return whitePointScaleOverride??lightingWhitePointScale;}
// Diagnostic sweep of the existing acquisition exposure; null restores the
// room's authored exposure without changing its material or display palette.
export function r3dSetCaptureExposureOverride(value=null){
  const number=Number(value);
  captureExposureOverride=value!=null&&Number.isFinite(number)?Math.max(1,Math.min(12,number)):null;
  return captureExposureOverride??lightingCaptureExposure;
}
// Forces the scale regardless of zone, so the ceiling can be SWEPT against
// measured ink instead of derived from an authored ambient that turns out not to
// predict screen luminance. null hands the room back its own.
// The bounce A/B. 0 is the flat ambient every room shared, which is the black
// ceiling; lampGain is how much lighting the floor lights what is over it.
export function r3dSetBounceAmount(v=1){bounceAmount=Math.max(0,Math.min(6,Number(v)??1));return bounceAmount;}
export function r3dSetBounceLampGain(v=2.4){bounceLampGain=Math.max(0,Math.min(12,Number(v)??2.4));return bounceLampGain;}
export function r3dBounce(){return{amount:bounceAmount,lampGain:bounceLampGain,
  zoneIntensity:lightingBounceIntensity,effective:lightingBounceIntensity*bounceAmount};}
export function r3dSetRainAmount(v=1){rainAmount=Math.max(0,Math.min(8,Number(v)??1));return rainAmount;}
export function r3dRainAmount(){return rainAmount;}
export function r3dSetIndoorRain(v=0){indoorRain=Math.max(0,Math.min(1,Number(v)||0));return indoorRain;}
export function r3dIndoorRain(){return indoorRain;}
export function r3dSetEndingWorldLook(id=null){
  const key=String(id||'');
  endingWorldLook=key?({
    'dawn-0600':1,'conservatoire-0600':1,'cathedral-dawn':1,'van-rain-0500':2,
  }[key]||1):0;
  return endingWorldLook;
}
export function r3dEndingWorldLook(){return endingWorldLook;}
// The screen A/B. null hands it back to the room, then to the look profile.
export function r3dSetScreenOverride(id=null){
  screenOverrideId=isScreen(id)?id:null;
  return screenOverrideId;
}
export function r3dScreen(){
  return{override:screenOverrideId,zone:lightingScreenId,
    effective:screenForWorld(screenOverrideId),sourceDitherMix};
}
export function r3dSetWhitePointScaleOverride(v=null){
  whitePointScaleOverride=v==null?null:Math.max(.002,Math.min(4,Number(v)||0));
  return whitePointScaleOverride;
}
export function r3dAgitation(){return dreamAgitation;}
function surfaceDreamBlend(nowMs=globalThis.performance?.now?.()||Date.now()){
  if(!surfDreamNextReady||!surfDreamTransitionMs)return 0;
  const t=Math.max(0,Math.min(1,(nowMs-surfDreamTransitionStart)/surfDreamTransitionMs));
  if(t>=1){
    [surfDreamTex,surfDreamStageTex]=[surfDreamStageTex,surfDreamTex];
    markLiveBase=markLiveBase?0:MARK_HALF_LAYERS;
    markReady.set(markStageReady);markStageReady.fill(0);
    [surfDreamFrames,surfDreamStageFrames]=[surfDreamStageFrames,surfDreamFrames];
    surfDreamReady=true;surfDreamNextReady=false;surfDreamActiveBank=surfDreamPendingBank;surfDreamPendingBank=null;surfDreamTransitionMs=0;
    return 0;
  }
  return t*t*(3-2*t);
}
export function r3dSurfaceDreamStats(){const look=currentLook();return{active:[...surfDreamMix].filter((v)=>v>0).length,mix:[...surfDreamMix],local:look.material.localDiffusion*localDiffusionAvailability,bank:surfDreamActiveBank,pendingBank:surfDreamPendingBank,transitioning:surfDreamNextReady,frames:surfDreamFrames,stagedFrames:surfDreamStageFrames,boilHz:look.material.boilHz??0,structureMix:look.material.structureMix??0,agitation:dreamAgitation,burst:burstMix,
  // The engraving, and what it costs. lastMs is watched because the lens
  // disables itself for the session on a single 33ms frame, so this number
  // going up is the early warning for that.
  marks:{ready:!!surfMarkTex,size:MARK_FIELD_SIZE,source:MARK_FIELD_SOURCE,
    derived:markDeriveCount,queued:markQueue.length,lastMs:+markLastMs.toFixed(2),densityGain:markDensityGain,grainGain:markGrainGain,
    avgMs:markDeriveCount?+(markDeriveMs/markDeriveCount).toFixed(2):0,
    // Slots currently engraved rather than drawn by the procedural hash.
    engraved:[...markReady].filter((v)=>v>0).length,staging:[...markStageReady].filter((v)=>v>0).length}};}
export function r3dSurfaceStats(){return{albedo:!!surfAlbedoTex,normal:!!surfNormalTex,
  // Roughness and relief share one array now (R and G), so they are ready together.
  roughness:!!surfMaterialTex,height:!!surfMaterialTex,
  ready:!!(surfAlbedoTex&&surfNormalTex&&surfMaterialTex)};}
let planTexture = null, materialTexture = null, sourceLayerTexture = null, planW = 0, planH = 0;
// The material/ambient bytes as last uploaded, so a region patch can rewrite
// material without having to re-derive the baked ambient sharing the texture.
let planMatAmb = null;
let planOriginX = 0, planOriginY = 0, planHeightOffset = 0, sourceSurfaceTexture = null;
let planExteriorPortal = null;
let sourceSurfaceBaker=null,sourceSurfaceDiagnostics=null;
let uniforms = {};
let facing = 0; // 0=N(0,-1) 1=E 2=S 3=W
let yaw = 0, yawTarget = 0, pitch = 0, pitchTarget = 0;
// HOW FAR THE WORLD IS TURNED UNDER THE PLAYER AT THIS POSITION.
//
// Non-zero only on the spiral. `yaw` stays the LOGICAL look angle — the thing
// the mouse and r3dStepDelta's eight-way snap both write — and the offset is
// added on the way into the shader, so "forward" on screen and "forward" in the
// logical corridor stay the same direction on every tread. That is why nothing
// about movement needs to change on a curved stair.
//
// Eased on its own clock. The offset is derived from position, and a raster
// cannot put tread centres at even angles: the measured step is monotone but
// uneven, 8.8 to 33.7 degrees against an 18.0 mean. Smoothing the camera is the
// right answer to that; distorting the ring to hide it is not.
let planYaw = 0, planYawTarget = 0;
let camX = 0, camZ = 0, camY = EYE_METERS / CELL;
let natatoriumMetric=NATATORIUM_METRIC_IDENTITY;
// The peek. A lateral offset on the EYE, in cells, eased so the head moves like
// a head. main.js clamps it against the geometry (game/cover.js) and hands the
// clamped value down; nothing in here decides how far you may lean.
let leanEase = 0;
let lastT = 0;
let fogOrigin = [0, 0];
const marchUniformCache=new Map();
let lightEase = 0;   // the building starts dark, and so do you

function compile(type, src) {
  const s = gl.createShader(type);
  if (!s) throw graphicsStartupError('Required shader allocation failed.');
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
    throw graphicsStartupError('shader: ' + gl.getShaderInfoLog(s));
  return s;
}
function program(fragSrc) {
  const p = gl.createProgram();
  if (!p) throw graphicsStartupError('Required shader program allocation failed.');
  gl.attachShader(p, compile(gl.VERTEX_SHADER, VERT));
  gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fragSrc));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS))
    throw graphicsStartupError('link: ' + gl.getProgramInfoLog(p));
  return p;
}
function reportGlError(label) {
  const code = gl?.getError?.() || 0;
  if (code) {
    const msg = `${label}: WebGL error ${code}`;
    pixelMeshStatus.lastGlError = code;
    pixelMeshStatus.lastError = msg;
    console.warn('[pixel-mesh]', msg);
  }
  return code;
}
function clearGlErrors() {
  if (!gl?.getError) return;
  while (gl.getError()) {}
}
function makeTex(w, h, data = null, format = 'rgba8') {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  if (format === 'r8') gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, w, h, 0, gl.RED, gl.UNSIGNED_BYTE, data);
  // Gray-Scott needs real precision: in RGBA8 the reaction term quantises to
  // 1/255 steps and the field degenerates into salt-and-pepper noise.
  else if (format === 'rgba16f') gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.FLOAT, data);
  else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  return t;
}
// `extra` attaches further colour targets. Only the scene uses it: the march is
// the one pass that knows a fragment's surface UV and slot, so the engraving has
// to leave alongside the image or it cannot be recovered downstream at all.
function makeFbo(tex, extra = [], depth = null) {
  const f = gl.createFramebuffer();
  if (!f) throw graphicsStartupError('Required framebuffer allocation failed.');
  gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  if (depth) gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
  if (extra.length) {
    extra.forEach((t, i) => gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT1 + i, gl.TEXTURE_2D, t, 0));
    gl.drawBuffers([gl.COLOR_ATTACHMENT0, ...extra.map((_, i) => gl.COLOR_ATTACHMENT1 + i)]);
  }
  const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  if (status !== gl.FRAMEBUFFER_COMPLETE) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.deleteFramebuffer(f);
    throw graphicsStartupError(`Required framebuffer incomplete (${status}).`);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return f;
}

function makeMeshTex(w, h) {
  const t = makeTex(w, h);
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}

function debugSourceToNumber(source) {
  if (source === 'world') return 1;
  if (source === 'signal') return 2;
  if (source === 'memory') return 3;
  if (source === 'edge') return 4;
  if (source === 'mask') return 5;
  if (source === 'threshold') return 6;
  if (source === 'recorded') return 7;
  if (source === 'instability') return 8;
  return 0;
}

function resolvePixelMeshCellScenePx() {
  const raw = pixelMeshSettings.cellSize;
  const authored = currentLook().vfd.cellPx || 2;
  const cssCell = raw === 'auto' ? authored : Math.max(2, Math.min(24, Number(raw) || authored));
  // During an animated window resize, the old targets remain live until the
  // motion settles. Keep the dither grid in that allocated pixel space.
  return Math.max(1, cssCell * (outputPixelRatioApplied ?? r3dEffectiveOutputPixelRatio()) * RENDER_SCALE);
}

function pixelMeshU(name) {
  if (!pixelMeshUniformCache.has(name)) pixelMeshUniformCache.set(name, gl.getUniformLocation(progPixelMesh, name));
  return pixelMeshUniformCache.get(name);
}

let frontEndPlate = normalizeFrontEndPlate(FRONT_END_PLATE_PRESETS.gameplay);
let frontEndPlatePresetId = null;
export function r3dSetFrontEndPlate(value='gameplay'){
  // main.js sets the plate every frame. Preset ids are the steady state; an
  // unchanged id keeps the last normalized plate without re-clamping it.
  if(typeof value==='string'&&value===frontEndPlatePresetId)return frontEndPlate;
  const next=normalizeFrontEndPlate(value);
  if(typeof value==='string')frontEndPlatePresetId=value;
  if(next.negative===frontEndPlate.negative&&next.print===frontEndPlate.print&&next.amount===frontEndPlate.amount
    &&next.detailRetention===frontEndPlate.detailRetention&&next.chromaRetention===frontEndPlate.chromaRetention
    &&next.exposureStops===frontEndPlate.exposureStops&&next.shoulder===frontEndPlate.shoulder&&next.toe===frontEndPlate.toe)return frontEndPlate;
  frontEndPlate=next;
  return frontEndPlate;
}
export function r3dFrontEndPlate(){ return {...frontEndPlate}; }

function postU(name) {
  if (!postUniformCache.has(name)) postUniformCache.set(name, gl.getUniformLocation(progPost, name));
  return postUniformCache.get(name);
}

function textSpaceU(name) {
  if (!textSpaceUniformCache.has(name)) textSpaceUniformCache.set(name, gl.getUniformLocation(progTextSpace, name));
  return textSpaceUniformCache.get(name);
}

function sourceHushProjection(body=hushBodyLast,amount=hushBodyManifestation){
  if(!hushBodyReady||hushBodyMode==='off'||amount<=.001)return{x:.5,y:.5,w:0,h:0,amount:0};
  const floorM=Number.isFinite(Number(body.floorH))?Number(body.floorH):0;
  const base=r3dProjectWorld({x:(body.x+.5)*CELL,y:floorM+.02,z:(body.y+.5)*CELL});
  const top=r3dProjectWorld({x:(body.x+.5)*CELL,y:floorM+body.heightM,z:(body.y+.5)*CELL});
  if(!base.visible&&!top.visible)return{x:.5,y:.5,w:0,h:0,amount:0};
  const h=Math.max(.012,Math.abs(base.y-top.y));
  const aspect=Math.max(.1,(uniforms.sceneW||1)/(uniforms.sceneH||1));
  const w=Math.max(.006,h*(body.widthM/body.heightM)/aspect);
  return{x:(base.x+top.x)*.5,y:1-(base.y+top.y)*.5,w,h,amount:Math.max(0,Math.min(1,amount))};
}

function presentTexture(texture){
  gl.useProgram(progCopy);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  gl.viewport(0,0,canvas.width,canvas.height);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
  gl.uniform1i(gl.getUniformLocation(progCopy,'uSrc'),0);
  gl.uniform2f(gl.getUniformLocation(progCopy,'uRes'),canvas.width,canvas.height);
  gl.drawArrays(gl.TRIANGLES,0,3);
}

const sourceVoidPhysicalUniformCache = new Map();
let sourceVoidDawn = 0;
let sourceVoidBeacon = null;
let sourceVoidRain = 0;
let sourceRainShelter = null;
let sourceBusLighting = null;
let sourceBusInterior = null;
// THE WET ROAD in the outskirts: { groundY (m), puddle [x, z, radius], wet 0–1 }, or null.
let sourceReflection = null, sourceReflectionDebug = false;
export function r3dSetSourceReflectionDebug(on = true) { sourceReflectionDebug = !!on; return sourceReflectionDebug; }
export function r3dReflectionStats() { return { active: !!sourceReflection, debug: sourceReflectionDebug, ...(P3.reflectionStats?.() || {}) }; }
export function r3dSetSourceReflection(frame = null) {
  sourceReflection = frame && frame.active ? {
    groundY: Number(frame.groundY) || 0,
    puddle: Array.isArray(frame.puddle) ? frame.puddle.map((v) => Number(v) || 0) : [0, 0, 0],
    wet: Math.max(0, Math.min(1, Number(frame.wet) || 0)),
  } : null;
  return !!sourceReflection;
}
let sourceVoidRainRate = 1;
export function r3dSetSourceRainRate(rate = 1) { sourceVoidRainRate = Number(rate) < 0 ? -1 : 1; return sourceVoidRainRate; }
let sourceCrossing = null;
// ST BRENDAN'S BELFRY, FOR THE TOWER DOOR. r3dCaptureTowerView renders the
// building's own frame once, off screen, from the belfry arrival, and keeps its
// colour and scene depth; the Source tower door reprojects them (props3d.js
// renderSourceTowerView). sourceTowerView is where the door is this frame.
let towerViewCapture=null,towerViewColorTex=null,towerViewColorFbo=null,towerViewDepthTex=null,towerViewDepthFbo=null,towerViewW=0,towerViewH=0;
let sourceTowerView=null,sourceTowerViewDrawn=0,lastBuildingViewState=null,towerCaptureInProgress=false;
// Doorways that show a flat field of colour, by which side the eye is on: the
// grey doors at the field's edge are black from the field and paper from outside.
let sourceOpenings=[];
// Where the building's post pass presents. Null is the canvas; a capture points it elsewhere.
let presentTarget=null;
function sourceTowerViewInside(eyeX,eyeZ){
  const view=sourceTowerView;if(!view)return false;
  const f=view.forward,o=view.origin,dx=eyeX-o[0],dz=eyeZ-o[2];
  const depth=dx*f[0]+dz*f[1],lateral=-dx*f[1]+dz*f[0];
  // From a hand-width short of the plane: nearer than that the opening would be
  // cut by the near plane and let the field show round its edges.
  return depth>=-.15&&depth<3&&Math.abs(lateral)<view.width/2+.3;
}
let sourceCrossingDrawn = false;
let sourceDoorLights = [];
const sourceVoidPhysicalLightPositions = new Float32Array(16);
const sourceVoidPhysicalLightColours = new Float32Array([.80,.86,.91,1.25, .92,.81,.64,.28, 1,.80,.58,0, 1,.72,.45,0]);
const sourceVoidPhysicalLightPenetration = new Float32Array([1,1,1,1]);
const sourceVoidPhysicalLightEmergency = new Float32Array([0,0,0,0]);
const sourceVoidPhysicalLightDirections = new Float32Array(16);
const sourceVoidPhysicalLightConeInner = new Float32Array([1,1,1,1]);
const sourceHomeNoMarks = new Float32Array(4);
function sourceVoidPhysicalU(name){
  if(!sourceVoidPhysicalUniformCache.has(name))sourceVoidPhysicalUniformCache.set(name,gl.getUniformLocation(progSourceVoidPhysical,name));
  return sourceVoidPhysicalUniformCache.get(name);
}

function drawSourceShore(now,{voidState,worldYaw,torchPower,torchColor,torchReach,torchConeInner,torchConeOuter,torchSpill,torchShoulder,torchYawOffset=0,lampFrame=null}={}){
  const eyeX=camX*CELL,eyeY=camY*CELL,eyeZ=camZ*CELL;
  const torch={power:torchPower,color:torchColor,reach:torchReach,coneInner:torchConeInner,
    coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder,yawOffset:torchYawOffset,lampFrame};
  // Keep nearby remembered-room detail on its own authored GLB materials and
  // real flashlight shadows. The dedicated hull pass supplies the distant
  // room and bank which are beyond props3d's ordinary ninety-metre camera.
  P3.renderPropPass({
    camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,light:torchPower,
    sourceCodeScreen:true,
    timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,
    fogTexture,fogOrigin,fogSize:FOG_TEX,cellMeters:CELL,zoneTints:ZONE_TINTS,
    localLightCount,localLightPositions,localLightColors,localLightPenetrations,
    localLightEmergency,localShadowIndex:-1,shadowLight:null,torchYawOffset,torch,lampFrame,
    ambientColor:[.67,.74,.77],ambientIntensity:.12,
    planTexture:null,planSize:[0,0],planOrigin:[0,0],streetTextures:false,
  });
  SHORE.sourceShoreDraw({frame:sourceShoreState,camX:eyeX,camY:eyeY,camZ:eyeZ,
    yaw:worldYaw,pitch,width:uniforms.sceneW,height:uniforms.sceneH,torch});
  const props=P3.propTargets();
  // Empty marks prevent the room we just left from engraving stale surface
  // marks into these independent world-space hulls.
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  gl.clearBufferfv(gl.COLOR,1,new Float32Array([0,0,0,0]));
  SHORE.sourceShoreComposite({target:sceneFbo,props,medium:sourceShoreState.demolitionMedium,
    eye:[eyeX,eyeY,eyeZ],yaw:worldYaw,pitch});
  // The nothingness is printed by the same acquisition and post as the room he
  // just left. Painting smooth colour back over the encode, then skipping post,
  // is what made the walk the one undithered stretch of the game.
  presentThroughPost(runPixelMeshPass(voidState,now));
  drawSourceCodeScreen(now,{worldYaw,boundaryOnly:false});
  lastPostSourceFbo=sceneFbo;
}

// What's out there at night: traffic, towns, red lights on tall things. Far past the
// prop range, so each is drawn straight onto the finished picture, on exactly the
// rays the land was marched along, and only where nothing solid stands in front.
const DRIVE_FAR_LIGHT_VERT=`#version 300 es
precision highp float;
layout(location=0) in vec4 aPoint;layout(location=1) in vec4 aColor;
uniform vec3 uEye;uniform vec3 uView;uniform vec2 uAspect;
out vec3 vColor;
void main(){
  vec3 w=aPoint.xyz-uEye;float cy=cos(uView.x),sy=sin(uView.x),cp=cos(uView.y),sp=sin(uView.y);
  float x=w.x*cy+w.z*sy,z=w.x*sy-w.z*cy,y=w.y*cp-z*sp,d=w.y*sp+z*cp;
  gl_Position=d>.5?vec4(x/d/(uAspect.x*.65),y/d/.65,0.0,1.0):vec4(2.0,2.0,2.0,1.0);
  gl_PointSize=max(1.0,aPoint.w*uView.z);
  vColor=aColor.rgb*aColor.a;
}`;
const DRIVE_FAR_LIGHT_FRAG=`#version 300 es
precision highp float;
in vec3 vColor;uniform sampler2D uDepth;
layout(location=0) out vec4 o;
void main(){
  vec2 q=gl_PointCoord*2.0-1.0;if(dot(q,q)>1.0)discard;
  if(texelFetch(uDepth,ivec2(gl_FragCoord.xy),0).r<.99999)discard;
  o=vec4(vColor,1.0);
}`;
let driveFarLightProgram=null,driveFarLightVao=null,driveFarLightBuffer=null,driveFarLightFailed=false;
function drawDriveFarLights(lights,{eye,yaw,pitch,depth}){
  if(driveFarLightFailed)return 0;
  if(!driveFarLightProgram){
    const compile=(type,source)=>{const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader));return shader;};
    try{
      const made=gl.createProgram();gl.attachShader(made,compile(gl.VERTEX_SHADER,DRIVE_FAR_LIGHT_VERT));gl.attachShader(made,compile(gl.FRAGMENT_SHADER,DRIVE_FAR_LIGHT_FRAG));gl.linkProgram(made);
      if(!gl.getProgramParameter(made,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(made));
      driveFarLightProgram=made;
    }catch(error){driveFarLightFailed=true;console.warn('Drive far lights unavailable',error);return 0;}
    driveFarLightVao=gl.createVertexArray();driveFarLightBuffer=gl.createBuffer();
    gl.bindVertexArray(driveFarLightVao);gl.bindBuffer(gl.ARRAY_BUFFER,driveFarLightBuffer);
    gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,32,0);
    gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,4,gl.FLOAT,false,32,16);
    gl.bindVertexArray(null);
  }
  const vao=gl.getParameter(gl.VERTEX_ARRAY_BINDING),program=gl.getParameter(gl.CURRENT_PROGRAM),w=gl.drawingBufferWidth,h=gl.drawingBufferHeight,view=gl.getParameter(gl.VIEWPORT);
  gl.useProgram(driveFarLightProgram);gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);
  const uniform=name=>gl.getUniformLocation(driveFarLightProgram,name);
  gl.uniform3f(uniform('uEye'),eye[0],eye[1],eye[2]);gl.uniform3f(uniform('uView'),yaw,pitch,view[3]/720);gl.uniform2f(uniform('uAspect'),view[2]/view[3],1);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,depth);gl.uniform1i(uniform('uDepth'),1);
  gl.bindVertexArray(driveFarLightVao);gl.bindBuffer(gl.ARRAY_BUFFER,driveFarLightBuffer);gl.bufferData(gl.ARRAY_BUFFER,lights.data,gl.DYNAMIC_DRAW);
  gl.drawArrays(gl.POINTS,0,lights.count);
  gl.bindVertexArray(vao);gl.useProgram(program);
  return lights.count;
}
// The occupied pocket writes every pixel and its own depth.
function drawOccupiedHome(now,{voidState,crossingReveal,torchPower,sourceTorchMode,present}){
  const realm=sourceCrossing.realm;
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  gl.clearBufferfv(gl.COLOR,1,sourceHomeNoMarks);
  sourcePortalsDrawn=0;
  sourceTowerViewDrawn=0;
  sourceCrossingDrawn=P3.renderSourceCrossing({
    framebuffer:sceneFbo,width:uniforms.sceneW,height:uniforms.sceneH,
    dir:[Math.sin(realm.pose.yaw),Math.cos(realm.pose.yaw)],pitch:realm.pose.pitch,reveal:crossingReveal,
    variant:sourceCrossing.variant,seed:sourceCrossing.seed,key:sourceCrossing.key,
    wayOut:sourceCrossing.wayOut?1:0,reducedMotion:pixelMeshSettings.reduceMotion,
    timeSec:Number.isFinite(realm.time)?realm.time:now,realm,realmId:sourceCrossing.id,
    frameTimeSec:now,homePresentation:sourceCrossing.homePresentation||null,torchPower,
  });
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  if(present)presentThroughPost(runPixelMeshPass(voidState,now,{occupiedHome:true}),{torchPower,sourceTorchMode});
  lastPostSourceFbo=sceneFbo;
}
function drawSourceVoidPhysical(now,{voidState,worldYaw,torchPower,torchColor=[.94,.96,1],torchReach,torchConeInner,torchConeOuter,torchSpill,sourceTorchMode=0,torchYawOffset=0,present=true,unravelling=null,lampFrame=null}={}){
  const crossingReveal=pixelMeshSettings.reduceMotion
    ?(sourceCrossing?.reveal>.5?1:0):sourceCrossing?.reveal;
  const occupiedHome=homeRealmAcquisition({
    realm:sourceCrossing?.realm,variant:sourceCrossing?.variant,reveal:crossingReveal,
  });
  // Blended thresholds still need the station geometry behind the pocket.
  if(occupiedHome){
    drawOccupiedHome(now,{voidState,crossingReveal,torchPower,sourceTorchMode,present});
    return;
  }
  const eyeX=camX*CELL,eyeY=camY*CELL,eyeZ=camZ*CELL;
  const patternOriginOffsetMetres=['x','y','z'].map(axis=>Number.isFinite(voidState?.recordingOriginOffset?.[axis])?voidState.recordingOriginOffset[axis]:0);
  const drive=voidState?.driveStudy?.active===true?voidState.driveStudy:null;
  const coastal=coastalWaterUniforms(voidState?.coastalMemory),physicalLighting=!!drive||coastal.active||!!sourceBusInterior?.active;
  // Broad, unobtrusive light gives the real normals form. No imaginary lamp
  // models, red emergency sources or inherited Scene Dock light fixtures.
  // The second lamp is the nearest leaking door when there is one, so the trees
  // and frames beside it take its world's colour.
  const leak=sourceDoorLights[0]||null;
  sourceVoidPhysicalLightPositions.set(leak
    ?[eyeX-60,eyeY+80,eyeZ-36,260, ...(Array.isArray(leak.lightAt)?[leak.lightAt[0],leak.lightAt[1],leak.lightAt[2],leak.pool?16:9+7*leak.strength]:[leak.x+leak.forward[0]*1.5,leak.y+1.4,leak.z+leak.forward[1]*1.5,9+7*leak.strength])]
    :[eyeX-60,eyeY+80,eyeZ-36,260, eyeX+45,eyeY+18,eyeZ+20,180]);
  sourceVoidPhysicalLightColours.set(leak?[leak.colour[0],leak.colour[1],leak.colour[2],.9*(leak.meshStrength??leak.strength)]:[.92,.81,.64,.28],4);
  const busCover=outskirtsBusInteriorLightMix([eyeX,eyeY,eyeZ],sourceBusLighting?.origin);
  sourceVoidPhysicalLightColours.set([.80,.86,.91,1.25*(1-.98*busCover)],0);
  sourceVoidPhysicalLightColours[7]*=1-.5*busCover;
  sourceVoidPhysicalLightColours[11]=0;
  const motorwayLamp=leak?.motorway&&sourceDoorLights.find(light=>light!==leak&&light.motorway&&Array.isArray(light.lightAt));
  if(motorwayLamp){
    sourceVoidPhysicalLightPositions.set([...motorwayLamp.lightAt,19],8);
    sourceVoidPhysicalLightColours.set([...motorwayLamp.colour,.78*(motorwayLamp.meshStrength??motorwayLamp.strength)],8);
  }
  if(busCover>0){
    sourceVoidPhysicalLightPositions.set([...sourceBusLighting.front,4.8],8);
    sourceVoidPhysicalLightColours.set([1,.80,.58,.42*sourceBusLighting.power.front*busCover],8);
  }
  if(sourceBusLighting?.face){
    const face=sourceBusLighting.face,cone=localLightConeDescriptor(face);
    // A bounded first reflection of the hooded rear practical. Its warm
    // return from the opposite low wall gives the opened cut faces depth;
    // replacing the remote night fill avoids illuminating the coach roof.
    const o=sourceBusLighting.origin,c=Math.cos(o.yaw),s=Math.sin(o.yaw);
    sourceVoidPhysicalLightPositions.set([o.x-.91*c+3.66*s,o.y+1.16,o.z+.91*s+3.66*c,3.4],4);
    sourceVoidPhysicalLightColours.set([.78,.49,.30,.26*sourceBusLighting.power.face],4);
    sourceVoidPhysicalLightPositions.set([...face.position,face.reach],12);
    sourceVoidPhysicalLightColours.set([...face.colour,face.strength*sourceBusLighting.power.face],12);
    sourceVoidPhysicalLightDirections.set([...cone.direction,cone.outer],12);sourceVoidPhysicalLightConeInner[3]=cone.inner;
  }
  const voidLightCount=sourceBusLighting?.face?4:motorwayLamp?3:2;


  // The horizon renderer leaves blending and depth writes in a different state.
  // Reassert both before drawing real mutually occluding GLB triangles.
  gl.disable(gl.BLEND);
  gl.depthMask(true);
  gl.depthFunc(gl.LEQUAL);
  // Out here there is almost nothing for the beam to land on, so what it does
  // reach it lights hard and far.
  const entryMetres=-100;
  const entryTorch=1;
  const coastalFoot=coastal.active&&!drive;
  const voidTorch=Math.min(1.6,Math.max(0,Number(torchPower)||0)*(coastalFoot?.50:1.35))*entryTorch;
  // Standing in the tower doorway the belfry is all there is: no rain, no sky.
  const towerInside=sourceTowerViewInside(eyeX,eyeZ);
  const flash=towerInside?0:stormFlash;
  // Character animation is simulation-owned. Freeze its evaluated pose and
  // this frame's shadow before either camera samples the deforming body.
  P3.prepareCharacterFrame(now);
  P3.preparePropShadowPass({camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,
    light:drive||(coastal.active&&localShadowLight)?1:voidTorch,shadowLight:physicalLighting?localShadowLight:null,timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,patternOriginOffsetMetres,torchYawOffset,lampFrame,torch:{reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill}});
  // THE WET ROAD, MIRRORED: the scene again from under the road at half size, for
  // the composite's puddles. Drawn before the main pass, into its own target.
  const reflecting=!!(sourceReflection&&!towerInside&&visualEffectsEnabled()&&P3.reflectionTargets);
  if(reflecting){
    P3.renderPropPass({
      camX:eyeX,camY:2*sourceReflection.groundY-eyeY,camZ:eyeZ,yaw:worldYaw,pitch:-pitch,light:voidTorch,
      patternOriginOffsetMetres,
      timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,
      fogTexture,fogOrigin,fogSize:FOG_TEX,cellMeters:CELL,zoneTints:ZONE_TINTS,
      localLightCount:drive?localLightCount:voidLightCount,localLightPositions:drive?localLightPositions:sourceVoidPhysicalLightPositions,
      localLightColors:drive?localLightColors:sourceVoidPhysicalLightColours,localLightPenetrations:drive?localLightPenetrations:sourceVoidPhysicalLightPenetration,
      localLightDirections:drive?localLightDirections:sourceVoidPhysicalLightDirections,localLightConeInner:drive?localLightConeInner:sourceVoidPhysicalLightConeInner,
      localLightEmergency:drive?localLightEmergency:sourceVoidPhysicalLightEmergency,localShadowIndex:drive?localShadowIndex:-1,shadowLight:drive?localShadowLight:null,
      torchYawOffset,lampFrame:lampFrame||resolveTorchFrame({eye:[eyeX,eyeY,eyeZ],yaw:worldYaw,pitch,yawOffset:torchYawOffset}),
      torch:{power:voidTorch,color:torchColor,reach:coastalFoot?torchReach:Math.min(3,torchReach*2.3),coneInner:torchConeInner,coneOuter:torchConeOuter,spill:Math.max(.08,torchSpill),shoulder:coastalFoot?.9:.65},
      ambientColor:[.66,.73,.80],ambientIntensity:.19*(1-.78*busCover)*(1+flash*5),
      planTexture:null,planSize:[0,0],planOrigin:[0,0],streetTextures:true,maxDistance:70,reflection:true,
    });
  }
  if(drive)P3.captureDriveMirrors({fogTexture,fogOrigin,fogSize:FOG_TEX,cellMeters:CELL,zoneTints:ZONE_TINTS,localLightCount,localLightPositions,localLightColors,localLightPenetrations,localLightEmergency,ambientColor:lightingAmbientColor,ambientIntensity:lightingAmbientIntensity,timeSec:now});
  P3.renderPropPass({
    camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,light:voidTorch,
    patternOriginOffsetMetres,
    shadowPrepared:true,
    timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,
    fogTexture,fogOrigin,fogSize:FOG_TEX,cellMeters:CELL,zoneTints:ZONE_TINTS,
    localLightCount:physicalLighting?localLightCount:voidLightCount,localLightPositions:physicalLighting?localLightPositions:sourceVoidPhysicalLightPositions,
    localLightColors:physicalLighting?localLightColors:sourceVoidPhysicalLightColours,localLightPenetrations:physicalLighting?localLightPenetrations:sourceVoidPhysicalLightPenetration,
    localLightDirections:physicalLighting?localLightDirections:sourceVoidPhysicalLightDirections,localLightConeInner:physicalLighting?localLightConeInner:sourceVoidPhysicalLightConeInner,physicalStudyMaterials:coastal.active||!!sourceBusInterior?.active,sourceBodyTissue:!!sourceBusInterior?.active||!!sourceBusLighting?.origin,
    localLightEmergency:physicalLighting?localLightEmergency:sourceVoidPhysicalLightEmergency,localShadowIndex:physicalLighting?localShadowIndex:-1,shadowLight:physicalLighting?localShadowLight:null,
    torchYawOffset,lampFrame,
    torch:{power:voidTorch,color:torchColor,reach:coastalFoot?torchReach:Math.min(3,torchReach*2.3),coneInner:torchConeInner,coneOuter:torchConeOuter,spill:Math.max(.08,torchSpill),shoulder:coastalFoot?.9:.65},
    // The old constant fill kept the outskirts props nearly as legible when
    // the torch died. Retain a small night floor there; bells keep their fill.
    ambientColor:physicalLighting?lightingAmbientColor:[.66,.73,.80],ambientIntensity:sourceBusInterior?.active?.045:physicalLighting?lightingAmbientIntensity:.19*(1-.78*busCover)*(1+flash*5),
    // Empty ground has no architectural occluder. Real props retain their own
    // depth test and flashlight shadow; no corridor plan is sampled here.
    planTexture:null,planSize:[0,0],planOrigin:[0,0],
    // The street's own surfaces on the untextured props out here.
    streetTextures:!physicalLighting,maxDistance:coastal.active?320:drive?240:90,
  });
  // Open door frames show somewhere else. Same targets, same camera, real depth.
  sourcePortalsDrawn=P3.renderSourcePortals?.({camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,portals:sourcePortals,reducedMotion:pixelMeshSettings.reduceMotion,timeSec:now,stormFlash:flash})||0;
  if(sourceOpenings.length)P3.renderSourceOpenings?.({camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,openings:sourceOpenings});
  // The open tower door shows St Brendan's belfry, rendered by the building's
  // own pass ahead of time and reprojected here; inside the doorway, all of it.
  sourceTowerViewDrawn=sourceTowerView&&P3.renderSourceTowerView
    ?P3.renderSourceTowerView({camX:eyeX,camY:eyeY,camZ:eyeZ,yaw:worldYaw,pitch,view:sourceTowerView,inside:towerInside}):0;
  const targets=P3.propTargets();
  gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
  gl.bindVertexArray(null);
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  // This physical set has no architectural wall engraving. Clear the last
  // field's marks before the shared recorder reads its material/depth pair.
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  gl.clearBufferfv(gl.COLOR,1,sourceHomeNoMarks);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0]);
  gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.useProgram(progSourceVoidPhysical);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,targets.color);
  gl.uniform1i(sourceVoidPhysicalU('uProps'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,targets.depth);
  gl.uniform1i(sourceVoidPhysicalU('uDepth'),1);
  gl.uniform2f(sourceVoidPhysicalU('uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.uniform2f(sourceVoidPhysicalU('uNearFar'),targets.near,targets.far);
  gl.uniformMatrix4fv(sourceVoidPhysicalU('uCoastInverse'),false,coastal.inverse);
  gl.uniform4fv(sourceVoidPhysicalU('uCoastSea'),coastal.params);
  gl.uniform2fv(sourceVoidPhysicalU('uCoastOptics'),coastal.optics);
  gl.uniform4fv(sourceVoidPhysicalU('uCoastLampPosition[0]'),coastal.positions);
  gl.uniform4fv(sourceVoidPhysicalU('uCoastLampDirection[0]'),coastal.directions);
  gl.uniform1f(sourceVoidPhysicalU('uPitch'),pitch);gl.uniform4f(sourceVoidPhysicalU('uDriveSky'),.016,.019,.024,drive?1:0);
  const driveLand=drive&&driveLandField?drive.land:null;
  if(driveLand&&!driveLandTex){
    driveLandTex=gl.createTexture();gl.activeTexture(gl.TEXTURE7);gl.bindTexture(gl.TEXTURE_2D,driveLandTex);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,driveLandField.size,driveLandField.size,0,gl.RGBA,gl.FLOAT,driveLandField.data);
    for(const[k,v]of[[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,k,v);
  }
  const driveLandOn=!!(driveLand&&driveLandTex&&driveLand.strength>0);
  driveLandLast=driveLandOn?{strength:driveLand.strength,eye:driveLand.eye,lights:drive.farLights?.count||0,vehicles:drive.farLights?.vehicles||0}:null;
  gl.activeTexture(gl.TEXTURE7);gl.bindTexture(gl.TEXTURE_2D,driveLandOn?driveLandTex:null);gl.uniform1i(sourceVoidPhysicalU('uDriveLandMap'),7);
  gl.uniform4f(sourceVoidPhysicalU('uDriveLand'),driveLandOn?driveLand.strength:0,driveLand?.fog||0,0,0);
  gl.uniform3f(sourceVoidPhysicalU('uDriveLandEye'),driveLand?.eye?.[0]??0,driveLand?.eye?.[1]??0,driveLand?.eye?.[2]??0);
  const weather=drive?.weather||null,wp=weather?.pane||{},wl=weather?.headlamps||[];gl.activeTexture(gl.TEXTURE5);const wt=P3.driveStudyWeatherTarget?.();
  gl.uniform4f(sourceVoidPhysicalU('uDriveWeather'),weather?.rain||0,weather?.extinction||0,weather?.timeSec||0,weather?.active&&wt?1:0);
  gl.uniform4f(sourceVoidPhysicalU('uDriveImpossibleWeather'),weather?.fog||0,weather?.snow||0,weather?.whiteout||0,0);
  gl.uniformMatrix4fv(sourceVoidPhysicalU('uDriveCabinInverse'),false,weather?.worldToCabin||[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
  const returnBlack=weather?.returnBlack;
  gl.uniformMatrix4fv(sourceVoidPhysicalU('uDriveReturnBodyInverse'),false,returnBlack?.worldToBody||[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
  gl.uniform4f(sourceVoidPhysicalU('uDriveReturnMin'),...(returnBlack?.min||[0,0,0]),Math.max(0,Math.min(1,Number(returnBlack?.amount)||0)));
  gl.uniform4f(sourceVoidPhysicalU('uDriveReturnMax'),...(returnBlack?.max||[0,0,0]),0);
  gl.uniform4f(sourceVoidPhysicalU('uDrivePane'),wp.left??-.79,wp.right??.79,wp.bottomY??1.30,wp.topY??2.16);
  gl.uniform4f(sourceVoidPhysicalU('uDrivePaneSlope'),wp.bottomZ??-1.17,((wp.topZ??-.77)-(wp.bottomZ??-1.17))/((wp.topY??2.16)-(wp.bottomY??1.30)),weather?.seed||0,weather?.roadWetness||0);
  gl.uniform4f(sourceVoidPhysicalU('uDriveWeatherExtra'),drive?.heading||0,drive?.lampDip??.020,weather?.wind?.[0]||0,weather?.wind?.[1]||0);
  gl.uniform4f(sourceVoidPhysicalU('uDriveStorm'),weather?.cloud||0,weather?.gust||0,weather?.shelter||0,0);
  const load=weather?.load||{};
  gl.uniform4f(sourceVoidPhysicalU('uDriveLoad'),load.value||0,load.water||0,load.anatomy||0,load.aftermath||0);
  gl.uniform4f(sourceVoidPhysicalU('uDriveAirLayer'),weather?.groundY||0,load.release||0,load.squall||0,0);
  const rainRoof=drive?.rainShelter;
  gl.uniform4f(sourceVoidPhysicalU('uDriveRainRoof'),rainRoof?.x||0,rainRoof?.y||0,rainRoof?.z||0,rainRoof?.heading||0);
  for(let i=0;i<2;i++){const l=wl[i]||{};gl.uniform4f(sourceVoidPhysicalU('uDriveFogLamp'+i),l.x||0,l.y||0,l.z||0,l.intensity||0);}
  gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,wt||null);gl.uniform1i(sourceVoidPhysicalU('uDriveWetness'),5);
  gl.activeTexture(gl.TEXTURE6);gl.bindTexture(gl.TEXTURE_2D,targets.shadow||null);gl.uniform1i(sourceVoidPhysicalU('uDriveVolumeShadow'),6);
  gl.uniformMatrix4fv(sourceVoidPhysicalU('uDriveVolumeShadowMatrix'),false,targets.shadowMatrix);gl.uniform1f(sourceVoidPhysicalU('uDriveVolumeShadowReady'),targets.shadowReady?1:0);
  gl.uniform1f(sourceVoidPhysicalU('uVoidDawn'),sourceVoidDawn);
  gl.uniform4f(sourceVoidPhysicalU('uUnravelling'),unravelling?.amount||0,unravelling?.street||0,unravelling?.loss||0,unravelling?.active?1:0);
  gl.uniform3fv(sourceVoidPhysicalU('uUnravelOrigin'),[0,0,0]);
  const beacon=sourceVoidBeacon,beaconRange=Math.max(1,Number(beacon?.distanceM)||1);
  gl.uniform4f(sourceVoidPhysicalU('uBeacon'),
    beacon?beacon.bearing:0,
    beacon?Math.atan2(Number(beacon.halfWidthM)||0,beaconRange):0,
    beacon?Math.atan2(Number(beacon.heightM)||0,beaconRange):0,
    beacon&&!unravelling?.active?Math.max(0,Math.min(1,Number(beacon.strength)||0)):0);
  gl.uniform1f(sourceVoidPhysicalU('uEntryMetres'),entryMetres);
  gl.uniform1f(sourceVoidPhysicalU('uYaw'),worldYaw);
  gl.uniform4f(sourceVoidPhysicalU('uTorch'),voidTorch,torchConeInner,torchConeOuter,torchReach);
  gl.uniform3fv(sourceVoidPhysicalU('uTorchColor'),torchColor);
  gl.uniform1f(sourceVoidPhysicalU('uRain'),towerInside?0:sourceVoidRain);
  // Rain uses the historical world-cell lattice. The bus's rendered origin
  // and the recording rebase enter that lattice once, without drying the view
  // beyond its windows or adding a camera-attached weather mask.
  const busRain=outskirtsBusRainUniforms({centreXCells:(sourceRainShelter?.x||0)/CELL,
    centreZCells:(sourceRainShelter?.z||0)/CELL,baseYCells:(sourceRainShelter?.y||0)/CELL,
    yaw:sourceRainShelter?.yaw||0,enabled:!!sourceRainShelter,
    patternOriginOffsetMetres:{x:patternOriginOffsetMetres[0],z:patternOriginOffsetMetres[2]}});
  gl.uniform4fv(sourceVoidPhysicalU('uBusRainRoof'),busRain.uBusRainRoof);
  gl.uniform4fv(sourceVoidPhysicalU('uBusRainFrame'),busRain.uBusRainFrame);
  gl.uniform1f(sourceVoidPhysicalU('uRainBack'),sourceVoidRainRate<0?1:0);
  gl.uniform1f(sourceVoidPhysicalU('uTime'),now);
  gl.uniform1f(sourceVoidPhysicalU('uReduceMotionOptical'),pixelMeshSettings.reduceMotion?1:0);
  gl.uniform1f(sourceVoidPhysicalU('uOpticalEffects'),visualEffectsEnabled()?1:0);
  gl.uniform1f(sourceVoidPhysicalU('uFlash'),flash);
  gl.uniform1f(sourceVoidPhysicalU('uOvercast'),towerInside?0:sourceVoidRain);
  gl.uniform3f(sourceVoidPhysicalU('uEyeCells'),camX,camY,camZ);
  gl.uniform3fv(sourceVoidPhysicalU('uWorldPatternOffset'),patternOriginOffsetMetres);
  const doorA=new Float32Array(12),doorB=new Float32Array(12),doorC=new Float32Array(12);
  sourceDoorLights.forEach((door,k)=>{
    doorA.set([door.x,door.z,door.forward[0],door.forward[1]],k*4);
    doorB.set([door.colour[0],door.colour[1],door.colour[2],Math.max(0,Number(door.strength)||0)],k*4);
    doorC.set([Math.max(.3,Number(door.width)||1),door.open?1:0,door.pool?1:0,0],k*4);
  });
  gl.uniform4fv(sourceVoidPhysicalU('uDoorA'),doorA);
  gl.uniform4fv(sourceVoidPhysicalU('uDoorB'),doorB);
  gl.uniform4fv(sourceVoidPhysicalU('uDoorC'),doorC);
  gl.uniform3f(sourceVoidPhysicalU('uEyeGround'),eyeX,eyeZ,Math.max(.2,eyeY-(Number.isFinite(leak?.y)?leak.y:eyeY-1.6)));
  const reflection=reflecting?P3.reflectionTargets():null,puddle=sourceReflection?.puddle||[0,0,0];
  gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,reflection?.ready?reflection.color:null);
  gl.uniform1i(sourceVoidPhysicalU('uReflection'),2);
  gl.activeTexture(gl.TEXTURE3);gl.bindTexture(gl.TEXTURE_2D,targets.openingMask);
  gl.uniform1i(sourceVoidPhysicalU('uOpeningMask'),3);
  gl.activeTexture(gl.TEXTURE4);gl.bindTexture(gl.TEXTURE_2D,targets.worldData);gl.uniform1i(sourceVoidPhysicalU('uPropMarks'),4);
  gl.uniform1f(sourceVoidPhysicalU('uOpeningMaskReady'),targets.openingMaskReady?1:0);
  gl.uniform4f(sourceVoidPhysicalU('uReflectEye'),eyeX,eyeZ,Math.max(.05,eyeY-(sourceReflection?.groundY??eyeY)),reflection?.ready?1:0);
  gl.uniform4f(sourceVoidPhysicalU('uPuddle'),puddle[0],puddle[1],puddle[2],sourceReflection?.wet??0);
  gl.uniform1f(sourceVoidPhysicalU('uReflectDebug'),sourceReflectionDebug?1:0);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);gl.drawArrays(gl.TRIANGLES,0,3);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);
  if(driveLandOn&&drive.farLights?.count)drawDriveFarLights(drive.farLights,{eye:[eyeX,eyeY,eyeZ],yaw:worldYaw,pitch,depth:targets.depth});
  // Walking through an open door: its world, over everything, for a few seconds.
  sourceCrossingDrawn=false;
  let physicalAcquisitionWeight=1;
  if(sourceCrossing&&P3.renderSourceCrossing){
    const realm=sourceCrossing.realm||null;
    const f=sourceCrossing.forward||[0,1],length=Math.hypot(f[0],f[1])||1,fx=f[0]/length,fz=f[1]/length;
    const cx=Math.sin(worldYaw),cz=-Math.cos(worldYaw);
    const reveal=crossingReveal;
    physicalAcquisitionWeight=1-Math.max(0,Math.min(1,Number(reveal)||0));
    sourceCrossingDrawn=P3.renderSourceCrossing({
      framebuffer:sceneFbo,width:uniforms.sceneW,height:uniforms.sceneH,
      dir:realm?[Math.sin(realm.pose.yaw),Math.cos(realm.pose.yaw)]:[cx*-fz+cz*fx,cx*fx+cz*fz],pitch:realm?realm.pose.pitch:pitch,reveal,
      variant:sourceCrossing.variant,seed:sourceCrossing.seed,key:sourceCrossing.key,
      // A door shut behind him: the way out stands in the world.
      wayOut:sourceCrossing.wayOut?1:0,
      // A crossing may carry its own distance walked (the way home); otherwise it drifts with time.
      drift:Number.isFinite(Number(sourceCrossing.drift))?Number(sourceCrossing.drift):(Number(sourceCrossing.elapsed)||0)*.6,reducedMotion:pixelMeshSettings.reduceMotion,timeSec:Number.isFinite(realm?.time)?realm.time:now,stormFlash:flash,
      realm,realmId:sourceCrossing.id,frameTimeSec:now,homePresentation:sourceCrossing.homePresentation||null,torchPower,
    });
  }
  // In the phone box, the drawn set in place of the scene.
  if(!sourceCrossing?.realm)drawTableau();
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  // THE GAME'S OWN LOOK, OUT HERE TOO. This used to copy its colour straight to
  // the screen, and out past the grey doors the game stopped looking like itself
  // — bare PBR in a void. It goes through the pixel mesh and the post upscale
  // now, like the building. The text field's transition history is separate.
  // The opening carries the same world-anchored hole into its physical drive.
  // Acquire its lens here too, before quantization; the room-memory path alone
  // cannot serve a camera that never leaves this physical renderer.
  if(present){runSourceRestHorizonPass();presentThroughPost(runPixelMeshPass(voidState,now,{physicalAcquisitionWeight}),{torchPower,sourceTorchMode});}
  lastPostSourceFbo=sceneFbo;
}

function drawTextSpace(texture,now,{torchPower=0,sourceTorchMode=0,torchColor,torchReach,torchConeInner,torchConeOuter,torchSpill,torchShoulder,torchYawOffset=0,worldState=null,lampFrame=null}={}) {
  if(sourceLook.roomMemoryActive){
    drawSourceRoomMemory(now,{torchPower,sourceTorchMode,torchColor,torchReach,
      torchConeInner,torchConeOuter,torchSpill,torchShoulder,torchYawOffset,worldState,lampFrame});
    return;
  }
  gl.useProgram(progTextSpace);
  gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFbo);
  // The scene framebuffer normally carries both colour and the architectural
  // mark field. Text Space has no mark output: leaving attachment 1 active
  // makes drawArrays INVALID_OPERATION on conforming WebGL2 drivers, so the
  // compositor writes nothing and the last black frame remains on screen.
  // Narrow this one draw to colour, then restore the raymarcher's two targets.
  gl.drawBuffers([gl.COLOR_ATTACHMENT0]);
  gl.viewport(0, 0, uniforms.sceneW, uniforms.sceneH);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.uniform1i(textSpaceU('uText'), 0);
  const openingTargets=P3.propTargets();
  gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,openingTargets.openingMask);
  gl.uniform1i(textSpaceU('uOpeningMask'),2);
  gl.uniform1f(textSpaceU('uOpeningMaskReady'),openingTargets.openingMaskReady?1:0);
  gl.uniform2f(textSpaceU('uRes'), uniforms.sceneW, uniforms.sceneH);
  gl.uniform1f(textSpaceU('uSunrise'), Math.max(0, Math.min(1, Number(sourceLook.sunrise) || 0)));
  gl.uniform1f(textSpaceU('uSourceChroma'), Math.max(0, Math.min(1, Number(sourceLook.chroma) || 0)));
  gl.uniform1f(textSpaceU('uPaper'), Math.max(0, Math.min(1, Number(sourceLook.paper) || 0)));
  gl.uniform1f(textSpaceU('uTime'),now);
  gl.uniform1f(textSpaceU('uNightSeed'),nightSeed);
  gl.uniform1f(textSpaceU('uRain'),Math.max(0,Math.min(1,Number(sourceWeather.rain)||indoorRain||0)));
  gl.uniform1f(textSpaceU('uLeaves'),Math.max(0,Math.min(1,Number(sourceWeather.leaves)||0)));
  gl.uniform1f(textSpaceU('uReducedMotion'),pixelMeshSettings.reduceMotion?1:0);
  gl.uniform1f(textSpaceU('uSourceEmergency'),sourceEmergencyStrength);
  gl.uniform1f(textSpaceU('uSourceWhiteout'),sourceWhiteoutStrength);
  gl.uniform1f(textSpaceU('uSourceTorchMode'),sourceTorchMode);
  gl.uniform1f(textSpaceU('uSourceTorchPower'),torchPower);
  gl.uniform2f(textSpaceU('uView'),yaw+planYaw,pitch);
  gl.uniform2f(textSpaceU('uMoonCloud'),Math.max(0,Math.min(1,Number(sourceWeather.moon)||0)),Math.max(0,Math.min(1,Number(sourceWeather.clouds)||0)));
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  // The legacy text field retains its authored presentation. Physical Pressure
  // still uses the shared recording shader, then only its depth-tested mesh
  // footprint and finite halo are merged back into the untouched text field.
  const pressure=P3.pressureTargets();
  const acquired=pressure.ready&&pressure.draws>0?runPixelMeshPass(worldState,now):null;
  pixelMeshStatus.enabled = !!acquired;
  const recorded=acquired?finishPressure(sceneTex,{acquired}):sceneTex;
  const resolved=runDatamoshPass(recorded,now);
  if(SHORE.sourceShoreBoundaryVisible(sourceShoreState)){
    SHORE.sourceShoreDraw({frame:sourceShoreState,camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,
      yaw:yaw+planYaw,pitch,width:uniforms.sceneW,height:uniforms.sceneH,boundaryOnly:true,
      torch:{power:torchPower,color:torchColor,reach:torchReach,coneInner:torchConeInner,
        coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder,yawOffset:torchYawOffset,lampFrame}});
    const boundary=SHORE.sourceShoreComposite({props:P3.propTargets(),encoded:resolved,boundaryOnly:true});
    presentTexture(boundary&&acquired?finishPressure(boundary,{acquired}):boundary||resolved);
  }else presentTexture(resolved);
  lastPostSourceFbo = sceneFbo;
}

function sourceRoomU(name){
  if(!sourceRoomUniformCache.has(name))sourceRoomUniformCache.set(name,gl.getUniformLocation(progSourceRoomAcquisition,name));
  return sourceRoomUniformCache.get(name);
}
function sourceIdentityU(name){
  if(!sourceIdentityUniformCache.has(name))sourceIdentityUniformCache.set(name,gl.getUniformLocation(progSourceIdentity,name));
  return sourceIdentityUniformCache.get(name);
}
function drawSourceIdentity(now){
  const targets=P3.propTargets();
  const width=presentTarget?.width||canvas.width,height=presentTarget?.height||canvas.height;
  gl.useProgram(progSourceIdentity);
  gl.bindFramebuffer(gl.FRAMEBUFFER,presentTarget?.fbo||null);
  gl.viewport(0,0,width,height);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,targets.openingMask);
  gl.uniform1i(sourceIdentityU('uOpeningMask'),0);
  gl.uniform1f(sourceIdentityU('uOpeningMaskReady'),targets.openingMaskReady?1:0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,P3.pressureTargets().color||targets.color);
  gl.uniform1i(sourceIdentityU('uHushBodyTex'),1);
  gl.uniform2f(sourceIdentityU('uRes'),width,height);
  gl.uniform1f(sourceIdentityU('uPressureReady'),hushBodyReady&&P3.pressureTargets().draws>0?1:0);
  gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,targets.depth);
  gl.uniform1i(sourceIdentityU('uPropDepth'),2);gl.uniform2f(sourceIdentityU('uNearFar'),targets.near,targets.far);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  gl.drawArrays(gl.TRIANGLES,0,3);
  gl.disable(gl.BLEND);
}
function drawSourceRoomMemory(now,{torchPower=0,sourceTorchMode=0,torchColor,torchReach,
  torchConeInner,torchConeOuter,torchSpill,torchShoulder,torchYawOffset=0,worldState=null,lampFrame=null}={}){
  pressureSceneDepthReady=true;
  const targets=P3.propTargets();
  // The finite first-lift bank remains behind the player after entering the
  // field. Resolve its real long-range hull depth before recording, rather
  // than letting the new text path erase the physical boundary on return.
  let hull=null;
  if(SHORE.sourceShoreBoundaryVisible(sourceShoreState)){
    SHORE.sourceShoreDraw({frame:sourceShoreState,camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,
      yaw:yaw+planYaw,pitch,width:uniforms.sceneW,height:uniforms.sceneH,boundaryOnly:true,
      recordingExposure:captureExposureOverride??lightingCaptureExposure,
      torch:{power:torchPower,color:torchColor,reach:torchReach,coneInner:torchConeInner,
        coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder,yawOffset:torchYawOffset,lampFrame}});
    hull=SHORE.sourceShoreTargets?.();
  }
  gl.useProgram(progSourceRoomAcquisition);
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(null);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,targets.color);
  gl.uniform1i(sourceRoomU('uProps'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,targets.depth);
  gl.uniform1i(sourceRoomU('uPropDepth'),1);
  gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,targets.marks||targets.color);
  gl.uniform1i(sourceRoomU('uPropMarks'),2);
  gl.uniform1f(sourceRoomU('uMarksReady'),targets.marksReady&&targets.marks?1:0);
  gl.uniform1f(sourceRoomU('uBlueprint'),sourceLook.blueprint===true&&sourceBlueprintEnabled()?1:0);
  gl.uniform2f(sourceRoomU('uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.uniform2f(sourceRoomU('uNearFar'),targets.near,targets.far);
  gl.activeTexture(gl.TEXTURE3);gl.bindTexture(gl.TEXTURE_2D,hull?.color||targets.color);
  gl.uniform1i(sourceRoomU('uHull'),3);
  gl.activeTexture(gl.TEXTURE4);gl.bindTexture(gl.TEXTURE_2D,hull?.depth||targets.depth);
  gl.uniform1i(sourceRoomU('uHullDepth'),4);
  gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,hull?.marks||targets.marks);gl.uniform1i(sourceRoomU('uHullMarks'),5);
  gl.uniform1f(sourceRoomU('uHullReady'),hull?.ready?1:0);
  gl.uniform2f(sourceRoomU('uHullNearFar'),hull?.near||targets.near,hull?.far||targets.far);
  gl.uniform2f(sourceRoomU('uRestSky'),Math.max(0,Math.min(1,Number(sourceWeather.horizon)||0)),pixelMeshSettings.reduceMotion?0:Math.max(0,Number(sourceWeather.clock)||0));
  gl.uniform2f(sourceRoomU('uRestView'),yaw+planYaw,pitch);
  const sunset=sourceWeather.sunset;
  gl.uniform4f(sourceRoomU('uRestSunset'),sunset?.amount||0,sunset?.bearing||0,sunset?.altitude||0,sunset?.storm||0);
  gl.uniform2f(sourceRoomU('uRestClouds'),Math.max(0,Math.min(1,Number(sourceWeather.clouds)||0)),Math.max(0,Math.min(1,Number(sourceWeather.moon)||0)));
  const coastal=coastalWaterUniforms(worldState?.coastalMemory);
  gl.uniformMatrix4fv(sourceRoomU('uCoastInverse'),false,coastal.inverse);
  gl.uniform4fv(sourceRoomU('uCoastSea'),coastal.params);gl.uniform2fv(sourceRoomU('uCoastOptics'),coastal.optics);
  gl.uniform4fv(sourceRoomU('uCoastLampPosition[0]'),coastal.positions);gl.uniform4fv(sourceRoomU('uCoastLampDirection[0]'),coastal.directions);
  gl.uniform3f(sourceRoomU('uRestEye'),camX*CELL,camY*CELL,camZ*CELL);
  gl.uniform1f(sourceRoomU('uReduceMotionOptical'),pixelMeshSettings.reduceMotion?1:0);
  gl.drawArrays(gl.TRIANGLES,0,3);
  // The prop pass supplies object faults to the shared recording acquisition.
  runSourceRestHorizonPass();
  const encoded=runPixelMeshPass({...worldState,hushBodyAllowed:false},now);
  const resolved=runDatamoshPass(encoded,now);
  presentThroughPost(resolved,{torchPower,sourceTorchMode});
  drawSourceCodeScreen(now,{boundaryOnly:true});
  drawSourceIdentity(now);
}

function drawSourceCodeScreen(now,{boundaryOnly=false,worldYaw=yaw+planYaw}={}){
  const target={fbo:presentTarget?.fbo||null,width:presentTarget?.width||canvas.width,height:presentTarget?.height||canvas.height},
    eye=[camX*CELL,camY*CELL,camZ*CELL];
  return P3.renderSourceCodeScreen?.({target,sceneDepth:sceneTex,pressure:P3.pressureTargets(),
    camera:{eye,yaw:worldYaw,pitch},faculties:sourceRestFaculties,
    drawAdditionalCode:typeof SHORE.sourceShoreCodeDraw==='function'?context=>SHORE.sourceShoreCodeDraw({...context,
      frame:sourceShoreState,camX:eye[0],camY:eye[1],camZ:eye[2],yaw:worldYaw,pitch,boundaryOnly}):null});
}

const DATAMOSH_FRAG=`#version 300 es
precision highp float;
uniform sampler2D uSource;
uniform sampler2D uTower;
uniform sampler2D uPrevious;
uniform vec2 uResolution;
uniform float uProgress;
uniform float uTime;
uniform float uReducedMotion;
uniform float uSourceEmergency;
uniform float uSourceWhiteout;
out vec4 outColor;
float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
void main(){
  vec2 uv=gl_FragCoord.xy/uResolution;
  vec2 blockId=floor(uv*vec2(40.0,23.0));
  float seed=hash(blockId+floor(uProgress*36.0));
  vec2 motion=vec2(hash(blockId+11.0)-.5,hash(blockId+29.0)-.5);
  motion*=mix(.002,.045,uProgress)*(1.0-uReducedMotion);
  motion.x+=sin(uTime*1.7+blockId.y)*.006*uProgress*(1.0-uReducedMotion);
  vec3 source=texture(uSource,uv+motion*.25).rgb;
  vec3 tower=texture(uTower,uv-motion).rgb;
  vec3 previous=texture(uPrevious,uv-motion*.7).rgb;
  float sourceLuma=dot(source,vec3(.2126,.7152,.0722));
  float towerLuma=dot(tower,vec3(.2126,.7152,.0722));
  // Blocks break on picture energy as well as time. Bright Source structure
  // tears through first while the hall's darker macroblocks persist as P-frame
  // residue, so this reads as a damaged physical transition rather than a wipe.
  float lumaBreak=(towerLuma-sourceLuma)*.22*(1.0-uReducedMotion);
  float reveal=smoothstep(seed-.12,seed+.12,uProgress+lumaBreak);
  vec3 current=mix(source,tower,reveal);
  float retention=(1.0-uReducedMotion)*mix(.15,.78,uProgress)*step(.18,seed);
  vec3 carried=mix(current,previous,retention);
  float chroma=.009*uProgress*(1.0-uReducedMotion);
  carried.r=mix(carried.r,texture(uTower,uv+vec2(chroma,0)).r,reveal);
  carried.b=mix(carried.b,texture(uSource,uv-vec2(chroma,0)).b,1.0-reveal);
  carried=mix(carried,vec3(1.0),clamp(uSourceWhiteout,0.0,1.0));
  // This pass can be the final writer for both physical and Text Space Source
  // frames during a threshold. Reassert the circuit here as well, after motion
  // retention, or old non-red P-frames can cover the maintained wash.
  float ePhase=mod(uTime,3.2);
  float ePulse=uReducedMotion>.5?.78:(ePhase<.18?1.0:ePhase<.42?.48:ePhase<.64?.92:ePhase<.92?.56:.46+.04*sin((ePhase-.92)*2.4));
  float eLuma=dot(carried,vec3(.2126,.7152,.0722));
  float eWash=clamp(uSourceEmergency*ePulse*(.78+.22*(1.0-eLuma)),0.0,.94);
  vec3 emergencyRed=vec3(max(.82,carried.r*1.18+.18),carried.g*.025,carried.b*.012);
  carried=mix(carried,emergencyRed,eWash);
  outColor=vec4(carried,1.0);
}`;

export function r3dBeginDatamosh({reducedMotion=false}={}){
  if(!gl||!lastPostSourceFbo||!datamoshSourceFbo)return false;
  gl.bindFramebuffer(gl.READ_FRAMEBUFFER,lastPostSourceFbo);
  gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,datamoshSourceFbo);
  gl.blitFramebuffer(0,0,uniforms.sceneW,uniforms.sceneH,0,0,uniforms.sceneW,uniforms.sceneH,gl.COLOR_BUFFER_BIT,gl.NEAREST);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  datamoshActive=true;datamoshProgress=0;datamoshReducedMotion=!!reducedMotion;datamoshFlip=false;
  return true;
}
export function r3dSetDatamoshProgress(value){datamoshProgress=Math.max(0,Math.min(1,Number(value)||0));return datamoshProgress;}
export function r3dEndDatamosh(){datamoshActive=false;datamoshProgress=0;return true;}
export function r3dDatamoshStatus(){return{active:datamoshActive,progress:datamoshProgress,reducedMotion:datamoshReducedMotion};}

function runDatamoshPass(towerTex,now){
  if(!datamoshActive||!progDatamosh||!datamoshSourceTex)return towerTex;
  const dstFbo=datamoshFlip?datamoshFboA:datamoshFboB,dstTex=datamoshFlip?datamoshTexA:datamoshTexB,previous=datamoshFlip?datamoshTexB:datamoshTexA;datamoshFlip=!datamoshFlip;
  gl.useProgram(progDatamosh);gl.bindFramebuffer(gl.FRAMEBUFFER,dstFbo);gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  const u=(name)=>gl.getUniformLocation(progDatamosh,name);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,datamoshSourceTex);gl.uniform1i(u('uSource'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,towerTex);gl.uniform1i(u('uTower'),1);
  gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,previous||datamoshSourceTex);gl.uniform1i(u('uPrevious'),2);
  gl.uniform2f(u('uResolution'),uniforms.sceneW,uniforms.sceneH);gl.uniform1f(u('uProgress'),datamoshProgress);gl.uniform1f(u('uTime'),now);gl.uniform1f(u('uReducedMotion'),datamoshReducedMotion?1:0);gl.uniform1f(u('uSourceEmergency'),sourceEmergencyStrength);gl.uniform1f(u('uSourceWhiteout'),sourceWhiteoutStrength);
  gl.drawArrays(gl.TRIANGLES,0,3);gl.bindFramebuffer(gl.FRAMEBUFFER,null);return dstTex;
}

// ── the possession burst ────────────────────────────────────────────────────
// The rendered room, handed back to the model and returned a second later as
// something that remembers being a room. It composites BEFORE the pixel mesh,
// so the VFD pass encodes it like everything else and possession stays inside
// the instrument instead of looking like a screenshot of another program.
//
// Latency is the honest problem: the reply describes the frame the player was
// looking at, not the one in front of them. So the mix is damped by camera
// motion — turn your head and the possession recedes; hold still and it takes
// the room. Standing still in a horror game is not a limitation. It is the game.
const BURST_FRAG=`#version 300 es
precision highp float;
uniform sampler2D uScene;
uniform sampler2D uBurst;
uniform vec2 uRes;
uniform float uMix;
uniform float uTime;
out vec4 outColor;
float bayer4(vec2 p){
  int x=int(mod(p.x,4.0)),y=int(mod(p.y,4.0));
  int i=y*4+x;
  float m[16]=float[16](0.,8.,2.,10.,12.,4.,14.,6.,3.,11.,1.,9.,15.,7.,13.,5.);
  return m[i]/16.0;
}
void main(){
  vec2 uv=gl_FragCoord.xy/uRes;
  vec3 scene=texture(uScene,uv).rgb;
  vec3 burst=texture(uBurst,uv).rgb;
  // Ordered dither on the blend: the repaint arrives as a spreading rash of
  // cells rather than a clean dissolve, which reads as the display failing.
  float threshold=bayer4(gl_FragCoord.xy);
  float amount=clamp(uMix*1.35-threshold*0.35,0.0,1.0);
  // Keep the room's own luminance structure underneath. The possession changes
  // what the walls are made of, never where they are.
  float sceneLum=dot(scene,vec3(.2126,.7152,.0722));
  float burstLum=max(.03,dot(burst,vec3(.2126,.7152,.0722)));
  vec3 relit=burst*mix(1.0,sceneLum/burstLum,0.45);
  outColor=vec4(mix(scene,clamp(relit,0.0,1.0),amount),1.0);
}`;
let progBurst=null,burstTex=null,burstFbo=null,burstOutTex=null,burstOutFbo=null;
let burstMix=0,burstTarget=0,burstLastAt=0,burstW=0,burstH=0;
function burstU(name){return gl.getUniformLocation(progBurst,name);}
export function r3dSetBurstFrame(image,{seconds=0}={}){
  if(!gl||!image)return false;
  if(!burstTex||burstW!==image.width||burstH!==image.height){
    if(burstTex)gl.deleteTexture(burstTex);
    burstW=image.width;burstH=image.height;
    burstTex=makeTex(burstW,burstH);
  }
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
  gl.bindTexture(gl.TEXTURE_2D,burstTex);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  burstTarget=1;
  burstLastAt=globalThis.performance?.now?.()||Date.now();
  return true;
}
export function r3dEndBurst(){burstTarget=0;}
export function r3dBurstActive(){return burstMix>0.004;}
function runBurstPass(sceneSource,now){
  const nowMs=(globalThis.performance?.now?.()||Date.now());
  // A reply that never came: fade out rather than hold a stale room forever.
  if(burstTarget>0&&burstLastAt&&nowMs-burstLastAt>2200)burstTarget=0;
  const dt=Math.max(0,Math.min(.25,now-(lastBurstTickAt||now)));
  lastBurstTickAt=now;
  const rate=burstTarget>burstMix?dt/0.30:dt/1.20;   // attack .3s, release 1.2s
  burstMix+=Math.max(-1,Math.min(1,burstTarget-burstMix))*Math.min(1,rate);
  if(burstMix<0.004){burstMix=0;return sceneSource;}
  if(!progBurst||!burstTex||!burstOutFbo)return sceneSource;
  // Camera motion damping: the repaint is always a moment stale, so it only
  // asserts itself while the recordist is holding still.
  const damped=burstMix*(1-Math.min(.8,vfdMovement*1.1));
  if(damped<0.004)return sceneSource;
  gl.useProgram(progBurst);
  gl.bindFramebuffer(gl.FRAMEBUFFER,burstOutFbo);
  gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sceneSource);gl.uniform1i(burstU('uScene'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,burstTex);gl.uniform1i(burstU('uBurst'),1);
  gl.uniform2f(burstU('uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.uniform1f(burstU('uMix'),damped);
  gl.uniform1f(burstU('uTime'),now);
  gl.drawArrays(gl.TRIANGLES,0,3);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  return burstOutTex;
}
let lastBurstTickAt=0;

export function r3dPhysicalAcquisitionExposure({lightingExposure=1,physicalWeight=0,override=null,minimumExposure=3}={}){
  if(override!==null&&override!==undefined)return override;
  const weight=Math.max(0,Math.min(1,Number(physicalWeight)||0));
  return lightingExposure+(Math.max(minimumExposure,lightingExposure)-lightingExposure)*weight;
}

// How the cab the camera rides in is screened: 0 as the world, 1 hatch, 2 contours.
const CABIN_SCREEN=1;
// A rigid vehicle-to-world matrix (column-major) turned the other way round.
function invertRigidMatrix(m){
  const t=[m[12],m[13],m[14]];
  return new Float32Array([m[0],m[4],m[8],0, m[1],m[5],m[9],0, m[2],m[6],m[10],0,
    -(m[0]*t[0]+m[1]*t[1]+m[2]*t[2]),-(m[4]*t[0]+m[5]*t[1]+m[6]*t[2]),-(m[8]*t[0]+m[9]*t[1]+m[10]*t[2]),1]);
}
// Between the rest acquisition and the recording: copy the acquired scene
// and its marks aside, then bend them around the horizon back into the same
// scene targets, with the wheels and shadow. Depth and pigment marks move
// with every pixel, so the unchanged recording inks the lensed image as itself.
function sourceRestHorizonTargets(){
  const w=uniforms.sceneW,h=uniforms.sceneH;
  if(sourceRestHorizonFbo&&sourceRestHorizonTargets.size===w+'x'+h)return true;
  for(const item of [sourceRestHorizonTex,sourceRestHorizonMarkTex])if(item)gl.deleteTexture(item);if(sourceRestHorizonFbo)gl.deleteFramebuffer(sourceRestHorizonFbo);
  sourceRestHorizonTex=makeTex(w,h,null,'rgba16f');sourceRestHorizonMarkTex=makeTex(w,h,null,'rgba8');
  sourceRestHorizonFbo=makeFbo(sourceRestHorizonTex,[sourceRestHorizonMarkTex]);sourceRestHorizonTargets.size=w+'x'+h;return true;
}
function runSourceRestHorizonPass(){
  sourceRestHorizonStatus.drawn=false;
  if(!sourceRestHorizon||!progSourceRestHorizon||!sceneFbo||!sourceRestHorizonTargets())return false;
  const w=uniforms.sceneW,h=uniforms.sceneH;
  gl.bindFramebuffer(gl.READ_FRAMEBUFFER,sceneFbo);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,sourceRestHorizonFbo);
  for(const attachment of [gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]){
    gl.readBuffer(attachment);gl.drawBuffers(attachment===gl.COLOR_ATTACHMENT0?[gl.COLOR_ATTACHMENT0,gl.NONE]:[gl.NONE,gl.COLOR_ATTACHMENT1]);
    gl.blitFramebuffer(0,0,w,h,0,0,w,h,gl.COLOR_BUFFER_BIT,gl.NEAREST);
  }
  gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,null);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,null);
  const U=name=>{if(!sourceRestHorizonUniformCache.has(name))sourceRestHorizonUniformCache.set(name,gl.getUniformLocation(progSourceRestHorizon,name));return sourceRestHorizonUniformCache.get(name);};
  const q=sourceRestHorizonLensUniforms(sourceRestHorizon);
  gl.useProgram(progSourceRestHorizon);gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);gl.viewport(0,0,w,h);
  gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(null);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sourceRestHorizonTex);gl.uniform1i(U('uHorizonScene'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,sourceRestHorizonMarkTex);gl.uniform1i(U('uHorizonMarks'),1);
  gl.uniform2f(U('uHorizonRes'),uniforms.sceneW,uniforms.sceneH);gl.uniform2f(U('uHorizonView'),yaw+planYaw,pitch);
  gl.uniform3f(U('uHorizonEye'),camX*CELL,camY*CELL,camZ*CELL);gl.uniform1f(U('uHorizonTan'),activeCameraTanHalfFov);
  gl.uniform4fv(U('uHorizonCentre'),q.centre);gl.uniform4fv(U('uHorizonSpin'),q.spin);gl.uniform4fv(U('uHorizonParams'),q.params);
  gl.uniform3fv(U('uHorizonRingNormal[0]'),q.normals);gl.uniform4fv(U('uHorizonRing[0]'),q.rings);gl.uniform1fv(U('uHorizonEyeAge[0]'),q.ages);
  gl.uniform2fv(U('uHorizonEyes'),q.eyes);
  gl.drawArrays(gl.TRIANGLES,0,3);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  sourceRestHorizonStatus.drawn=true;return true;
}

function runPixelMeshPass(state, now, { physicalAcquisitionWeight = 0, sourceTexture = sceneTex, occupiedHome = false } = {}) {
  driveMemoryAcquired=false;
  pixelMeshStatus.framesSeen += 1;
  pixelMeshStatus.shaderReady = !!progPixelMesh;
  pixelMeshStatus.supported = !!(gl && progPixelMesh && meshTexA && meshTexB && meshFboA && meshFboB);
  pixelMeshStatus.sceneWidth = uniforms.sceneW || 0;
  pixelMeshStatus.sceneHeight = uniforms.sceneH || 0;

  const forceSignal = Math.max(0, Math.min(1, pixelMeshStatus.forceSignalUntil > now ? 1 : 0));
  const effectiveSettings = pixelMeshSettings;
  const look = currentLook();
  pixelMeshStatus.lastProfile = look.id;
  pixelMeshStatus.enabled = true;

  if (!pixelMeshStatus.supported) {
    if (pixelMeshStatus.enabled) pixelMeshStatus.lastError = pixelMeshStatus.lastError || 'pixel mesh WebGL resources unavailable';
    return sourceTexture;
  }
  const dstFbo = meshFlip ? meshFboA : meshFboB;
  const dstTex = meshFlip ? meshTexA : meshTexB;
  const prevTex = meshFlip ? meshTexB : meshTexA;
  meshFlip = !meshFlip;

  // The physical performer, its overprints and its cold edge enter the same
  // acquisition as everything else. Never paint smooth mesh relief back over
  // the recorded result at presentation time.
  if(occupiedHome)pressureFinishReady=false;
  const pressureSourceTex = occupiedHome?sourceTexture:finishPressure(sourceTexture);
  // The DEV pre-print lens replaces colour only. Keep the original floating
  // view depth for world reconstruction rather than quantising it through the
  // lens's colour target. Ordinary pressure composition keeps its own depth.
  const depthSourceTex = sourceTexture === sceneTex ? pressureSourceTex : sceneTex;
  // The possession composites first so the VFD encodes it as part of the world.
  const worldTex = runBurstPass(pressureSourceTex, now);

  // Other passes may leave a WebGL diagnostic behind. Clear before the pixel
  // pass so __chunkSurferPixelMesh.status() reports this layer, not stale GL.
  //
  // BUT NOT EVERY FRAME. getError is a synchronous round trip to the GPU
  // process: asking it here made the CPU sit out the whole march before it could
  // record the rest of the frame. The audit still runs, on one frame in
  // GL_ERROR_AUDIT_FRAMES, and lastGlError still sticks once it has seen one.
  const auditGl = pixelMeshStatus.framesRendered % GL_ERROR_AUDIT_FRAMES === 0;
  if (auditGl) clearGlErrors();
  gl.useProgram(progPixelMesh);
  gl.uniform4fv(pixelMeshU('uDriveMemoryBreak'),driveMemoryBreak);
  gl.bindFramebuffer(gl.FRAMEBUFFER, dstFbo);
  gl.viewport(0, 0, uniforms.sceneW, uniforms.sceneH);

  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, worldTex);
  gl.uniform1i(pixelMeshU('uSrc'), 0);

  gl.activeTexture(gl.TEXTURE1);
  gl.bindTexture(gl.TEXTURE_2D, prevTex);
  gl.uniform1i(pixelMeshU('uPrev'), 1);

  gl.activeTexture(gl.TEXTURE2);
  gl.bindTexture(gl.TEXTURE_2D, depthSourceTex);
  gl.uniform1i(pixelMeshU('uDepth'), 2);

  // The engraving, in screen space. Unit 3 — this pass uses three samplers
  // against a limit of sixteen, so unlike the raymarch it has room to spare.
  gl.activeTexture(gl.TEXTURE3);
  gl.bindTexture(gl.TEXTURE_2D, markTex);
  gl.uniform1i(pixelMeshU('uMarks'), 3);
  gl.uniform1f(pixelMeshU('uMarkDensityGain'), markDensityGain);
  gl.uniform1f(pixelMeshU('uPrintedSurfaceMode'),printedSurfaceMode);
  gl.uniform1f(pixelMeshU('uMarkGrainGain'), markGrainGain);
  gl.uniform1f(pixelMeshU('uWorldLightTreatment'),worldLightTreatment.level);
  gl.uniform1f(pixelMeshU('uFineMarkPx'),fineMarkFootprint(resolvePixelMeshCellScenePx()));
  // A physical performer carries no wall engraving. The recording shader
  // rejects background material marks only where this mesh wrote view depth.
  const recordedPressure=P3.pressureTargets();
  gl.activeTexture(gl.TEXTURE5);
  gl.bindTexture(gl.TEXTURE_2D,recordedPressure.color||markTex);
  gl.uniform1i(pixelMeshU('uRecordedPressureGeometry'),5);
  gl.uniform1f(pixelMeshU('uRecordedPressureReady'),!occupiedHome&&recordedPressure.ready&&recordedPressure.draws>0?1:0);
  gl.uniform2f(pixelMeshU('uRecordedPressureNearFar'),recordedPressure.near,recordedPressure.far);
  gl.activeTexture(gl.TEXTURE6);gl.bindTexture(gl.TEXTURE_2D,pressureIdentityTex||markTex);
  gl.uniform1i(pixelMeshU('uRecordedPressureInk'),6);
  gl.uniform1f(pixelMeshU('uRecordedPressureInkReady'),pressureFinishReady?1:0);

  // Crosshatch is the common world plate. A deliberate debug/user override
  // remains available; stale room screen suggestions no longer replace it.
  // Only active Source frames receive the additional clustered-dot screen.
  const sourceDitherActive=!!state?.textSpace||!!state?.sourceVoidPhysical;
  const ditherDt=lastPixelMeshAt>0?Math.max(0,Math.min(.25,now-lastPixelMeshAt)):1/60;
  const sourceDitherTarget=targetSourceDither(state,{active:sourceDitherActive,override:screenOverrideId});
  sourceDitherMix=sourceDitherActive?advanceSourceDither(sourceDitherMix,sourceDitherTarget,ditherDt,{
    reducedMotion:!!effectiveSettings.reduceMotion,reducedFlash:!!effectiveSettings.reduceFlash,
  }):0;
  const screen = screenUniforms(screenForWorld(screenOverrideId));
  gl.uniform1i(pixelMeshU('uScreenKind'), screen.kind);
  gl.uniform1f(pixelMeshU('uClusteredDotMix'), sourceDitherMix);
  gl.uniform1f(pixelMeshU('uScreenPeriodPx'), screen.periodPx);
  gl.uniform3f(pixelMeshU('uScreenAngles'), screen.angles[0], screen.angles[1], screen.angles[2]);
  gl.uniform2f(pixelMeshU('uScreenBands'), screen.bands[0], screen.bands[1]);
  gl.uniform1f(pixelMeshU('uScreenSharpness'), screen.sharpness);
  gl.uniform1f(pixelMeshU('uScreenGrainFollow'), screen.grainFollow);
  gl.uniform1f(pixelMeshU('uScreenJitter'), screen.jitter);

  // The blue-noise threshold mask, on unit 4. NEAREST and REPEAT: it is a rank
  // table, not an image — interpolating between two ranks invents a threshold
  // that belongs to neither cell and reintroduces structure.
  gl.activeTexture(gl.TEXTURE4);
  gl.bindTexture(gl.TEXTURE_2D, ensureBlueNoise(gl));
  gl.uniform1i(pixelMeshU('uNoise'), 4);
  gl.uniform2f(pixelMeshU('uNoiseSize'), BLUE_NOISE_SIZE, BLUE_NOISE_SIZE);
  // The profile says how this LOOK reads; the zone says how much light this ROOM
  // has to read by. BOTH ENDS have to move together: scaling only the white point
  // was the first version of this and it changed nothing, because the black point
  // is the end the interiors actually fail. Measured raw, in byte terms against a
  // black point at 1.3: the loading bay's walls sit at 51 with 0.2% underneath it,
  // and the get-in's at 1.3 with 63% underneath — six times below the floor at the
  // median. Nothing downstream of that can draw a mark.
  // The strike pulls the ceiling down as it raises the floor of light, so the
  // dither runs out of headroom and the frame solidifies.
  const scale = (whitePointScaleOverride ?? lightingWhitePointScale) / (1 + stormFlash * 3.6);
  const blend = (authored, zoned) => zoned + (authored - zoned) * (1 - whitePointZoneAmount);
  const authoredWhite = look.vfd.whitePoint ?? 1.0;
  const authoredBlack = look.vfd.blackPoint ?? 0.0;
  const black = blend(authoredBlack, authoredBlack * scale);
  gl.uniform1f(pixelMeshU('uBlackPoint'), black);
  // Floored clear of the black point so a scale can never invert the curve.
  gl.uniform1f(pixelMeshU('uWhitePoint'),
    Math.max(black + 0.002, blend(authoredWhite, authoredWhite * scale)));
  gl.uniform1f(pixelMeshU('uToneGamma'), look.vfd.toneGamma ?? 1.0);
  // THE FRONT-END PLATE. Neutral in the room; a negative behind the menu. See
  // FRONT_END_GRADE in look-profiles.js for where the numbers come from.
  {
    // The front-end plate decides this, so every boundary main.js already
    // switches at -- credits, title, gameplay, and the per-frame session
    // snapshot -- carries the grade with it and there is no second switch to
    // keep in step. `negative` also crossfades, so a plate interpolated between
    // two scenes grades partway rather than snapping.
    const n = frontEndPlate.negative * (1 - frontEndPlate.print);
    const g = n > 0 ? FRONT_END_GRADE : NEUTRAL_GRADE;
    gl.uniform4f(pixelMeshU('uGrade'), g.invert * n, g.gamma, g.gain, g.soften * n);
    gl.uniform2f(pixelMeshU('uGradePlate'), g.plateBlack ?? 0, g.plateWhite ?? 1);
  }
  gl.uniform1f(pixelMeshU('uLineAmount'), look.vfd.lineAmount ?? 0.0);
  gl.uniform1f(pixelMeshU('uToneAmount'), look.vfd.toneAmount ?? 0.0);

  gl.uniform2f(pixelMeshU('uRes'), uniforms.sceneW, uniforms.sceneH);
  const homeAcquisition=sourceCrossingDrawn&&sourceVoidPhysicalActive?homeRealmAcquisition({
    realm:sourceCrossing?.realm,variant:sourceCrossing?.variant,
    reveal:pixelMeshSettings.reduceMotion?(sourceCrossing?.reveal>.5?1:0):sourceCrossing?.reveal,
  }):null;
  gl.uniform1f(pixelMeshU('uHomeEngraving'),homeAcquisition&&!screenOverrideId?1:0);
  const acquisitionCamera=homeAcquisition?.cameraMetres;
  const recordingOffset=state?.recordingOriginOffset;
  const recordingShift=axis=>Number.isFinite(recordingOffset?.[axis])?recordingOffset[axis]/CELL:0;
  gl.uniform3f(pixelMeshU('uCam'), acquisitionCamera?acquisitionCamera[0]/CELL:camX+recordingShift('x'),
    acquisitionCamera?acquisitionCamera[1]/CELL:camY+recordingShift('y'),acquisitionCamera?acquisitionCamera[2]/CELL:camZ+recordingShift('z'));
  // World bearing, not the logical one. This uniform drives the VFD temporal
  // reprojection: if the scene pass rotates on the spiral and this does not, the
  // whole climb smears.
  gl.uniform1f(pixelMeshU('uYaw'), homeAcquisition?.yaw??yaw + planYaw);
  gl.uniform1f(pixelMeshU('uCameraTanHalfFov'),activeCameraTanHalfFov);
  gl.uniform4fv(pixelMeshU('uNatatoriumMetric'),natatoriumMetricUniform(natatoriumMetric));
  // The van the camera rides in. Only while the eye is inside its box: a van
  // seen from the yard is part of the world and keeps the world's marks.
  const cabin=P3.cabinVolume(),worldToVan=cabin?invertRigidMatrix(cabin.matrix):null;
  const eyeVan=worldToVan&&[0,1,2].map(r=>worldToVan[r]*camX*CELL+worldToVan[4+r]*camY*CELL+worldToVan[8+r]*camZ*CELL+worldToVan[12+r]);
  const riding=!!eyeVan&&eyeVan.every((v,i)=>v>cabin.min[i]&&v<cabin.max[i]);
  rainClearMetres=riding?RAIN_CLEAR_OF_THE_CAB:0;
  gl.uniform1f(pixelMeshU('uVehicleActive'),riding?1:0);
  if(riding){
    gl.uniformMatrix4fv(pixelMeshU('uWorldToVehicle'),false,worldToVan);
    gl.uniform3fv(pixelMeshU('uVehicleBoxMin'),cabin.min);gl.uniform3fv(pixelMeshU('uVehicleBoxMax'),cabin.max);
  }
  gl.uniform1f(pixelMeshU('uCabinScreen'),CABIN_SCREEN);
  gl.uniform1f(pixelMeshU('uPitch'), homeAcquisition?.pitch??pitch);
  gl.uniform1f(pixelMeshU('uCellMeters'), CELL);
  gl.uniform1f(pixelMeshU('uTime'), now);
  const dt = lastPixelMeshAt > 0 ? Math.max(0, Math.min(0.25, now - lastPixelMeshAt)) : 1 / 60;
  lastPixelMeshAt = now;
  gl.uniform1f(pixelMeshU('uDt'), dt);
  // Owned by the seated Source-rest acquisition, before the final dither.
  // No second frame buffer or independently timed fault pass is involved.
  const faculty=sourceRestFacultyUniforms(sourceRestFaculties);
  gl.uniform4fv(pixelMeshU('uSourceRestFaculties'),faculty.uSourceRestFaculties);
  gl.uniform4fv(pixelMeshU('uSourceRestFacultyState'),faculty.uSourceRestFacultyState);
  gl.uniform1f(pixelMeshU('uCellPx'), resolvePixelMeshCellScenePx());
  gl.uniform1f(pixelMeshU('uBaseRetention'), look.vfd.baseRetention);
  gl.uniform1f(pixelMeshU('uPaletteAmount'), look.vfd.paletteAmount);
  gl.uniform1f(pixelMeshU('uSignalAmount'), forceSignal > 0 ? Math.max(look.vfd.signalGain, 1.15) : look.vfd.signalGain);
  gl.uniform1f(pixelMeshU('uEdgeGain'),state?.driveStudy?.active===true ? .65 : memorySky ? look.vfd.edgeGain*memorySky.edge : look.vfd.edgeGain);
  gl.uniform1f(pixelMeshU('uCoverage'), look.vfd.coverage);
  gl.uniform1f(pixelMeshU('uGlowAmount'), forceSignal > 0 ? Math.max(look.vfd.glow, 0.48) : look.vfd.glow);
  gl.uniform1f(pixelMeshU('uPersistenceMs'), effectiveSettings.memory ? look.vfd.persistenceMs : 16);
  gl.uniform1f(pixelMeshU('uAperture'), look.vfd.aperture);
  gl.uniform1f(pixelMeshU('uAmberAmount'), look.vfd.amber);
  gl.uniform1f(pixelMeshU('uAudio'), Math.max(0, Math.min(1, Number(state?.audio) || 0)));
  gl.uniform1f(pixelMeshU('uFear'), fearLevel);
  gl.uniform1f(pixelMeshU('uReduceFlash'), effectiveSettings.reduceFlash ? 1 : 0);
  gl.uniform1f(pixelMeshU('uReduceMotion'), effectiveSettings.reduceMotion ? 1 : 0);
  // Read the same current-eye anatomical grips as the near-face props. Other
  // scene owners and reduced-motion output always receive literal zero.
  const facePull=state?.recordingEmbodiment?.active&&!effectiveSettings.reduceMotion&&recordingViewPullEnabled?recordingViewPull:null,
    gripLeft=facePull?.left,gripRight=facePull?.right;
  gl.uniform4f(pixelMeshU('uRecordingGripLeft'),gripLeft?.anchor[0]||0,gripLeft?.anchor[1]||0,gripLeft?.strength||0,0);
  gl.uniform4f(pixelMeshU('uRecordingGripRight'),gripRight?.anchor[0]||0,gripRight?.anchor[1]||0,gripRight?.strength||0,0);
  gl.uniform4f(pixelMeshU('uRecordingPullDirections'),gripLeft?.pull[0]||0,gripLeft?.pull[1]||0,gripRight?.pull[0]||0,gripRight?.pull[1]||0);
  gl.uniform1f(pixelMeshU('uRecordingViewPull'),facePull?.active?facePull.strength:0);
  gl.uniform1f(pixelMeshU('uRecordingCaptureMix'), look.recording.captureMix);
  gl.uniform1f(pixelMeshU('uRoofSkyRecovery'), lightingRoofSkyRecovery);
  // The march writes this exact far-plane depth when a ray reaches the sky.
  // A nearer prop replaces its depth before acquisition, including Ren.
  const roofPropFar=P3.propTargets().far;
  gl.uniform1f(pixelMeshU('uRoofSkyPackedFar'), 1 / (1 + roofPropFar * .14));
  // This set now supplies linear light rather than its former display RGB.
  // Calibrate its night capture explicitly; crossing rooms and the horizon
  // retain their own acquisition, and review overrides keep priority.
  const captureExposure=r3dPhysicalAcquisitionExposure({lightingExposure:lightingCaptureExposure,
    physicalWeight:physicalAcquisitionWeight,override:captureExposureOverride,
    minimumExposure:state?.coastalMemory?.active&&!state?.driveStudy?.active?1:3});
  pixelMeshStatus.captureExposure=captureExposure;
  pixelMeshStatus.physicalAcquisition=physicalAcquisitionWeight>0;
  pixelMeshStatus.physicalAcquisitionWeight=physicalAcquisitionWeight;
  gl.uniform1f(pixelMeshU('uRecordingExposure'), captureExposure);
  gl.uniform1f(pixelMeshU('uRecordingSensitivity'), textSpaceActive&&sourceLook.roomMemoryActive?captureExposure:1);
  const blueprintRecording=textSpaceActive&&sourceLook.roomMemoryActive&&sourceLook.blueprint===true&&sourceBlueprintEnabled();
  gl.uniform2f(pixelMeshU('uSourceBlueprint'),blueprintRecording?1:0,1/(1+(P3.propTargets().far||90)*.14));
  gl.uniform1f(pixelMeshU('uSourceFinish'),blueprintRecording?normalizeSourceFinish(sourceLook.finish):0);
  // The one exception to Source only: a horizon that names its own stock, which only
  // the prologue's does. Spectral ink needs the wheels' pigment tag, so the ordinary
  // building under it prints as itself.
  if(!blueprintRecording&&sourceRestHorizon?.finish)gl.uniform1f(pixelMeshU('uSourceFinish'),normalizeSourceFinish(sourceRestHorizon.finish));
  const floodInk=textSpaceActive&&sourceLook.roomMemoryActive&&state?.coastalMemory?.active?state.coastalMemory:null;
  gl.uniform1f(pixelMeshU('uSourceSunsetInk'),textSpaceActive&&sourceLook.roomMemoryActive?(sourceWeather.sunset?.amount||0):0);
  gl.uniform4f(pixelMeshU('uSourceWaterInk'),floodInk?1:0,
    floodInk?(Number(floodInk.waterY)||0)+(Number(floodInk.siteMatrix?.[13])||0):0,
    floodInk?Math.max(.05,Math.min(1,Number(floodInk.waterOptics?.absorptionScale)||.35)):.35,0);
  gl.uniform1f(pixelMeshU('uRecordingPatternScale'), state?.driveStudy?.active===true ? 480 : look.recording.patternScale);
  gl.uniform1f(pixelMeshU('uRecordingBlackFloor'), look.recording.blackFloor);
  gl.uniform1f(pixelMeshU('uRecordingDensityGamma'), look.recording.densityGamma);
  gl.uniform1f(pixelMeshU('uRecordingThresholdNoise'), look.recording.thresholdNoise);
  gl.uniform1f(pixelMeshU('uRecordingIrregularity'), look.recording.thresholdIrregularity);
  gl.uniform1f(pixelMeshU('uRecordingTemporalHz'), look.recording.temporalHz);
  gl.uniform1f(pixelMeshU('uRecordingTemporalSmear'), look.recording.temporalSmear);
  gl.uniform1f(pixelMeshU('uRecordingScenePinning'), look.recording.scenePinning);
  gl.uniform1f(pixelMeshU('uRecordingFearGain'), look.recording.fearGain);
  gl.uniform1f(pixelMeshU('uRecordingAudioGain'), look.recording.audioGain);
  gl.uniform1f(pixelMeshU('uDebugSource'), debugSourceToNumber(effectiveSettings.debugSource));
  gl.uniform1f(pixelMeshU('uForceSignal'), forceSignal);
  gl.uniform1f(pixelMeshU('uMovement'), vfdMovement);
  gl.uniform1f(pixelMeshU('uPaletteChroma'), look.vfd.paletteChroma ?? 0);
  gl.uniform1f(pixelMeshU('uShadowLift'), look.vfd.shadowLift ?? 0);
  gl.uniform1f(pixelMeshU('uAgitation'), dreamAgitation);
  // Real geometry was acquired above; retire bitmap chroma-key reconstruction.
  gl.uniform4f(pixelMeshU('uHushBodyPost'),0,0,0,0);

  gl.drawArrays(gl.TRIANGLES, 0, 3);
  driveMemoryAcquired=true;
  pixelMeshStatus.framesRendered += 1;
  pixelMeshStatus.lastError = null;
  if (auditGl) reportGlError('pixel mesh pass');
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  lastPostSourceFbo=dstFbo;
  return dstTex;
}
function loadImageTexture(url){
  return new Promise((resolve,reject)=>{
    const img=new Image();img.onload=()=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.SRGB8_ALPHA8,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);resolve(t);};img.onerror=reject;img.src=url.href||String(url);
  });
}

// Linear data texture: the HUSH asset stores signed distance and coverage,
// not display colour. sRGB decoding would bend the distance field and thicken
// the body differently at each mip/range.
function loadDataTexture(url){
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>{
      const t=gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D,t);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,gl.RGBA,gl.UNSIGNED_BYTE,img);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
      resolve(t);
    };
    img.onerror=()=>reject(new Error(`failed to load data texture ${url}`));
    img.src=url.href||String(url);
  });
}

let boothTelevision=null;
export function r3dBoothTelevisionStatus(){return boothTelevision?.snapshot()||{ready:false,playing:false,uploads:0};}
export function r3dInit(mapEl) {
  boothTelevision?.dispose();boothTelevision=createBoothTelevision({upload:(name,video)=>P3.setWorldVideoFrame(name,video)});
  outcomeExposure.clear();
  const crowdLoadGeneration=streetCrowdPacks.reset();
  const peopleGeneration=++exteriorPeopleLoadGeneration;exteriorPeopleStatus={boothProps:false,boothCharacter:false,ambientProps:false,errors:[]};
  const hospitalityGeneration=++pubHospitalityLoadGeneration;pubHospitalityError=null;
  const costumeLoadGeneration=++costumeExchangeLoadGeneration;costumeExchangeAssetError=null;
  sourceSurfaceBaker?.dispose();sourceSurfaceBaker=null;sourceSurfaceDiagnostics=null;
  if(gl&&sourceSurfaceTexture)gl.deleteTexture(sourceSurfaceTexture);sourceSurfaceTexture=null;
  cinematicLensPass?.dispose();cinematicLensPass=null;activeCameraTanHalfFov=.95;
  canvas = document.createElement('canvas');
  canvas.className = 'r3d';
  canvas.style.cssText = 'display:block;width:100%;height:100%;';
  // Insert beneath, never wipe: the UI glyph layer and the diffusion overlay
  // are siblings that may already be mounted here.
  mapEl.insertBefore(canvas, mapEl.firstChild);
  // preserveDrawingBuffer: the diffusion client captures this canvas with
  // toBlob() outside the rAF that drew it.
  gl = canvas.getContext('webgl2', { antialias: false, preserveDrawingBuffer: true });
  verifyGraphicsStartup(gl);
  cinematicLensPass=createCinematicLensPass(gl);

  progRD = program(RD_FRAG);
  progWater = program(WATER_FRAG);
  progMarch = program(MARCH_FRAG);
  progPost = program(POST_FRAG);
  // The scanned fog. Until it arrives a crossing still has its white, only no film.
  loadDataTexture(assetUrl(FILM_LEAK_ATLAS.url)).then(t=>{filmLeakTex=t;}).catch(()=>{filmLeakTex=null;});
  progDepth = program(DEPTH_FRAG);
  progDatamosh = program(DATAMOSH_FRAG);
  progCopy = program(COPY_FRAG);
  progPressureFinish=program(PRESSURE_FINISH_FRAG);pressureFinishUniformCache.clear();
  progSourceVoidPhysical = program(SOURCE_VOID_PHYSICAL_FRAG);
  SHORE.sourceShoreInit(gl);
  sourceVoidPhysicalUniformCache.clear();
  canvas.dataset.sourceVoidPhysicalShader='ready';
  try { progBurst = program(BURST_FRAG); } catch (_) { progBurst = null; }
  progTextSpace = program(TEXT_SPACE_FRAG);
  progSourceRoomAcquisition=program(SOURCE_ROOM_ACQUISITION_FRAG);
  // A failed horizon program leaves Source II recorded without the hole
  // rather than taking down the rest of the renderer.
  try{progSourceRestHorizon=program(COMMON_GLSL+SOURCE_REST_HORIZON_LENS_GLSL);sourceRestHorizonStatus.error=null;}
  catch(error){progSourceRestHorizon=null;sourceRestHorizonStatus.error=String(error?.message||error);console.warn('[r3d] source rest horizon unavailable',error);}
  sourceRestHorizonUniformCache.clear();
  progSourceIdentity=program(SOURCE_IDENTITY_FRAG);
  sourceRoomUniformCache.clear();sourceIdentityUniformCache.clear();
  try {
    progPixelMesh = program(PIXEL_MESH_FRAG);
    pixelMeshStatus.shaderReady = true;
    pixelMeshStatus.supported = true;
    pixelMeshStatus.lastError = null;
  } catch (err) {
    progPixelMesh = null;
    pixelMeshStatus.shaderReady = false;
    pixelMeshStatus.supported = false;
    pixelMeshStatus.lastError = err?.message || String(err);
    console.error('pixel mesh shader unavailable; continuing without VFD mesh', err);
  }
  P3.props3dInit(gl);
  const tapeDemandGeneration=++chapelTapeDemandLoadGeneration;chapelTapeDemandReady=false;chapelTapeDemandError=null;

  anisoExt = gl.getExtension('EXT_texture_filter_anisotropic');
  if(anisoExt) anisoMax = gl.getParameter(anisoExt.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
  initSurfaceDream();

  // RD seed: mostly A=1, scattered B blots
  const seed = new Float32Array(RD_SIZE * RD_SIZE * 4);
  for (let i = 0; i < RD_SIZE * RD_SIZE; i++) {
    seed[i * 4] = 1;
    seed[i * 4 + 1] = Math.random() < 0.015 ? 0.8 : 0;
    seed[i * 4 + 3] = 1;
  }
  rdTexA = makeTex(RD_SIZE, RD_SIZE, seed, 'rgba16f');
  rdTexB = makeTex(RD_SIZE, RD_SIZE, seed, 'rgba16f');
  // trilinear on the RD field (mips regenerated each frame in r3dFrame)
  for (const t of [rdTexA, rdTexB]) {
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.generateMipmap(gl.TEXTURE_2D);
  }
  rdFboA = makeFbo(rdTexA);
  rdFboB = makeFbo(rdTexB);
  const waterSeed = new Float32Array(WATER_W * WATER_H * 4);
  for (let i = 0; i < WATER_W * WATER_H; i += 1) {
    waterSeed[i * 4] = 0.5;
    waterSeed[i * 4 + 1] = 0.5;
    waterSeed[i * 4 + 3] = 1;
  }
  driveLandTex = null;driveFarLightProgram = null;driveFarLightVao = null;driveFarLightBuffer = null;
  waterTexA = makeTex(WATER_W, WATER_H, waterSeed, 'rgba16f');
  waterTexB = makeTex(WATER_W, WATER_H, waterSeed, 'rgba16f');
  for (const t of [waterTexA, waterTexB]) {
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }
  waterFboA = makeFbo(waterTexA);
  waterFboB = makeFbo(waterTexB);
  fogTexture = makeTex(FOG_TEX, FOG_TEX, new Uint8Array(FOG_TEX * FOG_TEX).fill(255), 'r8');
  resize();
  // The mandatory bus is route geometry, not optional dressing: a base-ready
  // promise must never expose its colliders with the old solid side skin.
  const busStudioState={bus:false,studio:false,errors:[]};busStudioAssetState=busStudioState;
  basePropPackLoad=P3.loadPropPack(assetUrl('assets/conservatory-props.glb'))
    .then(async pack=>{
      await P3.addPropPack(assetUrl('assets/outskirts-bus-passage.glb'));
      await P3.addPropPack(assetUrl('assets/van-brand.glb'));
      await P3.addPropPack(assetUrl('assets/box-office.glb'));
      await P3.addPropPack(assetUrl('assets/ellery-garden-approaches.glb'));
      await P3.addPropPack(assetUrl('assets/glass-court.glb'));
      glassCourtReady=GLASS_COURT.meshNames.every(name=>P3.propMeshCatalog().includes(name));
      if(!glassCourtReady)throw new Error('Missing baseline glazed-link construction');
      // The wrecked van at the telephone box reuses the coastal crash model: its
      // bent hull and doors live in van-wreck.glb, and its torn-off bumper, hubcap,
      // headlamp and panel shards live in coastal-memory.glb. Both are optional so
      // a missing pack keeps the whole yard-van rather than breaking the street.
      void P3.addPropPack(assetUrl('assets/source-drive/coastal-memory/van-wreck.glb'))
        .catch((err)=>console.warn('van wreck unavailable; retaining the whole yard-van',err));
      void P3.addPropPack(assetUrl('assets/source-drive/coastal-memory/coastal-memory.glb'))
        .catch((err)=>console.warn('coastal memory debris unavailable',err));
      await loadBusStudioPacks(busStudioState);
      return pack;
    });
  authoredPropPackLoad=basePropPackLoad
    .then((pack)=>{
      SHORE.sourceShoreSetHardwarePack(pack);
      void P3.addPropPack(assetUrl('assets/chapel-tape-demand.glb')).then(()=>{
        if(tapeDemandGeneration!==chapelTapeDemandLoadGeneration)return;
        const catalog=new Set(P3.propMeshCatalog());
        if(!['tape_demand_paint_line','tape_demand_paint_block','tape_demand_paint_line_pale','tape_demand_paint_block_pale','tape_demand_field_case','tape_demand_strap','tape_demand_wall_catch'].every(name=>catalog.has(name)))throw Error('Incomplete chapel tape demand pack');
        chapelTapeDemandReady=true;chapelTapeDemandError=null;
      }).catch(error=>{if(tapeDemandGeneration!==chapelTapeDemandLoadGeneration)return;chapelTapeDemandError=String(error?.message||error);console.warn('chapel departure material unavailable; retaining an unbound exit',error);});
      void P3.addPropPack(assetUrl('assets/institution-posters.glb')).catch(err=>console.warn('institution posters unavailable',err));
      void P3.addPropPack(assetUrl('assets/source-outskirts-graffiti.glb')).catch(err=>console.warn('Source street graffiti unavailable',err));
      void streetCrowdPacks.load(crowdLoadGeneration);
      for(const[kind,file,names]of[
        ['boothProps','booth-guard-props.glb',['yard_booth_interior','yard_booth_workplace','yard_booth_tv_screen','booth_guard_pen','booth_guard_key','booth_guard_cup']],
        ['ambientProps','exterior-ambient-people-props.glb',['exterior_cycle_equipment','exterior_cycle_crank','exterior_walker_dog']],
      ])void P3.addPropPack(assetUrl('assets/'+file)).then(()=>{
        if(peopleGeneration!==exteriorPeopleLoadGeneration)return;
        const catalog=new Set(P3.propMeshCatalog());if(!names.every(name=>catalog.has(name)))throw Error('Incomplete exterior performer equipment: '+kind);
        exteriorPeopleStatus[kind]=true;
      }).catch(error=>{
        if(peopleGeneration!==exteriorPeopleLoadGeneration)return;
        exteriorPeopleStatus.errors.push(String(error?.message||error));console.warn('exterior performer equipment unavailable; retaining original appearance',error);
      });
      void P3.addCharacterPack(assetUrl('assets/pub-characters.glb')).then(()=>{pubStatus.characters=true;}).catch(err=>{pubStatus.error=String(err?.message||err);console.warn('pub characters unavailable',err);});
      void P3.addPropPack(assetUrl('assets/pub-quest-props.glb')).then(()=>{pubStatus.props=true;}).catch(err=>{pubStatus.error=String(err?.message||err);console.warn('pub service props unavailable',err);});
      void P3.addPropPack(assetUrl('assets/pub-hospitality.glb')).then(()=>{
        if(hospitalityGeneration===pubHospitalityLoadGeneration&&!P3.propMeshCatalog().includes('pub_warm_interior'))throw Error('The warm Lyric interior is missing from its pack.');
      }).catch(err=>{
        if(hospitalityGeneration===pubHospitalityLoadGeneration)pubHospitalityError=String(err?.message||err);
        console.warn('pub hospitality unavailable; retaining the original room',err);
      });
      void P3.addPropPack(assetUrl('assets/source-vehicle-interior.glb'))
        .then(()=>{vehicleInteriorStatus.loaded=true;vehicleInteriorStatus.error=null;
          // The dash's radio, over the old one of the same name. It keeps that one if this fails.
          return Promise.all([P3.addPropPack(assetUrl(CAB_RADIO_PACK)).catch(err=>console.warn('cab radio unavailable; keeping the original unit',err)),
            P3.addPropPack(assetUrl(CAB_DASH_PACK)).catch(err=>console.warn('cab dash unavailable; keeping the bare mouldings',err))]);})
        .catch((err)=>{vehicleInteriorStatus.error=String(err?.message||err);console.warn('vehicle interior unavailable',err);});
      // The opening booth and the later Wrong Fold share this actor. Begin its
      // optional decode as soon as the base catalog is installed, so unrelated
      // street/vegetation/Source packs cannot delay his opening appearance.
      void P3.addCharacterPack(assetUrl('assets/outskirts-characters.glb'))
        .then(()=>P3.addCharacterPack(assetUrl('assets/guard-presentations.glb'),{allowedMeshes:['outskirts_fold_guard','overworld_booth_guard']}))
        .then(()=>{if(peopleGeneration===exteriorPeopleLoadGeneration)exteriorPeopleStatus.boothCharacter=true;})
        .catch((err)=>console.warn('outskirts character pack unavailable',err));
      void P3.addCharacterPack(assetUrl('assets/outskirts-dog-handler.glb')).catch((err)=>console.warn('outskirts dog handler unavailable',err));
      // Dedicated informant costume/negative hull. Keep its residency separate
      // from the later Source operator whose identity and asset remain intact.
      void P3.addCharacterPack(assetUrl('assets/tower-warning-missing-man.glb'),{allowedMeshes:['tower_warning_missing_man']})
        .catch((err)=>console.warn('Missing Man character unavailable',err));
      void P3.addCharacterPack(assetUrl('assets/recordist-characters.glb')).catch((err)=>console.warn('recordist character pack unavailable',err));
      // The prop-store body and chamber cherub use this same skinned material,
      // shadow and final world dither path as the established Wrong Fold.
      void P3.addCharacterPack(assetUrl('assets/costume-exchange.glb')).catch((err)=>{
        if(costumeLoadGeneration===costumeExchangeLoadGeneration)costumeExchangeAssetError=String(err?.message||err);
        console.warn('costume exchange character unavailable',err);
      });
      const heldLoadGeneration=++heldNoteLoadGeneration;heldNoteAssetError=null;
      void P3.addCharacterPack(assetUrl('assets/held-note.glb')).catch((err)=>{
        if(heldLoadGeneration===heldNoteLoadGeneration)heldNoteAssetError=String(err?.message||err);
        console.warn('held note character unavailable',err);
      });
      // Anonymous reception residents use the ordinary skinned world targets.
      // Colour, depth, shadows and the final pixel-mesh dither remain shared.
      void P3.addCharacterPack(assetUrl('assets/source-last-reception-residents.glb')).catch((err)=>console.warn('Source reception residents unavailable',err));
      void P3.addCharacterPack(assetUrl('assets/academic-society-characters.glb'),{allowedMeshes:ACADEMIC_CHARACTER_PACK_MESHES}).catch((err)=>console.warn('Academic society characters unavailable',err));
      // Both established bus-woman mesh names resolve to this one wardrobe and
      // rig. Their ordinary prop targets feed the shared scene dither below.
      void P3.addCharacterPack(assetUrl('assets/bus-woman-character.glb')).catch((err)=>console.warn('bus woman character pack unavailable',err));
      // The Source's failed attachment belongs only to its thirteen road
      // memories. Separate names keep the ordinary shelter body intact even
      // when this optional pack cannot decode on a particular device.
      void P3.addCharacterPack(assetUrl('assets/outskirts-bus-woman-wrong-origin.glb'),{allowedMeshes:[1,2,3,4,5].map(stage=>`outskirts_bus_woman_wrong_origin_${stage}`)}).catch((err)=>console.warn('bus woman wrong origin character pack unavailable',err));
      // Six named vigil participants have individual anatomical skins and
      // hand-weighted documentary objects. Their catalog names replace the
      // conservative silhouettes in the base pack after each pair loads.
      for(const pair of ['ruth-leila','owen-denise','malcolm-kit'])
        void P3.addCharacterPack(assetUrl(`assets/vigil-characters-${pair}.glb`)).catch((err)=>console.warn('vigil character pair unavailable',pair,err));
      // The selected Outskirts encounter can be reached directly in review;
      // load its world geometry before the much larger optional room packs.
      // Both meshes enter the same lit/shadowed targets as the road, before
      // the final scene dither.
      return P3.addPropPack(assetUrl('assets/outskirts-vacant-dog.glb'))
        .catch((err)=>console.warn('outskirts vacant dog pack unavailable',err))
        .then(()=>P3.addPropPack(assetUrl('assets/conservatory-acquisitions.glb')));
    })
    .then(()=>P3.addPropPack(assetUrl('assets/hall-chandelier-proof.glb'))
      .then(()=>{const names=P3.propMeshCatalog();hallChandelierReady=['hall_chandelier_body','hall_chandelier_support_west','hall_chandelier_support_east'].every(name=>names.includes(name));})
      .catch(err=>{hallChandelierReady=false;console.warn('Hall chandelier proof unavailable; retaining original fitting',err);}))
    // Floor textiles, after the procedural pack so atrium_waiting_rug's
    // flat-shaded version is overridden by the textured one of the same name.
    // Optional, like vegetation: a missing pack leaves the bands in place.
    .then(()=>P3.addPropPack(assetUrl('assets/conservatory-textiles.glb')).catch((err)=>console.warn('textile pack unavailable; retaining procedural rug',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/conservatory-adversary-scenery.glb'))
      .catch((err)=>console.warn('adversary room dressing unavailable; retaining original prop store',err)))
    .then(()=>P3.addPropPack(assetUrl(EXTERIOR_FRONTAGE_PACK)))
    // Graffiti is its own surface dressing: neither the masonry nor the bus
    // mesh needs to be replaced, and a missing pack leaves the street usable.
    .then(()=>P3.addPropPack(assetUrl('assets/exterior-graffiti.glb'))
      .catch(err=>console.warn('Exterior graffiti unavailable',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/bus-graffiti.glb'))
      .catch(err=>console.warn('Bus graffiti unavailable',err)))
    .then(()=>P3.addPropPack(assetUrl(EXTERIOR_STREET_FABRIC.pack))
      .then(()=>{streetFabricReady=EXTERIOR_STREET_FABRIC.meshNames.every(name=>P3.propMeshCatalog().includes(name));})
      .catch(err=>console.warn('Street fabric unavailable; retaining existing road section',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/exterior-infrastructure.glb'))
      .catch(err=>console.warn('Connected exterior services unavailable',err)))
    .then(()=>P3.addPropPack(assetUrl(ELLERY_PUBLIC_FRONT_PACK))
      .then(()=>{elleryPublicFrontReady=Object.keys(ELLERY_PUBLIC_FRONT_MESHES).every(name=>P3.propMeshCatalog().includes(name));}))
    .then(()=>P3.addPropPack(assetUrl(EXTERIOR_ROOFLINE_PACK))
      .catch(err=>console.warn('exterior roof closure unavailable; retaining original elevations',err)))
    .then(()=>P3.addPropPack(assetUrl(EXTERIOR_STATIONERS_PACK))
      .catch(err=>console.warn('stationers pack unavailable; retaining original closed frontage',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/opening-street.glb'))
      .then(()=>{openingStreetReady=true;}))
    .then(()=>P3.addPropPack(assetUrl('assets/yard-jardins-boundary.glb'))
      .then(()=>{yardJardinsBoundaryReady=true;})
      .catch(err=>{yardJardinsBoundaryReady=false;console.warn('Yard pedestrian boundary unavailable',err);}))
    // One optional north-street proof. Unique mesh names keep the wider fleet
    // and arrival street unchanged if this small pack is unavailable.
    .then(()=>P3.addPropPack(assetUrl('assets/street-pilot.glb'))
      .then(()=>{streetPilotReady=true;})
      .catch((err)=>console.warn('street pilot unavailable; retaining legacy traffic',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/glass-court.glb'))
      .then(()=>{
        const names=P3.propMeshCatalog();
        glassCourtReady=GLASS_COURT.meshNames.every(name=>names.includes(name));
        if(!glassCourtReady)throw new Error('Incomplete indoor greenhouse pack');
      })
      .catch(err=>{glassCourtReady=false;console.warn('Greenhouse unavailable; retaining the existing pool route',err);}))
    // Hero vegetation deliberately overrides the conservative tree, hedge and
    // ruined-garden meshes. A missing optional pack falls back to those names
    // without preventing later structural packs from loading.
    .then(()=>P3.addPropPack(assetUrl('assets/vegetation.glb')).catch((err)=>console.warn('vegetation pack unavailable; retaining procedural fallbacks',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/academic-gallery.glb'))
      .then(()=>{academicGalleryReady=true;academicGalleryError=null;})
      .catch((err)=>{academicGalleryReady=false;academicGalleryError=String(err?.message||err);console.warn('academic gallery unavailable; retaining existing assemblies',err);}))
    .then(()=>P3.addPropPack(assetUrl('assets/student-strike-records.glb'))
      .catch(err=>console.warn('Recovery-site record surfaces unavailable',err)))
    // The ear room (data/stop-listening.js). Optional: without it the room is
    // only its sound and its words, which is less, but not broken.
    .then(()=>P3.addPropPack(assetUrl('assets/stop-listening.glb')).catch((err)=>console.warn('ear room pack unavailable',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/chapel-dressing.glb')).catch((err)=>console.warn('chapel dressing unavailable',err)))
    // Dedicated replacements resolve only St Brendan's exact instance IDs.
    // They share colour, depth, shadow and the final world dither; a missing
    // pack leaves the original church and all collision/encounters intact.
    .then(()=>P3.addPropPack(assetUrl('assets/st-brendans-treatment.glb')).catch((err)=>console.warn('St Brendan treatment unavailable; retaining original church',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/st-brendans-presences.glb')).catch((err)=>console.warn('St Brendan presences unavailable',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/source-demolition.glb')).catch((err)=>console.warn('Source demolition unavailable; retaining distant echo',err)))
    .then(()=>P3.addPropPack(assetUrl('assets/source-structures.glb')))
    .then(()=>{
      // Pressure decoding is optional and must not delay the doors or stairs.
      void r3dPrepareHushBody().catch(err=>console.warn('Pressure volume unavailable; retaining absence field',err));
    })
    .then(()=>P3.addPropPack(assetUrl('assets/conservatory-doors.glb')))
    .then(()=>P3.addPropPack(assetUrl('assets/tuning-fork.glb')))
    .then(()=>P3.addPropPack(assetUrl('assets/conservatory-main-stair.glb')))
    // The original host names and lettering datums remain unchanged. This
    // small replacement adds attached, worn mounting boards to the landings.
    .then(()=>P3.addPropPack(assetUrl('assets/conservatory-landing-fittings.glb'))
      .catch(err=>console.warn('landing fittings unavailable; retaining original lamps and signs',err)))
    // Retained wall ornament shares the ordinary depth, torch and final dither.
    // The masonry and the stair remain complete if this optional skin is absent.
    .then(()=>P3.addPropPack(assetUrl(MAIN_STAIR_WALL_PACK))
      .catch(err=>console.warn('stair wall ornament unavailable; retaining existing masonry',err)))
    .catch((err)=>{if(!vehicleInteriorStatus.loaded)vehicleInteriorStatus.error=String(err?.message||err);console.warn('prop pack unavailable',err);});
  P3.loadPortraitAtlas(assetUrl('assets/portraits/portrait-atlas.webp'))
    .catch((err)=>console.warn('portrait atlas unavailable',err));
  P3.loadPaperAtlas(assetUrl(PAPER_PIGMENT_PATH),{columns:PAPER_ATLAS.columns,rows:PAPER_ATLAS.rows,pigmentCoverage:true,
    materialUrl:assetUrl(PAPER_WORLD_MATERIAL.path),heightRangeM:PAPER_WORLD_MATERIAL.heightRangeM})
    .catch((err)=>console.warn('paper atlas unavailable; sheets retain stock material',err));
  Promise.all([
    loadTextureArray(assetUrl('assets/surfaces/surface-albedo.jpg'),{srgb:true}),
    loadTextureArray(assetUrl('assets/surfaces/surface-normal.png')),
    loadPackedMaterialArray(assetUrl('assets/surfaces/surface-rough.jpg'),
                            assetUrl('assets/surfaces/surface-height.png')),
  ]).then(([a,n,m])=>{surfAlbedoTex=a;surfNormalTex=n;surfMaterialTex=m;surfaceTexture=a;})
    .catch((err)=>console.warn('surface arrays unavailable; using native material fallback',err));
  window.addEventListener('resize', resize);
  // The stage can change size a frame after the window (platform/viewport-guard.js).
  window.addEventListener('chunk-surfer:stage-resize', resize);
}

function resize() {
  if(windowGeometryMotion){windowGeometryResizePending=true;return;}
  const w = Math.max(1, canvas.parentElement.clientWidth);
  const h = Math.max(1, canvas.parentElement.clientHeight);
  const pixelRatio=r3dEffectiveOutputPixelRatio();
  canvas.width = Math.round(w * pixelRatio);
  canvas.height = Math.round(h * pixelRatio);
  outputPixelRatioApplied=pixelRatio;
  const sw = Math.max(64, Math.round(canvas.width * RENDER_SCALE));
  const sh = Math.max(64, Math.round(canvas.height * RENDER_SCALE));
  if (sceneTex) { gl.deleteTexture(sceneTex); gl.deleteFramebuffer(sceneFbo); gl.deleteRenderbuffer(sceneDepthRb); }
  if(pressureFinishTex){gl.deleteTexture(pressureFinishTex);gl.deleteFramebuffer(pressureFinishFbo);}
  if(pressureIdentityTex)gl.deleteTexture(pressureIdentityTex);
  pressureFinishReady=false;
  // Pressure now carries material and view depth into the recording. Match
  // scene precision so its presence cannot quantise the whole world's depth.
  pressureFinishTex=makeTex(sw,sh,null,'rgba16f');
  pressureIdentityTex=makeTex(sw,sh);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  pressureFinishFbo=makeFbo(pressureFinishTex,[pressureIdentityTex]);
  if (markTex) { gl.deleteTexture(markTex); markTex = null; }
  if (meshTexA) {
    gl.deleteTexture(meshTexA); gl.deleteTexture(meshTexB);
    gl.deleteFramebuffer(meshFboA); gl.deleteFramebuffer(meshFboB);
  }
  for(const item of [[datamoshSourceTex,datamoshSourceFbo],[datamoshTexA,datamoshFboA],[datamoshTexB,datamoshFboB]]){if(item[0])gl.deleteTexture(item[0]);if(item[1])gl.deleteFramebuffer(item[1]);}
  if(burstOutTex){gl.deleteTexture(burstOutTex);gl.deleteFramebuffer(burstOutFbo);}
  burstOutTex=makeMeshTex(sw,sh);burstOutFbo=makeFbo(burstOutTex);
  // Preserve ray distance beyond eight alpha bits. The acquisition pass pins
  // its marks to reconstructed world space; quantised depth made that position
  // crawl sideways as the camera changed angle. RGB is explicitly clamped in
  // the raymarch shader, so this precision upgrade does not alter exposure.
  sceneTex = makeTex(sw, sh, null, 'rgba16f');
  // RGBA8, not the scene's rgba16f: density, a doubled-angle direction and a
  // coherence all live in 0..1, and test/mark-field.spec.mjs shows eight bits
  // resolve the grain to about a tenth of a degree, far finer than the warp
  // that consumes it. Half the bandwidth of matching the scene.
  markTex = makeTex(sw, sh, null, 'rgba8');
  // The Horizon portrait is composed here ahead of the projection grade. Its
  // overlapping stone surfaces need real depth or rear triangles overwrite
  // the face and turn the sculpture into high-frequency visual noise.
  sceneDepthRb = gl.createRenderbuffer();
  gl.bindRenderbuffer(gl.RENDERBUFFER, sceneDepthRb);
  gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, sw, sh);
  gl.bindRenderbuffer(gl.RENDERBUFFER, null);
  sceneFbo = makeFbo(sceneTex, [markTex], sceneDepthRb);
  meshTexA = makeMeshTex(sw, sh);
  meshTexB = makeMeshTex(sw, sh);
  meshFboA = makeFbo(meshTexA);
  meshFboB = makeFbo(meshTexB);
  datamoshSourceTex=makeMeshTex(sw,sh);datamoshSourceFbo=makeFbo(datamoshSourceTex);
  datamoshTexA=makeMeshTex(sw,sh);datamoshTexB=makeMeshTex(sw,sh);datamoshFboA=makeFbo(datamoshTexA);datamoshFboB=makeFbo(datamoshTexB);
  meshFlip = false;
  lastPixelMeshAt = 0;
  pixelMeshStatus.sceneWidth = sw;
  pixelMeshStatus.sceneHeight = sh;
  pixelMeshStatus.supported = !!progPixelMesh;
  P3.props3dResize(sw, sh, { shadowMapSize: RENDER_SCALE < .75 ? 512 : 1024 });
  uniforms.sceneW = sw; uniforms.sceneH = sh;
  r3dResetVfdMemory();
}

// Native window choreography can deliver thirty resize events per second. A
// normal resize rebuilds every scene/mesh/datamosh framebuffer, so doing that
// for every interpolation tick stalls the render stack. Keep one logical image
// during the tween (CSS presents it in the changing frame), then reconcile the
// native size exactly once when the cue settles.
export function r3dSetWindowGeometryMotion(active=false){
  windowGeometryMotion=!!active;
  if(!windowGeometryMotion&&windowGeometryResizePending){
    windowGeometryResizePending=false;
    resize();
  }
  return windowGeometryMotion;
}

// ── Facing / input hooks (main.js calls these in 3d mode) ────────────────────
export function r3dTurn(dir) {
  r3dCancelMouseLookGlide();
  const quarter=Math.PI/2,base=Math.round(yawTarget/quarter)+dir;
  facing = ((base % 4) + 4) % 4;
  yawTarget = base * quarter;
  r3dResetVfdMemory();
}
// These caps are a rail against GARBAGE INPUT — a wild delta from a lost
// pointer lock, a hot-plugged pad — and nothing else. They were ±.16 and ±.12
// radians, which is not a garbage threshold: it is roughly what a hand actually
// moves in one frame, so it silently became the sensitivity ceiling. The
// clamp bit whenever dx*sensitivity exceeded 33, which at the top of the slider
// is a movement of THREE PIXELS, making every setting above about 1.7
// indistinguishable and the maximum feel slow.
//
// Pixel-space deltas are already bounded upstream (clampDelta in
// pointer-mode.js), so these only need to be beyond anything a hand produces.
const LOOK_YAW_LIMIT=2.4;    // fast horizontal sweeps, still bounded against bad input
const LOOK_PITCH_LIMIT=.7;
const LOOK_UP_LIMIT=1.1;
// Keep the glass roof's near-vertical downward view; elsewhere the wider head
// range lets the player inspect floors and ceilings without flipping over.
const lookPitchFloor=()=>lightingRoofSkyRecovery>0?DOWNWARD_LOOK_LIMIT:-1.15;
let mouseGlideYaw=0,mouseGlidePitch=0;
const MOUSE_GLIDE_SECONDS=.09,MOUSE_GLIDE_GAIN=.08,MOUSE_GLIDE_MAX_SPEED=7.4;
export function r3dCancelMouseLookGlide(){mouseGlideYaw=0;mouseGlidePitch=0;}
// Integrate the bounded residual velocity analytically. Mouse displacement is
// applied immediately; this short tail supplies weight without camera lag.
function advanceMouseLookGlide(seconds){
  const dt=Math.max(0,Math.min(.1,Number(seconds)||0));
  if(!dt||(!mouseGlideYaw&&!mouseGlidePitch))return;
  const decay=Math.exp(-dt/MOUSE_GLIDE_SECONDS),fraction=MOUSE_GLIDE_SECONDS*(1-decay);
  const dyaw=mouseGlideYaw*fraction,dpitch=mouseGlidePitch*fraction;
  yaw+=dyaw;yawTarget+=dyaw;
  const before=pitchTarget,wanted=pitchTarget+dpitch;
  pitchTarget=Math.max(lookPitchFloor(),Math.min(LOOK_UP_LIMIT,wanted));
  pitch=Math.max(lookPitchFloor(),Math.min(LOOK_UP_LIMIT,pitch+pitchTarget-before));
  mouseGlideYaw*=decay;
  mouseGlidePitch=pitchTarget===wanted?mouseGlidePitch*decay:0;
  if(Math.abs(mouseGlideYaw)<.001)mouseGlideYaw=0;
  if(Math.abs(mouseGlidePitch)<.001)mouseGlidePitch=0;
  facing=((Math.round(yawTarget/(Math.PI/2))%4)+4)%4;
}
export function r3dLook(yawDelta=0,pitchDelta=0,{immediate=false,glide=false,deltaSeconds=0}={}) {
  const previousYawTarget=yawTarget,previousPitchTarget=pitchTarget;
  yawTarget += Math.max(-LOOK_YAW_LIMIT,Math.min(LOOK_YAW_LIMIT,Number(yawDelta)||0));
  pitchTarget = Math.max(lookPitchFloor(),Math.min(LOOK_UP_LIMIT,pitchTarget+Math.max(-LOOK_PITCH_LIMIT,Math.min(LOOK_PITCH_LIMIT,Number(pitchDelta)||0))));
  // Mouse displacement is direct. Move the visible camera by only the applied
  // delta, leaving any pending stick or scripted easing intact.
  if(immediate){
    yaw+=yawTarget-previousYawTarget;
    pitch=Math.max(lookPitchFloor(),Math.min(LOOK_UP_LIMIT,pitch+pitchTarget-previousPitchTarget));
    if(glide){
      const dt=Math.max(1/240,Math.min(.1,Number(deltaSeconds)||1/60));
      mouseGlideYaw=Math.max(-MOUSE_GLIDE_MAX_SPEED,Math.min(MOUSE_GLIDE_MAX_SPEED,(yawTarget-previousYawTarget)/dt))*MOUSE_GLIDE_GAIN;
      mouseGlidePitch=Math.max(-MOUSE_GLIDE_MAX_SPEED,Math.min(MOUSE_GLIDE_MAX_SPEED,(pitchTarget-previousPitchTarget)/dt))*MOUSE_GLIDE_GAIN;
    }else r3dCancelMouseLookGlide();
  }
  facing=((Math.round(yawTarget/(Math.PI/2))%4)+4)%4;
  r3dResetVfdMemory();
  return {yaw:yawTarget,pitch:pitchTarget,facing};
}
export function r3dLookAngles(){return{yaw:yawTarget,pitch:pitchTarget,facing};}
// Where the eye actually ended up, for the pixel harness: the lean is eased, so
// the camera lags the requested value and only this can say where it is.
export function r3dEyePoint(){return{x:camX,y:camY,z:camZ,lean:leanEase};}
// Physical eye and eased angles used by this frame, for picking world surfaces.
export function r3dViewCamera(){return{eye:{x:camX*CELL,y:camY*CELL,z:camZ*CELL},yaw:yaw+planYaw,pitch,
  tanHalfFov:activeCameraTanHalfFov,lens:r3dCinematicLensStatus(),natatoriumMetric:{...natatoriumMetric},
  width:canvas?.clientWidth||canvas?.width||1,height:canvas?.clientHeight||canvas?.height||1};}
// Project a physical world point (metres) through the same basis and 0.95 FOV
// used by the raymarcher. UI attached to architecture can then follow the thing
// itself while the player looks around instead of being painted at screen centre.
let driveFrameActive=false;
const vehicleInteriorStatus={loaded:false,error:null};
export function r3dVehicleInteriorStatus(){return {...vehicleInteriorStatus};}
export function r3dProjectWorld(point={}){
  const tx=(Number(point.x)||0)/CELL,ty=(Number(point.y)||0)/CELL,tz=(Number(point.z)||0)/CELL;
  const dx=tx-camX,dy=ty-camY,dz=(natatoriumMetricZ(tz*CELL,natatoriumMetric)-natatoriumMetricZ(camZ*CELL,natatoriumMetric))/CELL,worldYaw=yaw+planYaw;
  const {forward,right,up}=cameraBasis(worldYaw,pitch);
  const depth=dx*forward[0]+dy*forward[1]+dz*forward[2];
  if(depth<=.01)return{x:.5,y:.5,depth,visible:false};
  const tanHalfFov=activeCameraTanHalfFov;
  const viewX=(dx*right[0]+dz*right[2])/(depth*tanHalfFov);
  const viewY=(dx*up[0]+dy*up[1]+dz*up[2])/(depth*tanHalfFov);
  const aspect=Math.max(.1,(uniforms.sceneW||canvas?.width||1)/(uniforms.sceneH||canvas?.height||1));
  const ndcX=viewX/aspect,ndcY=viewY;
  return{x:(ndcX+1)*.5,y:(1-ndcY)*.5,depth,visible:Math.abs(ndcX)<=1.08&&Math.abs(ndcY)<=1.08};
}
// Rebase a stair portal's logical frame without snapping pending mouse-look.
// Both live and requested local yaw turn; their physical bearings stay fixed.
export function r3dShiftLookFrame(delta=0){
  const turn=Number(delta);if(!Number.isFinite(turn))return false;
  yaw+=turn;yawTarget+=turn;planYaw-=turn;planYawTarget-=turn;
  facing=((Math.round(yawTarget/(Math.PI/2))%4)+4)%4;
  return true;
}
export function r3dSetLookAngles({ yaw: nextYaw = yawTarget, pitch: nextPitch = pitchTarget, immediate = true } = {}) {
  r3dCancelMouseLookGlide();
  yawTarget = Number.isFinite(Number(nextYaw)) ? Number(nextYaw) : yawTarget;
  pitchTarget = Math.max(lookPitchFloor(), Math.min(LOOK_UP_LIMIT, Number.isFinite(Number(nextPitch)) ? Number(nextPitch) : pitchTarget));
  facing = ((Math.round(yawTarget / (Math.PI / 2)) % 4) + 4) % 4;
  if (immediate) { yaw = yawTarget; pitch = pitchTarget; }
  r3dResetVfdMemory();
  return { yaw: yawTarget, pitch: pitchTarget, facing };
}
// Authored vehicle shots may point into a fall. Ordinary head/mouse input
// retains its wall-reading limits; only an explicit cinematic owner uses this.
export function r3dSetCinematicLook({yaw:nextYaw=yawTarget,pitch:nextPitch=pitchTarget}={}){
  r3dCancelMouseLookGlide();
  if(Number.isFinite(Number(nextYaw)))yawTarget=Number(nextYaw);
  if(Number.isFinite(Number(nextPitch)))pitchTarget=Math.max(-1.48,Math.min(1.48,Number(nextPitch)));
  yaw=yawTarget;pitch=pitchTarget;
  facing=((Math.round(yawTarget/(Math.PI/2))%4)+4)%4;
  r3dResetVfdMemory();
  return{yaw:yawTarget,pitch:pitchTarget,facing};
}
// Put the head back level. Windowed play could leave pitch parked near its
// upper clamp — you spend the whole session looking at the ceiling — because
// nothing ever recentred it after focus was lost and regained.
export function r3dRecenterLook({ pitch: resetPitch = true, yaw: resetYaw = false, immediate = true } = {}) {
  r3dCancelMouseLookGlide();
  if (resetPitch) pitchTarget = 0;
  if (resetYaw) { const q = Math.PI / 2; const k = Math.round(yawTarget / q); facing = ((k % 4) + 4) % 4; yawTarget = k * q; }
  if (immediate) {
    if (resetPitch) pitch = pitchTarget;
    if (resetYaw) yaw = yawTarget;
  }
  r3dResetVfdMemory();
  return { yaw: yawTarget, pitch: pitchTarget, facing };
}
export function r3dDelta(sign) {
  const v = [[0, -1], [1, 0], [0, 1], [-1, 0]][facing];
  return [v[0] * sign, v[1] * sign];
}
// The direction the FEET go, from where the HEAD is actually pointed.
//
// `facing` is a quarter-turn index, so anything built on r3dDelta walked due
// north while you were looking north-east: the body refusing to follow the eyes.
// This reads the continuous yaw and snaps it to eight directions instead of
// four, which is as free as movement can be while collision is still resolved
// one grid cell at a time (see the diagonal guard in main.js step()).
const STEP_RING = [[0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1]];
export function r3dStepDelta(sign = 1) {
  const eighth = Math.PI / 4;
  const k = ((Math.round(yawTarget / eighth) % 8) + 8) % 8;
  const v = STEP_RING[k];
  return [v[0] * sign, v[1] * sign];
}
export function r3dFacing() { return facing; }
let cameraSnapPending = false;
// A warp changes camera ownership. Consume on the next rendered frame, after
// main.js has selected the destination's physical slice and eye-height policy.
export function r3dSnapCameraOnNextFrame() { cameraSnapPending = true; }

// A coordinate rebase moves the world and eye together. It is not a camera
// move: retain the recorder history, movement estimate, aim and settling.
export function r3dRebasePresentation({x=0,z=0}={}){
  if(!Number.isFinite(x)||!Number.isFinite(z))return false;
  camX+=x;camZ+=z;
  if(vfdPreviousX!==null)vfdPreviousX+=x;
  if(vfdPreviousZ!==null)vfdPreviousZ+=z;
  return true;
}

// Corridors are two cells wide, so an arbitrary spawn facing can put a wall
// both ahead of you and behind you — which reads exactly like broken arrow keys.
export function r3dSetFacing(f) {
  r3dCancelMouseLookGlide();
  facing = ((f % 4) + 4) % 4;
  yaw = yawTarget = facing * Math.PI / 2;
  pitch = pitchTarget = 0;
  r3dResetVfdMemory();
}

// The authored building, as the shader sees it. This is literally the array
// JS collision reads (world/floorplan.js `rgba`), so there is nothing to keep
// in sync — the drawn wall IS the solid wall.
// THE OPEN-GROUND FIELD.
//
// Per cell, the radius of the largest square centred on it in which the march
// can hit nothing for as long as the ray stays clear of a floor and a ceiling,
// and the highest floor in that square. Two kinds of square qualify:
//
//   open sky  — every cell sky, none solid, none wet. There is no ceiling or
//               header to meet under sky, and a ray above the highest floor
//               meets no floor or riser either, so the floors may differ: the
//               yard is road, kerb, pavement and grass at a dozen heights.
//   roofed    — every cell the same open cell: same floor byte, same ceiling
//               byte, none solid, none wet.
//
// Inside such a square the march steps without reading or testing a cell (see
// the walk in MARCH_FRAG). Out in the yard most rays cross dozens of these cells
// before they meet anything; capping the walk at 48 steps took the yard from 28
// to 18 ms, which is what this buys back without capping anything.
// Zero radius means "no promise", and is always safe.
const PLAN_SKIP_RADIUS_MAX = 64;
function planSkipField(rgba, material, w, h) {
  const n = w * h, key = new Int32Array(n), side = new Uint16Array(n);
  const radius = new Uint8Array(n), floorMax = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    const flags = rgba[i * 4 + 2];
    key[i] = (flags & 1) || (rgba[i * 4 + 3] & BORROWED_INTERIOR_ZONE_BIT) || material?.[i] === MATERIAL.wetTile ? -1
      : (flags & 4) ? 0x10000
      : (rgba[i * 4] << 8) | rgba[i * 4 + 1];
  }
  // The largest uniform square with its bottom-right corner on each cell.
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = y * w + x, k = key[i];
    if (k < 0) continue;
    side[i] = x && y && key[i - 1] === k && key[i - w] === k && key[i - w - 1] === k
      ? 1 + Math.min(side[i - 1], side[i - w], side[i - w - 1]) : 1;
  }
  // The highest floor byte over power-of-two blocks, so any square's highest
  // floor is the highest of four overlapping blocks.
  const levels = [new Uint8Array(n)];
  for (let i = 0; i < n; i++) levels[0][i] = rgba[i * 4];
  for (let k = 1; (1 << k) <= 2 * PLAN_SKIP_RADIUS_MAX + 1; k++) {
    const prev = levels[k - 1], next = new Uint8Array(n), half = 1 << (k - 1);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const x2 = Math.min(x + half, w - 1), y2 = Math.min(y + half, h - 1);
      next[y * w + x] = Math.max(prev[y * w + x], prev[y * w + x2], prev[y2 * w + x], prev[y2 * w + x2]);
    }
    levels.push(next);
  }
  // Centred on each cell: radius r holds when the corner square reaching
  // (x+r, y+r) is at least 2r+1 wide. It holds for every smaller r too.
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = y * w + x;
    if (key[i] < 0) continue;
    let lo = 0, hi = Math.min(PLAN_SKIP_RADIUS_MAX, x, y, w - 1 - x, h - 1 - y);
    while (lo < hi) {
      const r = (lo + hi + 1) >> 1;
      if (side[(y + r) * w + x + r] >= 2 * r + 1) lo = r; else hi = r - 1;
    }
    radius[i] = lo;
    const size = 2 * lo + 1, k = 31 - Math.clz32(size), span = 1 << k, level = levels[k];
    const x0 = x - lo, y0 = y - lo, x1 = x + lo - span + 1, y1 = y + lo - span + 1;
    floorMax[i] = Math.max(level[y0 * w + x0], level[y0 * w + x1], level[y1 * w + x0], level[y1 * w + x1]);
  }
  return { radius, floorMax };
}

export function r3dSetPlan(rgba, w, h, material = null, options = {}) {
  if (!gl) return;
  planW = w; planH = h;
  planOriginX = Number(options.originX) || 0;
  planOriginY = Number(options.originY) || 0;
  planHeightOffset = Number(options.heightOffset) || 0;
  planExteriorPortal = options.exteriorPortal || null;
  if (planTexture) gl.deleteTexture(planTexture);
  if (materialTexture) gl.deleteTexture(materialTexture);
  if (sourceLayerTexture) gl.deleteTexture(sourceLayerTexture);
  planTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, planTexture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, rgba);
  // NEAREST: a cell is a cell. Interpolating heights would smear the walls.
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  // RGBA8, not R8: G carries the baked per-cell ambient (world/floorplan.js
  // bakeAmbientField), B the open-ground radius and A that square's highest
  // floor byte (planSkipField). They ride
  // here rather than in textures of their own because MAX_TEXTURE_IMAGE_UNITS
  // is 16 on the target M4 Pro and all 16 are bound — adding a sampler to the
  // scene pass costs one that does not exist.
  // 255/AMBIENT_PLACE_SCALE is the neutral multiplier, so a plan slice with no
  // baked field renders exactly as it did before this existed.
  const mat = material || new Uint8Array(w * h).fill(MATERIAL.serviceConcrete);
  const amb = options.ambient || null;
  const skip = planSkipField(rgba, mat, w, h);
  const matAmb = new Uint8Array(w * h * 4);
  const neutral = Math.round(255 / AMBIENT_PLACE_SCALE);   // encodes to exactly 1.0
  for (let i = 0; i < w * h; i++) { matAmb[i * 4] = mat[i]; matAmb[i * 4 + 1] = amb ? amb[i] : neutral; matAmb[i * 4 + 2] = skip.radius[i]; matAmb[i * 4 + 3] = skip.floorMax[i]; }
  planMatAmb = matAmb;
  materialTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, materialTexture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, matAmb);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  const sourceLayer = options.sourceLayer || new Uint8Array(w * h);
  sourceLayerTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, sourceLayerTexture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, w, h, 0, gl.RED, gl.UNSIGNED_BYTE, sourceLayer);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}

export function r3dSetProps(instances) { P3.setPropInstances(instances); }
let ordinaryDynamicProps=[],nightWarningProps=[],recordingFaceProps=[];
let recordingViewPull=normalizeRecordingViewPull(null);
let recordingViewPullEnabled=true;
export function r3dSetRecordingViewPullEnabled(value=true){recordingViewPullEnabled=value!==false;return recordingViewPullEnabled;}
function submitWorldDynamicProps(){P3.setDynamicPropInstances([...ordinaryDynamicProps,...nightWarningProps,...recordingFaceProps]);}
export function r3dRecordingEmbodimentStatus(){return{count:recordingFaceProps.length,viewPullEnabled:recordingViewPullEnabled,viewPull:structuredClone(recordingViewPull),
  instances:recordingFaceProps.map(p=>({mesh:p.mesh,matrix:Array.from(p.matrix),diagnostics:{...p.diagnostics}}))};}
export function r3dSetDynamicProps(instances) { ordinaryDynamicProps=Array.isArray(instances)?instances:[];submitWorldDynamicProps(); }
export function r3dSetNightWarningProps(instances=[]) { nightWarningProps=Array.isArray(instances)?instances:[];submitWorldDynamicProps();return nightWarningProps.length; }
export function r3dRoofWatcherPresentation() { return P3.roofWatcherPresentation(); }
export function r3dSetDiagnosticProps(instances) { P3.setDiagnosticPropInstances(instances); }
export function r3dSetPropDiagnostics(enabled,options=null) { return P3.setPropDiagnostics(enabled,options); }
export function r3dSetEmergencyShadows(instances) { P3.setEmergencyShadowInstances(instances); }
export function r3dSetSourceTextInstances(instances) { P3.setSourceTextInstances(instances); }
export function r3dSetSourceScene(scene = {}) {
  P3.setSourceScene(scene);
  sourceLook = scene.look && typeof scene.look === 'object'
    ? { sunrise: scene.look.sunrise, chroma: scene.look.chroma, paper: scene.look.paper,
      roomMemoryActive: scene.look.roomMemoryActive===true, blueprint:scene.look.blueprint===true,finish:normalizeSourceFinish(scene.look.finish) }
    : { sunrise: 0, chroma: 1, paper: 0 };
  sourceWeather = scene.weather && typeof scene.weather === 'object'
    ? { rain: scene.weather.rain, moon: scene.weather.moon, clouds: scene.weather.clouds }
    : { rain: 0, moon: 1, clouds: 1 };
}
export function r3dSetSourceFinish(finish='bsod'){
  sourceLook.finish=normalizeSourceFinish(finish);return sourceLook.finish;
}
// Change atmosphere without replacing a Source scene's geometry or input owner.
export function r3dSetSourceWeather(weather={}){
  const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
  sourceWeather={rain:unit(weather.rain),moon:unit(weather.moon),clouds:unit(weather.clouds),leaves:unit(weather.leaves),horizon:unit(weather.horizon),clock:Math.max(0,Number(weather.clock)||0),sunset:weather.sunset?.active?{...weather.sunset,amount:unit(weather.sunset.amount)}:null};
  return {...sourceWeather};
}
export function r3dSetSourceEmergency(value = 0) {
  const strength = value && typeof value === 'object'
    ? (value.enabled === false ? 0 : Number(value.strength ?? 1))
    : Number(value);
  sourceEmergencyStrength = Math.max(0, Math.min(1.5, Number.isFinite(strength) ? strength : 0));
  return sourceEmergencyStrength;
}
// The outskirts' open door frames, as world-metre quads (see renderSourcePortals).
let sourcePortals=[],sourcePortalsDrawn=0;
// The door fields' crossings, and the light their doors leak (runtime
// doorCrossingFrame / doorFieldLeaks). See renderSourceCrossing.
// state: an ordinary building r3dFrame state. yaw/planYaw: the camera to take it
// with. sourceEye (metres) and sourceYaw: where that camera stands in Source,
// looking through the tower door, so the door can put the picture back.
export function r3dCaptureTowerView(state,{yaw:captureYaw=0,pitch:capturePitch=0,planYaw:capturePlanYaw=0,sourceEye=[0,0,0],sourceYaw=0,key='',allowSource=false}={}){
  if(!gl||!uniforms.sceneW||!uniforms.sceneH||!state)return null;
  const w=uniforms.sceneW,h=uniforms.sceneH;
  if(towerViewW!==w||towerViewH!==h){
    for(const t of[towerViewColorTex,towerViewDepthTex])if(t)gl.deleteTexture(t);
    for(const f of[towerViewColorFbo,towerViewDepthFbo])if(f)gl.deleteFramebuffer(f);
    towerViewColorTex=makeTex(w,h);towerViewColorFbo=makeFbo(towerViewColorTex);
    towerViewDepthTex=makeTex(w,h,null,'rgba16f');towerViewDepthFbo=makeFbo(towerViewDepthTex);
    towerViewW=w;towerViewH=h;
  }
  const saved={camX,camY,camZ,yaw,yawTarget,pitch,pitchTarget,planYaw,planYawTarget,leanEase,lightEase,lastT,vfdPreviousX,vfdPreviousZ,vfdMovement};
  yaw=yawTarget=captureYaw;pitch=pitchTarget=capturePitch;
  cameraSnapPending=true;presentTarget={fbo:towerViewColorFbo,width:w,height:h};
  try{
    towerCaptureInProgress=true;
    r3dFrame({...state,yawOffset:capturePlanYaw,lean:0,textSpace:allowSource&&!!state.textSpace,sourceVoidPhysical:allowSource&&!!state.sourceVoidPhysical});
    // The march leaves 1/(1+zView*.14) in the scene's alpha: view depth, metres.
    gl.useProgram(progCopy);gl.bindFramebuffer(gl.FRAMEBUFFER,towerViewDepthFbo);gl.viewport(0,0,w,h);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sceneTex);
    gl.uniform1i(gl.getUniformLocation(progCopy,'uSrc'),0);gl.uniform2f(gl.getUniformLocation(progCopy,'uRes'),w,h);
    gl.drawArrays(gl.TRIANGLES,0,3);
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  }finally{
    towerCaptureInProgress=false;
    presentTarget=null;cameraSnapPending=false;
    ({camX,camY,camZ,yaw,yawTarget,pitch,pitchTarget,planYaw,planYawTarget,leanEase,lightEase,lastT,vfdPreviousX,vfdPreviousZ,vfdMovement}=saved);
    r3dResetVfdMemory();
  }
  towerViewCapture={color:towerViewColorTex,depth:towerViewDepthTex,width:w,height:h,aspect:w/h,
    eye:[...sourceEye].map(Number),yaw:Number(sourceYaw)||0,key:String(key),at:performance.now()};
  if(sourceTowerView)sourceTowerView={...sourceTowerView,capture:towerViewCapture};
  return{width:w,height:h,key:towerViewCapture.key};
}
// A retained threshold borrows the actual departing room, with an authored
// reverse-facing eye. Capturing cannot replace the next ordinary-world frame.
export function r3dCaptureLastBuildingView({camera,sourceEye,sourceYaw=0,key=''}={}){
  if(!lastBuildingViewState||!camera)return null;
  return r3dCaptureTowerView({...lastBuildingViewState,authoredCamera:camera},
    {yaw:camera.yaw,pitch:camera.pitch||0,sourceEye,sourceYaw,key});
}
// Diagnostics: the captured belfry as an image, and what its depth says.
export function r3dTowerViewImage(){
  if(!gl||!towerViewCapture)return null;
  const w=towerViewCapture.width,h=towerViewCapture.height,raw=new Uint8Array(w*h*4);
  gl.bindFramebuffer(gl.FRAMEBUFFER,towerViewColorFbo);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,raw);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d'),img=ctx.createImageData(w,h);
  for(let y=0;y<h;y++){const s=(h-1-y)*w*4;img.data.set(raw.subarray(s,s+w*4),y*w*4);}
  ctx.putImageData(img,0,0);return c.toDataURL('image/png');
}
export function r3dTowerViewDepthStats(){
  if(!gl||!towerViewCapture)return null;
  const w=towerViewCapture.width,h=towerViewCapture.height,raw=new Float32Array(w*h*4);
  gl.bindFramebuffer(gl.FRAMEBUFFER,towerViewDepthFbo);
  try{gl.readPixels(0,0,w,h,gl.RGBA,gl.FLOAT,raw);}catch(error){gl.bindFramebuffer(gl.FRAMEBUFFER,null);return{error:String(error)};}
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  const z=(x,y)=>{const a=raw[(y*w+x)*4+3];return (1/Math.max(a,1e-4)-1)/.14;};
  const samples=[];for(let y=0;y<h;y+=Math.ceil(h/24))for(let x=0;x<w;x+=Math.ceil(w/24))samples.push(z(x,y));
  samples.sort((p,q)=>p-q);
  return{glError:gl.getError(),center:z(w>>1,h>>1),min:samples[0],p50:samples[samples.length>>1],max:samples.at(-1)};
}
export function r3dTowerViewCaptured(){return towerViewCapture?{key:towerViewCapture.key,width:towerViewCapture.width,height:towerViewCapture.height,sceneMatches:towerViewCapture.width===uniforms.sceneW&&towerViewCapture.height===uniforms.sceneH}:null;}
export function r3dClearTowerView(){towerViewCapture=null;sourceTowerView=null;return true;}
// frame: runtime towerDoorView(); null takes the belfry out of the door.
export function r3dSetSourceOpenings(list=[]){sourceOpenings=Array.isArray(list)?list.filter((o)=>Array.isArray(o?.corners)&&o.corners.length===4):[];return sourceOpenings.length;}
export function r3dSetSourceTowerView(frame=null){
  sourceTowerView=frame&&towerViewCapture&&(frame.id==null||frame.id===towerViewCapture.key)&&Array.isArray(frame.corners)&&Array.isArray(frame.origin)&&Array.isArray(frame.forward)
    ?{...frame,capture:towerViewCapture}:null;
  return !!sourceTowerView;
}
export function r3dSourceTowerViewStats(){return{captured:!!towerViewCapture,submitted:!!sourceTowerView,drawn:sourceTowerViewDrawn,
  capture:towerViewCapture?{eye:towerViewCapture.eye,yaw:towerViewCapture.yaw,width:towerViewCapture.width,height:towerViewCapture.height,key:towerViewCapture.key}:null};}
export function r3dSetSourceCrossing(frame=null){sourceCrossing=frame&&Number.isFinite(Number(frame.reveal))?frame:null;if(!sourceCrossing)P3.resetSourceRealmEye?.();return !!sourceCrossing;}
// The face alone needs the cabinet's material exposure. The old opaque wall
// painting needed a much higher gain and washed the face's shading away.
let tableauSource=null,tableauTex=null,tableauGain=1.15,progTableau=null,tableauDrawn=0,tableauPlane=null,tableauPanels=[];
export function r3dSetTableau(source=null,{gain=null,plane=null,panels=[]}={}){
  tableauSource=source||null;
  tableauPlane=source&&plane?plane:null;
  tableauPanels=source?panels.filter(panel=>panel?.source&&panel?.plane):[];
  if(gain!=null)tableauGain=Math.max(0,Number(gain)||0);
  return !!tableauSource;
}
export function r3dSetTableauGain(value=1){tableauGain=Math.max(0,Number(value)||0);return tableauGain;}
export function r3dTableauStats(){return {active:!!tableauSource,spatial:!!tableauPlane,panels:tableauSource?1+tableauPanels.length:0,gain:tableauGain,drawn:tableauDrawn};}
function drawTableau(){
  if(!tableauSource||!gl||!sceneFbo)return false;
  drawTableauPanel(tableauSource,tableauPlane);
  for(const panel of tableauPanels)drawTableauPanel(panel.source,panel.plane);
  return true;
}
function drawTableauPanel(source,plane){
  if(!progTableau)progTableau=program(TABLEAU_FRAG);
  if(!tableauTex){
    tableauTex=gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D,tableauTex);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  }
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D,tableauTex);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,gl.RGBA,gl.UNSIGNED_BYTE,source);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  // Only the face's covered fragments replace the world's material marks.
  // The clear parts preserve both the 3D booth and everything seen through it.
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
  gl.bindVertexArray(null);
  gl.useProgram(progTableau);
  gl.uniform1i(gl.getUniformLocation(progTableau,'uTableau'),0);
  gl.uniform2f(gl.getUniformLocation(progTableau,'uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.uniform1f(gl.getUniformLocation(progTableau,'uGain'),tableauGain);
  const targets=P3.propTargets();
  const basis=cameraBasis(yaw+planYaw,pitch);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,targets.depth);
  gl.uniform1i(gl.getUniformLocation(progTableau,'uPropDepth'),1);
  gl.uniform2f(gl.getUniformLocation(progTableau,'uNearFar'),targets.near,targets.far);
  gl.uniform1f(gl.getUniformLocation(progTableau,'uSpatial'),plane?1:0);
  gl.uniform3f(gl.getUniformLocation(progTableau,'uEye'),camX*CELL,camY*CELL,camZ*CELL);
  for(const [name,value] of [['uForward',basis.forward],['uCameraRight',basis.right],['uCameraUp',basis.up],
    ['uPlaneOrigin',plane?.origin||[0,0,0]],['uPlaneRight',plane?.right||[1,0,0]],['uPlaneUp',plane?.up||[0,1,0]]])
    gl.uniform3fv(gl.getUniformLocation(progTableau,name),value);
  gl.uniform2f(gl.getUniformLocation(progTableau,'uPlaneSize'),plane?.width||1,plane?.height||1);
  gl.drawArrays(gl.TRIANGLES,0,3);
  tableauDrawn+=1;
  return true;
}
export function r3dSetSourceDoorLights(list=[]){
  sourceDoorLights=(Array.isArray(list)?list:[]).filter((leak)=>leak&&Number.isFinite(leak.x)&&Number.isFinite(leak.z)
    &&Array.isArray(leak.forward)&&Array.isArray(leak.colour)).slice(0,3);
  return sourceDoorLights.length;
}
export function r3dSourceCrossingStats(){return{active:!!sourceCrossing,drawn:sourceCrossingDrawn,lights:sourceDoorLights.length};}
export function r3dSetSourcePortals(list=[]){sourcePortals=Array.isArray(list)?list:[];return sourcePortals.length;}
export function r3dSourcePortalStats(){return{submitted:sourcePortals.length,drawn:sourcePortalsDrawn,programReady:P3.sourcePortalProgramReady?.()??null};}
export function r3dSetSourceWhiteout(value = 0) {
  sourceWhiteoutStrength = Math.max(0, Math.min(1, Number(value) || 0));
  return sourceWhiteoutStrength;
}
export function r3dSetHushProp(id) { P3.setHushProp(id); }
export function r3dPropStats() { return P3.propPackStats(); }
export function r3dStBrendansTreatmentStats() { return P3.stBrendansTreatmentStats(); }
export function r3dStBrendansPresenceStats() { return P3.stBrendansPresenceStats(); }
export function r3dStreetPilotReady() { return streetPilotReady; }
export function r3dOpeningStreetReady() { return openingStreetReady; }
export function r3dGlassCourtReady() { return glassCourtReady; }
export function r3dStreetFabricReady() { return streetFabricReady; }
export function r3dYardJardinsReady() { return yardJardinsBoundaryReady; }
export function r3dElleryPublicFrontReady() { return elleryPublicFrontReady; }
export function r3dStationersReady() { return ['ellery_square_west_terrace_stationer','exterior_stationers_room'].every(name=>P3.propMeshCatalog().includes(name)); }
export function r3dAcademicGalleryStatus() { return {ready:academicGalleryReady,error:academicGalleryError}; }
export function r3dPropInstanceIds() { return P3.propInstanceIds(); }
export function r3dPropCatalog() { return P3.propMeshCatalog(); }

// Rasterise only exact corpus lines into the material atlas. The texture is a
// data source for albedo, glyph-edge normals and roughness; source materials do
// not sample the conventional surface arrays.
export function r3dSetSourceSurface(lines = []) {
  if(!gl||typeof document==='undefined')return false;
  if(!sourceSurfaceBaker){
    const context=gl;
    sourceSurfaceBaker=createSourceSurfaceLetteringBaker({assetUrl,
      onReady(bitmap){
        if(gl!==context)return;
        if(sourceSurfaceTexture)context.deleteTexture(sourceSurfaceTexture);
        sourceSurfaceTexture=context.createTexture();context.bindTexture(context.TEXTURE_2D,sourceSurfaceTexture);
        // The helper has already flipped raw rows. Typed-array uploads do not
        // obey UNPACK_FLIP_Y, and alpha must retain authored pigment coverage.
        context.pixelStorei(context.UNPACK_FLIP_Y_WEBGL,false);context.pixelStorei(context.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
        context.texImage2D(context.TEXTURE_2D,0,context.RGBA8,bitmap.width,bitmap.height,0,context.RGBA,context.UNSIGNED_BYTE,bitmap.pixels);
        context.generateMipmap(context.TEXTURE_2D);context.texParameteri(context.TEXTURE_2D,context.TEXTURE_MIN_FILTER,context.LINEAR_MIPMAP_LINEAR);
        context.texParameteri(context.TEXTURE_2D,context.TEXTURE_MAG_FILTER,context.LINEAR);context.texParameteri(context.TEXTURE_2D,context.TEXTURE_WRAP_S,context.REPEAT);
        context.texParameteri(context.TEXTURE_2D,context.TEXTURE_WRAP_T,context.REPEAT);
        sourceSurfaceDiagnostics={key:bitmap.key,fontKey:bitmap.fontKey,width:bitmap.width,height:bitmap.height,rowOrigin:bitmap.rowOrigin,
          rows:bitmap.rows.map(({layer,row,text,fontSize,fits})=>({layer,row,text,fontSize,fits}))};
      },onError:error=>console.warn('Source surface lettering unavailable',error)});
  }
  return sourceSurfaceBaker.request(lines);
}
export function r3dSourceSurfaceLetteringStatus(){return{...sourceSurfaceBaker?.status(),raster:sourceSurfaceDiagnostics};}

// A mutation touched a few cells: re-upload only those.
export function r3dPatchPlan(rgba, materialOrX, xOrY, yOrW, wOrH, maybeH) {
  if (!gl || !planTexture) return;
  const hasMaterial = materialOrX && typeof materialOrX !== 'number';
  const material = hasMaterial ? materialOrX : null;
  const x = hasMaterial ? xOrY : materialOrX;
  const y = hasMaterial ? yOrW : xOrY;
  const w = hasMaterial ? wOrH : yOrW;
  const h = hasMaterial ? maybeH : wOrH;
  const sub = new Uint8Array(w * h * 4);
  for (let ry = 0; ry < h; ry++) {
    const src = ((y + ry) * planW + x) * 4;
    sub.set(rgba.subarray(src, src + w * 4), ry * w * 4);
  }
  gl.bindTexture(gl.TEXTURE_2D, planTexture);
  gl.texSubImage2D(gl.TEXTURE_2D, 0, x, y, w, h, gl.RGBA, gl.UNSIGNED_BYTE, sub);
  if (materialTexture && planMatAmb) {
    // The texture is RGBA8 now, so this cannot upload RED — the format has to
    // match the internal format's base format or the call throws. Patching from
    // the retained packed buffer also keeps the baked ambient in G intact: a
    // mutation moves a wall, it does not relight the building.
    //
    // The open-ground radius cannot be patched in place: a moved wall breaks
    // every square that reached it. Every cell whose square could reach the
    // patch forgets its radius instead (zero is always safe), until the next
    // full upload measures the field again.
    const r = PLAN_SKIP_RADIUS_MAX;
    const ex = Math.max(0, x - r), ey = Math.max(0, y - r);
    const ew = Math.min(planW, x + w + r) - ex, eh = Math.min(planH, y + h + r) - ey;
    const mats = new Uint8Array(ew * eh * 4);
    for (let ry = 0; ry < eh; ry++) {
      for (let rx = 0; rx < ew; rx++) {
        const cx = ex + rx, cy = ey + ry, src = cy * planW + cx, dst = (ry * ew + rx) * 4;
        if (material && cx >= x && cx < x + w && cy >= y && cy < y + h) planMatAmb[src * 4] = material[src];
        planMatAmb[src * 4 + 2] = 0;
        mats.set(planMatAmb.subarray(src * 4, src * 4 + 4), dst);
      }
    }
    gl.bindTexture(gl.TEXTURE_2D, materialTexture);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, ex, ey, ew, eh, gl.RGBA, gl.UNSIGNED_BYTE, mats);
  }
}

export function r3dUpdateFog(fogGet, px, py) {
  // Retained as a compatibility no-op for the 2D exploration map. The 3D
  // architecture and prop passes receive a permanently clear texture.
  fogOrigin = [px - FOG_TEX / 2, py - FOG_TEX / 2];
}

// ── Collision mirror of the GLSL architecture (uint math: exact parity) ─────
// Every branch here must match solidCell() in MARCH_FRAG exactly, or the
// player walks through drawn walls / into invisible ones.
const CEIL = 3.2 / CELL, BLOCK = 6 * PLAN_SCALE, LANE = 2 * PLAN_SCALE;
let lastBeacons = { key: null, door: null };
function ihashJs(a) {
  a = a >>> 0;
  a ^= a >>> 16; a = Math.imul(a, 0x7feb352d) >>> 0;
  a ^= a >>> 15; a = Math.imul(a, 0x846ca68b) >>> 0;
  a ^= a >>> 16; return a >>> 0;
}
function ihash2Js(x, y) {
  return ihashJs(((Math.imul(x | 0, 1597334677) >>> 0) ^ (Math.imul(y | 0, 2891336453 | 0) >>> 0)) >>> 0);
}
function isExpanseJs(cx, cz) {
  const mx = Math.floor(cx / (BLOCK * 3)), mz = Math.floor(cz / (BLOCK * 3));
  return ihash2Js(mx + 404, mz + 909) % 100 < 22;
}
export function r3dSolid(x, y) {
  const cx = Math.floor(x), cz = Math.floor(y);
  if (isExpanseJs(cx, cz)) return false;
  const bx = Math.floor(cx / BLOCK), bz = Math.floor(cz / BLOCK);
  const lx = cx - bx * BLOCK, lz = cz - bz * BLOCK;
  if (lx < LANE || lz < LANE) return false;
  if (ihash2Js(bx, bz) % 10 < 4) return false;
  const ccx = cx + 0.5, ccz = cz + 0.5;
  for (const b of [lastBeacons.key, lastBeacons.door]) {
    if (b && ((ccx - b.x) ** 2 + (ccz - b.y) ** 2) < 4.0) return false;
  }
  return true;
}
export function r3dIsExpanse(x, y) { return isExpanseJs(Math.floor(x), Math.floor(y)); }

function resetWaterField() {
  if (!gl || !waterFboA || !waterFboB) return;
  const previous = gl.getParameter(gl.FRAMEBUFFER_BINDING);
  gl.clearColor(0.5, 0.5, 0, 1);
  for (const fbo of [waterFboA, waterFboB]) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.clear(gl.COLOR_BUFFER_BIT);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, previous);
  waterFlip = false;
}

let waterRainSeed = 0;
function updateWaterField(water, dt) {
  const active = !!water?.active;
  if (active !== waterWasActive) {
    resetWaterField();
    waterWasActive = active;
  }
  if (!gl || !progWater || !waterTexA || !waterTexB || !active) return waterFlip ? waterTexB : waterTexA;
  const src = waterFlip ? waterTexB : waterTexA;
  const dst = waterFlip ? waterFboA : waterFboB;
  gl.useProgram(progWater);
  gl.bindFramebuffer(gl.FRAMEBUFFER, dst);
  gl.viewport(0, 0, WATER_W, WATER_H);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, src);
  const waterU = (name) => {
    if (!waterUniformCache.has(name)) waterUniformCache.set(name, gl.getUniformLocation(progWater, name));
    return waterUniformCache.get(name);
  };
  gl.uniform1i(waterU('uPrev'), 0);
  gl.uniform2f(waterU('uTexel'), 1 / WATER_W, 1 / WATER_H);
  gl.uniform1f(waterU('uDt'), Math.max(0.05, Math.min(1.6, dt * 60)));
  gl.uniform1f(waterU('uDamping'), 0.985);
  gl.uniform1f(waterU('uReduceMotion'), water.reduceMotion ? 1 : 0);
  const rawSources = Array.isArray(water.rippleSources) ? water.rippleSources : [];
  const n = Math.min(MAX_WATER_SOURCES, rawSources.length);
  const packed = waterPackedScratch;
  for (let i = 0; i < n; i += 1) {
    const source = rawSources[i] || {};
    packed.set([
      Math.max(0, Math.min(1, Number(source.u) || 0)),
      Math.max(0, Math.min(1, Number(source.v) || 0)),
      Math.max(-0.5, Math.min(0.5, Number(source.strength) || 0)),
      Math.max(0.015, Math.min(0.75, Number(source.radius) || 0.1)),
    ], i * 4);
  }
  gl.uniform1i(waterU('uSourceCount'), n);
  gl.uniform1f(waterU('uRainDrops'), water.outdoor ? Math.max(0, Math.min(1, Number(water.rainAmount ?? rainAmount) || 0)) : 0);
  gl.uniform1f(waterU('uRainSeed'), (waterRainSeed = (waterRainSeed + 1) % 4096));
  gl.uniform4fv(waterU('uSources[0]'), packed);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  waterFlip = !waterFlip;
  return waterFlip ? waterTexB : waterTexA;
}

// state: { px, py, tileW, tileH, worldCount, worldTints:[[r,g,b]×5],
//          chunks:[{x,y,r,act,col}], key:{x,y}|null, door:{x,y}|null,
//          hush:{x,y,strength}|null, dockHauntingFade:0..1, audio:0..1 }
export function r3dFrame(state) {
  if(state.textSpace||state.sourceVoidPhysical||state.driveStudy?.active||state.boothTelevisionSuspended||state.paused)boothTelevision?.suspend();
  P3.setGlassCourtRainFrame?.(state.glassCourtRain?.shader||null);
  natatoriumMetric=normalizeNatatoriumMetric(!pixelMeshSettings.reduceMotion&&!state.authoredCamera&&!state.textSpace&&!state.sourceVoidPhysical&&!state.driveStudy?.active&&!towerCaptureInProgress&&!sourceTowerView&&!sourceCrossing
    ?state.natatoriumCoffeeMetric:null);
  P3.setNatatoriumMetricFrame(natatoriumMetric);
  if(!towerCaptureInProgress&&!state.textSpace&&!state.sourceVoidPhysical)lastBuildingViewState=state;
  driveFrameActive=state?.driveStudy?.active===true;
  if(!driveFrameActive)P3.setDriveStudyFrame(null);
  if (!gl) return;
  pressureFinishReady=false;
  const snapCamera = cameraSnapPending;
  cameraSnapPending = false;
  lastBeacons = { key: state.key || null, door: state.door || null };
  const now = performance.now() / 1000;
  const dt = Math.min(0.1, now - (lastT || now));
  lastT = now;
  // The application loop owns engraving work, including while the world is not
  // drawn. Spending another budget here doubles its cost on ordinary frames and
  // bypasses the loop's startup and Source throttling. Standalone renderer
  // clients that stream material banks must call r3dDrainMarkFields themselves.

  // main.js supplies a frame-interpolated physical player position. The camera
  // is that position—never a follower with its own lag or acceleration state.
  const authoredCamera=authoredCameraFrame(state.authoredCamera);
  activeCameraTanHalfFov=(driveFrameActive ? .65 : cinematicTanHalfFov(authoredCamera?.lens))/catchZoom;
  P3.setFrameCameraTanHalfFov(activeCameraTanHalfFov);
  cinematicLensPass?.inactive();
  const nextCamX=authoredCamera?authoredCamera.eye[0]/CELL:state.px+0.5, nextCamZ=authoredCamera?authoredCamera.eye[2]/CELL:state.py+0.5;
  const travel=vfdPreviousX==null?0:Math.hypot(nextCamX-vfdPreviousX,nextCamZ-vfdPreviousZ);
  if(snapCamera || travel>1.25)r3dResetVfdMemory();
  vfdMovement=Math.max(0,Math.min(1,travel/Math.max(dt*3.0,0.001)));
  vfdPreviousX=nextCamX;vfdPreviousZ=nextCamZ;
  camX=nextCamX;
  camZ=nextCamZ;
  if(authoredCamera||snapCamera)r3dCancelMouseLookGlide();else advanceMouseLookGlide(dt);
  yaw = authoredCamera ? authoredCamera.yaw : snapCamera ? yawTarget : yaw + (yawTarget - yaw) * (1 - Math.exp(-dt * 12));
  planYawTarget = authoredCamera ? 0 : Number(state.yawOffset) || 0;
  // Shortest way round, so crossing the atan2 branch does not spin the camera.
  const planYawDelta = Math.atan2(Math.sin(planYawTarget - planYaw), Math.cos(planYawTarget - planYaw));
  planYaw = authoredCamera ? 0 : snapCamera || state.resolvedStairFloor===true ? planYawTarget : planYaw + planYawDelta * (1 - Math.exp(-dt * 9));
  const worldYaw = yaw + planYaw;
  // LEANING OUT OF COVER MOVES THE EYE AND NOTHING ELSE.
  //
  // It goes in here, after the camera has been placed from state.px/py and after
  // the VFD travel above has been measured off the BODY. Doing it in main.js by
  // shifting the rendered point instead would be quietly wrong: that same point
  // keys the render-slice cache and the prop-group rebuild, and feeds the audio
  // listener, so a man leaning his head would reload the world and walk his own
  // ears across the room.
  //
  // The offset is along the camera's own right vector — the same `rgt` the march
  // builds at vec3(cos yaw, 0, sin yaw) — so it propagates for free to the
  // raymarch, the prop and shadow passes, pixel-mesh, and r3dProjectWorld, which
  // is why world-anchored HUD tracks the lean without being told.
  const leanGoal = authoredCamera ? 0 : Number(state.lean) || 0;
  leanEase = authoredCamera || snapCamera ? leanGoal : leanEase + (leanGoal - leanEase) * (1 - Math.exp(-dt * 11));
  if (leanEase) {
    camX += leanEase * Math.cos(worldYaw);
    camZ += leanEase * Math.sin(worldYaw);
  }
  pitch = authoredCamera ? authoredCamera.pitch : snapCamera ? pitchTarget : pitch + (pitchTarget - pitch) * (1 - Math.exp(-dt * 14));
  // Eye height above whatever floor you are standing on. Eased, so a stair is
  // a climb rather than a series of teleports.
  const floorGoal = authoredCamera ? authoredCamera.eye[1]/CELL : ((state.floorH ?? 0) + EYE_METERS) / CELL;
  // The drive already supplies the physical cabin/head suspension response.
  // Easing that eye again lets the driver drift through the moving cabin.
  camY = authoredCamera || snapCamera || driveFrameActive || state.resolvedStairFloor===true ? floorGoal : camY + (floorGoal - camY) * (1 - Math.exp(-dt * 14));
  // Resolve the close presence against this exact eye, after lean and look.
  // It shares ordinary world depth/material and the final acquisition pass.
  const faceProps=recordingEmbodimentInstances(state.recordingEmbodiment,{
    eye:[camX*CELL,camY*CELL,camZ*CELL],yaw:worldYaw,pitch,
    tanHalfFov:activeCameraTanHalfFov,width:canvas.width,height:canvas.height,
  });
  recordingViewPull=normalizeRecordingViewPull(recordingEmbodimentViewPull(state.recordingEmbodiment,{
    eye:[camX*CELL,camY*CELL,camZ*CELL],yaw:worldYaw,pitch,
    tanHalfFov:activeCameraTanHalfFov,width:canvas.width,height:canvas.height,
  }));
  if(faceProps.length||recordingFaceProps.length){recordingFaceProps=faceProps;submitWorldDynamicProps();}
  // A flashlight snaps. The only easing is a filament's breath on the way out.
  const lightGoal = typeof state.light === 'number'
    ? Math.max(0, Math.min(1, state.light))
    : state.light === false ? 0 : 1;
  lightEase += (lightGoal - lightEase) * (1 - Math.exp(-dt * (lightGoal ? 90 : 45)));
  if (Math.abs(lightGoal - lightEase) < 0.004) lightEase = lightGoal;
  const torch=state.torchLook||{};
  const torchPower=lightEase*Math.max(0,Math.min(1,Number(torch.power??1)||0));
  const sourceTorchMode=torch.sourceTorchMode==='xray'?1:torch.sourceTorchMode==='emergency'?2:0;
  const torchColor=Array.isArray(torch.color)?torch.color:[1,.94,.82];
  const {reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder}=normalizeTorchOptics(torch);
  const torchYawOffset=Math.max(-.4,Math.min(.4,Number(torch.yawOffset)||0));
  const torchFrame=resolveRecorderLamp({eye:[camX*CELL,camY*CELL,camZ*CELL],yaw:worldYaw,pitch,yawOffset:torchYawOffset,lamp:authoredCamera||driveFrameActive?null:state.recorderLamp});
  renderedTorchDiagnostic={power:torchPower,inputPower:Math.max(0,Math.min(1,Number(torch.power??1)||0)),
    lightEase,color:[...torchColor],reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder,
    origin:[...torchFrame.origin],forward:[...torchFrame.forward],sourceTorchMode,yawOffset:torchYawOffset,timeSec:now};
  const opticalEffects=visualEffectsEnabled()?1:0;
  const sensoryProfile=String(state.sensoryProfile||'story');
  const hushSense=sensoryProfile==='hush-prowl'?1:sensoryProfile==='hush-listen'?.75:0;
  const sourceRepriseSense=sensoryProfile==='source-reprise';
  const frameAmbientColor=hushSense>0?HUSH_AMBIENT_COLOR:sourceRepriseSense?SOURCE_REPRISE_AMBIENT_COLOR:lightingAmbientColor;
  const baseAmbientIntensity=hushSense>0
    ?Math.max(lightingAmbientIntensity,.24)
    :sourceRepriseSense?Math.max(lightingAmbientIntensity,.11):lightingAmbientIntensity;
  // Twelve times ambient at full strike. Interiors run .014-.043 and the bay
  // runs .155, so this is the difference between a room you are feeling your
  // way around and one you can read a work order in — for eighty milliseconds.
  const frameAmbientIntensity=baseAmbientIntensity*(1+stormFlash*6)+(state.workOrderRoomFill||0);

  // Keep the gameplay presence authoritative while giving only its drawing a
  // short material resolve. Despawn keeps the last world position long enough
  // to dissolve there; it does not retain collision, pursuit or awareness.
  // The caught performer's presentation may outlive its gameplay despawn by
  // one existing contact beat. Only an explicitly committed exposure can cross
  // ordinary actor suppression; the actual world root/pose stays captured.
  const exposureHush=outcomeExposure.resolve(state.hush,{reduceFlash:!!pixelMeshSettings.reduceFlash});
  const hushBodyRenderAllowed=state.hushBodyAllowed!==false||!!exposureHush;
  const incomingHush=exposureHush||(hushBodyRenderAllowed&&state.hush&&Number.isFinite(state.hush.x)&&Number.isFinite(state.hush.y)
    ? state.hush
    : null);
  const incomingHushSecondary=state.hushBodyAllowed!==false&&state.hushSecondary
    &&Number.isFinite(state.hushSecondary.x)&&Number.isFinite(state.hushSecondary.y)
    ?state.hushSecondary:null;
  if(incomingHush){
    hushBodyLast={
      ...incomingHush,
      x:Number(incomingHush.x),
      y:Number(incomingHush.y),
      strength:Math.max(0,Math.min(1,Number(incomingHush.strength)||0)),
      heightM:Math.max(1.2,Math.min(2.4,Number(incomingHush.heightM)||1.83)),
      widthM:Math.max(.35,Math.min(1.0,Number(incomingHush.widthM)||.58)),
      glow:Number.isFinite(Number(incomingHush.glow))?Math.max(.4,Math.min(3.2,Number(incomingHush.glow))):null,
      mode:typeof incomingHush.mode==='string'?incomingHush.mode:null,
      floorH:Number.isFinite(Number(incomingHush.floorH))?Number(incomingHush.floorH):0,
    };
  }
  if(incomingHushSecondary){
    hushBodySecondaryLast={
      ...incomingHushSecondary,
      floorH:Number.isFinite(Number(incomingHushSecondary.floorH))?Number(incomingHushSecondary.floorH):0,
      x:Number(incomingHushSecondary.x),
      y:Number(incomingHushSecondary.y),
      strength:Math.max(0,Math.min(1,Number(incomingHushSecondary.strength)||0)),
      heightM:Math.max(1.2,Math.min(2.4,Number(incomingHushSecondary.heightM)||1.83)),
      widthM:Math.max(.35,Math.min(1.0,Number(incomingHushSecondary.widthM)||.58)),
      glow:Number.isFinite(Number(incomingHushSecondary.glow))?Math.max(.4,Math.min(3.2,Number(incomingHushSecondary.glow))):null,
      mode:typeof incomingHushSecondary.mode==='string'?incomingHushSecondary.mode:null,
    };
  }
  const surfacesTarget=(surfAlbedoTex&&surfNormalTex&&surfMaterialTex)?1:0;
  // Slower than the hush body on the way in: this is a whole building's worth of
  // surface changing, and it should read as the light finding the material, not
  // as a cut. Instant on the way out, because losing the textures is a fault.
  surfacesManifestation+= surfacesTarget
    ? (surfacesTarget-surfacesManifestation)*(1-Math.exp(-dt*1.35))
    : (surfacesTarget-surfacesManifestation);
  if(Math.abs(surfacesTarget-surfacesManifestation)<.002)surfacesManifestation=surfacesTarget;
  // Simulation/replay owns fades and pose time; rendering never advances them.
  hushBodyManifestation=incomingHush?(incomingHush.performance?.manifestation??1):0;
  hushBodySecondaryManifestation=incomingHushSecondary?(incomingHushSecondary.performance?.manifestation??1):0;
  // A charted Source can show the same authoritative actor through an actual
  // aperture with a full rigid root matrix. The ordinary world retains its
  // captured-pressure factory; the borrowed scene owns these bounded views.
  const pressureDraws=(Array.isArray(state.sourcePressureInstances)
    ?hushBodyMode==='off'?[]:state.sourcePressureInstances.slice(0,4)
    :pressureInstances(incomingHush,incomingHushSecondary,{mode:hushBodyMode,reducedMotion:!!pixelMeshSettings.reduceMotion,reduceFlash:!!pixelMeshSettings.reduceFlash}));
  const resolvedPressureDraws=HUSH_MOTION_STUDY_DEV&&hushMotionStudyInstance
    ?pressureDraws.map(instance=>instance.id===hushMotionStudyInstance.id?hushMotionStudyInstance:instance):pressureDraws;
  P3.setPressureInstances(resolvedPressureDraws);
  P3.setPressureSurfaceInstances(pressureSurfaceInstances(resolvedPressureDraws));
  pressureSceneDepthReady=false;
  P3.prepareCharacterFrame(now);
  P3.renderPressurePass({camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,yaw:worldYaw,pitch,timeSec:now,reducedMotion:!!pixelMeshSettings.reduceMotion});

  gl.disable(gl.DEPTH_TEST);
  textSpaceActive = !!state.textSpace;
  const roomMemoryFlag = textSpaceActive&&sourceLook.roomMemoryActive?'true':'false';
  if(canvas.dataset.sourceRoomMemory!==roomMemoryFlag)canvas.dataset.sourceRoomMemory=roomMemoryFlag;
  sourceVoidPhysicalActive=!!state.sourceVoidPhysical;
  sourceVoidDawn=Math.max(0,Math.min(1,Number(state.sourceVoidDawn)||0));
  sourceVoidBeacon=state.sourceVoidBeacon&&Number.isFinite(state.sourceVoidBeacon.bearing)?state.sourceVoidBeacon:null;
  sourceVoidRain=Math.max(0,Math.min(1,Number(state.sourceVoidRain)||0));
  sourceRainShelter=state.sourceRainShelter||null;
  sourceBusLighting=state.sourceBusLighting||null;
  sourceBusInterior=state.sourceBusInterior||null;
  if(canvas.dataset.sourceVoidPhysical!==(sourceVoidPhysicalActive?'true':'false'))canvas.dataset.sourceVoidPhysical=sourceVoidPhysicalActive?'true':'false';

  // Beyond the telephone street, its physical props and recorded splats share
  // one camera, ground and gradually failing image. The building's raymarch
  // is bypassed; the existing street's post look dissolves progressively too.
  if (SHORE.sourceShoreRenderActive(sourceShoreState)) {
    drawSourceShore(now,{voidState:state,worldYaw,torchPower,torchColor,torchReach,
      torchConeInner,torchConeOuter,torchSpill,torchShoulder,
      torchYawOffset,lampFrame:torchFrame});
    return;
  }

  if(sourceVoidPhysicalActive){
    drawSourceVoidPhysical(now,{voidState:state,worldYaw,torchPower,torchColor,torchReach,torchConeInner,torchConeOuter,torchSpill,sourceTorchMode,torchYawOffset,lampFrame:torchFrame});
    return;
  }

  if (textSpaceActive) {
    P3.renderPropPass({
      camX: camX * CELL, camY: camY * CELL, camZ: camZ * CELL,
      maxDistance:authoredCamera?Math.max(90,Math.min(320,Number(state.authoredPropRange)||90)):90,
      yaw: worldYaw, pitch, torchYawOffset, light: torchPower, fogTexture, fogOrigin, fogSize: FOG_TEX,
      timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,lampFrame:torchFrame,
      sourceRoomLighting:sourceLook.roomMemoryActive===true,
      cellMeters: CELL, zoneTints: ZONE_TINTS,
      localLightCount, localLightPositions, localLightColors, localLightPenetrations, localLightEmergency,
      localLightDirections,localLightConeInner,localShadowIndex,shadowLight:localShadowLight,
      torch:{power:torchPower,color:torchColor,reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder},
      ambientColor:lightingAmbientColor,ambientIntensity:frameAmbientIntensity,
      planTexture,planSize:[planW,planH],planOrigin:[planOriginX,planOriginY],
    });
    sourceTowerViewDrawn=sourceTowerView&&P3.renderSourceTowerView
      ?P3.renderSourceTowerView({camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,yaw:worldYaw,pitch,view:sourceTowerView,inside:false}):0;
    if(sourceOpenings.length)P3.renderSourceOpenings?.({camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,yaw:worldYaw,pitch,openings:sourceOpenings});
    drawTextSpace(P3.propTargets().color,now,{torchPower,sourceTorchMode,torchColor,torchReach,
      torchConeInner,torchConeOuter,torchSpill,torchShoulder,torchYawOffset,worldState:state,lampFrame:torchFrame});
    return;
  }

  // reaction-diffusion: 2 steps/frame, audio drives feed/kill drift
  gl.useProgram(progRD);
  gl.viewport(0, 0, RD_SIZE, RD_SIZE);
  // seed frames need many iterations to settle into structure; steady state
  // only needs a couple to keep crawling
  const rdSteps = rdWarm < 400 ? 12 : 2;
  rdWarm += rdSteps;
  const rdPrevU = rdUniformCache.get('uPrev') ?? (rdUniformCache.set('uPrev', gl.getUniformLocation(progRD, 'uPrev')), rdUniformCache.get('uPrev'));
  const rdFeedU = rdUniformCache.get('uFeed') ?? (rdUniformCache.set('uFeed', gl.getUniformLocation(progRD, 'uFeed')), rdUniformCache.get('uFeed'));
  const rdKillU = rdUniformCache.get('uKill') ?? (rdUniformCache.set('uKill', gl.getUniformLocation(progRD, 'uKill')), rdUniformCache.get('uKill'));
  for (let i = 0; i < rdSteps; i++) {
    const src = rdFlip ? rdTexB : rdTexA;
    const dst = rdFlip ? rdFboA : rdFboB;
    gl.bindFramebuffer(gl.FRAMEBUFFER, dst);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, src);
    gl.uniform1i(rdPrevU, 0);
    gl.uniform1f(rdFeedU, 0.037 + state.audio * 0.012);
    gl.uniform1f(rdKillU, 0.06 - state.audio * 0.004);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    rdFlip = !rdFlip;
  }
  const rdTex = rdFlip ? rdTexB : rdTexA;
  // mipmap the RD field: without it, minified samples on distant walls and
  // floors shimmer into salt-and-pepper as the camera moves
  gl.bindTexture(gl.TEXTURE_2D, rdTex);
  gl.generateMipmap(gl.TEXTURE_2D);
  const waterTex = updateWaterField(state.water, dt);
  boothTelevision?.update({eye:[camX*CELL,camY*CELL,camZ*CELL],now,active:!textSpaceActive&&!sourceVoidPhysicalActive&&!driveFrameActive&&!state.boothTelevisionSuspended&&!state.paused});

  P3.renderPropPass({
    camX: camX * CELL, camY: camY * CELL, camZ: camZ * CELL,
    yaw: worldYaw, pitch, light: torchPower, fogTexture, fogOrigin, fogSize:FOG_TEX,
    maxDistance:authoredCamera?Math.max(90,Math.min(260,Number(state.authoredPropRange)||90)):90,
    timeSec:now,reducedMotion:pixelMeshSettings.reduceMotion,lampFrame:torchFrame,
    cellMeters:CELL, zoneTints:ZONE_TINTS,
    localLightCount,localLightPositions,localLightColors,localLightPenetrations,localLightEmergency,
    localLightDirections,localLightConeInner,localShadowIndex,shadowLight:localShadowLight,
    torch:{power:torchPower,color:torchColor,reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill,shoulder:torchShoulder},
    ambientColor:frameAmbientColor,ambientIntensity:frameAmbientIntensity,
    planTexture,planSize:[planW,planH],planOrigin:[planOriginX,planOriginY],
    academicAtriumLight:lightingAcademicAtriumLight,
  });

  // A physical threshold in the building can borrow the same captured-world
  // opening as the belfry. The plane writes depth into the ordinary prop pass,
  // so the wall behind it cannot flatten the receiving world's geometry.
  sourceTowerViewDrawn=sourceTowerView&&P3.renderSourceTowerView
    ?P3.renderSourceTowerView({camX:camX*CELL,camY:camY*CELL,camZ:camZ*CELL,yaw:worldYaw,pitch,view:sourceTowerView,inside:false}):0;

  // march into low-res scene buffer
  gl.useProgram(progMarch);
  pressureSceneDepthReady=true;
  gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFbo);
  gl.viewport(0, 0, uniforms.sceneW, uniforms.sceneH);
  const U = (n) => {if(!marchUniformCache.has(n))marchUniformCache.set(n,gl.getUniformLocation(progMarch,n));return marchUniformCache.get(n);};
  gl.uniform2f(U('uRes'), uniforms.sceneW, uniforms.sceneH);
  gl.uniform1f(U('uTime'), now);
  bindStillnessPresentation(gl,U);
  gl.uniform3f(U('uCam'), camX, camY, camZ);
  gl.uniform4fv(U('uNatatoriumMetric'),natatoriumMetricUniform(natatoriumMetric));
  gl.uniform1f(U('uYaw'), worldYaw);
  gl.uniform1f(U('uPitch'), pitch);
  gl.uniform1f(U('uCameraTanHalfFov'),activeCameraTanHalfFov);
  const b3Eye=[camX*CELL,camY*CELL,camZ*CELL];
  const b3Near=!!state.studioB3Glass&&b3Eye[0]>5&&b3Eye[0]<25&&b3Eye[2]>5&&b3Eye[2]<20&&b3Eye[1]>-3.9&&b3Eye[1]<-.8;
  if(b3Near&&b3Eye[0]<18.5){
    const prior=b3VisibilityCache,delta=prior?Math.hypot(...b3Eye.map((v,i)=>v-prior.eye[i])):Infinity;
    if(!prior||now-prior.at>.25||delta>.12||Math.abs(prior.yaw-worldYaw)>.12||Math.abs(prior.pitch-pitch)>.12||Math.abs(prior.power-torchPower)>.05||prior.plan!==state.studioB3Plan){
      const point=b3FigurePanePoint(b3Eye),plan=state.studioB3Plan;
      const visible=!!point&&b3ClearRay(plan,b3Eye,point,{propBlocks:state.studioB3PropBlocks});
      const lights=[];
      for(let i=0;i<localLightCount;i++){
        const j=i*4;lights.push({x:localLightPositions[j],y:localLightPositions[j+1],z:localLightPositions[j+2],radius:localLightPositions[j+3],intensity:localLightColors[j+3],direction:[localLightDirections[j],localLightDirections[j+1],localLightDirections[j+2]],coneOuterCos:localLightDirections[j+3],coneInnerCos:localLightConeInner[i]});
      }
      const energy=visible?b3PaneIllumination({point,eye:b3Eye,torch:{...torchFrame,power:torchPower,reach:torchReach,coneInner:torchConeInner,coneOuter:torchConeOuter,spill:torchSpill},ambient:frameAmbientIntensity,lights,plan}):0;
      b3VisibilityCache={at:now,eye:b3Eye,yaw:worldYaw,pitch,power:torchPower,plan,point,energy,visible,lit:energy>=.12};
    }
  }else b3VisibilityCache=null;
  const b3Figure=b3GlassMoment.step({active:b3Near,eye:b3Eye,yaw:worldYaw,pitch,dt,suspended:!!state.studioB3Suspended,visible:b3VisibilityCache?.visible===true,lit:b3VisibilityCache?.lit===true});
  b3GlassDiagnostic={active:b3Near,gain:b3Figure,suspended:!!state.studioB3Suspended,eye:b3Eye,point:b3VisibilityCache?.point||null,visible:b3VisibilityCache?.visible===true,lit:b3VisibilityCache?.lit===true,energy:b3VisibilityCache?.energy??0,torchPower};
  gl.uniform1f(U('uB3GlassActive'),b3Near?1:0);
  gl.uniform1f(U('uB3GlassFigure'),b3Figure);
  gl.uniform1f(U('uB3GlassReturned'),state.studioB3GlassReturned?1:0);
  gl.uniform2f(U('uTile'), state.tileW, state.tileH);
  gl.uniform1f(U('uWorldCount'), state.worldCount);
  gl.uniform3fv(U('uWorldTint[0]'), worldTintsFlat(state.worldTints));
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, rdTex);
  gl.uniform1i(U('uRD'), 0);
  gl.activeTexture(gl.TEXTURE1);
  gl.bindTexture(gl.TEXTURE_2D, fogTexture);
  gl.uniform1i(U('uFogTex'), 1);
  gl.uniform2f(U('uFogOrigin'), fogOrigin[0], fogOrigin[1]);
  gl.uniform1f(U('uAudio'), state.audio);
  gl.uniform1f(U('uLight'), torchPower);
  gl.uniform3fv(U('uTorchColor'),torchColor);
  gl.uniform3fv(U('uTorchOrigin'),torchFrame.origin);gl.uniform3fv(U('uTorchForward'),torchFrame.forward);gl.uniform3fv(U('uTorchRight'),torchFrame.right);gl.uniform3fv(U('uTorchUp'),torchFrame.up);
  gl.uniform1f(U('uTorchReach'),torchReach);
  gl.uniform2f(U('uTorchCone'),torchConeInner,torchConeOuter);
  gl.uniform1f(U('uTorchSpill'),torchSpill);
  gl.uniform1f(U('uTorchShoulder'),torchShoulder);
  gl.uniform3fv(U('uAmbientColor'),frameAmbientColor);
  gl.uniform1f(U('uAmbientIntensity'),frameAmbientIntensity);
  gl.uniform1f(U('uWorldLightTreatment'),worldLightTreatment.level);
  gl.uniform1f(U('uAmbientFloor'),ambientFloor);
  gl.uniform1f(U('uAmbientPlace'),ambientPlace);
  gl.uniform3fv(U('uBounceColor'),lightingBounceColor);
  gl.uniform1f(U('uBounceIntensity'),lightingBounceIntensity*bounceAmount);
  gl.uniform1f(U('uBounceLampGain'),bounceLampGain);
  gl.uniform1f(U('uRainAmount'),Number.isFinite(state.rainAmount)?state.rainAmount:rainAmount);
  gl.uniform1f(U('uGlassCourtRainShelter'),state.glassCourtRainShelter?1:0);
  gl.uniform1f(U('uRainIndoor'),indoorRain);
  gl.uniform1f(U('uRainClearM'),rainClearMetres);
  gl.uniform1f(U('uNightSeed'),nightSeed);
  {const seen=perceptionArmed?perception:PERCEPTION_IDENTITY;gl.uniform3f(U('uMoonMeaning'),seen.moonSize,seen.moonBlood,1/Math.max(.2,seen.chroma));
   if(memorySky){gl.uniform4f(U('uMemorySun'),memorySky.sun[0],memorySky.sun[1],memorySky.sun[2],1);gl.uniform4f(U('uMemorySky'),memorySky.day,memorySky.sunScale,memorySky.fault,memorySky.cloud);}
   else gl.uniform4f(U('uMemorySun'),0,1,0,0);}
  gl.uniform1f(U('uEndingWorldLook'),endingWorldLook);
  gl.uniform1f(U('uRoofView'),lightingRoofSkyRecovery>0?1:0);
  gl.uniform1f(U('uGalleryTreatment'),academicGalleryReady?1:0);
  gl.uniform1f(U('uAcademicAtriumLight'),lightingAcademicAtriumLight?1:0);
  gl.uniform1f(U('uHushSense'),hushSense);
  gl.uniform1f(U('uOpticalEffects'),opticalEffects);
  gl.uniform1f(U('uReduceMotionOptical'),pixelMeshSettings.reduceMotion?1:0);
  gl.uniform1f(U('uDockHauntingFade'),Math.max(0,Math.min(.995,Number(state.dockHauntingFade)||0)));
  const caughtPrint=state.elleryCaughtPrint;
  gl.uniform3f(U('uElleryCaughtPrint'),caughtPrint?.printLight||0,caughtPrint?.printClose||0,caughtPrint?.side||0);
  gl.uniform1i(U('uLocalLightCount'),localLightCount);
  gl.uniform1i(U('uLocalShadowIndex'),localShadowIndex);
  gl.uniform4fv(U('uLocalLightPos[0]'),localLightPositions);
  gl.uniform4fv(U('uLocalLightColor[0]'),localLightColors);
  gl.uniform1fv(U('uLocalLightPenetration[0]'),localLightPenetrations);
  gl.uniform1fv(U('uLocalLightEmergency[0]'),localLightEmergency);
  gl.uniform4fv(U('uLocalLightDirection[0]'),localLightDirections);gl.uniform1fv(U('uLocalLightConeInner[0]'),localLightConeInner);
  gl.uniform1f(U('uUsePlan'), state.plan ? 1 : 0);
  gl.uniform1f(U('uPlanHeightOffset'), planHeightOffset);
  gl.uniform4fv(U('uPlanExteriorPortal'), planExteriorPortal?.slice(0,4) || [0,0,0,0]);
  gl.uniform3f(U('uPlanExteriorPortalHeight'), planExteriorPortal?.[4] || 0, planExteriorPortal?.[5] || 0, planExteriorPortal ? 1 : 0);
  if (state.plan && planTexture) {
    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, planTexture);
    gl.uniform1i(U('uPlan'), 2);
    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, materialTexture);
    gl.uniform1i(U('uMat'), 3);
    gl.uniform2f(U('uPlanSize'), planW, planH);
    gl.uniform2f(U('uPlanOrigin'), planOriginX, planOriginY);
    gl.uniform3fv(U('uZoneTint[0]'), ZONE_TINTS);
  }
  // WebGL2 only guarantees sixteen fragment samplers and this pass already
  // uses them all. Source Space suppresses building actors, so its corpus atlas
  // and the HUSH SDF safely share unit 13 without ever being sampled together.
  const hushBodyTextureActive=hushBodyRenderAllowed&&hushBodyReady&&P3.pressureTargets().draws>0;
  const unit13Texture=hushBodyTextureActive?P3.pressureTargets().color:sourceSurfaceTexture;
  gl.uniform1f(U('uSourceReady'),sourceSurfaceTexture&&!hushBodyTextureActive?1:0);
  gl.activeTexture(gl.TEXTURE13);gl.bindTexture(gl.TEXTURE_2D,unit13Texture);gl.uniform1i(U('uSourceSurface'),13);
  gl.activeTexture(gl.TEXTURE14);gl.bindTexture(gl.TEXTURE_2D,sourceLayerTexture);gl.uniform1i(U('uSourceLayer'),14);
  const propTargets=P3.propTargets();
  gl.uniform1f(U('uPropsReady'),propTargets.ready?1:0);
  gl.uniform1f(U('uLitApparitions'),propTargets.litApparitionsVisible?1:0);
  gl.uniform1f(U('uPropNear'),propTargets.near);
  gl.uniform1f(U('uPropFar'),propTargets.far);
  const shoreAperture=sourceShoreState?.doorway;
  const shoreRoomSide=!!(sourceShoreState?.active&&!sourceShoreState.outside&&!sourceShoreState.proper&&shoreAperture);
  gl.uniform4f(U('uSourceShoreAperture'),shoreAperture?.centreX||0,shoreAperture?.doorZ||0,
    shoreAperture?.width||1,shoreAperture?.height||2.2);
  gl.uniform2f(U('uSourceShoreApertureState'),sourceShoreState?.room?.floor||0,shoreRoomSide?1:0);
  gl.uniform1f(U('uPropShadowReady'),propTargets.shadowReady?1:0);
  gl.uniformMatrix4fv(U('uPropShadowMatrix'),false,propTargets.shadowMatrix);
  gl.uniform2fv(U('uPropShadowTexel'),propTargets.shadowTexel);
  gl.activeTexture(gl.TEXTURE15);gl.bindTexture(gl.TEXTURE_2D,propTargets.shadow);gl.uniform1i(U('uPropShadow'),15);
  if(propTargets.ready){
    gl.activeTexture(gl.TEXTURE4);gl.bindTexture(gl.TEXTURE_2D,propTargets.color);gl.uniform1i(U('uPropColor'),4);
    gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,propTargets.worldData);gl.uniform1i(U('uPropDepth'),5);
  }
  gl.activeTexture(gl.TEXTURE12);gl.bindTexture(gl.TEXTURE_2D,waterTex || waterTexA);gl.uniform1i(U('uWaterHeight'),12);
  const water=state.water||{};
  const bounds=water.basinBounds||{};
  gl.uniform4f(U('uWaterBounds'), bounds.minX||0, bounds.minY||0, bounds.maxX||0, bounds.maxY||0);
  gl.uniform4f(U('uWaterParams'), water.active?1:0, Number(water.levelM ?? -0.06), Number(water.murk ?? 0.85), water.reduceMotion?1:0);
  gl.uniform4f(U('uWaterCamera'), water.cameraSubmerged?1:0, Number(water.submersionDepthM)||0, water.soaked?1:0, 0);
  const look=currentLook();
  const bankBlend=surfaceDreamBlend();
  gl.uniform1f(U('uSurfacesReady'),surfacesManifestation);
  // Sampler types need distinct units even while the asset-dependent branch
  // is disabled. Default zero aliases these arrays with the 2D uRD sampler.
  for(const[name,unit]of SURF_SAMPLER_UNITS)gl.uniform1i(U(name),unit);
  if(surfAlbedoTex&&surfNormalTex&&surfMaterialTex){
    gl.activeTexture(gl.TEXTURE6);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfAlbedoTex);gl.uniform1i(U('uSurfAlbedo'),6);
    gl.activeTexture(gl.TEXTURE7);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfNormalTex);gl.uniform1i(U('uSurfNormal'),7);
    gl.activeTexture(gl.TEXTURE8);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfMaterialTex);gl.uniform1i(U('uSurfMaterial'),8);
    gl.activeTexture(gl.TEXTURE9);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfDreamTex);gl.uniform1i(U('uSurfDream'),9);
    gl.activeTexture(gl.TEXTURE11);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfDreamStageTex);gl.uniform1i(U('uSurfDreamNext'),11);
    // Unit 10, freed by packing roughness and relief into one array.
    gl.activeTexture(gl.TEXTURE10);gl.bindTexture(gl.TEXTURE_2D_ARRAY,surfMarkTex);gl.uniform1i(U('uSurfMarks'),10);
    gl.uniform1f(U('uMarkStride'),MAX_DREAM_FRAMES);
    gl.uniform1f(U('uMarksLiveBase'),markLiveBase);
    gl.uniform1f(U('uMarksStageBase'),markLiveBase?0:MARK_HALF_LAYERS);
    gl.uniform1fv(U('uMarksReady[0]'),markReadyUniform(markReady,surfDreamFrames,markFadeStartLive));
    gl.uniform1fv(U('uMarksReadyNext[0]'),markReadyUniform(markStageReady,surfDreamStageFrames,markFadeStartStage));
  }
  gl.uniform1f(U('uDreamReady'),surfDreamReady&&surfDreamMix.some((v)=>v>0)?1:0);
  gl.uniform1f(U('uDreamNextReady'),surfDreamNextReady?1:0);
  gl.uniform1f(U('uDreamBankBlend'),bankBlend);
  gl.uniform1f(U('uDreamDetailGain'),look.material.detailGain);
  gl.uniform1f(U('uDreamChromaDrift'),look.material.chromaDrift);
  gl.uniform1f(U('uDreamFramesA'),surfDreamFrames);
  gl.uniform1f(U('uDreamFramesB'),surfDreamStageFrames);
  gl.uniform1f(U('uBoilHz'),look.material.boilHz??0);
  gl.uniform1f(U('uDreamStructureMix'),look.material.structureMix??0);
  gl.uniform1f(U('uDreamLumaLo'),look.material.lumaClampLo??.62);
  gl.uniform1f(U('uDreamLumaHi'),look.material.lumaClampHi??1.48);
  gl.uniform1f(U('uDreamLumaHold'),look.material.lumaHold??1);
  gl.uniform1f(U('uAgitation'),dreamAgitation);
  gl.uniform1f(U('uDreamRoughnessResponse'),look.material.roughnessResponse);
  gl.uniform1f(U('uDreamNormalResponse'),look.material.normalResponse);
  gl.uniform1f(U('uLocalDiffusion'),look.material.localDiffusion*localDiffusionAvailability);
  gl.uniform1fv(U('uDreamMix[0]'),surfDreamMix);
  const n = Math.min(state.chunks.length, MAX_CHUNKS);
  gl.uniform1i(U('uChunkCount'), n);
  let hasChunkGlow=false;
  if (n > 0) {
    const a = chunkScratchA, c = chunkScratchC;
    a.fill(0); c.fill(0);
    for (let i = 0; i < n; i++) {
      const ch = state.chunks[i];
      a.set([ch.x, ch.y, ch.r, ch.act], i * 4);
      c.set(ch.col, i * 3);
      // Test exactly what WebGL receives, including float32 rounding and NaN.
      if(a[i*4+3]!==0)hasChunkGlow=true;
    }
    gl.uniform4fv(U('uChunkA[0]'), a);
    gl.uniform3fv(U('uChunkC[0]'), c);
  }
  gl.uniform1f(U('uChunkGlowReady'),hasChunkGlow?1:0);
  gl.uniform4f(U('uKey'), state.key?.x ?? 0, state.key?.y ?? 0, state.key ? 1 : 0, 0);
  gl.uniform4f(U('uDoor'), state.door?.x ?? 0, state.door?.y ?? 0, state.door ? 1 : 0, 0);
  gl.uniform4f(U('uHush'), state.hush?.x ?? 0, state.hush?.y ?? 0, pressureRoomAbsorptionStrength(state.hush), state.hush?.radiusM ?? 0);
  gl.uniform1f(U('uPressureGeometryReady'),hushBodyTextureActive?1:0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Only the prologue sets a horizon over the building.
  runSourceRestHorizonPass();
  // A seep: the room isn't there for a moment. Printed like everything else.
  if(tableauSource)drawTableau();
  const lens=authoredCamera?.lens,lensOptions={width:uniforms.sceneW,height:uniforms.sceneH,outputHeight:canvas.height};
  const lensBeforePrint=state.cinematicLensStage==='pre-print';
  const sourceTexture=lensBeforePrint?cinematicLensPass.run(sceneTex,sceneTex,lens,{...lensOptions,stage:'pre-print'}):sceneTex;
  const pixelSourceTex = runPixelMeshPass(state, now,{sourceTexture});
  const postSourceTex = runDatamoshPass(pixelSourceTex,now);
  const focusedSourceTex=lensBeforePrint?postSourceTex:cinematicLensPass.run(postSourceTex,sceneTex,lens,{...lensOptions,stage:'post-print'});
  presentThroughPost(focusedSourceTex,{torchPower,sourceTorchMode});
}

// THE GAME'S OWN LOOK, AS ONE STEP. The post upscale the building frame ends in:
// glass, grain, the recording's temporal smear, the front-end plate. The
// physical void pass (outskirts, bell passage, chapel outskirts) used to skip it
// and copy its colour straight to the screen, which is why out there the game
// stopped looking like itself and showed bare PBR.
function finishPressure(sourceTex,{acquired=null}={}){
  pressureFinishReady=false;
  const geometry=P3.pressureTargets(),props=P3.propTargets();
  if(!progPressureFinish||!pressureFinishFbo||!geometry.ready||!geometry.draws||!props.depth)return sourceTex;
  const U=name=>{
    if(!pressureFinishUniformCache.has(name))pressureFinishUniformCache.set(name,gl.getUniformLocation(progPressureFinish,name));
    return pressureFinishUniformCache.get(name);
  };
  gl.bindFramebuffer(gl.FRAMEBUFFER,pressureFinishFbo);
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.bindVertexArray(null);gl.useProgram(progPressureFinish);
  for(const[unit,name,texture]of[[0,'uSrc',sourceTex],[1,'uGeometry',geometry.color],[2,'uScene',sceneTex],[3,'uPropsDepth',props.depth],[4,'uAcquired',acquired||sourceTex]]){
    gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,texture);gl.uniform1i(U(name),unit);
  }
  gl.uniform2f(U('uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.uniform2f(U('uPressureRes'),geometry.width,geometry.height);
  gl.uniform2f(U('uNearFar'),geometry.near,geometry.far);
  gl.uniform1f(U('uSceneDepthReady'),pressureSceneDepthReady?1:0);
  gl.uniform1f(U('uAcquiredOnly'),acquired?1:0);
  gl.uniform1f(U('uCaptureExposure'),captureExposureOverride??lightingCaptureExposure);
  gl.drawArrays(gl.TRIANGLES,0,3);
  pressureFinishReady=true;
  return pressureFinishTex;
}

let presentationReceiptListener=null;
export function r3dObservePresentation(listener){presentationReceiptListener=typeof listener==='function'?listener:null;return()=>{if(presentationReceiptListener===listener)presentationReceiptListener=null;};}
const PERCEPTION_IDENTITY=Object.freeze({chroma:1,contrast:1,narrowing:0,lift:0,centre:Object.freeze([.5,.5]),lids:0,moonSize:1,moonBlood:0,
  leak:0,white:0,time:0,seed:0,origin:Object.freeze([.5,.5]),waveRadius:0,waveBand:.2,lens:0,after:0,afterAt:Object.freeze([.5,.55]),shimmer:0});
let perception=PERCEPTION_IDENTITY,perceptionArmed=false,memorySky=null;
export function r3dSetPerception({chroma=1,contrast=1,narrowing=0,lift=0,centre=PERCEPTION_IDENTITY.centre,lids=0,moonSize=1,moonBlood=0,
  leak=0,white=0,time=0,seed=0,origin=PERCEPTION_IDENTITY.origin,waveRadius=0,waveBand=.2,lens=0,after=0,afterAt=PERCEPTION_IDENTITY.afterAt,shimmer=0}={}){
  const n=(v,f)=>Number.isFinite(Number(v))?Number(v):f;
  perception={chroma:n(chroma,1),contrast:n(contrast,1),narrowing:n(narrowing,0),lift:n(lift,0),centre:[n(centre?.[0],.5),n(centre?.[1],.5)],lids:n(lids,0),moonSize:n(moonSize,1),moonBlood:n(moonBlood,0),
    leak:n(leak,0),white:n(white,0),time:n(time,0),seed:n(seed,0),origin:[n(origin?.[0],.5),n(origin?.[1],.5)],waveRadius:n(waveRadius,0),waveBand:n(waveBand,.2),lens:n(lens,0),after:n(after,0),afterAt:[n(afterAt?.[0],.5),n(afterAt?.[1],.55)],shimmer:n(shimmer,0)};
  perceptionArmed=true;return perception;
}
export function r3dPerceptionStats(){return{armed:perceptionArmed,...perception,memorySky:memorySky?{...memorySky}:null};}
// `sun` is a direction. Null puts the night back.
export function r3dSetMemorySky(frame=null){
  memorySky=frame&&Array.isArray(frame.sun)?{sun:frame.sun,day:Number(frame.day)||0,sunScale:Number(frame.sunScale)||1,fault:Number(frame.fault)||0,cloud:Number.isFinite(frame.cloud)?frame.cloud:.6,edge:Number.isFinite(frame.edge)?frame.edge:1}:null;
  return !!memorySky;
}
function presentThroughPost(sourceTex,{torchPower=0,sourceTorchMode=0,unravellingColour=0,unravellingScene=null}={}){
  // post upscale to screen
  gl.useProgram(progPost);
  gl.uniform4fv(postU('uDriveMemoryBreak'),driveMemoryBreak);
  gl.uniform1f(postU('uDriveMemoryRaw'),driveMemoryAcquired?0:1);
  const presentW=presentTarget?.width||canvas.width,presentH=presentTarget?.height||canvas.height;
  gl.bindFramebuffer(gl.FRAMEBUFFER, presentTarget?.fbo||null);
  gl.viewport(0, 0, presentW, presentH);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, sourceTex);
  gl.uniform1i(postU('uSrc'), 0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,unravellingScene||sourceTex);
  gl.uniform1i(postU('uUnravellingScene'),1);
  gl.uniform1f(postU('uUnravellingColour'),unravellingColour);
  const pressure=P3.pressureTargets(),props=P3.propTargets();
  for(const[unit,name,texture]of[[2,'uPressureGeometry',pressure.color],[3,'uPressureScene',sceneTex],[4,'uPressurePropsDepth',props.depth]]){
    gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,texture||sourceTex);gl.uniform1i(postU(name),unit);
  }
  gl.uniform1f(postU('uPressureReady'),pressure.ready&&pressure.draws>0?1:0);
  gl.uniform1f(postU('uPressureSceneDepthReady'),pressureSceneDepthReady?1:0);
  gl.uniform2f(postU('uPressureNearFar'),pressure.near,pressure.far);
  gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,pressureIdentityTex||sourceTex);
  gl.uniform1i(postU('uPressureInk'),5);
  gl.uniform2f(postU('uCatchFlash'),catchFlash,catchNegative);
  gl.uniform1f(postU('uPressureInkReady'),pressureFinishReady?1:0);
  gl.activeTexture(gl.TEXTURE6);gl.bindTexture(gl.TEXTURE_2D,markTex||sourceTex);
  gl.uniform1i(postU('uMissingManMarks'),6);
  gl.uniform1f(postU('uMissingManMarksReady'),props.missingManCoreVisible?1:0);
  gl.uniform2f(postU('uRes'), presentW, presentH);
  gl.uniform1f(postU('uFear'), fearLevel);
  gl.uniform1f(postU('uTimeP'), performance.now() * 0.001);
  const postLook=currentLook();
  gl.uniform1f(postU('uGlassStrength'), postLook.glass.strength);
  gl.uniform1f(postU('uGlassFringe'), postLook.glass.fringe);
  gl.uniform1f(postU('uGlassBloom'), postLook.glass.bloom);
  gl.uniform1f(postU('uGlassGrain'), postLook.glass.grain);
  gl.uniform1f(postU('uRecordingPostGrain'), postLook.recording.postGrain);
  gl.uniform1f(postU('uRecordingLumaGrain'), postLook.recording.lumaGrain);
  gl.uniform1f(postU('uRecordingTemporalHz'), postLook.recording.temporalHz);
  gl.uniform1f(postU('uRecordingTemporalSmear'), postLook.recording.temporalSmear);
  gl.uniform1f(postU('uReduceFlash'), pixelMeshSettings.reduceFlash?1:0);
  gl.uniform1f(postU('uReduceMotion'), pixelMeshSettings.reduceMotion?1:0);
  gl.uniform1f(postU('uSourceEmergency'),sourceEmergencyStrength);
  gl.uniform1f(postU('uSourceWhiteout'),sourceWhiteoutStrength);
  gl.uniform1f(postU('uSourceTorchMode'),sourceTorchMode);
  gl.uniform1f(postU('uSourceTorchPower'),torchPower);
  gl.uniform1f(postU('uFrontEndAmount'),frontEndPlate.amount);
  gl.uniform1f(postU('uFrontEndDetailRetention'),frontEndPlate.detailRetention);
  gl.uniform1f(postU('uFrontEndChromaRetention'),frontEndPlate.chromaRetention);
  gl.uniform1f(postU('uFrontEndExposureStops'),frontEndPlate.exposureStops);
  gl.uniform1f(postU('uFrontEndShoulder'),frontEndPlate.shoulder);
  gl.uniform1f(postU('uFrontEndToe'),frontEndPlate.toe);
  gl.uniform1f(postU('uFrontEndPrint'),frontEndPlate.negative*frontEndPlate.print);
  // Held for one frame only: whoever owns the picture says so every frame, and
  // nothing that forgets to can inherit somebody else's failing eyes.
  const seen=perceptionArmed?perception:PERCEPTION_IDENTITY;perceptionArmed=false;
  gl.uniform4f(postU('uPerception'),seen.chroma,seen.contrast,seen.narrowing,seen.lift);
  gl.uniform4f(postU('uPerceptionAt'),seen.centre[0],seen.centre[1],seen.lids,0);
  gl.uniform4f(postU('uLeak'),seen.leak,seen.white,seen.time,seen.seed);
  gl.uniform4f(postU('uLeakWave'),seen.origin[0],seen.origin[1],seen.waveRadius,seen.waveBand);
  gl.uniform4f(postU('uLeakLens'),seen.lens,seen.after,seen.afterAt[0],seen.afterAt[1]);
  gl.uniform1f(postU('uLeakShimmer'),seen.shimmer);
  // Which frame of film is in the gate (game/film-leak.js). The transition's own shimmer
  // says whether it steps or runs smooth, so Reduce Flash is decided once.
  const film=filmLeakTex&&(seen.leak>.001||seen.white>.001)?filmLeakFrame({leak:seen.leak,white:seen.white,time:seen.time,seed:seen.seed,reducedFlash:!(seen.shimmer>.5)}):null;
  gl.activeTexture(gl.TEXTURE11);gl.bindTexture(gl.TEXTURE_2D,filmLeakTex||sourceTex);gl.uniform1i(postU('uLeakPlate'),11);
  gl.uniform4f(postU('uLeakPlateFog'),film?.fog.a||0,film?.fog.b||0,film?.fog.mix||0,film?.fog.scale||0);
  gl.uniform4f(postU('uLeakPlateBurn'),film?.burn.a||0,film?.burn.b||0,film?.burn.mix||0,film?.burn.scale||0);
  gl.uniform4f(postU('uLeakPlateGrid'),FILM_LEAK_ATLAS.cols,FILM_LEAK_ATLAS.rows,film?.mirrored?1:0,film?.grain||0);
  gl.uniform1f(postU('uLeakFilmOnly'),film?.filmOnly?1:0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  // CPU submit receipt, not a claim of OS compositor/GPU presentation timing.
  if(presentationReceiptListener&&!presentTarget)presentationReceiptListener(performance.now());
}

export function r3dCanvas() { return canvas; }
// Inspect the existing presentation target without allocating or restoring a
// context. Owners must not advance a cinematic after an undrawn/lost frame.
export function r3dDriveLandStatus(){return{field:!!driveLandField,texture:!!driveLandTex,last:driveLandLast};}
export function r3dSetDriveLandField(field=null){
  if(field===driveLandField)return !!field;
  if(driveLandTex&&gl&&!gl.isContextLost())gl.deleteTexture(driveLandTex);
  driveLandTex=null;driveLandField=field||null;return !!field;
}
export function r3dPresentationReady() { return !!(gl&&!gl.isContextLost()&&canvas?.width>0&&canvas?.height>0); }
// The drawing buffer is preserved, so a frame nobody draws over stays on screen.
// The front end with no camera to print behind it asks for black instead.
export function r3dClearScreen() {
  if (!gl) return;
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, canvas.width, canvas.height);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
}

// Explicit evidence readback only; never part of the frame loop. Coordinates
// here are framebuffer pixels (bottom-left), including the door-core sample.
export function r3dMissingManMaterialProof(){
  if(!gl||!markTex||!uniforms.sceneW)return{ready:false};
  const w=uniforms.sceneW,h=uniforms.sceneH,ow=presentTarget?.width||canvas.width,oh=presentTarget?.height||canvas.height;
  const old=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),read=gl.getParameter(gl.READ_BUFFER),fbo=gl.createFramebuffer();
  try{
    const marks=new Uint8Array(w*h*4),pixels=new Uint8Array(ow*oh*4);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,markTex,0);gl.readBuffer(gl.COLOR_ATTACHMENT0);
    if(gl.checkFramebufferStatus(gl.READ_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)return{ready:false,error:'Material marks target incomplete'};
    gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,marks);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,presentTarget?.fbo||null);gl.readBuffer(presentTarget?gl.COLOR_ATTACHMENT0:gl.BACK);
    gl.readPixels(0,0,ow,oh,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
    let count=0,black=0,maxChannel=0,smokePixels=0,smokeLightInkPixels=0;const bounds=[w,h,-1,-1],samples=[];
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const tag=marks[(y*w+x)*4+3];if(tag!==MISSING_MAN_CORE_BYTE&&tag!==MISSING_MAN_SMOKE_BYTE)continue;
      const ox=Math.min(ow-1,Math.floor((x+.5)*ow/w)),oy=Math.min(oh-1,Math.floor((y+.5)*oh/h)),at=(oy*ow+ox)*4;
      const rgb=Array.from(pixels.subarray(at,at+3));
      if(tag===MISSING_MAN_SMOKE_BYTE){smokePixels++;if(Math.max(...rgb)>=32)smokeLightInkPixels++;continue;}
      count++;if(rgb.every(v=>v===0))black++;
      maxChannel=Math.max(maxChannel,...rgb);bounds[0]=Math.min(bounds[0],x);bounds[1]=Math.min(bounds[1],y);bounds[2]=Math.max(bounds[2],x);bounds[3]=Math.max(bounds[3],y);
      if(samples.length<4)samples.push({scene:[x,y],output:[ox,oy],rgb});
    }
    return{ready:true,source:'Exact depth-winning world material marks and final presented game framebuffer',tagByte:MISSING_MAN_CORE_BYTE,
      scene:[w,h],output:[ow,oh],corePixels:count,exactBlackPixels:black,maxChannel,smokePixels,smokeLightInkPixels,bounds:count?bounds:null,samples,
      glError:gl.getError(),qualification:'Explicit developer readback only; UI canvas excluded. No human fear or frame-time claim.'};
  }finally{gl.deleteFramebuffer(fbo);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,old);gl.readBuffer(read);}
}
export function r3dSourceRoomRender({sample=false,provenance=false}={}){
  const targets=P3.propTargets(),active=textSpaceActive&&!!sourceLook.roomMemoryActive;
  const result={active,acquisition:active?'overworld-pixel-mesh':null,
    depthSource:active&&targets.depth?'current-prop-depth':null,
    marksSource:active?(targets.marksReady&&targets.marks?'current-prop-material-marks':'no-marks-sentinel'):null,
    pixelMeshEnabled:pixelMeshStatus.enabled,bypassedByTextSpace:textSpaceActive&&!sourceLook.roomMemoryActive,
    width:uniforms.sceneW,height:uniforms.sceneH,pressure:sourceHushProjection(),
    finalIdentityPass:active&&!!progSourceIdentity,
    coastalWater:active&&gl&&progSourceRoomAcquisition?{
      params:Array.from(gl.getUniform(progSourceRoomAcquisition,sourceRoomU('uCoastSea'))||[]),
      eye:Array.from(gl.getUniform(progSourceRoomAcquisition,sourceRoomU('uRestEye'))||[]),
    }:null};
  if(provenance&&gl&&progSourceRoomAcquisition){
    const shader=(gl.getAttachedShaders(progSourceRoomAcquisition)||[]).find(shader=>gl.getShaderParameter(shader,gl.SHADER_TYPE)===gl.FRAGMENT_SHADER),
      compiled=shader?gl.getShaderSource(shader)||'':'';
    let hash=2166136261;for(let n=0;n<compiled.length;n++)hash=Math.imul(hash^compiled.charCodeAt(n),16777619);
    result.skyProgram={linked:!!gl.getProgramParameter(progSourceRoomAcquisition,gl.LINK_STATUS),matchesAuthored:compiled===SOURCE_ROOM_ACQUISITION_FRAG,
      sourceBytes:compiled.length,fnv1a:(hash>>>0).toString(16),stars:compiled.includes('sourceRestStars(ray,starReveal'),
      sunset:compiled.includes('uRestSunset'),uniform:Array.from(gl.getUniform(progSourceRoomAcquisition,sourceRoomU('uRestSunset'))||[])};
  }
  if(!sample||!active||!gl||!sceneFbo)return result;
  const w=uniforms.sceneW,h=uniforms.sceneH;
  const previousRead=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);
  const previousReadBuffer=gl.getParameter(gl.READ_BUFFER);
  const readTexture=(texture,width,height,floating=false)=>{
    const framebuffer=gl.createFramebuffer();
    const values=floating?new Float32Array(width*height*4):new Uint8Array(width*height*4);
    try{
      gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);
      gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);
      gl.readBuffer(gl.COLOR_ATTACHMENT0);
      if(gl.checkFramebufferStatus(gl.READ_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)return null;
      gl.readPixels(0,0,width,height,gl.RGBA,floating?gl.FLOAT:gl.UNSIGNED_BYTE,values);
      return values;
    }finally{gl.deleteFramebuffer(framebuffer);}
  };
  try{
    const scene=readTexture(sceneTex,w,h,true),marks=readTexture(markTex,w,h);
    const openings=targets.openingMaskReady?readTexture(targets.openingMask,w,h):null;
    const outputW=presentTarget?.width||canvas.width,outputH=presentTarget?.height||canvas.height;
    const final=new Uint8Array(outputW*outputH*4);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,presentTarget?.fbo||null);
    gl.readBuffer(presentTarget?gl.COLOR_ATTACHMENT0:gl.BACK);
    gl.readPixels(0,0,outputW,outputH,gl.RGBA,gl.UNSIGNED_BYTE,final);
    let finalNonBlackPixels=0;
    for(let at=0;at<final.length;at+=4)if(final[at]||final[at+1]||final[at+2])finalNonBlackPixels++;
    const packedFar=1/(1+targets.far*.14);
    let validDepth=0,surfaceDepth=0,derivedMarks=0,sentinelMarks=0,minDepth=1,maxDepth=0;
    let doorCore=0,exactBlackCore=0,doorCoreSample=null;
    for(let i=0;i<w*h;i++){
      const at=i*4,d=scene?.[at+3];
      if(Number.isFinite(d)&&d>0&&d<=1){validDepth++;minDepth=Math.min(minDepth,d);maxDepth=Math.max(maxDepth,d);if(d>packedFar+.0001)surfaceDepth++;}
      if(marks){if(marks[at]>0)derivedMarks++;else sentinelMarks++;}
      if(openings?.[at]===255){
        const x=i%w,y=Math.floor(i/w);
        const ox=Math.min(outputW-1,Math.floor((x+.5)*outputW/w));
        const oy=Math.min(outputH-1,Math.floor((y+.5)*outputH/h));
        const oi=(oy*outputW+ox)*4,rgb=Array.from(final.subarray(oi,oi+3));
        doorCore++;if(rgb.every(value=>value===0))exactBlackCore++;
        if(!doorCoreSample)doorCoreSample={sceneX:x,sceneY:y,outputX:ox,outputY:oy,rgb};
      }
    }
    result.samples={pixels:w*h,validDepth,surfaceDepth,packedDepthRange:[minDepth,maxDepth],
      derivedMarks,sentinelMarks,doorCore,exactBlackCore,doorCoreSample,
      outputPixels:outputW*outputH,finalNonBlackPixels,
      note:'Door-core pixels covered by Pressure may contain its final silhouette; door-only views should be exact black.',glError:gl.getError()};
  }finally{
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,previousRead);
    gl.readBuffer(previousReadBuffer);
  }
  return result;
}

// Pull a raw stage only on explicit diagnostic requests. The physical march,
// prop pass and VFD encode must be distinguishable when a finished frame loses
// geometry; inspecting the final screenshot cannot tell which pass lost it.
export function r3dCaptureStageCanvas(stage='scene') {
  if(!gl||!uniforms.sceneW||!uniforms.sceneH)return null;
  const reflected=stage==='reflection'?P3.reflectionTargets():null;
  const texture=stage==='props'?P3.propTargets().color
    :stage==='reflection'?reflected?.color
    :stage==='pressure-material'?pressureFinishTex
    :stage==='pressure-identity'?pressureIdentityTex
    :stage==='pressure-geometry'?P3.pressureTargets().color
    :stage==='marks'||stage==='mark-alpha'?markTex
    :stage==='openingMask'?P3.propTargets().openingMask
    :stage==='vfd'?(meshFlip?meshTexB:meshTexA)
    :stage==='scene'?sceneTex:null;
  if(!texture)return null;
  const width=reflected?.width||uniforms.sceneW,height=reflected?.height||uniforms.sceneH;
  const previousRead=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);
  const target=gl.createFramebuffer();
  const floating=stage==='scene'||stage==='pressure-material';
  const pixels=floating?new Float32Array(width*height*4):new Uint8Array(width*height*4);
  try{
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,target);
    gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);
    if(gl.checkFramebufferStatus(gl.READ_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)return null;
    gl.readPixels(0,0,width,height,gl.RGBA,floating?gl.FLOAT:gl.UNSIGNED_BYTE,pixels);
  }finally{
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER,previousRead);
    gl.deleteFramebuffer(target);
  }
  const captured=document.createElement('canvas');captured.width=width;captured.height=height;
  const context=captured.getContext('2d'),frame=context.createImageData(width,height),row=width*4;
  for(let y=0;y<height;y++){
    if(floating){for(let x=0;x<row;x++)frame.data[y*row+x]=Math.round(Math.max(0,Math.min(1,pixels[(height-1-y)*row+x]))*255);}
    else frame.data.set(pixels.subarray((height-1-y)*row,(height-y)*row),y*row);
    if(stage==='mark-alpha')for(let x=0;x<width;x++){
      const i=y*row+x*4,value=frame.data[i+3];
      frame.data[i]=value;frame.data[i+1]=value;frame.data[i+2]=value;
    }
    // Scene alpha stores depth, not opacity. Keep it opaque for honest viewing.
    if(stage!=='props'&&stage!=='reflection'&&stage!=='pressure-geometry')for(let x=0;x<width;x++)frame.data[y*row+x*4+3]=255;
  }
  context.putImageData(frame,0,0);
  return captured;
}

// ── The depth the lens gets ─────────────────────────────────────────────────
// Resolves the alpha channel of the last rendered frame into a grey depth image
// on a 2D canvas the diffusion client can encode. Pulled ON DEMAND — only when
// a frame is actually being sent to the GPU (~10fps), never once per rAF —
// because readPixels is a stall, and a stall in the render loop is a stutter in
// a horror game.
//
// Exact, not estimated. Every other img2img pipeline in the world runs MiDaS to
// GUESS the depth of a picture. We marched the room; we know.
// The scene as the model will see it. Read back at burst resolution only while
// a possession is running — never per frame — because readPixels is a stall.
let burstCapCanvas=null,burstCapCtx=null,burstCapPix=null,burstCapImg=null,burstCapSize=0;
export function r3dCaptureSceneCanvas(size=384){
  if(!gl||!sceneTex||!sceneFbo)return null;
  if(burstCapSize!==size){
    burstCapCanvas=document.createElement('canvas');
    burstCapCanvas.width=burstCapCanvas.height=size;
    burstCapCtx=burstCapCanvas.getContext('2d');
    burstCapPix=new Uint8Array(size*size*4);
    burstCapImg=burstCapCtx.createImageData(size,size);
    burstCapSize=size;
  }
  // Downsample through the post program into the burst target, then read that:
  // the scene FBO is larger than the model wants and reading it whole costs
  // more than the inference does.
  gl.bindFramebuffer(gl.FRAMEBUFFER,burstOutFbo);
  gl.viewport(0,0,uniforms.sceneW,uniforms.sceneH);
  gl.useProgram(progPost);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sceneTex);gl.uniform1i(postU('uSrc'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,sceneTex);gl.uniform1i(postU('uUnravellingScene'),1);
  gl.uniform1f(postU('uUnravellingColour'),0);
  gl.uniform2f(postU('uRes'),uniforms.sceneW,uniforms.sceneH);
  gl.drawArrays(gl.TRIANGLES,0,3);
  const sx=Math.max(0,Math.floor((uniforms.sceneW-Math.min(uniforms.sceneW,uniforms.sceneH))/2));
  const sy=Math.max(0,Math.floor((uniforms.sceneH-Math.min(uniforms.sceneW,uniforms.sceneH))/2));
  const side=Math.min(uniforms.sceneW,uniforms.sceneH);
  const raw=new Uint8Array(side*side*4);
  gl.readPixels(sx,sy,side,side,gl.RGBA,gl.UNSIGNED_BYTE,raw);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  // GL is bottom-up; a canvas is top-down. Flip while scaling to the model size.
  const tmp=document.createElement('canvas');tmp.width=tmp.height=side;
  const tmpCtx=tmp.getContext('2d');
  const tmpImg=tmpCtx.createImageData(side,side);
  const row=side*4;
  for(let y=0;y<side;y++){
    const s=(side-1-y)*row,d=y*row;
    tmpImg.data.set(raw.subarray(s,s+row),d);
  }
  tmpCtx.putImageData(tmpImg,0,0);
  burstCapCtx.drawImage(tmp,0,0,side,side,0,0,size,size);
  return burstCapCanvas;
}
let depthTex=null, depthFbo=null, depthSize=0, depthCanvas=null, depthCtx=null, depthPix=null, depthImg=null;
export function r3dDepthCanvas(size = 512) {
  if (!gl || !sceneTex) return null;
  if (depthSize !== size) {
    if (depthTex) { gl.deleteTexture(depthTex); gl.deleteFramebuffer(depthFbo); }
    depthTex = makeTex(size, size);
    depthFbo = makeFbo(depthTex);
    depthCanvas = document.createElement('canvas');
    depthCanvas.width = depthCanvas.height = size;
    depthCtx = depthCanvas.getContext('2d');
    depthPix = new Uint8Array(size * size * 4);
    depthImg = depthCtx.createImageData(size, size);
    depthSize = size;
  }

  gl.useProgram(progDepth);
  gl.bindFramebuffer(gl.FRAMEBUFFER, depthFbo);
  gl.viewport(0, 0, size, size);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, sceneTex);
  gl.uniform1i(gl.getUniformLocation(progDepth, 'uSrc'), 0);
  gl.uniform2f(gl.getUniformLocation(progDepth, 'uRes'), size, size);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.readPixels(0, 0, size, size, gl.RGBA, gl.UNSIGNED_BYTE, depthPix);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);

  // NORMALISE. Raw inverse depth inside one small room occupies a narrow slice
  // of the range — a wall at five metres and a wall at nine are both "mid grey",
  // and a ControlNet handed a low-contrast map politely ignores it. Every depth
  // map these things were trained on (MiDaS) is rescaled to fill the range, so
  // we fill the range: the CONTRAST is the signal, not the metres.
  let lo = 255, hi = 0;
  for (let i = 0; i < depthPix.length; i += 4) {
    const v = depthPix[i];
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  const k = 255 / Math.max(1, hi - lo);

  // GL is bottom-up and a canvas is top-down. Flip, or the lens is handed a
  // room standing on its head and dutifully paints one.
  const row = size * 4, out = depthImg.data;
  for (let y = 0; y < size; y++) {
    let s = (size - 1 - y) * row, d = y * row;
    for (let x = 0; x < size; x++, s += 4, d += 4) {
      const v = (depthPix[s] - lo) * k;
      out[d] = out[d + 1] = out[d + 2] = v;
      out[d + 3] = 255;
    }
  }
  depthCtx.putImageData(depthImg, 0, 0);
  return depthCanvas;
}

export { BIOME_RGB, WORLD_RGB };

export function r3dSourceDemolitionStats(){return P3.sourceDemolitionStats();}
export function r3dExteriorInfrastructureReady(){return ['lyric_service_camera','lyric_extract_stack','lyric_service_bins','ellery_academic_rainwater','ellery_school_rainwater','ellery_baths_rainwater'].every(mesh=>P3.propMeshCatalog().includes(mesh));}
// Explicit offline frame-review tools can compile the exact production source
// without booting a second world or changing any gameplay/render state.
export function r3dLightingShaderSources(){return {vertex:VERT,march:MARCH_FRAG};}
export function r3dPostShaderSources(){return {vertex:VERT,fragment:POST_FRAG};}

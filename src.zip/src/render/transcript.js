//
//  transcript.js
//
//
//  Created by Sebastian Suarez-Solis on 7/12/26.
//

// AUDIOCORP two-channel transcript renderer.
//
// This is message-composer spatial logic translated into a field-recorder
// monitor: received voices live on the left, the local operator lives on the
// right, and machine/direction text occupies a centered rail. It owns no scene
// state and changes no input; presenters pass it a conversation view.

import { uiText, uiItalicText, uiWrap, uiGlyph } from './ui.js';
import { obscuredGlyphAt, obscuredShape } from '../narrative/obscured-name.js';
import { visualEffectsEnabled } from '../game/access.js';
import { registerReviewRegion } from '../game/local-text-review.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// A LINE THE RAIN TOOK.
//
// uiText is only a loop over uiGlyph, so drawing a row character by character
// costs nothing and buys the whole effect: the ink goes down left to right, and
// the rain comes up behind it and thickens each mark until there is nothing to
// read. No letter is ever involved — obscuredGlyphAt is the only source of
// glyphs here, and its alphabet is six blocks and a space.
//
// Two things have to be true when the animation is not running. With effects
// off we draw the authored caption instead, which is exactly the behaviour this
// replaced, so that path is the accessible one and it is the one that was
// already shipping. With instant text the reveal arrives at 1 on the first
// frame, and the settled shape is the correct picture with no motion at all.
function drawMaskedRow(row, drawX, cy, laneW, cls, alpha) {
  const shape = obscuredShape(row.mask);
  if (!shape || !visualEffectsEnabled()) {
    const drawText = row.italic ? uiItalicText : uiText;
    const text = row.text.slice(0, Math.max(0, laneW - row.x));
    drawText(drawX, cy, text, cls, alpha);
    return text.trim() ? { x: drawX, w: text.length } : null;
  }

  const reveal = Math.max(0, Math.min(1, Number(row.reveal ?? 1)));
  // The nib runs slightly ahead of the weather, so there is always a little wet
  // ink at the end of it that has not been taken yet.
  const written = Math.ceil(reveal * (shape.length + 2));
  const room = Math.max(0, laneW - row.x);

  let first = null, last = null;
  for (let i = 0; i < Math.min(shape.length, room); i++) {
    if (i >= written) break;
    const glyph = obscuredGlyphAt(shape, i, reveal);
    if (!glyph || glyph === ' ') continue;
    uiGlyph(drawX + i, cy, glyph, cls, alpha);
    first ??= i; last = i;
  }
  return first == null ? null : { x: drawX + first, w: last - first + 1 };
}

const SPEAKER_LABEL = Object.freeze({
  me: 'YOU',
  you: 'YOU',
  player: 'YOU',
  guard: 'GUARD',
  sarah: 'SARAH',
  client: 'CLIENT',
  radio: 'RADIO',
  recordist: 'RECORDIST',
  surfer: 'SIGNAL',
  unknown: 'UNKNOWN',
  // The recordist's own faculties, at the HUSH (source-contact.js).
  meter: 'METER',
  tape: 'TAPE',
  hands: 'HANDS',
  ears: 'EARS',
  // The phone box (source-space.payphone): the network, the operator, and Lyle's greeting.
  line: 'LINE',
  operator: 'OPERATOR',
  lyle: 'LYLE',
  // The conservatoire's teaching voice, through a practice-room wall.
  institution: 'FACULTY',
});

const SPEAKER_ACCENT = Object.freeze({
  guard: 'ui-amber',
  sarah: 'ui-blue',
  line: 'ui-counter',
  operator: 'ui-blue',
  lyle: 'ui-green',
  client: 'ui-blue',
  radio: 'ui-amber',
  recordist: 'ui-green',
  surfer: 'ui-danger',
  unknown: 'ui-counter',
  meter: 'ui-green',
  tape: 'ui-marker',
  hands: 'ui-warning',
  ears: 'ui-counter',
  institution: 'ui-amber',
});

function keyOf(who) {
  return String(who || 'direction').trim().toLowerCase();
}

function labelOf(who) {
  const key = keyOf(who);
  return SPEAKER_LABEL[key] || String(who || 'SOURCE').trim().toUpperCase();
}

export function transcriptRole(who) {
  const key = keyOf(who);

  if (key === 'me' || key === 'player') {
    return {
      key: 'player:spoken',
      kind: 'player',
      side: 'right',
      speaker: 'YOU',
      labelCls: 'ui-amber',
      bodyCls: 'ui-amber',
      cursorCls: 'ui-amber',
      activeAlpha: 1,
      groupable: true,
    };
  }

  if (key === 'you') {
    return {
      key: 'player:internal',
      kind: 'player',
      side: 'right',
      speaker: 'YOU',
      labelCls: 'ui-amber',
      bodyCls: 'ui-primary',
      cursorCls: 'ui-amber',
      activeAlpha: 0.96,
      groupable: true,
    };
  }

  if (key === 'system' || key === 'machine') {
    return {
      key: 'system',
      kind: 'system',
      side: 'center',
      speaker: '',
      labelCls: 'ui-label',
      bodyCls: 'ui-amber',
      cursorCls: 'ui-amber',
      activeAlpha: 0.82,
      groupable: false,
    };
  }

  if (key === 'direction' || key === 'narration' || key === '') {
    return {
      key: 'direction',
      kind: 'direction',
      side: 'center',
      speaker: '',
      labelCls: 'ui-secondary',
      // Narration is a live signal, not unlit faceplate ink. The centered rail
      // identifies its role; sparse phosphor dots must not also be dimmed to
      // the history floor. History still cools through the shared fade below.
      bodyCls: 'ui-counter',
      cursorCls: 'ui-counter',
      activeAlpha: 0.95,
      groupable: false,
    };
  }

  return {
    key: `incoming:${key}`,
    kind: 'incoming',
    side: 'left',
    speaker: labelOf(who),
    labelCls: SPEAKER_ACCENT[key] || 'ui-amber',
    bodyCls: SPEAKER_ACCENT[key] || 'ui-primary',
    cursorCls: SPEAKER_ACCENT[key] || 'ui-amber',
    activeAlpha: 1,
    groupable: true,
  };
}

export function transcriptSource(who) {
  const role = transcriptRole(who);

  if (role.side === 'right') return 'LOCAL';
  if (role.side === 'center') return 'SYSTEM';
  return 'RX';
}

function normalizeLane(lane, width, fallbackRole = transcriptRole('me')) {
  if (!lane) return laneFor(fallbackRole, width);
  const w = Math.max(12, Math.floor(Number(width) || 12));
  const lx = clamp(Math.floor(Number(lane.x) || 0), 0, Math.max(0, w - 1));
  const lw = clamp(Math.floor(Number(lane.w) || 0), 8, Math.max(8, w - lx));
  return {
    x: lx,
    w: lw,
    align: lane.align || 'left',
  };
}

export function fixedTranscriptLanes(width, { split = null, gap = 2 } = {}) {
  const w = Math.max(12, Math.floor(Number(width) || 12));
  const g = Math.max(1, Math.floor(Number(split?.gap ?? gap) || 1));
  const artW = Math.max(0, Math.floor(Number(split?.artCols) || Math.floor((w - g) / 2)));
  const textX = clamp(artW + g, 0, Math.max(0, w - 8));
  const textW = Math.max(8, w - textX);
  return {
    // With a fixed story-art split the left half is not a transcript lane.
    // Incoming speakers normally live on the left, but here they must join the
    // other roles in the right text pane or their copy paints over the image.
    left: { x: textX, w: textW, align: 'left' },
    right: { x: textX, w: textW, align: 'left' },
    center: { x: textX, w: textW, align: 'center' },
  };
}

function laneFor(role, width, explicitLanes = null) {
  const w = Math.max(12, Math.floor(width));

  if (explicitLanes) {
    if (role.side === 'right') return normalizeLane(explicitLanes.right, w, role);
    if (role.side === 'center') return normalizeLane(explicitLanes.center || explicitLanes.right, w, role);
    if (role.side === 'left') return normalizeLane(explicitLanes.left || explicitLanes.right, w, role);
  }

  // Narrow layouts retain the spatial distinction through indentation without
  // sacrificing most of the line length.
  if (w < 52) {
    if (role.side === 'right') {
      return {
        x: 3,
        w: Math.max(10, w - 3),
        align: 'left',
      };
    }

    if (role.side === 'center') {
      return {
        x: 1,
        w: Math.max(10, w - 2),
        align: 'center',
      };
    }

    return {
      x: 0,
      w: Math.max(10, w - 3),
      align: 'left',
    };
  }

  if (role.side === 'right') {
    const laneW = Math.max(24, Math.floor(w * 0.56));

    return {
      x: w - laneW - 1,
      w: laneW,
      align: 'left',
    };
  }

  if (role.side === 'center') {
    const laneW = Math.max(24, Math.floor(w * 0.68));

    return {
      x: Math.floor((w - laneW) / 2),
      w: laneW,
      align: 'center',
    };
  }

  const laneW = Math.max(24, Math.floor(w * 0.62));

  return {
    x: 1,
    w: laneW,
    align: 'left',
  };
}

function normalizeEntry(entry, index, active = false, view = null) {
  const who = entry?.who || 'direction';
  const role = transcriptRole(who);
  // Names belong to lines, not interaction roles: two guests may share the
  // incoming channel while keeping separate captions and transcript groups.
  const sourceLabel = String(entry?.sourceLabel || '').trim();

  return {
    id: entry?.serial ?? `${active ? 'active' : 'history'}:${index}`,
    who,
    role: sourceLabel ? { ...role, speaker: sourceLabel } : role,
    text: String(entry?.text ?? ''),
    reviewTarget: entry?.reviewTarget || null,
    // The mask's NAME only. The shape is resolved at draw time from the run's
    // registry, so nothing in the transcript, the history or a saved view ever
    // holds it.
    mask: entry?.mask || null,
    // How far the line has been written. A masked line uses this for both the
    // ink going down and the rain taking it; a finished one is simply 1.
    reveal: active && view?.line
      ? Math.min(1, Number(view.typed || 0) / Math.max(1, String(view.line?.text ?? '').length))
      : 1,
    active,
    typing: active && !!view?.typing,
  };
}

function mayGroup(a, b) {
  return !!a &&
    !!b &&
    a.role.groupable &&
    b.role.groupable &&
    a.role.key === b.role.key &&
    a.role.speaker === b.role.speaker;
}

export function transcriptBlocks(view, { keep = 12 } = {}) {
  const entries = [];
  const history = Array.isArray(view?.history)
    ? view.history.slice(-Math.max(0, keep))
    : [];

  history.forEach((entry, i) => {
    entries.push(normalizeEntry(entry, i, false, view));
  });

  // A branch is opened after the current line was committed to history.
  // Adding it again here would duplicate the last line above the choices.
  if (
    view?.line &&
    Number(view.typed) > 0 &&
    view?.pending?.kind !== 'branch'
  ) {
    entries.push(normalizeEntry({
      text: String(view.line?.text ?? view.line ?? '')
        .slice(0, Math.max(0, view.typed)),
      who: view.who,
      sourceLabel: view.line?.sourceLabel,
      mask: view.line?.mask || null,
      serial: view.lineSerial,
      reviewTarget: view.line?.reviewTarget,
    }, entries.length, true, view));
  }

  const blocks = [];

  for (const entry of entries) {
    const prev = blocks[blocks.length - 1];

    if (mayGroup(prev, entry)) {
      prev.segments.push(entry);
      prev.active = prev.active || entry.active;
      continue;
    }

    blocks.push({
      id: entry.id,
      role: entry.role,
      speaker: entry.role.speaker,
      segments: [entry],
      active: entry.active,
    });
  }

  return blocks;
}

function centerText(text, width) {
  const s = String(text || '').slice(0, Math.max(0, width));

  return {
    text: s,
    offset: Math.max(0, Math.floor((width - s.length) / 2)),
  };
}

function preparedRows(block, lane) {
  const rows = [];
  const bodyInset = block.role.side === 'center' ? 0 : 2;
  const bodyW = Math.max(8, lane.w - bodyInset - 1);

  for (let s = 0; s < block.segments.length; s++) {
    const segment = block.segments[s];
    const raw = String(segment.text || '');

    if (block.role.kind === 'system') {
      const wrapped = uiWrap(raw.toUpperCase(), Math.max(6, lane.w - 4));

      wrapped.forEach((line, i) => {
        const decorated =
          `${i === 0 ? '[ ' : ''}` +
          `${line}` +
          `${i === wrapped.length - 1 ? ' ]' : ''}`;

        const centered = centerText(decorated, lane.w);

        rows.push({
          reviewTarget: segment.reviewTarget,
          text: centered.text,
          x: centered.offset,
          active: segment.active,
          typing: segment.typing && i === wrapped.length - 1,
          segmentLast: i === wrapped.length - 1,
        });
      });

      continue;
    }

    if (block.role.kind === 'direction') {
      const wrapped = uiWrap(raw, Math.max(6, lane.w - 2));

      wrapped.forEach((line, i) => {
        const centered = centerText(line, lane.w);

        rows.push({
          reviewTarget: segment.reviewTarget,
          text: centered.text,
          x: centered.offset,
          italic: true,
          mask: segment.mask || null,
          reveal: segment.reveal,
          active: segment.active,
          typing: false,
          segmentLast: i === wrapped.length - 1,
        });
      });

      continue;
    }

    const wrapped = uiWrap(raw, bodyW);

    wrapped.forEach((line, i) => {
      rows.push({
        reviewTarget: segment.reviewTarget,
        text: line,
        x: bodyInset,
        mask: segment.mask || null,
        reveal: segment.reveal,
        active: segment.active,
        typing: segment.typing && i === wrapped.length - 1,
        segmentLast: i === wrapped.length - 1,
      });
    });
  }

  return rows;
}

function prepareBlock(block, width, lanes = null) {
  const lane = laneFor(block.role, width, lanes);
  const rows = preparedRows(block, lane);
  const labelRows = block.role.side === 'center' ? 0 : 1;

  return {
    ...block,
    lane,
    rows,
    labelRows,
    height: Math.max(1, labelRows + rows.length + 1),
  };
}

export function layoutTranscript(view, {
  width,
  maxRows,
  keep = 12,
  lanes = null,
} = {}) {
  const all = transcriptBlocks(view, { keep })
    .map((block) => prepareBlock(block, width, lanes));

  const limit = Math.max(1, Math.floor(maxRows || 1));
  const visible = [];
  let used = 0;

  // Fill upward from the current signal so active/recent material always wins.
  for (let i = all.length - 1; i >= 0; i--) {
    const block = all[i];

    if (visible.length && used + block.height > limit) break;

    if (!visible.length && block.height > limit) {
      const availableBody = Math.max(
        1,
        limit - block.labelRows - 1,
      );

      visible.unshift({
        ...block,
        rows: block.rows.slice(-availableBody),
        height:
          block.labelRows +
          Math.min(block.rows.length, availableBody) +
          1,
        clipped: true,
      });

      used = limit;
      break;
    }

    visible.unshift(block);
    used += block.height;
  }

  return {
    blocks: visible,
    height: Math.min(limit, used),
    hiddenBefore: Math.max(0, all.length - visible.length),
    lineAge: Math.max(0, Number(view?.lineAge) || 0),
  };
}

function spentAlpha(age) {
  if (age <= 0) return 0.72;
  if (age === 1) return 0.60;
  if (age === 2) return 0.49;
  if (age === 3) return 0.40;

  return clamp(
    0.34 - (age - 4) * 0.035,
    0.24,
    0.34,
  );
}

function easeOutCubic(t) {
  const x = clamp(t, 0, 1);
  return 1 - Math.pow(1 - x, 3);
}

function drawAligned(
  x,
  y,
  width,
  text,
  align,
  cls,
  alpha,
) {
  const s = String(text || '').slice(0, Math.max(0, width));
  let dx = x;

  if (align === 'right') {
    dx = x + Math.max(0, width - s.length);
  } else if (align === 'center') {
    dx = x + Math.max(
      0,
      Math.floor((width - s.length) / 2),
    );
  }

  uiText(dx, y, s, cls, alpha);
  return dx;
}

function labelText(block, active, railOn) {
  const label = block.speaker || '';
  if (!label) return '';

  if (block.role.side === 'right') {
    const leftRail = active ? '─── ' : '';
    const rightRail = active && railOn ? ' ▐' : '';

    return `${leftRail}${label}${rightRail}`;
  }

  const leftRail = active && railOn ? '▌ ' : '';
  const rightRail = active ? ' ───' : '';

  return `${leftRail}${label}${rightRail}`;
}

export function drawTranscript(layout, {
  x,
  y,
  width,
  maxRows = Infinity,
} = {}) {
  const blocks = layout?.blocks || [];
  const activeEase = easeOutCubic(
    (layout?.lineAge || 0) / 0.24,
  );

  const acquireAlpha = 0.28 + activeEase * 0.72;

  const railOn =
    (layout?.lineAge || 0) >= 0.48 ||
    Math.floor((layout?.lineAge || 0) * 14) % 2 === 0;

  let cy = y;
  let used = 0;

  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    if (used >= maxRows) break;

    const newer = blocks.length - 1 - i;
    const baseSpent = spentAlpha(newer);
    const topFade =
      i === 0 && layout.hiddenBefore > 0
        ? 0.74
        : 1;

    const laneX = x + block.lane.x;

    // Active incoming signals acquire from the left. Local speech acquires
    // from the right. The offset is deliberately tiny and non-springy.
    const enterOffset = block.active
      ? (1 - activeEase) *
        1.6 *
        (
          block.role.side === 'right'
            ? 1
            : block.role.side === 'left'
              ? -1
              : 0
        )
      : 0;

    const bx = laneX + enterOffset;

    if (block.labelRows) {
      const label = labelText(
        block,
        block.active,
        railOn,
      );

      const labelAlpha = block.active
        ? acquireAlpha * 0.92
        : baseSpent * 0.82 * topFade;

      drawAligned(
        bx,
        cy,
        block.lane.w,
        label,
        block.role.side === 'right'
          ? 'right'
          : 'left',
        block.active || newer <= 1
          ? block.role.labelCls
          : 'ui-secondary',
        labelAlpha,
      );

      cy++;
      used++;
    }

    for (
      let r = 0;
      r < block.rows.length && used < maxRows;
      r++
    ) {
      const row = block.rows[r];
      const activeRow = !!row.active;

      // The most recently cooled signal retains some of its original hue.
      // Older material settles into the common dim phosphor/silkscreen color.
      const cls =
        activeRow || newer <= 1
          ? block.role.bodyCls
          : 'ui-secondary';

      let alpha = activeRow
        ? block.role.activeAlpha * acquireAlpha
        : baseSpent * topFade;

      if (block.role.kind === 'direction') {
        alpha *= activeRow ? 0.86 : 0.78;
      }

      if (block.role.kind === 'system') {
        alpha *= activeRow ? 0.95 : 0.88;
      }

      const drawX = bx + row.x;
      let reviewSpan = null;

      if (row.mask) {
        reviewSpan = drawMaskedRow(row, drawX, cy, block.lane.w, cls, alpha);
      } else {
        const drawText = row.italic ? uiItalicText : uiText;
        const text = row.text.slice(0, Math.max(0, block.lane.w - row.x));
        drawText(
          drawX,
          cy,
          text,
          cls,
          alpha,
        );
        if (text.trim()) reviewSpan = { x: drawX, w: text.length };
      }
      if (row.reviewTarget && reviewSpan) registerReviewRegion(row.reviewTarget, { ...reviewSpan, y: cy, h: 1, active: activeRow });

      if (row.typing) {
        const cursor =
          block.role.kind === 'direction' ||
          block.role.kind === 'system'
            ? '·'
            : '▌';

        uiText(
          drawX + row.text.length,
          cy,
          cursor,
          block.role.cursorCls,
          alpha,
        );
      }

      cy++;
      used++;
    }

    if (used < maxRows) {
      cy++;
      used++;
    }
  }

  return {
    rows: used,
    y: cy,
  };
}

function wrapChoice(text,width){
  const words=String(text??'').split(/\s+/).filter(Boolean),lines=[];
  let line='';
  for(const word of words){
    if(line && line.length+1+word.length>width){lines.push(line);line='';}
    let rest=word;
    while(rest.length>width){lines.push(rest.slice(0,width));rest=rest.slice(width);}
    line=line?`${line} ${rest}`:rest;
  }
  if(line)lines.push(line);
  return lines.length?lines:[''];
}

export function layoutTranscriptChoices(view, width, { lane = null, label = null } = {}) {
  const options = view?.pending?.options || [];

  if (!options.length) {
    return {
      rows: [],
      height: 0,
      lane: normalizeLane(lane, width, transcriptRole('me')),
    };
  }

  const role = transcriptRole('me');

  const choiceLane = lane
    ? normalizeLane(lane, width, role)
    : width < 52
      ? laneFor(role, width)
      : {
          x: Math.max(
            1,
            width - Math.floor(width * 0.80) - 1,
          ),
          w: Math.floor(width * 0.80),
          align: 'left',
        };

  // The ordinary bank keeps its existing five-cell gutter. Two digits fit in
  // the number field; only a list above 99 needs a uniformly wider gutter.
  const gutterWidth = Math.max(5, String(options.length).length + 3);
  const rows = [];

  const heading = label ?? (view.pending.kind === 'say'
    ? 'YOU / READY ▐'
    : 'YOU / REPLY ▐');

  rows.push({
    kind: 'label',
    text: heading,
    selected: false,
  });

  options.forEach((choice, idx) => {
    const selected = idx === view.pending.index;
    const spent = !!view.spent?.(choice);
    const signal = choice.archiveSignal ? '◆' : ' ';
    const prefix = `${selected ? '▸' : ' '} ${idx + 1}${signal} `;
    const continuation = ' '.repeat(prefix.length);

    // A check names the voice that makes it, the way it is printed on the
    // choice before you commit to it.
    const tag = choice.tag ? `[${String(choice.tag).toUpperCase()}] ` : '';
    const parts = wrapChoice(
      `${tag}${String(choice.text || choice.label || '')}`,
      Math.max(1, choiceLane.w - Math.max(prefix.length, gutterWidth)),
    );

    parts.forEach((part, lineIdx) => {
      rows.push({
        kind: 'choice',
        reviewTarget: choice.reviewTarget || null,
        choiceIndex: idx,
        gutterWidth,
        firstLine: lineIdx === 0,
        bodyText: part,
        text:
          `${lineIdx === 0 ? prefix : continuation}` +
          `${part}`,
        selected,
        spent,
        disabled: choice.disabled === true,
        archiveSignal: !!choice.archiveSignal,
      });
    });
  });

  return {
    rows,
    height: rows.length + 1,
    lane: choiceLane,
    selectedIndex: view.pending.index,
    optionCount: options.length,
    gutterWidth,
  };
}

// A fitted window can start partway through a long response. Its first visible
// row must identify that response even when the source row was a continuation.
// Ordinary rows retain the exact text/spacing used by the recorder display.
export function transcriptChoiceText(row = {}) {
  if (row.kind !== 'choice' || !Number.isInteger(row.choiceIndex) || row.bodyText == null) return String(row.text || '');
  const prefix = `${row.selected ? '▸' : ' '} ${row.choiceIndex + 1}${row.archiveSignal ? '◆' : ' '} `;
  return `${row.firstLine ? prefix : ' '.repeat(prefix.length)}${row.bodyText}`;
}

// A bounded display follows the selected response rather than silently hiding
// the bottom of a long list. Preserve complete wrapped rows in the source layout.
export function fitTranscriptChoices(layout, maxRows, {selectedOffset=0}={}) {
  if (!layout?.rows?.length) return layout;
  const capacity = Math.max(1, Math.floor(Number(maxRows) || 1));
  if (layout.rows.length <= capacity) return {...layout, overflow:false, selectedScroll:false};
  const heading = layout.rows[0], groups = [];
  for (const row of layout.rows.slice(1)) {
    let group = groups.at(-1);
    if (!group || group.index !== row.choiceIndex) groups.push(group = {index:row.choiceIndex, rows:[]});
    group.rows.push(row);
  }
  if (!groups.length) return {...layout, rows:[heading], height:2, overflow:true, selectedScroll:false};
  const selected = Math.max(0, groups.findIndex(group => group.index === layout.selectedIndex));
  const current = groups[selected];
  if(capacity===1){
    const offset=Math.max(0,Math.min(current.rows.length-1,Math.floor(Number(selectedOffset)||0)));
    const rows=[{...current.rows[offset],firstLine:true}];
    return {...layout,rows,height:rows.length+1,overflow:true,selectedScroll:current.rows.length>1,selectedOffset:offset,selectedMaxOffset:current.rows.length-1};
  }
  const space = capacity - 1;
  if (current.rows.length > space) {
    const offset = Math.max(0, Math.min(current.rows.length-space, Math.floor(Number(selectedOffset)||0)));
    const visible=current.rows.slice(offset,offset+space).map((row,index)=>index===0?{...row,firstLine:true}:row);
    const rows = [{...heading,text:`${heading.text}  ${offset+1}–${offset+space}/${current.rows.length}`}, ...visible];
    return {...layout,rows,height:rows.length+1,overflow:true,selectedScroll:true,selectedOffset:offset,selectedMaxOffset:current.rows.length-space};
  }
  let first=selected,last=selected,used=current.rows.length;
  while (true) {
    const prev=first>0?groups[first-1]:null,next=last+1<groups.length?groups[last+1]:null;
    if (prev && used+prev.rows.length<=space) { first--;used+=prev.rows.length;continue; }
    if (next && used+next.rows.length<=space) { last++;used+=next.rows.length;continue; }
    break;
  }
  const rows=[{...heading,text:`${heading.text}  ${first+1}–${last+1}/${groups.length}`},...groups.slice(first,last+1).flatMap(group=>group.rows)];
  return {...layout,rows,height:rows.length+1,overflow:true,selectedScroll:false,selectedOffset:0,selectedMaxOffset:0};
}

export function drawTranscriptChoices(layout, {
  x,
  y,
  width,
  maxRows = Infinity,
} = {}) {
  if (!layout?.rows?.length) {
    return {
      rows: 0,
      y,
    };
  }

  const laneX = x + layout.lane.x;
  let cy = y;
  let used = 0;

  for (const row of layout.rows) {
    if (used >= maxRows) break;

    if (row.kind === 'label') {
      drawAligned(
        laneX,
        cy,
        layout.lane.w,
        row.text,
        'right',
        'ui-label',
        0.74,
      );
    } else {
      const cls = row.disabled ? 'ui-secondary' : row.selected ? 'ui-amber'
        : row.spent ? 'ui-secondary'
        : row.archiveSignal ? 'ui-blue' : 'ui-primary';

      const alpha = row.disabled ? 0.34 : row.selected ? 1 : row.spent ? 0.48 : row.archiveSignal ? 0.9 : 0.82;

      const gutterWidth = row.gutterWidth || layout.gutterWidth
        || Math.max(5, String((row.choiceIndex ?? 0) + 1).length + 3);
      // Number, cursor and archive mark are addressable phosphor on the same
      // glass as the changing response, never a physical cap above the cover.
      if (row.firstLine && Number.isInteger(row.choiceIndex)) {
        const number = String(row.choiceIndex + 1);
        if (row.selected) uiText(laneX, cy, '▸', cls, alpha);
        uiText(laneX + gutterWidth - 2 - number.length, cy, number, cls, alpha);
        if (row.archiveSignal) uiText(laneX + gutterWidth - 2, cy, '◆', 'ui-blue', .9);
      }
      const bodyText = String(row.bodyText ?? row.text).slice(0, Math.max(0, layout.lane.w - gutterWidth));
      uiText(laneX + gutterWidth, cy, bodyText, cls, alpha);
      const text = transcriptChoiceText(row).slice(0, layout.lane.w);
      if (row.reviewTarget && text.trim()) registerReviewRegion(row.reviewTarget,
        { x: laneX, y: cy, w: Math.min(layout.lane.w, gutterWidth + bodyText.length), h: 1, selected: row.selected });
    }

    cy++;
    used++;
  }

  return {
    rows: used,
    y: cy,
  };
}

export function drawTranscriptHeader({
  x,
  y,
  width,
  slate = '',
  system = '',
} = {}) {
  let cy = y;
  let rows = 0;

  if (slate) {
    uiText(
      x,
      cy,
      String(slate).toUpperCase().slice(0, width),
      'ui-label',
      0.70,
    );

    cy++;
    rows++;
  }

  if (system) {
    if (rows) cy++;

    const raw = `[ ${String(system).toUpperCase()} ]`;

    const text = raw.length <= width
      ? raw
      : `[ ${String(system)
          .toUpperCase()
          .slice(0, Math.max(1, width - 5))}… ]`;

    drawAligned(
      x,
      cy,
      width,
      text,
      'center',
      'ui-amber',
      0.84,
    );

    cy++;
    rows += rows ? 2 : 1;
  }

  return {
    rows,
    y: cy,
  };
}

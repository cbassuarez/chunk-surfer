// Authored metre-scale geometry for the Source II listening place. These
// meshes give its near surfaces thickness, rounded edges and material relief.
import {LEAF_SHAPES,leafOutline} from '../world/leaf-species.js';
import {SOURCE_REST_ROUTE_GROUPS} from '../data/source-rest-route-composition.js';
const box=(a,b,c,d,e,f)=>({p:[a,c,e,b,c,e,b,c,f,a,c,f,a,d,e,b,d,e,b,d,f,a,d,f],i:[0,2,3,0,1,2,4,7,6,4,6,5,0,4,5,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,4,3,4,0]});
const join=(items)=>{const p=[],i=[];for(const g of items){const o=p.length/3;p.push(...g.p);i.push(...g.i.map(n=>n+o));}return{p,i};};
function foliage(){const p=[],i=[],rings=[[0,.27],[.20,.48],[.68,.35],[1,.018]];for(const[y,r]of rings)for(let k=0;k<9;k++){const a=k*Math.PI*2/9;p.push(Math.cos(a)*r,y,Math.sin(a)*r);}for(let j=0;j<3;j++)for(let k=0;k<9;k++){const a=j*9+k,b=j*9+(k+1)%9,c=a+9,d=b+9;i.push(a,c,b,b,c,d);}for(let k=1;k<8;k++)i.push(0,k,k+1);return{p,i};}
function rainRing(){const p=[],i=[];for(let k=0;k<16;k++){const a=k*Math.PI*2/16;for(const r of[.83,1])p.push(Math.cos(a)*r,0,Math.sin(a)*r);}for(let k=0;k<16;k++){const a=k*2,b=(k+1)%16*2;i.push(a,a+1,b+1,a,b+1,b);}return{p,i};}
function weatherLeaf(shape){const p=[],i=[],rows=leafOutline(shape);for(const row of rows)p.push(Math.sin((row.along+.5)*Math.PI)*shape.curl*.09,row.along,row.lower,Math.sin((row.along+.5)*Math.PI)*shape.curl*.09,row.along,row.upper);for(let n=0;n<rows.length-1;n++){const a=n*2,b=a+2;i.push(a,a+1,b+1,a,b+1,b);}return{p,i};}
function gardenArch(){
  const pieces=[box(-.5,.5,0,2.5,-4.05,-3.30),box(-.5,.5,0,2.5,3.30,4.05)];
  for(let k=0;k<20;k++){
    const a=k*Math.PI/20,b=(k+1)*Math.PI/20,p=[];
    for(const x of[-.5,.5])for(const[r,t]of[[3.30,a],[4.05,a],[4.05,b],[3.30,b]])p.push(x,2.5+Math.sin(t)*r,Math.cos(t)*r);
    pieces.push({p,i:[0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,1,2,6,1,6,5,2,3,7,2,7,6,3,0,4,3,4,7]});
  }
  return join(pieces);
}
function bevel(a,b,c,d,e,f,r=.03){
  const p=[],i=[],outline=(inset,y)=>{const x0=a+inset,x1=b-inset,z0=e+inset,z1=f-inset,q=Math.max(.001,r-inset);
    return [[x0+q,y,z0],[x1-q,y,z0],[x1,y,z0+q],[x1,y,z1-q],[x1-q,y,z1],[x0+q,y,z1],[x0,y,z1-q],[x0,y,z0+q]];};
  const rings=[outline(r*.45,c),outline(0,c+r),outline(0,d-r),outline(r*.45,d)];p.push(...rings.flat(2));
  for(let n=0;n<3;n++)for(let k=0;k<8;k++){const a=n*8+k,b=n*8+(k+1)%8,c=(n+1)*8+k,d=(n+1)*8+(k+1)%8;i.push(a,c,b,b,c,d);}
  for(let k=1;k<7;k++){i.push(0,k,k+1);i.push(24,24+k+1,24+k);}return{p,i};
}
const leg=(x,z)=>bevel(x-.045,x+.045,.02,.45,z-.055,z+.055,.014);
const frame=join([
  ...[-.24,.25].flatMap(x=>[-.77,.77].map(z=>leg(x,z))),
  bevel(-.34,.37,.34,.43,-.88,.88,.025),
  bevel(-.35,-.26,.43,.97,-.88,.88,.025),
  ...[-1,1].map(s=>bevel(-.32,.40,.63,.71,s<0?-.94:.83,s<0?-.83:.94,.025)),
  ...[-1,1].flatMap(s=>[box(.25,.30,.42,.65,s*.89-.035,s*.89+.035),box(-.29,-.24,.43,.65,s*.89-.035,s*.89+.035)]),
  ...[-.61,0,.61].map(z=>bevel(-.385,-.345,.52,.92,z-.018,z+.018,.006)),
]);
const cushions=join([
  ...[-1,1].map(s=>bevel(-.24,.35,.43,.57,s<0?-.80:.025,s<0?-.025:.80,.05)),
  ...[-1,1].map(s=>bevel(-.26,-.15,.59,.92,s<0?-.79:.025,s<0?-.025:.79,.035)),
]);
const piping=join([...[-1,1].flatMap(s=>[box(-.215,.325,.545,.555,s<0?-.77:.035,s<0?-.76:.045),box(-.215,.325,.545,.555,s<0?-.045:.76,s<0?-.035:.77)]),
  ...[-.40,.40].map(z=>bevel(-.15,-.14,.735,.762,z-.014,z+.014,.004))]);
const model=(geometry,material,base,extra={})=>({...geometry,material,base:[...base,1],...extra});
const cabinetFolios=[[-.68,1.05,.19,.30],[-.46,1.05,.12,.34],[-.24,1.05,.18,.25],
  [.03,1.05,.13,.33],[.28,1.05,.17,.28],[.49,1.05,.09,.31],
  [-.70,1.50,.13,.31],[-.51,1.50,.17,.26],[-.17,1.50,.20,.34],
  [.12,1.50,.11,.28],[.32,1.50,.19,.32],[.56,1.50,.08,.24],
  [-.62,1.95,.21,.27],[-.31,1.95,.14,.32],[-.04,1.95,.17,.25],
  [.22,1.95,.12,.31],[.48,1.95,.15,.28]];
const folioMaterial=n=>n%4===0?'copper':n%3===0?'stone':'glass';
const folios=material=>join(cabinetFolios.flatMap(([z,y,w,h],n)=>folioMaterial(n)===material
  ?[bevel(-.065,.065,y,y+h,z-w/2,z+w/2,.008)]:[]));
// Dimensions are local to the settle. These are the same fitted members as
// the loose construction, merged only by material and spatial region.
const studyJoinery={oak:[[.565,1.00,-.10,.075,1.38,1.46]],copper:[]},studyCoffer={oak:[],copper:[]};
for(let n=0;n<4;n++){
  const y=1+n*.45;
  studyJoinery.oak.push([.49,y,-.10,.24,.045,1.51]);
  studyJoinery.copper.push([.365,y+.025,-.10,.018,.018,1.49]);
}
for(const z of [-.80,-.37,.12,.61])studyJoinery.oak.push([.49,1.03,z,.23,1.32,.045]);
for(const side of [-1,1]){
  const z=side<0?-.74:.54;
  studyCoffer.oak.push([-.20,2.43,z,1.35,.09,.045]);
  studyCoffer.copper.push([-.20,2.425,z,1.20,.012,.012]);
  studyCoffer.copper.push([-.22,2.49,side<0?-.84:.64,1.47,.026,.035]);
}
for(let n=0;n<3;n++)studyCoffer.oak.push([-.70+n*.50,2.43,-.10,.045,.09,1.31]);
const studyMembers=rows=>join(rows.map(([x,y,z,sx,sy,sz])=>{
  const mesh=bevel(-.5,.5,0,1,-.5,.5,.035);
  mesh.p=mesh.p.map((v,k)=>k%3===0?x+v*sx:k%3===1?y+v*sy:z+v*sz);
  return mesh;
}));
const studyFloorOak=Array.from({length:7},(_,k)=>[-.22,.012,-.81+k*.23,1.60,.025,.21]);
const studyFloorCopper=[[-.98,.037,-.12,.026,.018,1.64],[.54,.037,-.12,.026,.018,1.64],[-.67,.012,-1.08,.026,.018,.57]];
const studyRoofGlass=Array.from({length:4},(_,n)=>[.38-n*.40,2.66-n*.045,-.10,.36,.10,1.72]);
const studyRoofOak=Array.from({length:4},(_,n)=>[.19-n*.40,2.56-n*.045,-.10,.045,.13,1.77]);
for(const z of [-.84,.64])studyRoofOak.push([-.22,2.53,z,1.70,.12,.13]);
export function sourceRestGeometryLibrary(){return{
  ...Object.fromEntries(SOURCE_REST_ROUTE_GROUPS.map(group=>[group.mesh,model(join(group.pieces.map(p=>
    box(p.x-p.sx/2,p.x+p.sx/2,p.y,p.y+p.sy,p.z-p.sz/2,p.z+p.sz/2))),group.material,group.base)])),
  'rest-settle-frame':model(frame,'wood',[.68,.48,.27]),
  'rest-settle-cloth':model(cushions,'case-lining',[.46,.55,.39]),
  'rest-settle-piping':model(piping,'linen',[.67,.59,.38]),
  'rest-oak':model(bevel(-.5,.5,0,1,-.5,.5,.035),'wood',[.66,.48,.29]),
  'rest-stone':model(bevel(-.5,.5,0,1,-.5,.5,.045),'linen',[.78,.73,.61]),
  'rest-vista-arch':model(gardenArch(),'linen',[.82,.76,.61]),
  'rest-copper':model(bevel(-.5,.5,0,1,-.5,.5,.025),'worn-metal',[.58,.39,.22]),
  'rest-green':model(foliage(),'linen',[.32,.43,.28]),
  'rest-water':model(box(-.5,.5,0,.012,-.5,.5),'dark',[.27,.38,.39]),
  'rest-light-strip':model(box(-.5,.5,0,1,-.5,.5),'linen',[.74,.59,.37],{emissive:[.24,.14,.045]}),
  'rest-rain':model(join([box(-.5,.5,0,1,-.035,.035),box(-.035,.035,0,1,-.5,.5)]),'linen',[.61,.70,.69],{emissive:[.07,.10,.095]}),
  'rest-rain-ring':model(rainRing(),'linen',[.53,.64,.63],{emissive:[.035,.05,.045]}),
  'rest-roof-glass':model(bevel(-.5,.5,0,1,-.5,.5,.025),'linen',[.44,.52,.49],{roughness:.42}),
  'rest-folios-copper':model(folios('copper'),'worn-metal',[.58,.39,.22]),
  'rest-folios-stone':model(folios('stone'),'linen',[.78,.73,.61]),
  'rest-folios-glass':model(folios('glass'),'linen',[.44,.52,.49]),
  'rest-study-joinery-oak':model(studyMembers(studyJoinery.oak),'wood',[.66,.48,.29]),
  'rest-study-joinery-copper':model(studyMembers(studyJoinery.copper),'worn-metal',[.58,.39,.22]),
  'rest-study-coffer-oak':model(studyMembers(studyCoffer.oak),'wood',[.66,.48,.29]),
  'rest-study-coffer-copper':model(studyMembers(studyCoffer.copper),'worn-metal',[.58,.39,.22]),
  'rest-study-floor-oak':model(studyMembers(studyFloorOak),'wood',[.66,.48,.29]),
  'rest-study-floor-copper':model(studyMembers(studyFloorCopper),'worn-metal',[.58,.39,.22]),
  'rest-study-roof-glass':model(studyMembers(studyRoofGlass),'linen',[.44,.52,.49],{roughness:.42}),
  'rest-study-roof-oak':model(studyMembers(studyRoofOak),'wood',[.66,.48,.29]),
  'rest-rain-wet':model(box(-.5,.5,0,.006,-.5,.5),'dark',[.20,.31,.31],{roughness:.40}),
  'rest-weather-sheet':model({p:[0,-.5,-.35,.055,-.5,0,0,-.5,.35,0,.5,-.35,.055,.5,0,0,.5,.35],i:[0,1,4,0,4,3,1,2,5,1,5,4]},'linen',[.78,.72,.55]),
  ...Object.fromEntries(LEAF_SHAPES.map(shape=>['rest-weather-leaf-'+shape.id,model(weatherLeaf(shape),'linen',[.62,.46,.24])])),
};}

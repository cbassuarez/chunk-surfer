// Offscreen glyph atlas: each (glyph, resolved style) pair is lazily rendered
// once into a padded tile with its glow (text-shadow layers) baked in, then
// blitted per cell each frame. Pad exists so halos bleed into neighbouring
// cells the way DOM text-shadow does; blur radii are capped to the pad.

import { resolveStyle } from './styles-map.js';
import { drawVfdGlyph, vfdGlowBleed } from './vfd-font.js';
import { uiRoleColor, uiRoleDim, uiBrightness, paletteKey, uiBandKey } from './palette.js';

export const CELL_W = 7.84;          // matches computeViewDims cw
export const CELL_H = 13 * 1.38;     // matches computeViewDims ch
export const FONT_PX = 13;
export const UI_CELL_W = 8.45;
export const UI_CELL_H = 20;
export const UI_FONT_PX = 14;
export const MONO_STACK = "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace";
const PAD_CELLS = 2;                 // halo bleed, in cells, each side
const MAX_BLUR = 24;                 // cap: larger CSS blurs are approximated

let dpr = 1;
const tiles = new Map(); // role + class + glyph -> {canvas, ox, oy}

export function atlasConfigure(devicePixelRatio) {
  const next = Math.max(1, Math.min(3, devicePixelRatio || 1));
  if (next !== dpr) { dpr = next; tiles.clear(); }
}

export function atlasDpr() { return dpr; }

function metricsFor(role) {
  return role === 'ui'
    ? { cellW: UI_CELL_W, cellH: UI_CELL_H, fontPx: UI_FONT_PX }
    : { cellW: CELL_W, cellH: CELL_H, fontPx: FONT_PX };
}

function fontString(bold, fontPx) {
  return `${bold ? 'bold ' : ''}${fontPx * dpr}px ${MONO_STACK}`;
}

// The UI layer is a vacuum-fluorescent display: its text is a 5×7 dot matrix,
// not a font. Lit dots glow; a faint dormant grid shows where the unlit dots
// are, which is the single thing that separates a VFD from glowing text. Colour
// comes from the active theme (amber for menus, green for the recorder).
function renderUiTile(glyph, cls, x = 0, cols = 80) {
  const { cellW, cellH } = metricsFor('ui');
  // THE PAD COMES FROM THE GLOW, NOT FROM A CELL COUNT.
  //
  // PAD_CELLS = 2 gave 34 device px each side horizontally at DPR 2 and 80
  // vertically, because a UI cell is 8.45 wide and 20 tall. The wide bloom
  // wanted more than 34, so it was cut off in a straight vertical line on both
  // sides of every glyph, while 80px of vertical pad went to waste. Asking
  // vfd-font.js how far its light actually reaches fixes the clipping AND makes
  // the tiles smaller — the cache is unbounded and only ever cleared on a DPR
  // change (atlasConfigure), so smaller tiles matter.
  const boxW = cellW * dpr;
  const boxH = Math.min(cellH * dpr, cellW * 1.42 * dpr);
  const bleed = vfdGlowBleed(boxW, boxH);
  const padX = bleed, padY = bleed;
  const w = Math.ceil(cellW * dpr) + padX * 2;
  const h = Math.ceil(cellH * dpr) + padY * 2;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');

  // INK IS NOT A PHOSPHOR. 'ui-ink' is a legend printed on an illuminated cap;
  // it takes the dot matrix and none of the light, which is the same rule the
  // paper roles follow two lines down.
  const isInk = cls === 'ui-ink';
  const isVfd = cls.startsWith('ui-') && !isInk;
    // Ink takes its colour from the PALETTE like every other ui- role — it is a
    // theme token (capInk), not a CSS style. Falling through to resolveStyle
    // here returned the amber default, which printed a legend the same colour as
    // the lit cap it was supposed to be readable on.
    const color = isVfd || isInk ? uiRoleColor(cls, x, cols) : (resolveStyle(cls).color || '#F2A81E');
    // No dormant matrix under ink. The unlit dots are the tell of a display; a
    // silkscreened word has no unlit half.
    const dim = isVfd ? uiRoleDim(cls, x, cols) : null;
    const b = uiBrightness();

  // A 5×7 character keeps a real aspect (~5:7); the tall UI cell is generous
  // line spacing, so the glyph lives in a box the width of the cell, centred.
  // boxW/boxH are computed above, because the pad is derived from them.
  const ox = padX, oy = padY + (cellH * dpr - boxH) / 2;

  // ONE CALL, TWO LOBES.
  //
  // There used to be a second, wider pass here for the brightest classes,
  // wrapped in ctx.globalAlpha = 0.30 to keep it low. That did nothing:
  // drawVfdGlyph assigned globalAlpha per dot rather than multiplying by what
  // it was handed, so the "low" bloom ran at full strength and every primary
  // glyph was double-exposed — which is where most of the old glow came from,
  // and why it read as a flat wash instead of light. The wide veil is one of
  // the two lobes inside drawVfdGlyph now, at an amplitude that is actually
  // honoured, so brightness reaches it through `alpha` alone.
  drawVfdGlyph(ctx, glyph, ox, oy, boxW, boxH, {
    color, dim, blur: 3.2, dpr, alpha: Math.min(1, b),
    // INK DOES NOT GLOW. The phosphor classes are lit dots behind glass and get
    // the two-lobe halation; anything else — paper ink most of all — is a mark
    // ON something, and adding light around it is how you make a printed form
    // look like a screenshot of one. Same dot matrix, no emission.
    halation: isVfd ? undefined : 0,
  });
  return { canvas: c, ox: padX, oy: padY, pulse: false };
}

function renderTile(glyph, cls, role, x = 0, cols = 80) {
  if (role === 'ui') return renderUiTile(glyph, cls, x, cols);
  const style = resolveStyle(cls);
  const { cellW, cellH, fontPx } = metricsFor(role);
  const padX = Math.ceil(cellW * PAD_CELLS * dpr);
  const padY = Math.ceil(cellH * PAD_CELLS * dpr);
  const w = Math.ceil(cellW * dpr) + padX * 2;
  const h = Math.ceil(cellH * dpr) + padY * 2;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.font = fontString(style.bold, fontPx);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const cx = w / 2, cy = h / 2;
  if (style.shadows) {
    // Each text-shadow layer: draw the glyph with shadow displaced far
    // off-canvas so only the shadow lands in the tile (clean glow, no
    // double-fill), matching how CSS stacks shadow layers under the text.
    const OFF = w * 2;
    for (const sh of style.shadows) {
      ctx.save();
      ctx.shadowColor = sh.color;
      ctx.shadowBlur = Math.min(sh.blur, MAX_BLUR) * dpr;
      ctx.shadowOffsetX = OFF + sh.dx * dpr;
      ctx.shadowOffsetY = sh.dy * dpr;
      ctx.fillStyle = '#ffffff';
      ctx.fillText(glyph, cx - OFF, cy);
      ctx.restore();
    }
  }
  ctx.fillStyle = style.color;
  ctx.fillText(glyph, cx, cy);
  return { canvas: c, ox: padX, oy: padY, pulse: style.pulse };
}

export function getTile(glyph, cls, role = 'world', x = 0, cols = 80) {
  // UI tiles depend on the active theme and the player's settings, so their key
  // carries the palette version; a phosphor/brightness change re-renders them.
  // Filter-band phosphor also depends on horizontal screen position. Cache by
  // band, not raw x, so the atlas stays small.
  const key = role === 'ui'
    ? JSON.stringify(['ui', paletteKey(), uiBandKey(x, cols), cls || '', glyph])
    : JSON.stringify([role, cls || '', glyph]);

  let t = tiles.get(key);
  if (!t) {
    t = renderTile(glyph, cls || '', role, x, cols);
    tiles.set(key, t);
  }

  return t;
}

export function atlasSize() { return tiles.size; }

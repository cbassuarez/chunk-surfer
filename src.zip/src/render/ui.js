// Typographic UI layer: a glyph surface that floats above whatever renders
// the world (ASCII grid, raymarcher, or the diffusion overlay). This is where
// the game's *authored* voice lives — dialogue, portraits, menus, battle
// chrome — and it is deliberately the one thing the lens can never repaint.
//
// Coordinates are cells, using the same metrics as the ASCII renderer, so a
// dialogue box occupies the same visual module as the map it covers.

import { UI_CELL_W as CELL_W, UI_CELL_H as CELL_H, atlasConfigure, atlasDpr, getTile } from './atlas.js';
import { UI_COLOR, uiFlickerAlpha, uiRoleColor, uiRoleDim, uiBrightness } from './palette.js';
import { fitText } from './fit-text.js';
import { drawElectronicText } from './electronic-text.js';

let host = null, canvas = null, ctx = null;
let cols = 0, rows = 0;
let layoutSize = null;
let uiScale = 1;
let scaledCellW = CELL_W;
let scaledCellH = CELL_H;

export function uiInit(hostEl) {
  host = hostEl;
  canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:8;';
  if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
  host.appendChild(canvas);
  ctx = canvas.getContext('2d');
  // Start the bundled instrument typeface during arrival; never gate gameplay
  // on font decoding. Printed-label metric caches also key font readiness.
  document.fonts?.load?.('600 14px "Hardware Sans"')?.catch?.(() => {});
  resize();
  window.addEventListener('resize', resize);
  // The stage can change size a frame after the window (platform/viewport-guard.js).
  window.addEventListener('chunk-surfer:stage-resize', resize);
  return { cols: () => cols, rows: () => rows };
}

function resize() {
  if (!host || !canvas) return;
  atlasConfigure(window.devicePixelRatio);
  const dpr = atlasDpr();
  canvas.width = Math.round(host.clientWidth * dpr);
  canvas.height = Math.round(host.clientHeight * dpr);
  cols = Math.max(20, Math.floor(host.clientWidth / scaledCellW));
  rows = Math.max(8, Math.floor(host.clientHeight / scaledCellH));
}

export function uiSetScale(value = 1) {
  const next = Math.max(0.8, Math.min(1.5, Number(value) || 1));
  uiScale = next;
  scaledCellW = CELL_W * uiScale;
  scaledCellH = CELL_H * uiScale;
  resize();
  return uiScale;
}

export function uiCurrentScale() { return uiScale; }

export function uiPhysicalSize() { return { cols, rows }; }
// Reserved instrument territory is a persistent layout, not a render-only
// transform. Menu key/pointer handlers read the same dimensions between frames.
// Coordinates and client picking remain in the unchanged physical pixel frame.
export function uiSize() {
  return layoutSize ? {cols:cols>0?Math.min(cols,layoutSize.cols):layoutSize.cols,
    rows:rows>0?Math.min(rows,layoutSize.rows):layoutSize.rows} : { cols, rows };
}
export function uiSetLayoutSize(value = null) {
  layoutSize=value&&Number.isFinite(value.cols)&&Number.isFinite(value.rows)
    ?{cols:Math.max(1,Math.floor(value.cols)),rows:Math.max(1,Math.floor(value.rows))}:null;
  return uiSize();
}
export function uiWithLayoutSize(value,draw) {
  const previous=layoutSize;uiSetLayoutSize(value);
  try{return typeof draw==='function'?draw():undefined;}finally{layoutSize=previous;}
}
export function uiClear() { if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height); }
export function uiCanvasSize() { return { width: canvas?.width || 0, height: canvas?.height || 0 }; }
// Multiply everything already drawn on the transparent UI surface without
// laying a dark rectangle over the 3D world beneath it.  Callers can then draw
// the one piece of chrome that must remain legible after this pass.
export function uiAttenuate(alpha = 1) {
  if (!ctx || !canvas) return;
  const amount = Math.max(0, Math.min(1, Number(alpha) || 0));
  if (amount >= .9999) return;
  ctx.save();
  ctx.globalCompositeOperation = 'destination-in';
  ctx.globalAlpha = amount;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
}
export function uiPointFromClient(clientX, clientY) {
  // Pointer picking must use the actual rendered overlay rectangle, not the
  // nominal cell size. In windowed desktop shells the CSS rect, DPR/backing
  // pixels, and titlebar/window coordinates can diverge; ratio-mapping from
  // the rendered canvas keeps hover/clicks aligned with what the player sees.
  const rect = canvas?.getBoundingClientRect?.() || host?.getBoundingClientRect?.();
  if (!rect || rect.width <= 0 || rect.height <= 0) return { cellX:-1, cellY:-1 };
  return {
    cellX: ((Number(clientX) - rect.left) / rect.width) * cols,
    cellY: ((Number(clientY) - rect.top) / rect.height) * rows,
  };
}

// Cell metrics in cell space, for instruments that must place drawn art and
// uiText glyphs on the same geometry. Cells are taller than they are wide, so
// anything that wants to stay square has to know the ratio before it can pick
// its scale — and that decision happens outside the draw callback.
export function uiCellMetrics() {
  return { cellW: scaledCellW, cellH: scaledCellH, aspect: scaledCellW / (scaledCellH || 1) };
}

// Low-level drawing hook for code-native instruments. The callback receives
// device-pixel metrics; authored modules still express all geometry in cells.
let uiAlphaScope=1;
export function uiWithAlpha(alpha,draw){const prev=uiAlphaScope;uiAlphaScope=prev*Math.max(0,Math.min(1,Number(alpha)||0));try{return typeof draw==='function'?draw():undefined;}finally{uiAlphaScope=prev;}}
// Paint an existing cell-based surface into a texture while retaining its layout.
export function uiWithCanvas(target, draw) {
  const previous = ctx;
  ctx = target;
  try { return draw(); }
  finally { ctx = previous; }
}

export function uiDraw(draw) {
  if (!ctx || typeof draw !== 'function') return;
  const size=uiSize();
  ctx.save();ctx.globalAlpha*=uiAlphaScope;try{draw({ ctx, dpr: atlasDpr(), cellW: scaledCellW, cellH: scaledCellH, ...size });}finally{ctx.restore();}
}

// Instrument surfaces have two physical planes. Display content is clipped to
// the aperture; keys and their ink are painted after the cover glass. Scopes
// are synchronous, nestable, and restore both clipping and alpha on exceptions.
let hardwareLayer = null;
export function uiDrawHardware(draw) {
  if (typeof draw !== 'function') return;
  if (!hardwareLayer) return uiDraw(draw);
  const alpha = uiAlphaScope;
  hardwareLayer.push(() => {
    const previous = uiAlphaScope;
    uiAlphaScope = alpha;
    try { uiDraw(draw); } finally { uiAlphaScope = previous; }
  });
}
export function uiWithClip(rect, draw) {
  if (typeof draw !== 'function') return;
  if (!ctx) return draw();
  const dpr = atlasDpr();
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(rect.x * scaledCellW * dpr, rect.y * scaledCellH * dpr,
      Math.max(0, rect.w) * scaledCellW * dpr, Math.max(0, rect.h) * scaledCellH * dpr);
    ctx.clip();
    return draw();
  } finally { ctx.restore(); }
}
export function uiWithHardwareLayer(draw, cover) {
  const previous = hardwareLayer, queue = [];
  hardwareLayer = queue;
  let result;
  try { result = draw(); }
  finally {
    hardwareLayer = previous;
    // Flush only after the caller's display clipping has unwound. In nested
    // panels, keep their hardware above the outermost cover too.
    try { cover?.(); }
    finally {
      if (previous) previous.push(...queue);
      else for (const paint of queue) paint();
    }
  }
  return result;
}

// Dim the world behind a scene without hiding it — dread survives, text reads.
export function uiScrim(alpha = 0.55) {
  if (!ctx) return;
  ctx.fillStyle = `rgba(6,7,9,${alpha})`;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

export function uiGlyph(cx, cy, ch, cls = 't-chunk', alpha = 1) {
  if (!ctx || ch == null || ch === ' ') return;
  const tile = getTile(ch, cls, 'ui', cx, cols);
  const dpr = atlasDpr();
  const a = alpha * uiAlphaScope * uiFlickerAlpha(cx, cy, cls);

  if (a !== 1) ctx.globalAlpha = a;
  ctx.drawImage(
    tile.canvas,
    cx * scaledCellW * dpr - tile.ox * uiScale,
    cy * scaledCellH * dpr - tile.oy * uiScale,
    tile.canvas.width * uiScale,
    tile.canvas.height * uiScale,
  );
  if (a !== 1) ctx.globalAlpha = 1;
}

// `max` is the width in cells this text is allowed to occupy. It is OPTIONAL
// and defaults to the old behaviour, because several hundred call sites rely on
// it — but a caller that knows its region should pass one.
//
// Without it, uiText draws a glyph per cell and keeps going: past the panel
// bezel, past the region it was handed, past the edge of the canvas. That is
// why every surface in this renderer grew its own `fit`/`clip` helper, and why
// half of them amputated a word with no mark to say they had.
//
// The last cell is also clamped to the grid, so nothing can draw off-screen
// even if a caller gets its arithmetic wrong.
export function uiText(cx, cy, str, cls = 't-chunk', alpha = 1, max = null) {
  const s = fitText(str, max);
  const limit = Math.min(s.length, Math.max(0, Math.ceil(uiSize().cols - cx)));
  for (let i = 0; i < limit; i++) uiGlyph(cx + i, cy, s[i], cls, alpha);
}

// Direction/system copy shares the display's character hardware. Keep this
// legacy entry point so transcript semantics and pacing do not change, but a
// machine's aside cannot bypass its ROM with italic native-font text.
export function uiItalicText(cx, cy, str, cls = 'ui-secondary', alpha = 1) {
  const s = fitText(String(str ?? ''),Math.max(0,Math.floor(uiSize().cols-cx)));
  if (!ctx || !s) return;
  const dpr = atlasDpr();
  drawElectronicText(ctx,s,cx*scaledCellW*dpr,(cy+.5)*scaledCellH*dpr,{
    mode:'vfd',fontSize:Math.min(scaledCellW*1.42,scaledCellH)*dpr,
    cellWidth:scaledCellW*dpr,color:uiRoleColor(cls,cx,cols),dim:uiRoleDim(cls,cx,cols),
    alpha:alpha*uiAlphaScope*Math.min(1,uiBrightness())*uiFlickerAlpha(cx,cy,cls),dpr,baseline:'middle',
  });
}

// Typewriter ink on paper. NOT the VFD dot-matrix: a real monospace face with
// slightly uneven per-character ink, the way a struck ribbon lands. Drawn
// directly (paper is static, so per-frame fillText is cheap) so it never
// touches the phosphor atlas.
export function uiInk(cx, cy, str, { color = '#20180F', alpha = 1, weight = '' } = {}) {
  const s = String(str ?? '');
  if (!ctx || !s) return;
  const dpr = atlasDpr();
  ctx.save();
  ctx.font = `${weight ? weight + ' ' : ''}${Math.round(scaledCellH * 0.62 * dpr)}px "Courier New", Courier, ui-monospace, monospace`;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = color;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === ' ') continue;
    // uneven ink: a stable, SUBTLE per-cell jitter — a struck ribbon, not a
    // drunk one. Mostly the ink weight varies; the baseline barely moves.
    const h = ((cx + i) * 2654435761 ^ cy * 40503) >>> 0;
    const jA = 0.90 + ((h & 255) / 255) * 0.10;
    const jx = (((h >> 8) & 7) - 3.5) * 0.014;
    const jy = (((h >> 12) & 7) - 3.5) * 0.016;
    ctx.globalAlpha = alpha * uiAlphaScope * jA;
    ctx.fillText(ch, ((cx + i) + jx) * scaledCellW * dpr, (cy + 0.5 + jy) * scaledCellH * dpr);
  }
  ctx.restore();
}

export function uiFill(cx, cy, w, h, color = 'rgba(6,7,9,0.92)') {
  if (!ctx) return;
  const dpr = atlasDpr();
  ctx.save();ctx.globalAlpha*=uiAlphaScope;
  ctx.fillStyle = color;
  const x0 = cx * scaledCellW * dpr;
  const y0 = cy * scaledCellH * dpr;
  // The cell grid is floor(width / cellW) cells wide, so a full-screen fill would
  // leave a sub-cell remainder strip on the right (and bottom) uncovered — and
  // the opaque layer beneath, the diffusion canvas, would show through it as a
  // band. When a fill runs to the grid extent, snap its far edge to the canvas
  // so the background covers that strip.
  const x1 = (cx + w >= cols) ? canvas.width : x0 + w * scaledCellW * dpr;
  const y1 = (cy + h >= rows) ? canvas.height : y0 + h * scaledCellH * dpr;
  ctx.fillRect(x0, y0, x1 - x0, y1 - y0);ctx.restore();
}

export function uiStrokeRect(cx, cy, w, h, color = UI_COLOR.frame, alpha = 1, lineWidth = 1) {
  uiDraw(({ ctx: c, dpr, cellW, cellH }) => {
    c.save();
    c.globalAlpha = alpha;
    c.strokeStyle = color;
    c.lineWidth = lineWidth * dpr;
    c.strokeRect((cx * cellW + 0.5) * dpr, (cy * cellH + 0.5) * dpr,
      Math.max(0, w * cellW - 1) * dpr, Math.max(0, h * cellH - 1) * dpr);
    c.restore();
  });
}

export function uiLine(x1, y1, x2, y2, color = UI_COLOR.frame, alpha = 1, lineWidth = 1) {
  uiDraw(({ ctx: c, dpr, cellW, cellH }) => {
    c.save(); c.globalAlpha = alpha; c.strokeStyle = color; c.lineWidth = lineWidth * dpr;
    c.beginPath(); c.moveTo(x1 * cellW * dpr, y1 * cellH * dpr);
    c.lineTo(x2 * cellW * dpr, y2 * cellH * dpr); c.stroke(); c.restore();
  });
}

export function uiBox(cx, cy, w, h, cls = 't-gate-frame', fill = 'rgba(6,7,9,0.92)') {
  if (fill) uiFill(cx, cy, w, h, fill);
  uiGlyph(cx, cy, '┌', cls); uiGlyph(cx + w - 1, cy, '┐', cls);
  uiGlyph(cx, cy + h - 1, '└', cls); uiGlyph(cx + w - 1, cy + h - 1, '┘', cls);
  for (let x = 1; x < w - 1; x++) { uiGlyph(cx + x, cy, '─', cls); uiGlyph(cx + x, cy + h - 1, '─', cls); }
  for (let y = 1; y < h - 1; y++) { uiGlyph(cx, cy + y, '│', cls); uiGlyph(cx + w - 1, cy + y, '│', cls); }
}

// Word-wrap to a cell width; returns lines.
export function uiWrap(text, width) {
  const words = String(text ?? '').split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (const w of words) {
    const next = line ? `${line} ${w}` : w;
    if (next.length > width) { if (line) lines.push(line); line = w; }
    else line = next;
  }
  if (line) lines.push(line);
  return lines;
}

// Centred, and never wider than the screen it is centred on. It used to clamp
// the x to zero and leave an over-long line running off the right edge.
export function uiCenter(cy, str, cls, alpha, max = null) {
  const width=uiSize().cols;
  const s = fitText(str, Math.min(width, max == null ? width : max));
  uiText(Math.max(0, Math.floor((width - s.length) / 2)), cy, s, cls, alpha);
}

// The instrument surfaces, modelled on the A k a i AM M5 / HX M5 and the hi ta chi
// DA-1000. Two rules the landed refactor broke:
//
//   1. NO GRADIENTS. A VFD is flat black glass. All the depth is the phosphor
//      glow on lit elements and the dim silkscreen legends that never light.
//   2. TEXT IS A DOT MATRIX, not a segment font (see render/vfd-font.js, wired
//      through the atlas). Segments are for the numeric counter only.
//
// A machine panel is a faceplate: a matte bezel, a wordmark, a champagne model
// strip, silkscreen header/footer legends, and the lit data on the glass.

import { uiDraw, uiFill, uiText } from './ui.js';
import { THEMES, UI_COLOR, activeTheme, setActiveSurface, uiBrightness, themeRoleColor, themeRoleDim, uiFlickerAlpha, uiRoleColor } from './palette.js';
import { drawVfdGlyph, vfdGlowBleed } from './vfd-font.js';
import { drawPromptParts } from './prompt-glyphs.js';
import { fitText } from './fit-text.js';
import { MONITOR_DANGER_THRESHOLDS, MONITOR_THRESHOLDS, monitorSnapshot } from '../audio/monitor.js';
import {
  METER_MIN_DB, locationMarks, locationScaleFits, locationTicks,
  meterGeometry, meterMarkBoxes, meterMarks, meterScaleFits, meterSegmentAt,
  meterSegmentCount, meterState, meterTicks, unitToDb,
} from './meter.js';

export const PANEL = Object.freeze({ padX: 2, headerRows: 2, footerRows: 2 });

export function machinePanelBody(x, y, w, h, { footer = '' } = {}) {
  return {
    x: x + PANEL.padX + 1,
    y: y + PANEL.headerRows + 2,
    w: Math.max(1, w - PANEL.padX * 2 - 2),
    h: Math.max(1, h - PANEL.headerRows - (footer ? PANEL.footerRows : 1) - 2),
  };
}

const clamp01 = (v) => Math.max(0, Math.min(1, Number.isFinite(Number(v)) ? Number(v) : 0));
const nowSec = () => ((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()) * 0.001;
const pwm16 = (a) => Math.round(clamp01(a) * 16) / 16;
function scanDuty(x = 0, y = 0, strength = 1) {
  // Multiplex scan artifact: subtle, fast, and column-biased. It is not a
  // decorative wobble; it is the display being addressed grid by grid.
  const phase = (nowSec() * 112 + x * 0.37 + y * 0.61) % 1;
  const blank = phase < 0.045 ? 0.90 : phase > 0.955 ? 0.94 : 1;
  return 1 - (1 - blank) * Math.max(0, Math.min(1, strength));
}
function litDuty(x, y, role = 'phosphor', alpha = 1) {
  return pwm16(alpha * uiBrightness() * uiFlickerAlpha(x, y, role) * scanDuty(x, y));
}

// A flat rectangle in device px, no gradient.
function rect(ctx, x, y, w, h, color, alpha = 1) {
  ctx.globalAlpha = alpha; ctx.fillStyle = color; ctx.fillRect(x, y, w, h); ctx.globalAlpha = 1;
}
function hairline(ctx, x, y, w, h, color, alpha = 1, lw = 1, dpr = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.strokeStyle = color; ctx.lineWidth = lw * dpr;
  ctx.strokeRect(x + 0.5 * dpr, y + 0.5 * dpr, w - dpr, h - dpr); ctx.restore();
}

function drawPanelHardware(ctx, { px, py, pw, ph, gx, gy, gw, gh, dpr }) {
  const screw = Math.max(1.5 * dpr, 2);
  const inset = Math.max(0.72 * dpr, 1);
  ctx.save();

  // Four punched square heads in the bezel. Their slots all face the same way,
  // as if one technician closed every panel on the line.
  for (const [sx, sy] of [
    [px + inset, py + inset],
    [px + pw - inset - screw, py + inset],
    [px + inset, py + ph - inset - screw],
    [px + pw - inset - screw, py + ph - inset - screw],
  ]) {
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = '#8a887f';
    ctx.fillRect(sx, sy, screw, screw);
    ctx.globalAlpha = 0.24;
    ctx.fillStyle = '#050505';
    ctx.fillRect(sx + screw * 0.18, sy + screw * 0.46, screw * 0.64, Math.max(0.5, dpr * 0.36));
  }

  // Registration crosses live on the silkscreen, outside the data area.
  ctx.strokeStyle = '#74776e';
  ctx.lineWidth = Math.max(0.5, dpr * 0.42);
  ctx.globalAlpha = 0.32;
  const arm = Math.max(2 * dpr, 1.5);
  for (const [cx, cy] of [[gx + arm * 1.4, gy - arm], [gx + gw - arm * 1.4, gy + gh + arm]]) {
    ctx.beginPath();
    ctx.moveTo(cx - arm, cy); ctx.lineTo(cx + arm, cy);
    ctx.moveTo(cx, cy - arm); ctx.lineTo(cx, cy + arm);
    ctx.stroke();
  }

  // Dormant service lamps are manufacturing detail, not state. They never
  // animate or brighten and remain below the footer's information hierarchy.
  ctx.globalAlpha = 0.12;
  const led = Math.max(1, dpr * 0.8);
  for (let index = 0; index < 3; index += 1) {
    ctx.fillStyle = index === 1 ? '#7b5431' : '#35584f';
    ctx.fillRect(px + pw - (7 - index * 1.7) * dpr, py + ph - 2.3 * dpr, led, led);
  }

  // A second imperfect stamping line gives the matte plate thickness without
  // introducing a glossy bevel or gradient.
  ctx.globalAlpha = 0.12;
  ctx.strokeStyle = '#6a675f';
  ctx.lineWidth = Math.max(0.5, dpr * 0.45);
  ctx.strokeRect(px + 1.6 * dpr, py + 1.35 * dpr, pw - 3.2 * dpr, ph - 2.7 * dpr);
  ctx.restore();
}

// ── the faceplate ─────────────────────────────────────────────────────────────
export function drawMachinePanel(x, y, w, h, {
  label = 'MONITOR', source = '', footer = '', meter = true, scrim = false,
  // What the needle reads. Defaults to the HUSH exposure snapshot, which is what
  // every in-run surface wants — but that measures SEMANTIC player noise, so it
  // is flat zero anywhere outside a story run and the title's header meter has
  // always been dead. A caller with a better signal supplies it here.
  meterSnapshot = null,
  theme = 'amber', wordmark = 'AUDIOCORP', model = '', buttons = null,
  // Prompt parts, drawn as button glyphs on a pad and as bracketed text on a
  // keyboard. Takes precedence over `footer` when both are given, so a caller
  // can migrate one surface at a time.
  footerParts = null,
} = {}) {
  // Same guard. god-menu.js asks for theme:'red' for the whole developer panel
  // and has always drawn amber.
  if (THEMES[theme]) setActiveSurface(theme);
  const t = activeTheme();
  if (scrim) uiFill(0, 0, 999, 999, 'rgba(2,2,3,0.74)');

  uiDraw(({ ctx, dpr, cellW, cellH }) => {
    const px = x * cellW * dpr, py = y * cellH * dpr;
    const pw = w * cellW * dpr, ph = h * cellH * dpr;
    // The bezel: matte black, a shade off the glass, with a hairline edge. Flat.
    rect(ctx, px, py, pw, ph, '#101010');
    const gx = px + 1.4 * cellW * dpr, gy = py + (PANEL.headerRows + 0.35) * cellH * dpr;
    const gw = pw - 2.8 * cellW * dpr, gh = ph - (PANEL.headerRows + PANEL.footerRows + 0.7) * cellH * dpr;
    // The glass, flat.
    rect(ctx, gx, gy, gw, gh, t.glass);
    hairline(ctx, gx, gy, gw, gh, '#000', 0.9, 1, dpr);
    hairline(ctx, px, py, pw, ph, '#242424', 1, 1, dpr);
    drawPanelHardware(ctx, { px, py, pw, ph, gx, gy, gw, gh, dpr });
  });

  // Header silkscreen legends. The brand/model/label live on one padded row;
  // earlier revisions split this into two rows and made the top band feel
  // tighter than the footer.
  const meterX = meter ? x + w - 17 : x + w - 3;
  let sourceLabelX = x + w;
  if (source) {
    const s = String(source).toUpperCase();
    const sx = Math.max(x + 9, meterX - 1 - s.length);
    sourceLabelX = sx - 7;
    uiText(sx - 7, y + 1, 'SOURCE', 'ui-label');
    uiText(sx, y + 1, s, 'ui-primary');
  }
  const leftHeader = [wordmark, model, String(label).toUpperCase()].filter(Boolean).join(' ');
  if (leftHeader) {
    const maxLeft = Math.max(1, (source ? sourceLabelX : x + w - 2) - (x + 2) - 1);
    uiText(x + 2, y + 1, leftHeader.slice(0, maxLeft), 'ui-label');
  }
  if (meter) {
    const snapshot = meterSnapshot || monitorSnapshot();
    drawVfdMeter(meterX, y + 1, 12, snapshot, { theme, bandThresholds: MONITOR_DANGER_THRESHOLDS });
    drawVfdWarningTriangle(x + w - 3, y + 1, snapshot);
  }

  // Footer.
  if (footerParts?.length) drawPromptParts(x + 2, y + h - 2, footerParts, { role: 'ui-label', cols: w });
  else if (footer) uiText(x + 2, y + h - 2, String(footer).slice(0, Math.max(0, w - 4)), 'ui-label');
  if (buttons) drawButtonCluster(x + w - buttons.w - 2, y + PANEL.headerRows + 1, buttons);

  return machinePanelBody(x, y, w, h, { footer: footer || footerParts?.length ? 'CONTROLS' : '' });
}

// ── the bargraph meter (DA-1000 / Akai VOLUME scale) ─────────────────────────
//
// The instrument, not a texture. See render/meter.js for why it has a scale at
// all — two authored lines describe a meter "flat at the bottom of the scale",
// and the sound design files a flat meter as evidence the protagonist reasons
// from rather than decoration. The arithmetic lives there, pure and tested;
// this draws it.
//
// Three things this fixes that no amount of restyling would have:
//
//   · It was hard-capped at twelve segments. `n = min(THRESHOLDS.length, width)`
//     and then `totalW = n * cellW`, so a caller asking for thirty cells got
//     twelve segments in twelve cells and the rest of its budget vanished.
//   · The peak marker was dead code everywhere but one call site. It drew only
//     when `peakIndex >= lit`, and every recorder meter is fed
//     `monitorSnapshotForRms(scalar)` — where `peak === rms`, so `peakIndex` is
//     always inside the lit run. The tape has always kept peak-hold; the needle
//     beside it never showed one.
//   · Dormant segments were hard-coded phosphor at 0.10, ignoring the `dim`
//     token the palette explicitly calls "dormant phosphor — the VFD tell".
//
// SIZE is `auto` by default: the widget takes the rows it is given and drops
// the scale rather than overflowing a panel. The grid is not generous at the
// extremes — uiScale runs to 1.5, so the worst case is 75x20 — and roughly
// twenty machine-panel headers draw this in a single row.
export function drawVfdMeter(x, y, width = 14, snapshot = monitorSnapshot(), {
  thresholdDb = -3, label = '', theme = null, bandThresholds = null,
  rows = 1, marks = null, id = null, scaleLabel = '', over = null,
} = {}) {
  // A bad theme name used to repaint the surface amber AND leave it amber for
  // everything drawn afterwards, because setActiveSurface is global and sticky.
  // drawVfdText was fixed for this; this was missed. Only amber and green are
  // themes.
  if (theme && THEMES[theme]) setActiveSurface(theme);
  const t = activeTheme();

  const w = Math.max(1, Number(width) || 1);
  const count = meterSegmentCount(w);
  const key = id || `${x}:${y}`;

  // `segments` stays authoritative for how much is lit, so the HUSH pressure
  // monitorDisplaySnapshot injects and the clip-to-full-scale rule both survive
  // exactly — but position comes from dB, so the bar and the printed scale
  // cannot describe different things.
  const rawDb = Number.isFinite(Number(snapshot?.db)) ? Number(snapshot.db) : METER_MIN_DB;
  const flooredDb = snapshot?.segments > 0
    ? Math.max(rawDb, MONITOR_THRESHOLDS[Math.min(MONITOR_THRESHOLDS.length, snapshot.segments) - 1])
    : rawDb;

  const ballistic = meterState(key, flooredDb, nowSec() * 1000, { clipped: !!snapshot?.clipped });
  const lit = meterSegmentAt(ballistic.needleDb, count);
  const peakSeg = meterSegmentAt(ballistic.peakDb, count);
  const overNow = over != null ? !!over : nowSec() * 1000 < (ballistic.overUntilMs || 0);

  // Banks of four across twelve-ish segments land on the same boundaries as
  // MONITOR_DANGER_THRESHOLDS' normal / mid-hot / hot, so the grouping and the
  // colouring say the same thing in two languages.
  const { shape, offset } = meterGeometry({ x, w, segments: count, bankSize: 4 });
  const scaleRow = rows >= 2 && meterScaleFits(w);
  const placed = scaleRow ? meterMarks(marks, w) : [];

  uiDraw(({ ctx, dpr, cellW, cellH, cols }) => {
    const top = (y + 0.24) * cellH * dpr;
    const height = 0.44 * cellH * dpr;

    for (const cell of shape.cells) {
      const i = cell.index;
      const px = (offset + cell.x) * cellW * dpr;
      const pw = Math.max(1, cell.w * cellW * dpr);
      const at = offset + cell.x;
      const phosphor = themeRoleColor('phosphor', at, cols);
      const db = unitToDb((i + 0.5) / count);
      const on = i < lit;

      ctx.save();
      if (on) {
        const hot = bandThresholds ? db >= Number(bandThresholds.hotDb) : db >= thresholdDb;
        const midHot = bandThresholds && !hot && db >= Number(bandThresholds.midHotDb);
        ctx.fillStyle = hot ? t.danger : midHot ? themeRoleColor('warning', at, cols) : phosphor;
        ctx.globalAlpha = litDuty(at, y, hot ? 'danger' : midHot ? 'counter' : 'phosphor', 1);
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 4.5 * dpr;
      } else {
        // Dormant. Unlit elements on a real VFD do not go black; that faint
        // grid is the tell.
        //
        // NOT `themeRoleDim` — the `dim` token carries its own alpha (0.055
        // amber / 0.06 green), which is little more than HALF the 0.10 used
        // here, and globalAlpha cannot scale it back up. Switching to it would
        // have quietly dimmed the dormant segments on all sixteen metered panel
        // headers. The token is right for the unlit dot matrix under a glyph,
        // where drawVfdGlyph applies it; it is too faint for a segment.
        ctx.fillStyle = phosphor;
        ctx.globalAlpha = 0.10;
      }
      ctx.fillRect(px, top, pw, height);
      ctx.restore();
    }

    // THE HELD PEAK. A cap above the lit run that sits, then falls — which is
    // what a microphone does, and the rule the tape already keeps: a single
    // close pass is on the recording forever.
    if (peakSeg > 0 && peakSeg > lit) {
      const cell = shape.cells[Math.min(shape.cells.length - 1, peakSeg - 1)];
      ctx.save();
      ctx.globalAlpha = 0.95 * uiFlickerAlpha(x + peakSeg, y, 'counter');
      ctx.fillStyle = themeRoleColor('counter', x + peakSeg, cols);
      ctx.fillRect((offset + cell.x) * cellW * dpr, top, Math.max(1, cell.w * cellW * dpr), height);
      ctx.restore();
    }

    // Reference marks: a hairline standing through the bar at a level the
    // player is being asked to stay under. Drawn over the segments so the bar
    // visibly crosses it.
    for (const mark of placed) {
      const mx = (x + mark.x) * cellW * dpr;
      ctx.save();
      // The SPOIL mark is the DA-1000's red POSITION marker, which is exactly
      // its meaning here: the one place on the scale that matters.
      ctx.fillStyle = mark.kind === 'spoil' || mark.kind === 'catch'
        ? themeRoleColor('marker', x + mark.x, cols)
        : themeRoleColor('silkscreen', x + mark.x, cols);
      ctx.globalAlpha = mark.kind === 'floor' ? .55 : .92;
      ctx.fillRect(mx, top - .10 * cellH * dpr, Math.max(1, dpr), height + .20 * cellH * dpr);
      ctx.restore();
    }
  });

  // OVER, latched. A clip that blinks out before you look up did not tell you
  // anything.
  if (overNow) uiText(x + Math.max(0, w - 4), y, 'OVER', 'ui-danger', 1, 4);

  if (label) uiText(Math.max(0, x - label.length - 1), y, String(label).toUpperCase(), 'ui-label');

  if (!scaleRow) return { rows: 1, scale: false };

  // ── the printed scale ──────────────────────────────────────────────────────
  //
  // Marks are placed first and the numbers step around them. A player needs to
  // know where SPOIL is more than they need to read -12, and drawing both into
  // the same cells produced "SPOIL12CATCH".
  const boxes = meterMarkBoxes(marks, w);
  for (const tick of meterTicks(w, { avoid: boxes })) {
    uiText(x + Math.round(tick.left), y + 1, tick.label, 'ui-label', .72);
  }
  for (const box of boxes) {
    uiText(x + Math.round(box.left), y + 1, box.mark.label,
      box.mark.kind === 'floor' ? 'ui-secondary' : 'ui-marker', .85);
  }
  if (scaleLabel) uiText(x, y + 1, String(scaleLabel).toUpperCase(), 'ui-label', .6);
  return { rows: 2, scale: true };
}

export function drawVfdWarningTriangle(x, y, snapshot = monitorSnapshot(), { now = null } = {}) {
  const band = snapshot?.band || 'normal';
  if (band === 'normal') return false;
  const hot = band === 'hot';
  const seconds = Number.isFinite(Number(now)) ? Number(now) / 1000 : nowSec();
  const blink = .34 + .66 * (Math.sin(seconds * Math.PI * (hot ? 5.2 : 3.4)) > 0 ? 1 : .18);
  const color = hot ? activeTheme().danger : themeRoleColor('warning');
  uiDraw(({ ctx, dpr, cellW, cellH }) => {
    const left = x * cellW * dpr;
    const top = (y + .08) * cellH * dpr;
    const width = Math.max(4, 1.75 * cellW * dpr);
    const height = Math.max(4, .78 * cellH * dpr);
    ctx.save();
    ctx.globalAlpha = blink;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, dpr);
    ctx.shadowColor = color;
    ctx.shadowBlur = 4 * dpr;
    ctx.beginPath();
    ctx.moveTo(left + width * .5, top);
    ctx.lineTo(left + width, top + height);
    ctx.lineTo(left, top + height);
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
  });
  uiText(x + .64, y, '!', hot ? 'ui-danger' : 'ui-warning', blink);
  return true;
}

// The DA-1000 LOCATION INDICATOR: a row of vertical bars with a red position
// marker, used for take progress. `p` is 0..1.
export function drawLocationIndicator(x, y, width, p, {
  theme = 'green', seconds = 45, marks = null, rows = 1, label = '',
} = {}) {
  // Guarded, like drawVfdText. Only amber and green are themes; setActiveSurface
  // is global and sticky, so a bad name repainted this amber AND left the
  // surface amber for everything drawn after it. combat.js asks for 'red' on
  // the correction stage and has never once rendered it.
  if (THEMES[theme]) setActiveSurface(theme);
  const t = activeTheme();
  const b = uiBrightness();

  const w = Math.max(4, Math.floor(width));
  const placed = locationMarks(marks, w);
  const scaleRow = rows >= 2 && locationScaleFits(w);
  const ticks = scaleRow ? locationTicks(w, { seconds }) : [];

  uiDraw(({ ctx, dpr, cellW, cellH, cols }) => {
    const n = w;
    const gap = Math.max(1, Math.round(1.6 * dpr));
    const totalW = n * cellW * dpr;
    const segW = Math.max(2 * dpr, (totalW - gap * (n - 1)) / n);
    const base = (y + 0.9) * cellH * dpr;
    const mark = Math.round(clamp01(p) * (n - 1));
    // FLAT, NOT SWELLED. The bars used to grow toward the middle on a sine,
    // which made both ends read as less important — backwards, because the
    // right-hand end is where the take completes. A graduated scale earns its
    // shape from its marks, not from a curve.
    const bh = 0.62 * cellH * dpr;

    for (let i = 0; i < n; i++) {
      const px = x * cellW * dpr + i * (segW + gap);
      const phosphor = themeRoleColor('phosphor', x + i, cols);
      const on = i <= mark;
      ctx.save();
      ctx.fillStyle = phosphor;
      ctx.globalAlpha = on ? Math.min(1, b * uiFlickerAlpha(x + i, y, 'phosphor')) : 0.12;
      if (on) { ctx.shadowColor = phosphor; ctx.shadowBlur = 3 * dpr; }
      ctx.fillRect(px, base - bh, segW, bh);
      ctx.restore();
    }

    // Graduation notches, standing in the dormant run so the strip reads as a
    // scale even before anything has been recorded on it.
    for (const tick of ticks) {
      const tx = (x + tick.x) * cellW * dpr;
      ctx.save();
      ctx.fillStyle = themeRoleColor('silkscreen', x + tick.x, cols);
      ctx.globalAlpha = tick.major ? .85 : .5;
      ctx.fillRect(tx, base - bh - (tick.major ? .16 : .09) * cellH * dpr,
        Math.max(1, dpr), (tick.major ? .18 : .11) * cellH * dpr + bh * (tick.major ? .34 : .2));
      ctx.restore();
    }

    // WHAT HAPPENED, AND WHEN. Everything here was already being recorded and
    // had nowhere to be seen: after a spoiled take you knew THAT it went wrong
    // and never when. Drawn through the whole strip so a mark reads against the
    // lit run rather than beside it.
    for (const entry of placed) {
      const mx = (x + entry.x) * cellW * dpr;
      // Three kinds, three weights. The one that ended the take is the marker
      // red — the same colour as the playhead, because both are answers to
      // "where": one is where you are, the other is where it went wrong.
      const role = entry.kind === 'spoil' ? 'marker'
        : entry.kind === 'presence' ? 'counter'
          : 'warning';
      ctx.save();
      ctx.fillStyle = themeRoleColor(role, x + entry.x, cols);
      ctx.globalAlpha = entry.kind === 'near' ? .62 : .95;
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 4 * dpr;
      ctx.fillRect(mx, base - bh - .12 * cellH * dpr, Math.max(1, dpr), bh + .24 * cellH * dpr);
      ctx.restore();
    }

    // THE PLAYHEAD, through the strip rather than floating above it. It used to
    // be a block in its own row at y+0.05, which read as a separate object
    // sitting near the bar instead of a position on it.
    const mx = x * cellW * dpr + mark * (segW + gap);
    ctx.save();
    ctx.globalAlpha = litDuty(x + mark, y, 'marker', 1);
    ctx.fillStyle = t.marker;
    ctx.shadowColor = t.marker;
    ctx.shadowBlur = 5 * dpr;
    ctx.fillRect(mx, base - bh - .22 * cellH * dpr, Math.max(segW, 1.5 * dpr), bh + .34 * cellH * dpr);
    ctx.restore();
  });

  if (scaleRow) {
    for (const tick of ticks) uiText(x + Math.round(tick.left), y + 1, tick.label, 'ui-label', .68);
    if (label) uiText(x, y + 1, String(label).toUpperCase(), 'ui-label', .6);
  }
  return { rows: scaleRow ? 2 : 1, scale: scaleRow };
}


// ── the numeric counter (7-segment, pale-cyan on the DA-1000) ────────────────
const DIGIT = {
  0: 'abcdef', 1: 'bc', 2: 'abdeg', 3: 'abcdg', 4: 'bcfg',
  5: 'acdfg', 6: 'acdefg', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg', '-': 'g', ' ': '',
};
const SEG7 = {
  a: [.16, .06, .84, .06], b: [.88, .10, .88, .48], c: [.88, .52, .88, .90],
  d: [.16, .94, .84, .94], e: [.12, .52, .12, .90], f: [.12, .10, .12, .48], g: [.18, .50, .82, .50],
};
export function drawVfdCounter(x, y, value, { scale = 1, theme = null, color = null } = {}) {
  if (theme) setActiveSurface(theme);

  const b = uiBrightness();
  const text = String(value);

  uiDraw(({ ctx, dpr, cellW, cellH, cols }) => {
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineWidth = Math.max(1.4, 2.0 * scale) * dpr;

    const uw = cellW * 1.05 * scale;
    const uh = cellH * scale;

    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      const bx = (x + i * 1.15 * scale) * cellW * dpr;
      const by = y * cellH * dpr;
      const cellX = x + i * 1.15 * scale;
      const col = color || themeRoleColor('counter', cellX, cols);
      const dim = themeRoleDim('counter', cellX, cols) || 'rgba(255,255,255,0.05)';
      const duty = litDuty(cellX, y, 'counter', 1);

      if (ch === ':' || ch === '.') {
        ctx.fillStyle = col;
        ctx.shadowColor = col;
        ctx.shadowBlur = 4 * dpr;
        ctx.globalAlpha = duty;

        const dots = ch === ':' ? [.34, .66] : [.9];
        for (const dy of dots) {
          ctx.fillRect(bx + uw * .42, by + uh * dy, 2 * dpr, 2 * dpr);
        }

        continue;
      }

      const active = DIGIT[ch] || '';

      // dormant segments first, then lit
      for (const [name, p] of Object.entries(SEG7)) {
        const on = active.includes(name);

        ctx.strokeStyle = on ? col : dim;
        ctx.globalAlpha = on ? duty : 1;
        ctx.shadowColor = on ? col : 'transparent';
        ctx.shadowBlur = on ? 5.5 * dpr : 0;

        ctx.beginPath();
        ctx.moveTo(bx + p[0] * uw * dpr, by + p[1] * uh * dpr);
        ctx.lineTo(bx + p[2] * uw * dpr, by + p[3] * uh * dpr);
        ctx.stroke();
      }
    }

    ctx.globalAlpha = 1;
    ctx.restore();
  });
}

// Big dot-matrix text (the title, a speaker name) at an arbitrary scale.
//
// FOUR THINGS THIS USED TO GET WRONG, all of them silently:
//
//   · `color` and `max` were accepted and dropped on the floor. Ten call sites
//     passed them expecting a colour override and a width, and got a full-length
//     string in plain phosphor that could run off the end of its panel.
//   · `theme:'danger'` and `theme:'red'` are not themes. setActiveSurface falls
//     back to amber, so five call sites asking for red have been drawing amber.
//     A colour is what they wanted; `color` now does it, and a bad theme name
//     no longer silently repaints the whole surface.
//   · every `role` except 'ui-counter' collapsed to phosphor, so 'ui-danger'
//     and 'ui-primary' were the same word in the same colour. The palette
//     already has the map (uiRoleColor); use it.
//   · the glyph box was `cellW * 1.42 * scale` tall while the row advanced by
//     `cellH`, so anything above scale ~1.4 overflowed the row below it.
//
// The DORMANT GRID is deliberately always the panel's own dim phosphor, whatever
// colour the lit dots are: the unlit matrix belongs to the glass, not to what is
// written on it.
// THE BIG-TEXT PATH IS CACHED TOO, AND IT HAS TO BE.
//
// uiText goes through the atlas, so its glow is baked once per glyph and blitted
// thereafter. drawVfdText did not: it re-ran the whole dot loop every frame, for
// every character, at 50 call sites across combat, dialogue, titles, credits and
// the recorder. A 20-character title at scale 2 was several hundred shadowed
// fills a frame. Making the glow better without caching this would have made the
// worst path worse.
//
// BRIGHTNESS IS NOT PART OF THE KEY. It is the blit.
//
// The two time-varying terms — litDuty (16 pwm steps) and scanDuty (three
// values) — are both pure amplitude multipliers, so folding them into the cache
// key would have meant baking 48 variants of every character and re-baking as
// the multiplex artifact cycled. Measured, the two-lobe bake is ~0.15ms a glyph
// against ~0.02ms for the shadowBlur it replaced, so 48 variants of a title is
// a real hitch rather than a rounding error.
//
// So the tile is baked ONCE at full duty and dimmed with globalAlpha when it is
// blitted. The key collapses to (glyph, colour, size) and the whole display
// dims together, which is what a display does. It is also exactly what the
// atlas has always done for uiText — bake at brightness, blit at alpha.
const vfdTextTiles = new Map();
const VFD_TEXT_TILE_LIMIT = 1400;

function vfdTextTile(glyph, { color, dim, cw, ch, dpr, blur, halation }) {
  const key = `${glyph}|${color}|${dim}|${Math.round(cw)}|${Math.round(ch)}|${dpr}`;
  const hit = vfdTextTiles.get(key);
  if (hit) return hit;
  if (typeof document === 'undefined' || typeof document.createElement !== 'function') return null;
  const bleed = vfdGlowBleed(cw, ch);
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(cw + bleed * 2);
  canvas.height = Math.ceil(ch + bleed * 2);
  const tileCtx = canvas.getContext('2d');
  if (!tileCtx) return null;
  drawVfdGlyph(tileCtx, glyph, bleed, bleed, cw, ch, { color, dim, blur, dpr, alpha: 1, scan: 1, halation });
  // A flat cap rather than an LRU: the key space is bounded by construction, so
  // this only trips if a caller invents sizes every frame — and if that happens,
  // dropping the lot is cheaper than pretending to be clever about it.
  if (vfdTextTiles.size > VFD_TEXT_TILE_LIMIT) vfdTextTiles.clear();
  const tile = { canvas, bleed };
  vfdTextTiles.set(key, tile);
  return tile;
}

export function drawVfdText(x, y, text, {
  scale = 2, theme = null, role = 'ui-primary', alpha = 1, color = null, max = null,
} = {}) {
  if (theme && THEMES[theme]) setActiveSurface(theme);
  const tint = color || (theme && !THEMES[theme] ? theme : null);

  const value = fitText(String(text).toUpperCase(), max == null ? null : Math.floor(max / Math.max(0.25, scale)));

  uiDraw(({ ctx, dpr, cellW, cellH, cols }) => {
    const cw = cellW * scale * dpr;
    // Height follows the ROW the text sits on, so a scaled word occupies the
    // rows it claims and nothing underneath it.
    const ch = Math.min(cellW * 1.42, cellH) * scale * dpr;
    const oy = y * cellH * dpr;

    for (let i = 0; i < value.length; i++) {
      const cellX = x + i * scale;
      const duty = litDuty(cellX, y, 'phosphor', alpha);
      const px = (x * cellW * dpr) + i * cw;
      const glyphColor = tint || uiRoleColor(role, cellX, cols);
      const glyphDim = themeRoleDim('phosphor', cellX, cols);
      const scan = scanDuty(cellX, y);
      const tile = vfdTextTile(value[i], {
        color: glyphColor, dim: glyphDim, cw, ch, dpr, blur: 4.25, halation: 0.18,
      });
      if (tile) {
        const level = Math.max(0, Math.min(1, duty * scan));
        if (level <= 0) continue;
        if (level !== 1) ctx.globalAlpha = level;
        ctx.drawImage(tile.canvas, px - tile.bleed, oy - tile.bleed);
        if (level !== 1) ctx.globalAlpha = 1;
      } else {
        drawVfdGlyph(ctx, value[i], px, oy, cw, ch, {
          color: glyphColor, dim: glyphDim, blur: 4.25, dpr, alpha: duty, scan, halation: 0.18,
        });
      }
    }
  });

  return value.length * scale;
}

// A right-hand button cluster: square silkscreened keys, a few lit. `spec` is
// { w, keys: [{ label, lit?: 'rec'|'play'|'power' }] }.
export function drawButtonCluster(x, y, { w = 6, keys = [] } = {}) {
  const t = activeTheme();
  const lit = { rec: '#FF3B30', play: t.phosphor, power: '#3B7BFF' };
  keys.forEach((k, i) => {
    const by = y + i * 2;
    uiDraw(({ ctx, dpr, cellW, cellH }) => {
      const bx = x * cellW * dpr, byy = by * cellH * dpr;
      const bw = (w - 2) * cellW * dpr, bh = 1.4 * cellH * dpr;
      rect(ctx, bx, byy, bw, bh, '#161616');
      hairline(ctx, bx, byy, bw, bh, '#333', 1, 1, dpr);
      if (k.lit) {
        const c = lit[k.lit] || t.phosphor;
        ctx.save(); ctx.globalAlpha = uiFlickerAlpha(x + w - 2, by, k.lit === 'rec' ? 'marker' : 'phosphor'); ctx.fillStyle = c; ctx.shadowColor = c; ctx.shadowBlur = 4 * dpr;
        ctx.beginPath(); ctx.arc(bx + bw - 4 * dpr, byy + bh / 2, 2.2 * dpr, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      }
    });
    if (k.label) uiText(x, by, k.label, k.lit ? 'ui-primary' : 'ui-label');
  });
}

// ── the paper ─────────────────────────────────────────────────────────────────
// A real typed sheet: flat warm cream stock with a fine tooth (noise, not
// bands), a soft contact shadow beneath it, and a letterhead rule. The type
// itself is drawn by the reader with slightly uneven ink.
let paperTex = null, paperTexW = 0, paperTexH = 0;
function paperTexture(w, h) {
  if (paperTex && paperTexW === w && paperTexH === h) return paperTex;
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#D8CFB8'; ctx.fillRect(0, 0, w, h);
  const img = ctx.getImageData(0, 0, w, h); const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * 16;      // fibre tooth, subtle
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n * 0.9));
  }
  ctx.putImageData(img, 0, 0);
  paperTex = c; paperTexW = w; paperTexH = h;
  return c;
}

export function drawPaperPanel(x, y, w, h) {
  uiDraw(({ ctx, dpr, cellW, cellH }) => {
    const px = x * cellW * dpr, py = y * cellH * dpr, pw = w * cellW * dpr, ph = h * cellH * dpr;
    // contact shadow: a soft dark pad offset down-right, no gradient fill — a
    // blurred rect.
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 18 * dpr;
    ctx.shadowOffsetX = 3 * dpr; ctx.shadowOffsetY = 6 * dpr;
    ctx.fillStyle = '#000'; ctx.fillRect(px, py, pw, ph);
    ctx.restore();
    // the sheet, flat cream with a fibre tooth
    const tex = paperTexture(Math.max(2, Math.round(pw)), Math.max(2, Math.round(ph)));
    ctx.drawImage(tex, px, py);
    // a faint deckle edge
    ctx.save(); ctx.globalAlpha = 0.10; ctx.strokeStyle = '#20180F'; ctx.lineWidth = dpr;
    ctx.strokeRect(px + 0.5 * dpr, py + 0.5 * dpr, pw - dpr, ph - dpr); ctx.restore();
  });
  return { x: x + 3, y: y + 2, w: Math.max(1, w - 6), h: Math.max(1, h - 4) };
}

// ── the paperwork ─────────────────────────────────────────────────────────────
//
// THE FORM IS FILLED IN AT RUNTIME, WHICH IS WHY IT IS DRAWN AND NOT BUILT.
//
// The offline paper pipeline (scripts/build-paper-assets.mjs, game/paper-assets.js)
// owns every AUTHORED document: 211 of them, rasterised to immutable 2048x2896
// sheets with real impact-printer morphology and photocopy generations. Its own
// rule is that "meaning never changes here: strings were fixed before this
// program runs" — and a return form carrying tonight's take count is precisely
// a document whose strings cannot be fixed in advance. It is stationery that is
// being typed on now, in front of the player, so it is drawn now.
//
// The glyphs are the UI dot matrix in paper ink, which is not a compromise: a
// 1980s works office filled these in on a nine-pin impact printer, and a dot
// matrix on cream stock is what that looks like.

// A ruled line across the sheet, in ink rather than phosphor.
export function drawFormRule(x, y, w, { alpha = 0.30, weight = 1 } = {}) {
  uiDraw(({ ctx, dpr, cellW, cellH }) => {
    const px = x * cellW * dpr, py = (y + 0.62) * cellH * dpr, pw = w * cellW * dpr;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = UI_COLOR.paperInk;
    ctx.fillRect(px, py, pw, Math.max(1, weight * dpr));
    ctx.restore();
  });
}

// LABEL . . . . . . . . . . . VALUE
//
// Leader dots, because that is how a form guides an eye across a wide sheet and
// it is the detail that separates stationery from a table. A row with no value
// is a blank waiting to be filled, and prints its leaders anyway.
export function drawFormRow(x, y, w, label, value = '', {
  labelRole = 'paper-ink', valueRole = 'paper-ink', alpha = 1, leader = '.',
} = {}) {
  const name = String(label || '').toUpperCase();
  const entry = String(value ?? '');
  const room = Math.max(0, w - name.length - entry.length - 2);
  uiText(x, y, name, labelRole, alpha);
  if (room > 0) {
    // Spaced leaders: a solid run of dots reads as a rule, not as guidance.
    let dots = '';
    for (let i = 0; i < room; i += 1) dots += (i % 2 ? ' ' : leader);
    uiText(x + name.length + 1, y, dots, labelRole, alpha * 0.42);
  }
  if (entry) uiText(x + w - entry.length, y, entry, valueRole, alpha);
  return y + 1;
}

// The rubber stamp. Boxed, slightly off-square, and deliberately the only thing
// on the sheet that is not aligned to the grid — a stamp is put on by a hand.
export function drawFormStamp(x, y, text, { alpha = 1, tilt = -0.035 } = {}) {
  const mark = String(text || '').toUpperCase();
  if (!mark) return;
  uiDraw(({ ctx, dpr, cellW, cellH }) => {
    const px = x * cellW * dpr, py = y * cellH * dpr;
    const pw = (mark.length + 4) * cellW * dpr, ph = 2.6 * cellH * dpr;
    ctx.save();
    ctx.translate(px + pw / 2, py + ph / 2);
    ctx.rotate(tilt);
    ctx.translate(-(px + pw / 2), -(py + ph / 2));
    ctx.globalAlpha = alpha * 0.72;
    ctx.strokeStyle = UI_COLOR.paperInk;
    ctx.lineWidth = Math.max(1.4, 1.8 * dpr);
    ctx.strokeRect(px, py, pw, ph);
    ctx.lineWidth = Math.max(1, 0.9 * dpr);
    ctx.strokeRect(px + 2 * dpr, py + 2 * dpr, pw - 4 * dpr, ph - 4 * dpr);
    ctx.restore();
  });
  uiText(x + 2, y + 1, mark, 'paper-ink', alpha * 0.86);
}

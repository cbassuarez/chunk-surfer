import { ENDING_IDS } from './schema.js';
import { lastReturnRecord } from './return-history.js';
import { secondShiftForEnding } from '../game/second-shift.js';
import { normalizeInterferenceRecord } from '../game/interference-case.js';

const clone = (value) => JSON.parse(JSON.stringify(value));

export const RETURN_DEFS = Object.freeze([
  Object.freeze({ id: 'sacrifice', order: 1, title: 'THE SEAL', classification: 'CONTAINMENT', hiddenUntilSeen: true }),
  Object.freeze({ id: 'helped', order: 2, title: 'HE TRIED TO HELP', classification: 'INTERVENTION', hiddenUntilSeen: true }),
  Object.freeze({ id: 'inversion', order: 3, title: 'THE OTHER DOOR', classification: 'INVERSION', hiddenUntilSeen: true }),
  Object.freeze({ id: 'drugged', order: 4, title: 'COLD, BITTER, GONE', classification: 'CONTAMINATION', hiddenUntilSeen: true }),
  Object.freeze({ id: 'surfaced', order: 5, title: 'THE OTHER RECORDIST', classification: 'EXTRACTION', hiddenUntilSeen: true }),
  Object.freeze({ id: 'contact-won', order: 6, family: 'CONTACT', title: 'OPEN CHANNEL', classification: 'CONTACT / VICTORY', hiddenUntilSeen: true }),
  Object.freeze({ id: 'contact-lost', order: 7, family: 'CONTACT', title: 'NO RETURN', classification: 'CONTACT / TERMINAL', hiddenUntilSeen: true }),
  Object.freeze({ id: 'tower-won', order: 8, family: 'TOWER', title: 'EXIT THROUGH THE GIFT SHOP', classification: 'TOWER / EXTRACTION', hiddenUntilSeen: true }),
  Object.freeze({ id: 'tower-lost', order: 9, family: 'TOWER', title: 'THE FULL PEAL', classification: 'TOWER / TERMINAL', hiddenUntilSeen: true }),
]);

export function returnDefinition(id) {
  return RETURN_DEFS.find((def) => def.id === id) || null;
}

export function returnIndexEntries(meta) {
  const seen = new Set((meta?.endingsSeen || []).filter((id) => ENDING_IDS.includes(id)));
  const revealClassifications = seen.size >= 2;
  const last = lastReturnRecord(meta);
  const shift = secondShiftForEnding(last?.endingId);
  const records = Object.values(meta?.returns?.records || {})
    .filter((entry) => entry && typeof entry === 'object')
    .sort((a, b) => (Number(b.completedAt) || 0) - (Number(a.completedAt) || 0));
  return RETURN_DEFS.map((def) => {
    const filed = records.find((entry) => entry.endingId === def.id);
    return {
      ...def,
      seen: seen.has(def.id),
      adjacent: !seen.has(def.id) && shift?.adjacentEndingId === def.id,
      adjacentLead: shift?.adjacentEndingId === def.id ? shift.lead : '',
      displayTitle: seen.has(def.id) ? def.title : '████████████',
      displayClassification: seen.has(def.id) || revealClassifications || shift?.adjacentEndingId === def.id ? def.classification : '',
      status: seen.has(def.id) ? 'FILED' : shift?.adjacentEndingId === def.id ? 'LEAD' : 'WITHHELD',
      interference: normalizeInterferenceRecord(filed?.interference),
    };
  });
}

export function buildRunSummary({ endingId, save, meta, authoritative = {}, now = Date.now() } = {}) {
  const run = save?.run;
  if (!run || !ENDING_IDS.includes(endingId)) throw new Error(`cannot summarize ending: ${endingId}`);
  const ledger = run.ledger || {};
  const rec = authoritative.rec || {};
  const completedRooms = Array.isArray(rec.takes) ? [...new Set(rec.takes)] : [...new Set(ledger.takes?.rooms || [])];
  const injuries = Number.isFinite(Number(rec.injuries)) ? Number(rec.injuries) : Number(ledger.injuries) || 0;
  const issued = ['light', 'recorder', 'map', 'radio'];
  const dropped = [...new Set(ledger.equipment?.dropped || [])];
  const missing = [...new Set(authoritative.missingEquipment || dropped)];
  const returned = issued.filter((id) => !missing.includes(id));
  const contaminatedRooms = Array.isArray(rec.contaminated)
    ? [...new Set(rec.contaminated)].filter((id) => completedRooms.includes(id))
    : [...new Set(ledger.takes?.contaminated || [])].filter((id) => completedRooms.includes(id));

  return {
    schema: 1,
    id: `return:${run.id}`,
    runId: run.id,
    endingId,
    startedAt: run.startedAt,
    completedAt: now,
    durationSeconds: Math.max(0, Number(save?.playSeconds) || Math.floor((now - run.startedAt) / 1000)),
    rules: clone(run.rules),
    integrity: clone(run.integrity),
    takes: {
      completed: completedRooms.length,
      spoiled: Number(ledger.takes?.spoiled) || 0,
      aborted: Number(ledger.takes?.aborted) || 0,
      rooms: completedRooms,
      contaminated: contaminatedRooms,
      // Where in the room each one was rolled. Only the concert hall has more
      // than one answer; every other room reports nothing rather than a place
      // that could only ever have one value.
      places: Object.fromEntries(Object.entries(rec.places || ledger.takes?.places || {})
        .filter(([roomId, place]) => place && completedRooms.includes(roomId))),
    },
    injuries,
    battles: clone(ledger.battles || { started: 0, won: 0, lost: 0, firstPassWon: 0, results: {} }),
    disclosures: { found: (ledger.disclosures || []).length, ids: [...(ledger.disclosures || [])] },
    documents: { read: (ledger.documentsRead || []).length, ids: [...(ledger.documentsRead || [])] },
    equipment: {
      issued: issued.length,
      returned: returned.length,
      missing,
      dropped,
      recovered: [...(ledger.equipment?.recovered || [])],
    },
    choices: clone(ledger.choices || {}),
    interference: normalizeInterferenceRecord(authoritative.interference || run.interference),
    replay: clone(run.replay || {}),
    power: clone(ledger.power || { live: [], everRestored: [] }),
    unlockedAchievements: [],
    newlyUnlockedFeatures: [],
    endingsAtCompletion: new Set([...(meta?.endingsSeen || []), endingId]).size,
  };
}

export function formatDuration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return [h, m, s].map((n) => String(n).padStart(2, '0')).join(':');
}

import { DEFAULT_SETTINGS, freshMeta, normalizeSettings, normalizeMeta } from '../../progression/schema.js';
import { SAVE_VERSION } from '../../progression/schema.js';
import { freshCombatLoadout } from '../../game/combat-loadout.js';

export function defaultSettings() {
  return normalizeSettings(DEFAULT_SETTINGS);
}

export function defaultProfile() {
  return normalizeMeta(freshMeta());
}

export function defaultSave(settings = defaultSettings()) {
  return {
    version: SAVE_VERSION,
    flags: {},
    area: 'prologue',
    px: 0,
    py: 0,
    takes: [],
    items: [],
    props: { inspected: [], auditioned: [], cycles: {}, hushSeed: 0x43535552, hushCount: 0 },
    encounters: { cleared: [] },
    bagLoadout: freshCombatLoadout(),
    doors: { schema: 2, states: {} },
    playSeconds: 0,
    steps: 0,
    bagNav: null,
    hushAudio: null,
    chunkSurf: null,
    chapelTower: null,
    settings: normalizeSettings(settings),
    run: null,
  };
}

import { isTauriRuntime } from './detect.js';
import { logWarn } from './diagnostics/diagnostics.js';
import { sectorErrorPhases } from '../render/sector-error.js';
import { sourceWarningFrames } from '../render/source-warning.js';
import { drawPracticeRebus } from '../render/practice-rebus.js';
import { SOURCE_FAULT_RUN_MS, SOURCE_FAULT_LANES } from '../game/source-faults.js';
import { TAKEOVER_CLINICAL, TAKEOVER_COMFORT } from '../game/interruption-director.js';
import {createWindowMediaSimulation} from './window-media-simulation.js';
import {sourceRestOwnedFramesValid} from '../render/source-rest-apertures.js';
import {validateWindowArchitecturePacket,windowArchitectureCueAllowed} from '../render/window-media-architecture.js';
import { ensureWorldLetteringFonts } from '../render/world-lettering-fonts.js';
import {
  apertureCompositionPlan,
  compilePaneScore,
  compileWindowCompositionPlan,
  deathCompositionPlan,
  endingCompositionPlan,
  returnCompositionPlan,
  sectorErrorCompositionPlan,
  sourceWarningCompositionPlan,
  sourceDecayCompositionPlan,
  SOURCE_DECAY_STAGES,
  SECTOR_INTRUSION_EVENT,
  SECTOR_RUN_EVENT_PREFIX,
  SECTOR_CLEAR_EVENT,
  evaluateCompositionConstraints,
  titleCompositionPlan,
  windowMediaAsset,
} from './window-composition.js';

export const WINDOW_CHOREOGRAPHY_PRIMITIVES=Object.freeze([
  'Frame','Glide','Cinch','Bloom','Dock','Breach','Restore','Split','Cast',
  'Handoff','Orbit','Swarm','Recenter','Simulate',
]);

const BATTLE_PROFILES=Object.freeze({
  natatorium:Object.freeze({
    battleId:'natatorium',intensity:.18,activity:.18,intro:'rise',formation:'rise-drift',
    introFrom:{x:.50,y:1.12},damageAxis:'vertical',primitives:['Breach','Glide','Split','Cast'],
  }),
  hall:Object.freeze({
    battleId:'hall',intensity:.36,activity:.34,intro:'take-seat',formation:'seat-align',
    introFrom:{x:.78,y:.80},damageAxis:'lateral',primitives:['Breach','Dock','Glide','Split','Cast'],
  }),
  practice:Object.freeze({
    battleId:'practice',intensity:.52,activity:.52,intro:'rewind',formation:'retake-loop',
    introFrom:{x:.18,y:.50},damageAxis:'rewind',primitives:['Breach','Handoff','Glide','Split','Cast'],
  }),
  chapel:Object.freeze({
    battleId:'chapel',intensity:.78,activity:.82,intro:'descend',formation:'orbit-cross',
    introFrom:{x:.50,y:-.15},damageAxis:'constrict',primitives:['Breach','Dock','Orbit','Cinch','Split','Cast'],
  }),
  'source-final':Object.freeze({
    battleId:'source-final',intensity:1,activity:1,intro:'assemble',formation:'swarm-recombine',
    introFrom:{x:.50,y:.50},damageAxis:'unstable',primitives:['Handoff','Orbit','Cinch','Swarm','Split','Cast'],
  }),
});

const ENDING_PROFILES=Object.freeze({
  sacrifice:{primitive:'Cinch',resolution:'containment'},
  helped:{primitive:'Cinch',resolution:'containment'},
  inversion:{primitive:'Bloom',resolution:'ordinary-exterior'},
  drugged:{primitive:'Dock',resolution:'van-inert'},
  surfaced:{primitive:'Handoff',resolution:'two-names-returned'},
  'contact-won':{primitive:'Cinch',resolution:'failing-body-recorder'},
  'contact-lost':{primitive:'Handoff',resolution:'distant-dot'},
  'tower-won':{primitive:'Bloom',resolution:'exterior-doors'},
  'tower-lost':{primitive:'Swarm',resolution:'completed-peal'},
});

const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,Number(value)||0));
const safe=(task)=>Promise.resolve().then(task).catch(()=>null);
const stableId=(value='')=>String(value||'').replace(/[^a-z0-9:_-]/giu,'-').slice(0,96);
const wait=(ms)=>new Promise((resolve)=>setTimeout(resolve,ms));

export function battleChoreographyProfile(battleId=''){
  return BATTLE_PROFILES[String(battleId||'')]||null;
}

export function endingChoreographyProfile(endingId=''){
  const profile=ENDING_PROFILES[String(endingId||'')];
  return profile?Object.freeze({endingId:String(endingId),...profile}):null;
}

export function windowChoreographyPolicy(sceneId=''){
  const id=String(sceneId||'');
  if(BATTLE_PROFILES[id]||id.startsWith('battle:'))return 'battle-only';
  if(id==='source:white-crossing'||id==='source:proper'||id==='source-final'||id==='source:standing-tear'||id==='source:continuation')return 'source-leakage';
  if(id.startsWith('ending:')||ENDING_PROFILES[id])return 'ending-resolution';
  if(id==='credits')return 'credits-restoration';
  // THE ONE PUZZLE THAT REACHES OUTSIDE THE WINDOW, AND IT ONLY EVER SHOWS.
  //
  // Everything above earned the compositor by being a rupture: a battle, the
  // Source leak, an ending, the credits. This is an ordinary room, so it gets a
  // policy of its own rather than being folded into one of those — and what it
  // is allowed to do is narrower than any of them. The box office surfaces are
  // CLUE DISPLAY: three key tags laid beside the window so they can be read
  // together, which is the one thing an in-game inspect prompt cannot do.
  //
  // They never take input, they never move the main window, and nothing is
  // gated on them: the tags are readable in the room and the ledger names the
  // key, so a browser build, withheld consent, disabled effects or reduced
  // motion cost atmosphere and never the answer. See test/box-office.spec.mjs,
  // which asserts the puzzle is solvable with the policy forced to 'stable'.
  if(id==='box-office:key-cabinet')return 'box-office';
  // THE SECOND ORDINARY ROOM, AND THE SAME NARROW PERMISSION.
  //
  // The plant header is a microgame, not a comparison, so what its surfaces do
  // is slightly different from the box office's and just as limited: the
  // service card says which fitting closes in which order, and the gauges show
  // the header actually falling. That is REASSURANCE and INSTRUCTION, for a
  // player who cannot tell whether the thing they are doing is working.
  //
  // Nothing is gated on them. The card is a prop on the plant-room wall and the
  // gauges are on the header itself, so a browser build, withheld consent,
  // disabled effects or reduced motion costs comfort and never the repair. See
  // test/plant-isolation.spec.mjs, which shuts the header with the policy
  // forced to 'stable'.
  if(id==='plant:header')return 'plant-header';
  // A pane that opens beside the window and then covers it from inside the frame.
  // The OS pane can't take input, can't take focus and never moves the main window.
  // Nothing is gated on it, and browser builds, withheld consent and reduced dread
  // each run their own whole version. See src/game/window-takeover.js.
  if(id==='takeover:memory')return 'memory-takeover';
  return 'stable';
}

// The FOH threshold is the firewall. Progress, elapsed time and emergency-red
// metadata are deliberately ignored until the Source runtime says the body is
// physically in the approach. This keeps the page, both HUSH planes, Scene Dock
// and the real FOH door out of the compositor's state machine.
export function sourceLeakStage(frame={}){
  if(frame?.sourcePhase===false||String(frame?.phase||'').toLowerCase()==='horizon')return Object.freeze({id:'sealed',active:false,progress:0,red:0});
  if(frame?.complete)return Object.freeze({id:'proper',active:true,progress:1,red:clamp(frame.redProgress??1)});
  if(!frame?.approach)return Object.freeze({id:'sealed',active:false,progress:0,red:0});
  const elapsed=Math.max(0,Number(frame.elapsedSeconds)||0);
  const progress=clamp(frame.progress);
  const red=clamp(frame.redProgress);
  if(elapsed<10)return Object.freeze({id:'white',active:true,progress,red:0});
  if(progress<2/3)return Object.freeze({id:'red',active:true,progress,red});
  if(progress<.92)return Object.freeze({id:'swarm',active:true,progress,red});
  return Object.freeze({id:'proper',active:true,progress,red});
}

export function validateWindowChoreographyPlan(plan={}){
  const errors=[];
  if(plan.schema!==1)errors.push('schema');
  if(!stableId(plan.cueId))errors.push('cueId');
  if(!stableId(plan.sceneId))errors.push('sceneId');
  if(!Array.isArray(plan.primitives)||!plan.primitives.length)errors.push('primitives');
  else for(const primitive of plan.primitives)if(!WINDOW_CHOREOGRAPHY_PRIMITIVES.includes(primitive))errors.push(`primitive:${primitive}`);
  if(!Array.isArray(plan.mainFrame))errors.push('mainFrame');
  if(!Array.isArray(plan.surfaces)||plan.surfaces.length>4)errors.push('surfaces');
  for(const surface of plan.surfaces||[]){
    if(!stableId(surface.id))errors.push('surface.id');
    if(!Number.isFinite(Number(surface.x))||!Number.isFinite(Number(surface.y)))errors.push(`surface.position:${surface.id}`);
    if(!Number.isFinite(Number(surface.size))||Number(surface.size)<64||Number(surface.size)>320)errors.push(`surface.size:${surface.id}`);
  }
  return Object.freeze({ok:errors.length===0,errors:Object.freeze(errors)});
}

export function compileWindowChoreographyPlan({
  cueId,sceneId,primitives=['Frame'],mainFrame=[],surfaces=[],content='game-authored',
  focus='main',input='none',easing='out-cubic',interruptible=true,reducedMotion=false,
  fallback='simulate',restore='transaction',scope='battle',narrativeBlocking=false,nonblocking=true,
}={}){
  if(!Array.isArray(surfaces)||surfaces.length>4)throw new Error('invalid window choreography plan: surfaces');
  const plan=Object.freeze({
    schema:1,cueId:stableId(cueId),sceneId:stableId(sceneId),
    primitives:Object.freeze([...new Set(primitives)]),
    mainFrame:Object.freeze(mainFrame.map((keyframe)=>Object.freeze({
      dx:Number(keyframe.dx)||0,dy:Number(keyframe.dy)||0,
      scaleX:clamp(keyframe.scaleX??1,.55,1.35),scaleY:clamp(keyframe.scaleY??1,.55,1.35),
      durationMs:Math.max(0,Math.min(2200,Number(keyframe.durationMs)||0)),
      easing:String(keyframe.easing||easing),dock:String(keyframe.dock||'center'),
    }))),
    surfaces:Object.freeze(surfaces.slice(0,4).map((surface,index)=>Object.freeze({
      id:stableId(surface.id||`${cueId}:${index}`),index,
      x:clamp(surface.x,.02,.98),y:clamp(surface.y,.02,.98),
      size:Math.max(64,Math.min(320,Math.round(Number(surface.size)||160))),
      mode:String(surface.mode||'fragment'),title:String(surface.title||'').slice(0,48),
      text:String(surface.text||'').slice(0,320),palette:String(surface.palette||'black'),
      interactive:!!surface.interactive,
    }))),
    content,focus,input,easing,interruptible:!!interruptible,reducedMotion:!!reducedMotion,
    fallback,restore,scope,narrativeBlocking:!!narrativeBlocking,nonblocking:!!nonblocking,
  });
  const validation=validateWindowChoreographyPlan(plan);
  if(!validation.ok)throw new Error(`invalid window choreography plan: ${validation.errors.join(', ')}`);
  return plan;
}

// The single OS pane a takeover opens with, away to the side of the main window.
export function compileTakeoverPanePlan({mediaId='',reducedMotion=false,flashMode='full',epochMs=Date.now(),name=null}={}){
  const asset=windowMediaAsset(mediaId);
  const proceduralPreset=['empty-field','paper-close'].includes(mediaId)?mediaId:null;
  const content=asset?.kind==='video'?{kind:'video',assetId:asset.id}:proceduralPreset?{kind:'procedural',preset:proceduralPreset,...(proceduralPreset==='paper-close'&&name?{name}:{})}:null;
  if(!content)return null;
  // The verb's answer grades the pane. The body failing arrives hard and torn
  // (nvme-sector, fault accelerating); the light at the end arrives quiet and
  // settles (violet-dither, almost no fault). The paper search settles too.
  const clinical=TAKEOVER_CLINICAL.includes(mediaId),comfort=TAKEOVER_COMFORT.includes(mediaId),paper=mediaId==='paper-close';
  const grade=clinical
    ?{shader:'nvme-sector',fault:{profile:'nvme-sector',intensity:.55,seed:41,cadenceMs:reducedMotion?900:280},formation:{mode:'impact-scatter',durationMs:360,staggerMs:35}}
    :comfort||paper
      ?{shader:'violet-dither',fault:{profile:'violet-dither',intensity:.02,seed:219,cadenceMs:900},formation:{mode:'memory-unfold',durationMs:450,staggerMs:0}}
      :{shader:'nvme-sector',fault:{profile:'nvme-sector',intensity:.12,seed:17,cadenceMs:reducedMotion?900:480},formation:{mode:'practice-windows',durationMs:0,staggerMs:0}};
  return compileWindowCompositionPlan({
    compositionId:`takeover:${mediaId}`,sceneId:'takeover:memory',purpose:'takeover',epochMs,reducedMotion,flashMode,
    surfaces:[{id:'takeover:pane',content,initial:{x:.88,y:.16},width:320,height:180,shader:grade.shader,draggable:false,description:''}],
    fault:grade.fault,formation:grade.formation,foldDurationMs:0,completion:{mode:'nonblocking'},
  });
}

// Two readable clue windows flank the adversary. Two separate NVMe windows
// carry corrupted footage; their fault never destroys a letter in the puzzle.
export function compilePracticeCuePlan(cue={}, {clueTokens=[],reducedMotion=false,flashMode='full',epochMs=Date.now()}={}){
  if(clueTokens.length!==2)return null;
  return compileWindowCompositionPlan({
    compositionId:cue.id||'practice:clue',sceneId:'battle:practice',purpose:'practice',epochMs,reducedMotion,flashMode,
    surfaces:[
      ...clueTokens.map((token,index)=>({
        id:`practice:clue:${index}`,content:{kind:'snapshot',token},
        initial:{x:index ? .92 : .08,y:.44},width:280,height:280,
        shader:'violet-dither',draggable:true,description:`Clue ${index+1} of 2. Name the image, subtract the marked letters.`,
      })),
      ...['bellringers-datamosh','sunflower-datamosh'].map((assetId,index)=>({
        id:`practice:fault:${index}`,content:{kind:'video',assetId},
        initial:{x:index ? .69 : .31,y:.09},width:220,height:124,
        shader:'nvme-sector',draggable:false,phaseOffsetMs:index*1700,
        description:'Corrupted practice footage',
      })),
    ],
    fault:{profile:'nvme-sector',intensity:Math.min(.8,.5+(Number(cue.cycle)||1)*.075),seed:137+(Number(cue.cycle)||0),cadenceMs:reducedMotion?900:360},
    formation:{mode:'practice-windows',durationMs:0,staggerMs:0},foldDurationMs:0,
    completion:{mode:'nonblocking'},
  });
}

function battleIntroPlan(profile,{sequence=0,reducedMotion=false}={}){
  const offset=profile.battleId==='natatorium'?{dx:0,dy:-18}
    :profile.battleId==='hall'?{dx:42,dy:0}
      :profile.battleId==='practice'?{dx:-30,dy:0}
        :profile.battleId==='chapel'?{dx:0,dy:28}:{dx:18,dy:-12};
  const surfaces=Array.from({length:profile.battleId==='source-final'?3:1},(_,index)=>({
    id:`${profile.battleId}:invader:${sequence}:${index}`,
    x:clamp(profile.introFrom.x+(index-1)*.16,.08,.92),
    y:clamp(profile.introFrom.y+(index-1)*.12,.08,.92),size:176,
    mode:'boss',palette:profile.battleId==='natatorium'?'water':'black',
    text:profile.intro.toUpperCase(),interactive:false,
  }));
  return compileWindowChoreographyPlan({
    cueId:`${profile.battleId}:invade:${sequence}`,sceneId:`battle:${profile.battleId}`,
    primitives:profile.primitives,scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[{...offset,durationMs:320+profile.intensity*260,easing:'out-cubic'}],surfaces,
  });
}

function battleDamagePlan(profile,{grade='light',origin={x:.5,y:.5},sequence=0,reducedMotion=false}={}){
  const heavy=grade==='heavy'||grade==='phase';
  const phase=grade==='phase';
  const x=clamp(origin?.x),y=clamp(origin?.y);
  const dx=profile.damageAxis==='lateral'?(x<.5?24:-24):profile.damageAxis==='rewind'?-18:(x-.5)*-28;
  const dy=profile.damageAxis==='vertical'?(y<.5?16:-16):(y-.5)*-18;
  const scale=phase?.86:heavy?.92:1;
  return compileWindowChoreographyPlan({
    cueId:`${profile.battleId}:damage:${sequence}`,sceneId:`battle:${profile.battleId}`,
    primitives:phase?['Dock','Cinch']:heavy?['Cinch']:['Glide'],scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[
      {dx,dy,scaleX:scale,scaleY:scale,durationMs:heavy?260:110,easing:'out-cubic'},
      {dx:0,dy:0,scaleX:1,scaleY:1,durationMs:heavy?360:160,easing:'in-out-cubic'},
    ],surfaces:[],
  });
}

function defeatPlan(battleId,sequence=0,reducedMotion=false){
  const fragments=Array.from({length:4},(_,index)=>({
    id:`${battleId}:defeat:${sequence}:${index}`,x:.2+index*.2,y:.34+(index%2)*.24,size:150,
    mode:'shatter',palette:'black',text:'',interactive:false,
  }));
  return compileWindowChoreographyPlan({
    cueId:`${battleId}:defeat:${sequence}`,sceneId:`battle:${battleId}`,
    primitives:['Split','Glide','Recenter'],scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[{dx:0,dy:34,scaleX:.94,scaleY:.94,durationMs:360}],surfaces:fragments,
  });
}

function sourcePlan(stage,sequence=0,reducedMotion=false){
  const counts={white:1,red:2,swarm:4,proper:3};
  const count=counts[stage.id]||0;
  const drift=(index)=>Math.sin((sequence+1)*(index+2)*1.71);
  const surfaces=Array.from({length:count},(_,index)=>({
    id:`source:${stage.id}:${sequence}:${index}`,
    x:clamp(.16+(index*.23)+(stage.id==='swarm'?drift(index)*.08:drift(index)*.025),.08,.92),
    y:clamp(.28+((index*37)%3)*.22+(stage.id==='swarm'?drift(index+4)*.06:0),.12,.88),
    size:stage.id==='proper'&&index===0?190:128+(index%2)*24,
    mode:stage.id==='proper'&&index===0?'narrative':'fragment',
    palette:stage.red>0?'red':'white',
    text:stage.id==='proper'&&index===0?'ENTER THE RETURN PATH':'',
    interactive:stage.id==='proper'&&index===0,
  }));
  const motion=stage.id==='white'||reducedMotion?[]
    :stage.id==='red'?[{dx:sequence%2?6:-5,dy:sequence%3?-3:2,scaleX:.99,scaleY:.99,durationMs:520}]
      :stage.id==='swarm'?[{dx:sequence%2?-18:21,dy:sequence%3?8:-6,scaleX:.95,scaleY:.95,durationMs:620}]
        :[{dx:24,dy:-12,scaleX:.91,scaleY:.91,durationMs:680}];
  return compileWindowChoreographyPlan({
    cueId:`source:${stage.id}:${sequence}`,sceneId:'source:white-crossing',
    primitives:stage.id==='white'?['Split']:stage.id==='red'?['Split','Glide','Cinch']
      :stage.id==='swarm'?['Split','Swarm','Handoff','Glide']:['Split','Handoff','Cinch'],
    scope:'source',reducedMotion,mainFrame:motion,surfaces,
    input:stage.id==='proper'?'pointer-or-main':'none',focus:'main',nonblocking:true,
  });
}

function endingPlan(profile,sequence=0,reducedMotion=false){
  const persistent=0;
  return compileWindowChoreographyPlan({
    cueId:`ending:${profile.endingId}:${sequence}`,sceneId:`ending:${profile.endingId}`,
    primitives:[profile.primitive],scope:'ending',reducedMotion,
    mainFrame:reducedMotion?[]:[{
      dx:profile.primitive==='Dock'?120:profile.primitive==='Handoff'?-36:0,dy:profile.primitive==='Dock'?80:0,
      scaleX:profile.primitive==='Cinch'?.72:profile.endingId==='contact-lost'?.65:profile.primitive==='Bloom'?1.08:1,
      scaleY:profile.primitive==='Cinch'?.72:profile.endingId==='contact-lost'?.65:profile.primitive==='Bloom'?1.08:1,
      durationMs:900,easing:'in-out-cubic',
    }],
    surfaces:Array.from({length:persistent},(_,index)=>({
      id:`ending:${profile.endingId}:${index}`,x:.28+index*.18,y:.54+(index%2)*.12,size:132,
      mode:'ending',palette:'black',text:profile.resolution.toUpperCase(),interactive:false,
    })),
  });
}

function createSimulation(documentApi,effects){
  const media=createWindowMediaSimulation({documentApi,effects});
  let root=null;
  const panes=new Map();
  const formationTimers=new Set();
  const scoreTimers=new Set();
  let activePlan=null;
  const ensure=()=>{
    if(root||!documentApi?.createElement)return root;
    root=documentApi.createElement('div');
    root.className='window-choreography-sim';
    root.setAttribute('aria-hidden','true');
    (documentApi.querySelector?.('#wrap')||documentApi.body)?.append?.(root);
    return root;
  };
  const clear=()=>{
    for(const timer of formationTimers)clearTimeout(timer);formationTimers.clear();
    for(const timer of scoreTimers)clearTimeout(timer);scoreTimers.clear();
    panes.clear();activePlan=null;if(root)root.replaceChildren();
  };
  const dispatch=(event,detail)=>{
    const CustomEventCtor=documentApi?.defaultView?.CustomEvent||globalThis.CustomEvent;
    if(CustomEventCtor)documentApi?.defaultView?.dispatchEvent?.(new CustomEventCtor(event,{detail}));
  };
  function report(plan,surface,pane){
    const hostRect=root.getBoundingClientRect(),rect=pane.getBoundingClientRect();
    dispatch('chunk-surfer:window-media-moved',{cueId:plan.cueId,paneId:surface.id,label:'simulate',placement:{shown:true,scale:1,
      origin:{x:rect.left,y:rect.top},center:{x:rect.left-hostRect.left+rect.width/2,y:rect.top-hostRect.top+rect.height/2},
      normalized:{x:(rect.left-hostRect.left+rect.width/2)/Math.max(1,hostRect.width),y:(rect.top-hostRect.top+rect.height/2)/Math.max(1,hostRect.height)},
      width:rect.width,height:rect.height,workWidth:hostRect.width,workHeight:hostRect.height}});
  }
  function mediaChild(plan,surface,assignment=surface.assignment||surface){
    const content=assignment.content||{};
    let child=null;
    if(content.kind==='video'){
      const asset=windowMediaAsset(content.assetId),poster=asset?.derivatives?.poster?.path;
      if(plan.reducedMotion){const img=documentApi.createElement('img');img.src=poster||'';img.alt=surface.description||'';child=img;}
      else{
      const video=documentApi.createElement('video');video.muted=true;video.defaultMuted=true;video.loop=true;video.autoplay=true;video.playsInline=true;video.preload='auto';
      if(poster)video.poster=poster;
      for(const kind of ['webm','mp4']){const path=asset?.derivatives?.[kind]?.path;if(!path)continue;const source=documentApi.createElement('source');source.src=path;source.type=kind==='webm'?'video/webm':'video/mp4';video.append(source);}
      void video.play?.().catch?.(()=>{});child=video;
      }
    }
    else if(content.kind==='snapshot'){
      const img=documentApi.createElement('img');img.src=effects?.snapshotData?.(content.token)||'';img.alt=surface.description||'';child=img;
    }
    else if(content.kind==='text'){const span=documentApi.createElement('span');span.textContent=content.text||'';child=span;}
    else{const field=documentApi.createElement('div');field.className=`window-composition-procedural preset-${content.preset||'game-fragment'}`;child=field;}
    const crop=assignment.crop||{x:0,y:0,w:1,h:1};
    child.dataset.contentId=content.assetId||content.preset||content.kind||'unknown';
    if(['video','image','snapshot'].includes(content.kind)){
      child.style.position='absolute';child.style.maxWidth='none';child.style.maxHeight='none';
      child.style.width=`${100/Math.max(.05,crop.w||1)}%`;child.style.height=`${100/Math.max(.05,crop.h||1)}%`;
      child.style.left=`${-100*(crop.x||0)/Math.max(.05,crop.w||1)}%`;child.style.top=`${-100*(crop.y||0)/Math.max(.05,crop.h||1)}%`;
    }
    return child;
  }
  function replaceMedia(plan,surface,pane,assignment,action={}){
    const next=mediaChild(plan,surface,assignment),old=pane.firstElementChild;
    if(old&&action.transition!=='cut'&&action.durationMs){pane.classList.add(`transition-${action.transition}`);setTimeout(()=>pane.classList.remove(`transition-${action.transition}`),action.durationMs);}
    pane.replaceChildren(next);pane.dataset.contentId=next.dataset.contentId||'';
  }
  function applyScoreAction(plan,surface,pane,action,cueId=''){
    if(!pane||!action)return;
    pane.dataset.lastScoreCue=cueId;
    if(action.type==='assignment')replaceMedia(plan,surface,pane,action.assignment,action);
    else if(action.type==='visible')pane.style.display=action.visible?'block':'none';
    else if(action.type==='frozen')for(const video of pane.querySelectorAll?.('video')||[]){if(action.frozen)video.pause?.();else void video.play?.().catch?.(()=>{});}
    else if(action.type==='seek')for(const video of pane.querySelectorAll?.('video')||[]){try{video.currentTime=Math.max(0,Number(action.seekMs)||0)/1000;}catch(_){}}
    else if(action.type==='shader'){
      if(action.coherent!==null)pane.classList.toggle('coherent',!!action.coherent);
      if(action.intensity!==null)pane.style.setProperty('--fault-intensity',String(action.intensity));
    }else if(action.type==='geometry'&&(!pane.dataset.manual||action.geometry?.force)){
      pane.style.left=`${action.geometry.anchorX*100}%`;pane.style.top=`${action.geometry.anchorY*100}%`;
    }
  }
  function schedulePaneScore(plan,surface,pane){
    const score=compilePaneScore(plan,surface.id);
    const runCycle=()=>{
      if(activePlan!==plan)return;
      replaceMedia(plan,surface,pane,score.initial);pane.style.display='block';
      const duration=Math.max(1,score.durationMs),raw=Math.max(0,Date.now()-score.epochMs),elapsed=score.loop?raw%duration:Math.min(duration,raw);
      for(const cue of score.cues){
        if(!Object.hasOwn(cue,'atMs'))continue;
        const due=cue.atMs+cue.delayMs;
        if(due<=elapsed)applyScoreAction(plan,surface,pane,cue.action,cue.id);
        else{const timer=setTimeout(()=>{scoreTimers.delete(timer);if(activePlan===plan)applyScoreAction(plan,surface,pane,cue.action,cue.id);},due-elapsed);scoreTimers.add(timer);}
      }
      if(score.loop){const timer=setTimeout(()=>{scoreTimers.delete(timer);runCycle();},Math.max(1,duration-elapsed));scoreTimers.add(timer);}
    };
    runCycle();
  }
  function show(plan){
    if(plan.kind==='composition'){clear();root?.classList?.remove('active');return media.show(plan);}
    media.hide();
    const host=ensure();if(!host)return false;
    clear();activePlan=plan;host.dataset.cue=plan.cueId;host.classList.add('active');
    host.classList.toggle('composition',plan.kind==='composition');
    for(const surface of plan.surfaces){
      const pane=documentApi.createElement('div');
      pane.className=plan.kind==='composition'?'window-choreography-sim-pane window-composition-pane':`window-choreography-sim-pane palette-${surface.palette}`;
      const x=plan.kind==='composition'?surface.entry.x:surface.x,y=plan.kind==='composition'?surface.entry.y:surface.y;
      pane.style.left=`${x*100}%`;pane.style.top=`${y*100}%`;
      pane.style.width=`${plan.kind==='composition'?surface.width:surface.size}px`;pane.style.height=`${plan.kind==='composition'?surface.height:surface.size}px`;
      if(plan.kind==='composition'){
        pane.style.zIndex=String(surface.z);
        pane.dataset.shader=surface.shader;
        pane.style.setProperty('--fault-intensity',String(Math.min(1,(plan.fault?.intensity||0)*(surface.faultScale||1))));
        pane.classList.toggle('flash-reduced',plan.fault?.flashMode==='reduced');
        pane.classList.toggle('flash-off',plan.fault?.flashMode==='off');
      }
      pane.dataset.paneId=surface.id;panes.set(surface.id,pane);
      if(plan.kind==='composition'){
        pane.append(mediaChild(plan,surface));
        if(surface.draggable){
          pane.style.pointerEvents='auto';let drag=null;
          pane.addEventListener?.('pointerdown',(event)=>{event.preventDefault?.();event.stopPropagation?.();pane.dataset.manual='true';drag={x:event.clientX,y:event.clientY,left:pane.offsetLeft,top:pane.offsetTop};pane.setPointerCapture?.(event.pointerId);});
          pane.addEventListener?.('pointermove',(event)=>{if(!drag)return;pane.style.left=`${drag.left+event.clientX-drag.x}px`;pane.style.top=`${drag.top+event.clientY-drag.y}px`;});
          const end=(event)=>{if(!drag)return;drag=null;pane.releasePointerCapture?.(event.pointerId);report(plan,surface,pane);};
          pane.addEventListener?.('pointerup',end);pane.addEventListener?.('pointercancel',end);
        }
      }
      if(surface.interactive){
        pane.style.pointerEvents='auto';
        pane.addEventListener?.('pointerdown',(event)=>{
          event.preventDefault?.();event.stopPropagation?.();
          dispatch('chunk-surfer:window-pane-action',{cueId:plan.cueId,paneId:surface.id,action:'enter'});
        });
      }
      if(plan.kind!=='composition')pane.textContent=surface.text||'';host.append(pane);
      if(plan.kind==='composition'){
        const delay=(plan.formation?.delayMs||0)+surface.index*(plan.formation?.staggerMs||0);
        const duration=plan.formation?.durationMs||0;
        const timer=setTimeout(()=>{
          formationTimers.delete(timer);
          pane.style.transition=duration?`left ${duration}ms cubic-bezier(.22,.75,.18,1), top ${duration}ms cubic-bezier(.22,.75,.18,1)`:'none';
          pane.style.left=`${surface.initial.x*100}%`;pane.style.top=`${surface.initial.y*100}%`;
          const reportTimer=setTimeout(()=>{formationTimers.delete(reportTimer);report(plan,surface,pane);},duration);
          formationTimers.add(reportTimer);
        },delay);
        formationTimers.add(timer);
        schedulePaneScore(plan,surface,pane);
      }
    }
    return true;
  }
  function snap(plan,{coherent=false}={}){
    if(plan.kind==='composition')return media.snap(plan,{coherent});
    const host=ensure();if(!host)return false;
    const bounds=host.getBoundingClientRect();
    for(const surface of plan.surfaces){const pane=panes.get(surface.id);if(!pane||!surface.target)continue;
      pane.style.left=`${surface.target.anchorX*bounds.width+surface.target.offsetX}px`;
      pane.style.top=`${surface.target.anchorY*bounds.height+surface.target.offsetY}px`;
      pane.classList.toggle('coherent',!!coherent);report(plan,surface,pane);}return true;
  }
  function coherence(value=true){media.coherence(value);for(const pane of panes.values())pane.classList.toggle('coherent',!!value);}
  function freeze(value=true){media.freeze(value);for(const pane of panes.values())for(const video of pane.querySelectorAll?.('video')||[]){if(value)video.pause?.();else void video.play?.().catch?.(()=>{});}}
  function trigger(plan,eventName,options={}){
    if(plan.kind==='composition')return media.trigger(plan,eventName,options);
    if(activePlan!==plan)return false;
    let matched=false;
    for(const surface of plan.surfaces){
      const pane=panes.get(surface.id),score=compilePaneScore(plan,surface.id);
      for(const cue of score.cues){
        if(cue.event!==eventName)continue;matched=true;
        const timer=setTimeout(()=>{scoreTimers.delete(timer);if(activePlan===plan)applyScoreAction(plan,surface,pane,cue.action,cue.id);},cue.delayMs||0);scoreTimers.add(timer);
      }
    }
    return matched;
  }
  function hide(){media.hide();if(root){root.classList.remove('active');clear();}}
  return{show,snap,coherence,freeze,trigger,hold:(value,options)=>media.hold(value,options),hide,updateStudyFrames:request=>media.updateStudyFrames(request),updateStudyArchitecture:request=>media.updateStudyArchitecture(request),architectureLayout:()=>media.architectureLayout(),active:()=>media.active()||!!root?.classList?.contains('active'),debug:()=>media.debug()};
}

// ── THE BOX OFFICE KEY TAGS ─────────────────────────────────────────────────
//
// Three tags laid beside the game so they can be read TOGETHER. That is the
// whole reason this cue exists: the rings hang in one cabinet and the game can
// only ever inspect one at a time, so the comparison the puzzle is made of —
// CH-04 says CHAPEL, C-17 is a replacement number in biro, FOH-M admits it stops
// at the doors — is the one thing the room cannot show you.
//
// Everything about it is narrower than a rupture:
//   · `mainFrame: []`  the game window never moves. Nothing is taken away.
//   · `interactive:false`, `input:'none'`  they are pictures of tags, not tags.
//   · `focus:'main'`  the player keeps their cursor and their keyboard.
//   · `Frame` only  no Breach, no Swarm, no Cast. It places and it restores.
//
// And it is never the route to the answer. The tags are readable on the rings
// and the ledger names C-17, so this is corroboration for somebody already
// standing in the room. test/box-office.spec.mjs holds that.
export const BOX_OFFICE_CUE_ID='box-office:key-tags';
export const BOX_OFFICE_SCENE_ID='box-office:key-cabinet';

export function compileBoxOfficeKeyTagPlan({tags=[],reducedMotion=false}={}){
  // Across the top, evenly, in tag order. Three fits inside the four-surface
  // ceiling with one spare, which is deliberate: a fourth tag would mean the
  // cabinet had grown and the plan should be re-read rather than silently
  // truncated by the compiler.
  const wanted=tags.slice(0,3);
  const columns=[0.18,0.5,0.82];
  return compileWindowChoreographyPlan({
    cueId:BOX_OFFICE_CUE_ID,
    sceneId:BOX_OFFICE_SCENE_ID,
    primitives:['Frame','Restore'],
    mainFrame:[],
    surfaces:wanted.map((entry,index)=>({
      id:`${BOX_OFFICE_CUE_ID}:${String(entry.tag||index).toLowerCase()}`,
      x:columns[index]??0.5,
      y:0.14,
      size:196,
      mode:'card',
      title:String(entry.tag||''),
      text:String(entry.text||''),
      palette:'brass',
      interactive:false,
    })),
    content:'game-authored',
    focus:'main',
    input:'none',
    reducedMotion:!!reducedMotion,
    restore:'transaction',
    scope:'box-office',
    narrativeBlocking:false,
    nonblocking:true,
  });
}

export const HORIZON_SLATE_CUE_ID='horizon:transport-readings';
export const HORIZON_SLATE_SCENE_ID='source:proper';

// THE THREE READINGS, SIDE BY SIDE.
//
// The machine at the edge of the field has a reel, a gate and a log, and each
// can be read on its own in the room. What no in-game inspect prompt can do is
// show all three AT ONCE, and comparing them is the whole point: the run length
// against the walk, the picture's offset against the way the corridor drifts,
// the damaged span against where on the tape it falls.
//
// Same contract as the box office: display only, no input, nothing gated on it.
// Source already owns a policy ('source-leakage'), so this opens no new door in
// the firewall — see windowChoreographyPolicy above.
export function compileHorizonSlatePlan({readings=[],reducedMotion=false}={}){
  const wanted=readings.slice(0,3);
  const columns=[0.16,0.5,0.84];
  return compileWindowChoreographyPlan({
    cueId:HORIZON_SLATE_CUE_ID,
    sceneId:HORIZON_SLATE_SCENE_ID,
    primitives:['Frame','Restore'],
    mainFrame:[],
    surfaces:wanted.map((entry,index)=>({
      id:`${HORIZON_SLATE_CUE_ID}:${String(entry.dial||index).toLowerCase()}`,
      x:columns[index]??0.5,
      y:0.16,
      size:208,
      mode:'card',
      title:`${String(entry.part||'')} — ${String(entry.title||'')}`,
      text:`${String(entry.reading||'')}\n\n${String(entry.note||'')}`,
      palette:'brass',
      interactive:false,
    })),
    content:'game-authored',
    focus:'main',
    input:'none',
    reducedMotion:!!reducedMotion,
    restore:'transaction',
    scope:'horizon',
    narrativeBlocking:false,
    nonblocking:true,
  });
}

export const PLANT_HEADER_CUE_ID='plant:header-card';
export const PLANT_HEADER_SCENE_ID='plant:header';

// The service card and two gauges, beside the window while the wrench is on the
// tree. Recompiled as fittings seat, so the needles actually fall — a player who
// cannot tell whether they are making progress can watch the header let go.
export function compilePlantHeaderPlan({order=[],trap='',seated=0,total=3,reducedMotion=false}={}){
  const shut=Math.max(0,Math.min(total,Number(seated)||0));
  const openFraction=total?1-shut/total:1;
  const bar=(4.1*openFraction).toFixed(1);
  const flow=['SHUT','TRICKLE','PART','FULL'][Math.max(0,Math.min(3,total-shut))];
  const columns=[0.16,0.5,0.84];
  const cards=[
    {
      id:'card',title:'HEADER 3 · SERVICE CARD',
      text:`${order.map((entry,i)=>`${i+1}. ${entry.label} — ${entry.note}`).join('\n')}\n\nNOT THIS HEADER: ${trap}`,
    },
    {id:'pressure',title:'HEADER PRESSURE',text:`${bar} bar\n\n${shut} of ${total} fittings shut.\nIt falls as they seat and rises when they let go.`},
    {id:'flow',title:'FLOW',text:`${flow}\n\nThe gauge follows the pipe, not the wrench.`},
  ];
  return compileWindowChoreographyPlan({
    cueId:PLANT_HEADER_CUE_ID,
    sceneId:PLANT_HEADER_SCENE_ID,
    primitives:['Frame','Restore'],
    mainFrame:[],
    surfaces:cards.map((entry,index)=>({
      id:`${PLANT_HEADER_CUE_ID}:${entry.id}`,
      x:columns[index]??0.5,
      y:0.15,
      size:206,
      mode:'card',
      title:entry.title,
      text:entry.text,
      palette:'brass',
      interactive:false,
    })),
    content:'game-authored',
    focus:'main',
    input:'none',
    reducedMotion:!!reducedMotion,
    restore:'transaction',
    scope:'plant-header',
    narrativeBlocking:false,
    nonblocking:true,
  });
}

export function sourceStudyArchitectureLayout(metrics,surfaces=[{id:'rest:source',width:240,height:160},{id:'rest:answer',width:240,height:160}]){
  const valid=r=>r&&['x','y','width','height'].every(k=>Number.isFinite(r[k]))&&r.width>0&&r.height>0,main=metrics?.content_rect,work=metrics?.work_area;
  if(!valid(main)||!valid(work))return null;
  const bound=(x,a,b)=>Math.max(a,Math.min(b,x)),panes=surfaces.filter(p=>['rest:source','rest:answer'].includes(p.id)).map((surface,index)=>{
    const width=bound(surface.width||240,160,320),height=bound(surface.height||160,96,320),x=index?main.x+main.width-width*.65:main.x-width*.35,
      rect={x:bound(x,work.x,Math.max(work.x,work.x+work.width-width)),y:bound(index?main.y:main.y+main.height*.38-height/2,work.y,Math.max(work.y,work.y+work.height-height)),width,height};
    return{surfaceId:surface.id,rect,crop:{x:(rect.x-main.x)/main.width,y:(rect.y-main.y)/main.height,width:width/main.width,height:height/main.height}};
  });
  return{mainRect:{...main},workArea:{...work},viewport:{width:main.width,height:main.height},panes};
}
export function createWindowChoreographyDirector({
  effects=null,runtimeApi=null,documentApi=globalThis.document,
  getEnabled=()=>true,getDisplayMode=()=> 'windowed',getReducedMotion=()=>false,
  getCompositionContext=()=>({introduced:false,lastEndingId:'',reduceDread:false}),
  getSourceIdentity=()=>({operatorName:null,permitted:false}),
  isApertureComplete=()=>false,onFirstBreach=()=>{},onPuzzleState=()=>{},onApertureComplete=()=>{},
  tokenFactory=()=>`window-session-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  waitFn=wait,onState=()=>{},onGeometryMotion=()=>{},
  releaseFullscreen=async (transition)=>transition(),
}={}){
  let api=runtimeApi;
  let transaction=null;
  let transactionOpening=null;
  let practiceCueGeneration=0;
  const practiceClueTokens=new Map();
  let battle=null;
  let source={stage:'sealed',sequence:0,bucket:-1};
  let sourceWarningSeen=false;
  // The windows' walk out of Source (sourceDecay). done: gone for this crossing.
  let decay={stage:0,active:null,done:false};
  let faultRun={run:-1,active:false};
  let decayTokens=null;
  let ending=null;
  let composition=null;
  let presentationHeld=false;
  let sequence=0;
  let epoch=0;
  let planTail=Promise.resolve();
  let lastEscapeAt=-Infinity;
  let titleGeneration=0;
  let returnGeneration=0,returnPending=null;
  let frontEndLease=null;
  let frontEndReady=Promise.resolve(null);
  let sourceDesktop=null;
  let sourceDesktopGeneration=0;
  let sourceDesktopEvents=null;
  let sourceDesktopLastReason=null;
  let paneAuthority=null,takeoverLease=null;
  const simulation=createSimulation(documentApi,effects);

  const reduced=()=>!!getReducedMotion();
  const compositionContext=()=>{
    const context=getCompositionContext()||{};
    return{...context,flashMode:['full','reduced','off'].includes(context.flashMode)?context.flashMode:'full'};
  };
  // WINDOW CHOREOGRAPHY is the authority for whether desktop windows exist.
  // Reduced motion removes travel and dissolves in the compiled plans; it must
  // not silently replace the feature with an in-frame simulation after the
  // player explicitly left choreography enabled.
  const nativeDesired=()=>!!getEnabled()&&isTauriRuntime();
  async function loadApi(){
    if(api)return api;
    if(!nativeDesired())return null;
    try{api=await import('@tauri-apps/api/core');}catch(_){api=null;}
    return api;
  }
  // Is the window covering the screen by ANY route — game mode, a macOS Space,
  // or a frame someone dragged out to the edges? Any of the three has to be
  // left before an authored cue can move the window or open a surface beside
  // it, and only the first of them is anything the app knows it did.
  // Whether a transaction has to LEAVE a fullscreen state before it can move
  // the window — a cue cannot reposition a frame that has nowhere to move to.
  // It is not "was the app in game mode": see restore_transaction in
  // window_choreography.rs, which records which state it left and puts that one
  // back rather than imposing simple fullscreen on all three.
  async function measuredFullscreen(nativeApi){
    if(nativeApi?.invoke){
      const metrics=await safe(()=>nativeApi.invoke('chunk_window_metrics'));
      if(metrics&&typeof metrics==='object'){
        return !!(metrics.native_fullscreen||metrics.simple_fullscreen||metrics.fills_screen);
      }
    }
    return getDisplayMode()==='game-mode';
  }

  function beginTransaction(sceneId,options={}){
    if(transaction)return Promise.resolve(transaction);
    if(transactionOpening)return transactionOpening.promise;
    const opening={owner:epoch,controller:new AbortController(),native:false,token:stableId(tokenFactory())};
    transactionOpening=opening;
    opening.promise=openTransaction(sceneId,options,opening).finally(()=>{
      if(transactionOpening===opening)transactionOpening=null;
    });
    return opening.promise;
  }

  async function openTransaction(sceneId,{forceSimulate=false},opening){
    const {token,owner,controller}=opening;
    if(forceSimulate){transaction={token,sceneId,native:false,restoreGameMode:false,cancelled:false};onState({type:'begin',...transaction});return transaction;}
    const nativeApi=await loadApi();
    // ASK THE WINDOW, DO NOT ASK THE SETTINGS FILE.
    //
    // This was `getDisplayMode()==='game-mode'` — a persisted settings string.
    // It never asked the OS, so every fullscreen the app did not itself put the
    // player into was invisible to it. The common one is macOS NATIVE
    // fullscreen: the window is decorated and resizable, so the green
    // traffic-light button and Cmd+Ctrl+F are live and produce a real Space.
    // The setting still read 'windowed', restore_game_mode:false went to Rust,
    // the exit was skipped — and then base_center refused to place any surface
    // at all, because nothing can be composited over a Space. From the outside:
    // authored window motion simply never happened, and windowing the app by
    // hand fixed it.
    //
    // The metrics call is the truth now (display_policy.rs reports native,
    // simple and measured fills-screen separately). The setting is only the
    // fallback for when the probe itself fails.
    const restoreGameMode=await measuredFullscreen(nativeApi);
    if(owner!==epoch)return null;
    let native=false;
    if(nativeApi?.invoke){
      const undoOpening=async()=>{
        if(!opening.native)return;
        opening.native=false;
        await safe(()=>nativeApi.invoke('chunk_window_choreography_restore',{token}));
      };
      const begin=async()=>{
        if(owner!==epoch||controller.signal.aborted)return false;
        const result=await safe(()=>nativeApi.invoke('chunk_window_choreography_begin',{request:{token,sceneId,restoreGameMode}}));
        opening.native=!!result;
        if(owner!==epoch||controller.signal.aborted){await undoOpening();return false;}
        return result;
      };
      const result=restoreGameMode ? await releaseFullscreen(begin,{signal:controller.signal}) : await begin();
      if(owner!==epoch||(restoreGameMode&&!result)){
        controller.abort();
        await undoOpening();
        return null;
      }
      native=!!result;
      // A begin that fails leaves the cue as an in-frame simulation, which is a
      // legitimate fallback and used to be a completely silent one — the only
      // realistic error is "fullscreen exit did not settle" and nobody ever saw
      // it. Say so.
      if(!native)void logWarn('window choreography transaction refused',`scene ${sceneId} played in frame; leaving fullscreen was ${restoreGameMode?'required':'not required'}`);
    }
    // THE AUTHORED POLICY, WHICH WAS WRITTEN DOWN AND NEVER CONSULTED.
    //
    // windowChoreographyPolicy() is the per-scene display opinion — battle-only,
    // source-leakage, ending-resolution, credits-restoration, stable — and until
    // now its only consumer was a test. It is the closest thing this codebase has
    // to authored framing, and it was decorative. Carrying it on the transaction
    // means a scene's declared policy travels with the cue and is reported to
    // onState, so anything downstream can act on it and a reader can tell it is
    // in effect.
    const policy=windowChoreographyPolicy(sceneId);
    transaction={token,sceneId,native,restoreGameMode,policy,cancelled:false};
    onState({type:'begin',...transaction});
    return transaction;
  }

  async function performPlan(plan,{forceSimulate=false,nativeOnly=false,presentationOwner=null,compositionMode='cold',handoffDurationMs=260,isCurrent=()=>true,startOnPresent=false,onPresentationPlan=()=>{}}={}){
    if(sourceDesktop||!isCurrent()||(nativeOnly&&(transaction||transactionOpening)))return null;
    // A pane's cleanup owns one exact submission and transaction, never the
    // next battle/ending that happens to reuse its choreography transaction.
    const authority={epoch,cueId:plan.cueId,transaction:null,opening:null};
    paneAuthority=authority;if(presentationOwner)presentationOwner.authority=authority;
    const pending=beginTransaction(plan.sceneId,{forceSimulate});
    authority.opening=transactionOpening;
    const active=await pending;authority.transaction=active;
    if(!active||!isCurrent())return null;
    const useNative=active.native&&!forceSimulate;
    if(nativeOnly&&!useNative)return{plan,native:false,simulated:false};
    let nativeMoved=false,nativePanes=false;
    if(plan.kind==='composition'){
      // A fullscreen notice or a queued transaction may take arbitrary time.
      // Study time begins after those waits, immediately before assignment.
      const startScore=()=>{if(startOnPresent){plan=Object.freeze({...plan,epochMs:Date.now()});onPresentationPlan(plan);}};
      startScore();
      if(useNative)nativePanes=!!await safe(()=>effects?.showComposition?.(plan,{
        token:effects?.sessionToken?.(),mode:compositionMode,handoffDurationMs,isCurrent,
      }));
      if(!isCurrent())return null;
      const simulated=forceSimulate||!useNative||!nativePanes;
      if(simulated&&useNative)startScore();
      if(simulated&&!nativeOnly)simulation.show(plan);else simulation.hide();
      onState({type:'composition',plan,native:useNative&&!simulated,simulated:simulated&&!nativeOnly});
      return{plan,native:useNative&&!simulated,simulated:simulated&&!nativeOnly};
    }
    if(useNative&&api?.invoke&&plan.mainFrame.length){
      onGeometryMotion(true);
      try{
        nativeMoved=!!await safe(()=>api.invoke('chunk_window_choreography_execute',{request:{
          token:active.token,cueId:plan.cueId,keyframes:plan.mainFrame,interruptible:plan.interruptible,
        }}));
      }finally{onGeometryMotion(false);}
    }
    if(useNative&&plan.surfaces.length){
      nativePanes=!!await safe(()=>effects?.showPanes?.(plan.surfaces,{token:effects?.sessionToken?.(),cueId:plan.cueId}));
    }else if(!plan.surfaces.length){
      await safe(()=>effects?.hidePanes?.());
      nativePanes=true;
    }
    const simulated=forceSimulate||!useNative||(plan.surfaces.length&&!nativePanes)||(plan.mainFrame.length&&!nativeMoved);
    if(simulated)simulation.show(plan);else simulation.hide();
    onState({type:'plan',plan,native:useNative&&!simulated,simulated});
    return{plan,native:useNative&&!simulated,simulated};
  }

  function runPlan(plan,options={}){
    if(sourceDesktop)return Promise.resolve(null);
    const owner=epoch;
    const task=planTail.then(()=>owner===epoch?performPlan(plan,options):null);
    planTail=task.catch(()=>null);
    return task;
  }

  function sourceDesktopState(){
    return sourceDesktop?{active:true,mode:sourceDesktop.mode,token:sourceDesktop.token,revision:sourceDesktop.revision,
      placement:sourceDesktop.placement||null,reason:sourceDesktop.reason||null,suspended:!!sourceDesktop.suspended}
      :{active:false,mode:'fallback',token:null,revision:0,placement:null,reason:sourceDesktopLastReason,suspended:false};
  }
  function reportSourceDesktop(active){
    const state=sourceDesktopState();
    onState({type:'source-desktop',...(state||{mode:'ended'}),generation:active?.generation});
    return state||{mode:'fallback',reason:'cancelled'};
  }
  async function bindSourceDesktopEvents(){
    if(sourceDesktopEvents)return sourceDesktopEvents;
    sourceDesktopEvents=(async()=>{
      let events=api;
      if(!events?.listen){try{events=await import('@tauri-apps/api/event');}catch(_){return false;}}
      if(!events?.listen)return false;
      await events.listen('source-desktop:cancelled',event=>{
        const payload=event?.payload||event,active=sourceDesktop;
        if(!active||payload?.token!==active.token)return;
        active.mode='fallback';active.reason=String(payload.reason||'native-stage-cancelled');active.suspended=false;
        transaction=null;reportSourceDesktop(active);
      });
      await events.listen('source-desktop:visibility',event=>{
        const payload=event?.payload||event,active=sourceDesktop;
        if(!active||payload?.token!==active.token)return;
        active.focusSuspended=payload.focused===false;
        active.suspended=payload.visible!==true;reportSourceDesktop(active);
      });
      await events.listen('source-desktop:error',event=>{
        const payload=event?.payload||event,active=sourceDesktop;
        if(!active||payload?.label!=='source-desktop')return;
        const token=active.token;
        active.mode='fallback';active.reason=String(payload.message||'desktop-renderer-failed');
        void (async()=>{
          if(token)await safe(()=>api.invoke('chunk_source_desktop_end',{token}));
          if(sourceDesktop===active){transaction=null;reportSourceDesktop(active);}
        })();
      });
      return true;
    })().catch(()=>false);
    return sourceDesktopEvents;
  }

  // The same reducer drives either presentation. An unavailable compositor
  // changes the mode, never grants another recovery or advances combat time.
  function beginSourceDesktop(snapshot={}){
    if(sourceDesktop){
      if(sourceDesktop.mode==='opening')return sourceDesktop.opening;
      void updateSourceDesktop(snapshot);return Promise.resolve(sourceDesktopState());
    }
    const active={generation:++sourceDesktopGeneration,mode:'opening',token:null,revision:0,
      placement:null,pending:null,pumping:null,suspended:false,reason:null};
    sourceDesktop=active;
    const current=()=>sourceDesktop===active&&sourceDesktopGeneration===active.generation;
    active.opening=(async()=>{
      // Acquire the guard synchronously, then drain a frame tween already in
      // flight. No later damage/cast cue can queue behind the desktop lease.
      await planTail.catch(()=>null);
      if(!current())return{mode:'fallback',reason:'cancelled'};
      clearCompositionTimers();simulation.hide();
      await safe(()=>effects?.hideComposition?.());await safe(()=>effects?.hidePanes?.());
      if(!current())return{mode:'fallback',reason:'cancelled'};
      if(!getEnabled()||!(api?.invoke||nativeDesired())){
        active.mode='fallback';active.reason='native-disabled';return reportSourceDesktop(active);
      }
      const tx=await beginTransaction('source:desktop');
      if(!current())return{mode:'fallback',reason:'cancelled'};
      active.token=tx?.token||null;
      if(!tx?.native){active.mode='fallback';active.reason='native-unavailable';return reportSourceDesktop(active);}
      const bound=await bindSourceDesktopEvents();
      if(!current())return{mode:'fallback',reason:'cancelled'};
      active.revision=1;onGeometryMotion(true);
      try{
        if(!bound)throw new Error('desktop lifecycle events unavailable');
        const placement=await api.invoke('chunk_source_desktop_begin',{request:{token:active.token,revision:active.revision,snapshot}});
        if(!placement||!Number.isFinite(placement.width)||!Number.isFinite(placement.command?.height))throw new Error('native desktop placement refused');
        if(!current()){
          await safe(()=>api.invoke('chunk_source_desktop_end',{token:active.token}));
          return{mode:'fallback',reason:'cancelled'};
        }
        active.mode='native';active.placement=placement;
        return reportSourceDesktop(active);
      }catch(error){
        await safe(()=>api.invoke('chunk_source_desktop_end',{token:active.token}));
        await safe(()=>api.invoke('chunk_window_choreography_restore',{token:active.token}));
        if(current()){
          transaction=null;active.mode='fallback';active.reason=String(error?.message||error||'native-stage-unavailable');
          void logWarn('Source desktop presentation unavailable',active.reason);
          return reportSourceDesktop(active);
        }
        return{mode:'fallback',reason:'cancelled'};
      }finally{onGeometryMotion(false);}
    })();
    return active.opening;
  }
  function updateSourceDesktop(snapshot={}){
    const active=sourceDesktop;
    if(!active||active.mode!=='native')return Promise.resolve(false);
    active.pending=snapshot;
    if(active.pumping)return active.pumping;
    active.pumping=(async()=>{
      let accepted=false;
      while(sourceDesktop===active&&active.mode==='native'&&active.pending){
        const next=active.pending;active.pending=null;
        try{
          accepted=!!await api.invoke('chunk_source_desktop_update',{request:{token:active.token,revision:++active.revision,snapshot:next}});
          if(!accepted)throw new Error('native desktop lease expired');
          if(sourceDesktop===active)active.suspended=!!active.focusSuspended||next.paused===true;
        }catch(error){
          if(sourceDesktop!==active)break;
          // Hide before publishing fallback, including a failed emitter. The
          // native side always attempts the geometry restore as well.
          await safe(()=>api.invoke('chunk_source_desktop_end',{token:active.token}));
          transaction=null;active.mode='fallback';active.reason=String(error?.message||error);reportSourceDesktop(active);break;
        }
      }
      return accepted;
    })().finally(()=>{active.pumping=null;});
    return active.pumping;
  }
  async function endSourceDesktop(reason='source-desktop-end'){
    if(!sourceDesktop)return{restored:true,mode:'ended'};
    const result=await restore(reason);
    return{restored:result,mode:'ended'};
  }

  function compositionEvent(name,payload={}){
    const plan=composition?.plan,event=stableId(name);
    if(!plan||!event||!plan.score?.cues?.some((cue)=>cue.event===event))return false;
    if(!composition.presented){composition.pendingEvents?.add(event);onState({type:'composition-event-queued',plan,event});return true;}
    const effectiveAtMs=Math.max(Date.now()+32,Number(payload?.effectiveAtMs)||Date.now()+64);
    simulation.trigger(plan,event,{effectiveAtMs});
    void safe(()=>effects?.triggerComposition?.(plan,event,{effectiveAtMs}));
    onState({type:'composition-event',plan,event});
    return true;
  }
  function markCompositionPresented(active){
    if(composition!==active)return false;
    active.presented=true;
    const pending=[...(active.pendingEvents||[])];active.pendingEvents?.clear();
    for(const event of pending)compositionEvent(event);
    return true;
  }

  async function beginStudy(plan,{key=null,isCurrent=()=>true}={}){
    if(plan?.purpose!=='source-study'||sourceDesktop||!isCurrent())return null;
    const active={plan,purpose:'source-study',key,presented:false,pendingEvents:new Set(),completed:false,held:presentationHeld};
    composition=active;
    const current=()=>composition===active&&isCurrent();
    const desktop=nativeDesired()&&!!compositionContext().introduced;
    if(desktop){effects?.ensure?.({intensity:'standard',fullscreen:false,reducedMotion:reduced()});await safe(()=>effects?.prepareMedia?.({count:plan.surfaces.length}));}
    if(!current())return null;
    const result=await runPlan(active.plan,{forceSimulate:!desktop,isCurrent:current,startOnPresent:true,
      onPresentationPlan:value=>{if(current())active.plan=value;}});
    if(!current())return null;
    if(result){
      active.native=!!result.native;
      markCompositionPresented(active);
      if(presentationHeld){simulation.hold(true);await safe(()=>effects?.holdComposition?.(true));}
    }
    return result;
  }
  // A player-raised passive instrument shares this Source transaction. It
  // cannot quietly bypass the measured fullscreen handoff or opt-in policy.
  async function requestSourceRestRecorder({isCurrent=()=>true}={}){
    if(!nativeDesired()||!compositionContext().introduced||sourceDesktop||!isCurrent())return false;
    const owner=epoch;
    const active=await beginTransaction('source:continuation');
    return owner===epoch&&isCurrent()&&!!active?.native;
  }
  async function endStudy(key=null){
    if(composition?.purpose!=='source-study'||key!==null&&composition.key!==key)return false;
    effects?.releaseStudyFrames?.();
    return restore('source-study-end',{preserveSnapshots:true});
  }
  async function updateStudyFrames({key,frames,revision}={}){
    const active=composition;
    if(active?.purpose!=='source-study'||!String(active.plan.cueId).startsWith('source-rest:apertures:')||active.key!==key||!active.presented||presentationHeld||active.held||active.framePublishing
      ||compositionContext().reduceDread||!Number.isSafeInteger(revision)||revision<1||revision<=(active.frameRevision||0)
      ||active.plan.reducedMotion&&(active.frameRevision||0)>0||!sourceRestOwnedFramesValid(frames,active.plan.surfaces.filter(p=>p.sensitivity==='none').map(p=>p.id)))return false;
    active.frameRevision=revision;active.framePublishing=true;
    try{const request={cueId:active.plan.cueId,frames,revision};const okay=active.native?await effects?.updateStudyFrames?.(request):simulation.updateStudyFrames(request);return composition===active&&!!okay;}
    finally{active.framePublishing=false;}
  }
  async function updateStudyArchitecture({key,revision,packet}={}){
    const active=composition;
    if(active?.purpose!=='source-study'||!windowArchitectureCueAllowed(active.plan.cueId)||active.key!==key||!active.presented||presentationHeld||active.held||active.architecturePublishing||compositionContext().reduceDread||!Number.isSafeInteger(revision)||revision<1||revision<=(active.architectureRevision||0)||active.plan.reducedMotion&&(active.architectureRevision||0)>0)return false;
    const old=active.architectureCatalogue,same=old?.meshRevision===packet?.meshRevision,wire=same?{...packet,meshes:undefined}:packet,valid=validateWindowArchitecturePacket(wire,{catalogue:same?old.catalogue:null});
    if(!valid.ok||!packet.panes.every(p=>active.plan.surfaces.some(s=>s.id===p.surfaceId&&s.sensitivity==='none')))return false;
    active.architectureCatalogue=same?old:{meshRevision:packet.meshRevision,catalogue:valid.catalogue,meshes:packet.meshes};active.architectureRevision=revision;active.architecturePublishing=true;
    const panes=wire.panes.map(pane=>{const layout=active.architectureLayout?.panes.find(p=>p.surfaceId===pane.surfaceId);return layout?{...pane,desktopOrigin:{x:layout.rect.x,y:layout.rect.y}}:pane;});
    try{const request={cueId:active.plan.cueId,revision,packet:{...wire,panes,meshes:same?undefined:packet.meshes}};
      const okay=active.native?await effects?.updateStudyArchitecture?.(request):simulation.updateStudyArchitecture(request);return composition===active&&!!okay;
    }finally{active.architecturePublishing=false;}
  }
  async function layoutStudyArchitecture({key}={}){
    const active=composition;
    if(active?.purpose!=='source-study'||active.key!==key||!active.presented||presentationHeld||active.held)return null;
    if(!active.native)return simulation.architectureLayout();
    if(active.architectureLayoutPromise)return active.architectureLayoutPromise;
    if(active.architectureLayout&&Date.now()-(active.architectureLayoutPoll||0)<1000)return active.architectureLayout;
    active.architectureLayoutPoll=Date.now();
    active.architectureLayoutPromise=(async()=>{
      const metrics=await safe(()=>api?.invoke?.('chunk_window_metrics'));
      if(composition!==active||presentationHeld||active.held)return null;
      const layout=sourceStudyArchitectureLayout(metrics,active.plan.surfaces);if(!layout)return active.architectureLayout||null;
      const signature=JSON.stringify([layout.mainRect,layout.workArea]);if(signature===active.architectureLayoutSignature)return active.architectureLayout;
      const panes=[];
      for(const pane of layout.panes){
        if(composition!==active||presentationHeld||active.held)return null;
        const surface=active.plan.surfaces.find(p=>p.id===pane.surfaceId),w=layout.workArea,placement=await safe(()=>api?.invoke?.('chunk_window_media_place',{request:{label:`window-media-${surface.index+1}`,index:surface.index,x:(pane.rect.x+pane.rect.width/2-w.x)/w.width,y:(pane.rect.y+pane.rect.height/2-w.y)/w.height,width:pane.rect.width,height:pane.rect.height,recoverable:24,durationMs:0,interactive:false}}));
        if(composition!==active)return null;
        const rect=placement?.center&&Number.isFinite(placement.width)?{x:w.x+placement.center.x-placement.width/2,y:w.y+placement.center.y-placement.height/2,width:placement.width,height:placement.height}:pane.rect;
        panes.push({...pane,rect,crop:{x:(rect.x-layout.mainRect.x)/layout.mainRect.width,y:(rect.y-layout.mainRect.y)/layout.mainRect.height,width:rect.width/layout.mainRect.width,height:rect.height/layout.mainRect.height}});
      }
      active.architectureLayoutSignature=signature;active.architectureLayout={...layout,panes,revision:(active.architectureLayout?.revision||0)+1,native:true};return active.architectureLayout;
    })().finally(()=>{active.architectureLayoutPromise=null;});
    return active.architectureLayoutPromise;
  }
  function holdComposition(value=true){
    const held=!!value;presentationHeld=held;
    if(!composition||composition.plan.cueId.includes(':last-exposure')||composition.held===held)return false;
    composition.held=held;
    const effectiveAtMs=Date.now();simulation.hold(held,{effectiveAtMs});
    void safe(()=>effects?.holdComposition?.(held,{effectiveAtMs}));
    return true;
  }

  function clearCompositionTimers(){
    if(composition?.holdTimer)clearTimeout(composition.holdTimer);
    if(composition?.hintTimer)clearTimeout(composition.hintTimer);
    if(composition?.retireTimer)clearTimeout(composition.retireTimer);
    if(composition?.warningTokens)effects?.releaseSnapshots?.(composition.warningTokens);
    composition=null;
  }
  async function restore(reason='restore',{closePool=false,preserveComposition=false,preserveSnapshots=false}={}){
    paneAuthority=null;takeoverLease=null;
    returnGeneration+=1;returnPending=null;
    const desktop=sourceDesktop;sourceDesktop=null;sourceDesktopGeneration+=1;
    sourceDesktopLastReason=reason;
    let restored=true;
    epoch+=1;
    titleGeneration+=1;
    practiceCueGeneration+=1;
    practiceClueTokens.clear();
    if(['source-runtime-exit','source-god-warp','title-exit'].includes(reason))sourceWarningSeen=false;
    if(['source-runtime-exit','source-god-warp','god-source-preset','title-exit','source-drive'].includes(reason))decay={stage:0,active:null,done:false};
    else if(decay.active)decay={stage:0,active:null,done:true};
    const active=transaction;
    const opening=transactionOpening;
    const puzzleWasActive=composition?.purpose==='puzzle'&&!composition.completed;
    const openingWasNative=!!opening?.native;
    if(opening)opening.native=false;
    // Invalidate every owner before abort listeners or native awaits can run.
    transactionOpening=null;
    transaction=null;battle=null;ending=null;source={stage:'sealed',sequence:0,bucket:-1};frontEndLease=null;frontEndReady=Promise.resolve(null);
    opening?.controller.abort();
    if(desktop?.token&&api?.invoke){
      try{await api.invoke('chunk_source_desktop_end',{token:desktop.token});}
      catch(error){restored=false;onState({type:'source-desktop-restore-error',reason:String(error?.message||error),token:desktop.token});}
    }
    if(!preserveComposition){clearCompositionTimers();simulation.hide();await safe(()=>effects?.hideComposition?.({releaseSnapshots:!preserveSnapshots}));if(puzzleWasActive)onPuzzleState(false);}
    onGeometryMotion(false);
    await safe(()=>effects?.hidePanes?.());
    if(openingWasNative&&api?.invoke)await safe(()=>api.invoke('chunk_window_choreography_restore',{token:opening.token}));
    if(active?.native&&api?.invoke&&active.token!==opening?.token)await safe(()=>api.invoke('chunk_window_choreography_restore',{token:active.token}));
    if(closePool)await safe(()=>effects?.emergencyRestore?.({notify:false}));
    onState({type:'restore',reason,token:active?.token||null,policy:active?.policy||null});
    if(desktop)onState({type:'source-desktop',...sourceDesktopState()});
    return restored;
  }

  // Only ever beside a window that is free to have something beside it. A fullscreen
  // handoff would stop for a notice, and a takeover must never stop the game to start.
  async function releaseTakeoverLease(lease,reason='takeover-complete'){
    if(!lease||takeoverLease!==lease)return false;
    takeoverLease=null; // invalidate in-flight assignment before any native await
    const authority=lease.authority;
    if(!authority||authority!==paneAuthority||authority.epoch!==epoch||battle||ending||sourceDesktop)return false;
    const owns=authority.transaction?transaction===authority.transaction
      :authority.opening&&transactionOpening===authority.opening;
    if(!owns)return false;
    const activeCue=effects?.debug?.()?.activeCompositionCue;
    if(activeCue&&activeCue!==authority.cueId)return false;
    await restore(reason);return true;
  }
  async function hideTakeoverPane(){return releaseTakeoverLease(takeoverLease);}
  async function showTakeoverPane(mediaId,{reducedMotion=false,name,isCurrent=()=>true}={}){
    const available=()=>isCurrent()&&nativeDesired()&&compositionContext().introduced&&!transaction&&!transactionOpening&&!sourceDesktop&&!battle&&!ending;
    if(!available())return false;
    const nativeApi=await loadApi();
    if(!nativeApi?.invoke||await measuredFullscreen(nativeApi)||!available())return false;
    const identity=getSourceIdentity?.();
    const paperName=name===undefined?(identity?.permitted?identity.operatorName:null):name;
    const plan=compileTakeoverPanePlan({mediaId,reducedMotion,flashMode:compositionContext().flashMode,name:paperName});
    if(!plan)return false;
    const lease={authority:null};takeoverLease=lease;
    const current=()=>takeoverLease===lease&&isCurrent()&&!battle&&!ending&&!sourceDesktop;
    // The takeover owns its prepared in-game surface. A second generic
    // composition simulation would obscure it and duplicate the encounter.
    const result=await runPlan(plan,{nativeOnly:true,presentationOwner:lease,isCurrent:current});
    if(!result?.native||!current()){await releaseTakeoverLease(lease,'takeover-unavailable');return false;}
    return true;
  }

  async function showPracticeCue(cue){
    const generation=++practiceCueGeneration,owner=epoch;
    const current=()=>generation===practiceCueGeneration&&owner===epoch;
    if(!nativeDesired())return{native:false,unavailable:true,reason:getEnabled()?'desktop-required':'disabled'};
    if(transaction?.native){
      const fullscreen=await measuredFullscreen(api);
      if(!current())return null;
      if(fullscreen){
        // A player may re-enter fullscreen mid-exercise. The next clue must
        // perform the same advisory handoff as the first one.
        const resetting=restore('practice:fullscreen');
        const nextEpoch=epoch;
        await resetting;
        return nextEpoch===epoch?showPracticeCue(cue):null;
      }
    }
    effects?.ensure?.({intensity:'standard',fullscreen:false,reducedMotion:reduced()});
    const ready=await safe(()=>effects?.prepareMedia?.({count:4}));
    if(!current())return null;
    if(!ready)return{native:false,unavailable:true};
    // A snapshot is permanent: do not cache a substituted browser face while
    // the pinned clue alphabet is still loading. Headless document probes have
    // no FontFaceSet and do not rasterize real glyphs.
    if(documentApi?.fonts){
      const fonts=await safe(()=>ensureWorldLetteringFonts({ownerDocument:documentApi}));
      if(!current())return null;
      if(!fonts)return{native:false,unavailable:true,reason:'lettering-fonts'};
    }
    const clueTokens=[];
    for(const part of cue.parts||[]){
      if(!practiceClueTokens.has(part)){
        const canvas=documentApi?.createElement?.('canvas');
        if(!canvas)return{native:false,unavailable:true};
        canvas.width=560;canvas.height=560;
        drawPracticeRebus(canvas.getContext('2d'),0,0,560,560,part);
        const token=effects?.registerSnapshot?.(canvas.toDataURL('image/png'));
        if(!token)return{native:false,unavailable:true};
        practiceClueTokens.set(part,token);
      }
      clueTokens.push(practiceClueTokens.get(part));
    }
    const plan=compilePracticeCuePlan(cue,{clueTokens,reducedMotion:reduced(),flashMode:compositionContext().flashMode});
    if(!plan)return{native:false,unavailable:true};
    const task=planTail.then(async()=>{
      if(!current())return null;
      const active=await beginTransaction('battle:practice');
      if(!current()||!active)return null;
      const native=!!(active.native&&await safe(()=>effects?.showComposition?.(plan,{token:effects?.sessionToken?.()})));
      if(!current()||!native){
        const activeCue=effects?.debug?.()?.activeCompositionCue;
        if(!activeCue||activeCue===plan.cueId)await safe(()=>effects?.hideComposition?.({releaseSnapshots:false}));
      }
      if(!current())return null;
      // These puzzles belong to actual desktop windows. Never replace the
      // opponent or cover its controls with an in-frame simulation.
      onState({type:'practice-clue',plan,native});
      return{plan,native,unavailable:!native};
    });
    planTail=task.catch(()=>null);
    return task;
  }

  function prepareBattle({battleId='',encounterId='',reducedMotion=false}={}){
    // A fast deliberate HUSH challenge may arrive while the warning is still
    // printing. Invalidate a pending renderer and retire the visible warning
    // before a battle owns the panes. Keep the once-per-journey warning latch.
    if(source.warningStarted)source={...source};
    if(composition?.purpose==='death'||composition?.purpose==='source-warning'){
      void safe(()=>effects?.hideComposition?.());simulation.hide();clearCompositionTimers();
    }
    const profile=battleChoreographyProfile(battleId);
    battle=profile?{battleId:profile.battleId,encounterId,profile,sequence:0,damageCount:0,breached:false,reducedMotion:!!reducedMotion}:null;
    return battle;
  }

  function beginSourceContact(){
    // Dialogue has foreground ownership before the player chooses whether to
    // fight. Suppress any later warning in this journey, including one still
    // waiting for snapshot registration or a desktop presentation transaction.
    sourceWarningSeen=true;
    const sourceOwned=source.stage!=='sealed'||source.warningStarted
      ||composition?.purpose==='source-warning'||String(transaction?.sceneId||'').startsWith('source:');
    if(!sourceOwned)return Promise.resolve(false);
    // restore invalidates queued plans synchronously, removes the simulated
    // panes immediately, and erases native image envelopes before resolving.
    // This reason deliberately does not reset the once-per-journey latch.
    return restore('source-contact');
  }

  async function fireballCast({battleId='',castId='',windowLock=false}={}){
    if(sourceDesktop)return null;
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile)return null;
    if(!battle)battle={battleId:profile.battleId,encounterId:battleId,profile,sequence:0,damageCount:0,breached:false,reducedMotion:reduced()};
    // The first actual cast is the first breach. Merely entering a fight only
    // prewarms surfaces and never changes the desktop.
    if(battle.breached)return null;
    battle.breached=true;
    if(profile.battleId==='natatorium')onFirstBreach({battleId:profile.battleId,castId:String(castId||'')});
    const result=await runPlan(battleIntroPlan(profile,{sequence:battle.sequence++,reducedMotion:reduced()||battle.reducedMotion||windowLock}));
    await waitFn(reduced()?220:680);
    if(battle?.battleId===profile.battleId){
      await safe(()=>effects?.hidePanes?.());simulation.hide();
      onState({type:'merge',sceneId:`battle:${profile.battleId}`});
    }
    return result;
  }

  async function damage({battleId='',received=0,phase=false,origin=null,windowLock=false}={}){
    if(sourceDesktop)return null;
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile||windowLock)return null;
    if(battle)battle.damageCount+=1;
    const count=battle?.damageCount||1;
    const authored=phase||profile.activity>=1
      ||(profile.activity>=.8&&count%5!==0)
      ||(profile.activity>=.5&&count%2===1)
      ||(profile.activity>=.3&&count%3===1)
      ||(profile.activity<.3&&count%5===1);
    if(!authored)return null;
    const grade=phase?'phase':Number(received)>=8?'heavy':'light';
    return runPlan(battleDamagePlan(profile,{grade,origin,sequence:sequence++,reducedMotion:reduced()}));
  }

  async function result({battleId='',result='abort',snapshotToken:retainedSnapshot=''}={}){
    if(sourceDesktop)return null;
    if(result!=='lose')return null;
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile)return null;
    const context=compositionContext();
    const snapshotToken=retainedSnapshot||effects?.captureSnapshot?.();
    if(!snapshotToken)return null;
    const plan=deathCompositionPlan({battleId:profile.battleId,snapshotToken,lastExposure:true,reduceDread:!!context.reduceDread,reducedMotion:reduced(),flashMode:context.flashMode,epochMs:Date.now()});
    const active={plan,purpose:'death',state:{},completed:false,presented:false,pendingEvents:new Set()};
    composition=active;
    void runPlan(plan,{isCurrent:()=>composition===active}).then(()=>markCompositionPresented(active)).catch(()=>null);
    // The result dialogue owns retry timing. A native decoder or surface that
    // is late is allowed to fall back, never to hold this promise open.
    return{plan,scheduled:true};
  }

  async function finishBattle({battleId='',result='abort'}={}){
    if(sourceDesktop&&['win','lose'].includes(result)){
      battle=null;onState({type:'handoff',from:'source-desktop',to:'ending'});return true;
    }
    // A battle breach is one transaction. Source hands that transaction to its
    // ending; every other result and every abort restores here.
    if((battleId==='source-final'||battle?.battleId==='source-final')&&['win','lose'].includes(result)){
      battle=null;
      onState({type:'handoff',from:'battle:source-final',to:'ending'});
      return true;
    }
    return restore(`battle:${result}`,{preserveComposition:result==='lose'});
  }

  function placementState(detail){
    const value=detail?.placement;if(!value?.center)return null;
    return{x:Number(value.center.x)||0,y:Number(value.center.y)||0,width:Number(value.width)||0,height:Number(value.height)||0,monitor:String(value.monitor||'')};
  }
  async function completeAperture(){
    if(!composition||composition.purpose!=='puzzle'||composition.completed)return false;
    composition.completed=true;
    if(composition.holdTimer)clearTimeout(composition.holdTimer);
    compositionEvent('aperture:complete');
    await safe(()=>effects?.freezeComposition?.(composition.plan.cueId,true));simulation.freeze(true);
    onState({type:'puzzle-complete',plan:composition.plan});
    await waitFn(300);
    await safe(()=>effects?.hideComposition?.());simulation.hide();
    onApertureComplete();onPuzzleState(false);composition=null;
    return true;
  }
  function evaluatePuzzle(){
    if(!composition||composition.purpose!=='puzzle'||composition.completed)return null;
    const result=evaluateCompositionConstraints(composition.plan,composition.state);
    if(result.ok&&!composition.holdTimer&&!composition.settling)void settleAperture();
    else if(!result.ok&&composition.holdTimer){clearTimeout(composition.holdTimer);composition.holdTimer=null;}
    if(!result.ok){
      const tolerances=new Map(composition.plan.constraints.map((constraint)=>[constraint.id,constraint.tolerance]));
      const near=result.results.filter((entry)=>entry.ok||entry.error<=Math.max(24,(tolerances.get(entry.id)||0)*2)).map((entry)=>entry.id).sort().join(':');
      const now=Date.now();
      if(near&&(near!==composition.nearKey||now-(composition.nearAt||0)>900)){
        composition.nearKey=near;composition.nearAt=now;compositionEvent('aperture:near');
      }
    }
    onState({type:'puzzle-progress',result,elapsedMs:Date.now()-composition.startedAt});
    return result;
  }
  async function settleAperture(){
    const active=composition;
    if(!active||active.purpose!=='puzzle'||active.completed||active.settling)return false;
    active.settling=true;
    simulation.snap(active.plan,{coherent:true});
    await safe(()=>effects?.snapComposition?.(active.plan,{coherent:true,durationMs:120}));
    if(composition!==active||active.completed)return false;
    active.settling=false;
    const result=evaluateCompositionConstraints(active.plan,active.state);
    onState({type:'puzzle-settled',plan:active.plan,result});
    if(!result.ok)return false;
    active.holdTimer=setTimeout(()=>{void completeAperture();},active.plan.completion.holdMs||650);
    active.holdTimer.unref?.();
    return true;
  }
  function noteCompositionMove(detail={}){
    if(!composition||composition.purpose!=='puzzle'||String(detail.cueId||'')!==composition.plan.cueId)return false;
    const next=placementState(detail);if(!next)return false;
    composition.state[detail.paneId]=next;evaluatePuzzle();return true;
  }
  function armPuzzleHint(active){
    if(!active||active.purpose!=='puzzle'||active.completed)return;
    const delay=Math.max(0,20000-(Date.now()-active.startedAt));
    active.hintTimer=setTimeout(()=>{
      if(composition!==active||active.completed)return;
      simulation.coherence(true);void safe(()=>effects?.setCompositionCoherence?.(active.plan,true));
      compositionEvent('aperture:hint');
      onState({type:'puzzle-hint',plan:active.plan});
    },delay);
    active.hintTimer.unref?.();
  }
  async function startAperture({forceSimulate=false}={}){
    if(isApertureComplete()||composition?.purpose==='puzzle')return null;
    const context=compositionContext();
    const plan=apertureCompositionPlan({reduceDread:!!context.reduceDread,reducedMotion:reduced(),flashMode:context.flashMode,epochMs:Date.now()});
    const active={plan,purpose:'puzzle',state:{},startedAt:Date.now(),completed:false,settling:false,holdTimer:null,hintTimer:null,presented:false,pendingEvents:new Set()};
    composition=active;
    onPuzzleState(true);onState({type:'puzzle-start',plan});
    armPuzzleHint(composition);
    const result=await runPlan(plan,{forceSimulate});markCompositionPresented(active);return result;
  }
  async function puzzleInteract(){
    if(!composition||composition.purpose!=='puzzle'||composition.completed)return false;
    if(Date.now()-composition.startedAt<45000)return false;
    simulation.snap(composition.plan,{coherent:true});
    await safe(()=>effects?.snapComposition?.(composition.plan,{coherent:true}));
    onState({type:'puzzle-auto-assemble',plan:composition.plan});return true;
  }

  async function sourceFrame(frame={}){
    const stage=sourceLeakStage(frame);
    if(stage.id==='sealed'){
      // A stale Source transaction may exist after a god-menu jump or reload,
      // but the real page/dock/door chain must never inherit it. Past the
      // perimeter nothing is cut here: sourceDecay() takes the windows apart
      // across the outskirts and restores at the tape.
      const outskirts=String(frame?.phase||'').toLowerCase()==='horizon';
      if(source.stage!=='sealed'&&!outskirts)await restore('source-threshold-exit');
      source={stage:'sealed',sequence:0,bucket:-1};
      return stage;
    }
    const bucket=Math.floor(stage.progress*12);
    if(stage.id===source.stage&&bucket===source.bucket)return stage;
    source.stage=stage.id;
    source.bucket=bucket;
    if(nativeDesired()){
      effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
      if(stage.id==='white')void safe(()=>effects?.prepareMedia?.({count:4}));
    }
    if(stage.id==='proper'){
      await beginSourceWarning();
      return stage;
    }
    await runPlan(sourcePlan(stage,source.sequence++,reduced()));
    return stage;
  }

  async function ensureDecayFrames(){
    if(decayTokens&&(!effects?.snapshotData||decayTokens.every((token)=>effects.snapshotData(token))))return decayTokens;
    const context=compositionContext();
    const frames=[.25,.5,.75,1].flatMap((damage,index)=>sectorErrorPhases({
      count:1,rowsPerPhase:1,width:640,height:432,seed:4417+index*13,reducedMotion:reduced(),flashMode:context.flashMode,damage,
    }));
    const tokens=[];
    for(const frame of frames){const token=await safe(()=>effects?.registerSnapshot?.(frame));if(token)tokens.push(token);}
    decayTokens=tokens.length?tokens:null;
    return decayTokens;
  }

  // THE WINDOWS COME APART ON THE WAY OUT. progress is the walk from the field's
  // edge (0) to the head of the tape (1). Stages only advance: walking back does
  // not mend a window, and once they are gone nothing reopens them.
  async function sourceDecay(progress=0){
    const p=clamp(progress);
    if(decay.done||p<=0)return false;
    if(p>=1){
      const owned=decay.active&&composition===decay.active;
      decay={stage:0,active:null,done:true};
      if(owned)await restore('source-decay-end');
      return true;
    }
    if(!decay.active){
      if(composition&&!['source-warning','sector'].includes(composition.purpose))return false;
      const opening={stage:0,active:true,done:false};decay=opening;
      const context=compositionContext();
      const terminals=await ensureSectorPhases();
      const decays=await ensureDecayFrames();
      if(decay!==opening)return false;
      const plan=sourceDecayCompositionPlan({phaseTokens:terminals||[],decayTokens:decays||[],epochMs:Date.now(),reducedMotion:reduced(),flashMode:context.flashMode,runMs:SOURCE_FAULT_RUN_MS});
      const active={plan,purpose:'source-decay',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
      composition=active;decay.active=active;
      if(nativeDesired())effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
      await runPlan(plan);markCompositionPresented(active);
      if(decay.active!==active)return false;
    }
    if(decay.active===true)return false;
    const reached=SOURCE_DECAY_STAGES.filter((at)=>p>=at).length;
    while(decay.stage<reached){decay.stage+=1;compositionEvent(`source-decay-${decay.stage}`);}
    return true;
  }

  // THE FLOOR AND THE GLASS FAIL TOGETHER. Fed every Source frame with the
  // world's fault frame (game/source-faults.js). A run's first frame sends the
  // terminals that are up `sector:run:<lane>`; its last sends `sector:clear`.
  // Plans without terminals carry no such cue and compositionEvent ignores it.
  function sourceFault(frame={}){
    const active=!!frame?.active&&!!frame.overflowActive;
    if(active&&(!faultRun.active||faultRun.run!==frame.overflowRun)){
      const lane=Math.max(0,Math.min(SOURCE_FAULT_LANES-1,Math.floor(Number(frame.overflowLane)||0)));
      faultRun={run:frame.overflowRun,active:true,lane};
      return compositionEvent(`${SECTOR_RUN_EVENT_PREFIX}${lane}`);
    }
    if(!active&&faultRun.active){
      faultRun={...faultRun,active:false};
      return compositionEvent(SECTOR_CLEAR_EVENT);
    }
    return false;
  }

  function leaveSource(reason='source-exit'){
    if(sourceDesktop&&['source-exit','source-runtime-exit'].includes(reason))return Promise.resolve(false);
    const driveHandoff=reason==='source-drive'&&(sourceDesktop||decay.active||['source-warning','source-decay'].includes(composition?.purpose));
    const sourceOwned=driveHandoff||source.stage!=='sealed'||composition?.purpose==='puzzle'||String(transaction?.sceneId||'').startsWith('source:');
    if(!sourceOwned)return Promise.resolve(false);
    // Browser fragments must disappear in this turn, before any asynchronous
    // native restore. restore() invalidates pending plans before its awaits.
    if(reason==='source-drive')simulation.hide();
    return restore(reason);
  }

  async function beginEnding(endingId=''){
    if(sourceDesktop){ending=endingChoreographyProfile(endingId);return{...sourceDesktopState(),handoff:true};}
    const profile=endingChoreographyProfile(endingId);
    if(!profile)return null;
    ending=profile;
    if(nativeDesired())effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
    const context=compositionContext();
    const plan=endingCompositionPlan(endingId,{epochMs:Date.now(),reduceDread:!!context.reduceDread,reducedMotion:reduced(),flashMode:context.flashMode,intrusionToken:sectorTokens?.[0]||''});
    if(nativeDesired())await safe(()=>effects?.prepareMedia?.({count:plan.surfaces.length}));
    const active={plan,purpose:'ending',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
    composition=active;
    const result=await runPlan(endingPlan(profile,sequence++,reduced()));
    await runPlan(plan);
    markCompositionPresented(active);
    await waitFn(reduced()?80:620);
    if(composition===active){
      simulation.snap(plan,{coherent:true});
      await safe(()=>effects?.snapComposition?.(plan,{coherent:true,durationMs:reduced()?0:600}));
    }
    return result;
  }

  // THE RETURN, ON THE SURFACES.
  //
  // `sections` are already-rasterised data URLs, one per part of the account —
  // rendered by the caller because a text pane has no shader path and would come
  // up black out here. They are registered as snapshots and handed to the panes,
  // which is the same road the death composition's quartered frame travels.
  async function beginReturn(sections=[],{lastExposure=false,snapshotToken='',snapshotImage=''}={}){
    const generation=++returnGeneration,owner=epoch;
    const pending={generation,owner};returnPending=pending;
    const current=()=>generation===returnGeneration&&owner===epoch&&returnPending===pending;
    const pages=lastExposure
      ?(!snapshotToken&&String(snapshotImage).startsWith('data:image/')?[{image:snapshotImage,label:'Final world exposure'}]:[])
      :(Array.isArray(sections)?sections:[]).filter((entry)=>String(entry?.image||'').startsWith('data:'));
    if(lastExposure?!snapshotToken&&!pages.length:pages.length<2){if(current())returnPending=null;return null;}
    if(nativeDesired())effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
    const tokens=snapshotToken&&lastExposure?[snapshotToken]:[];
    const registered=[];
    const abandon=()=>{if(registered.length)effects?.releaseSnapshots?.(registered);return null;};
    for(const page of pages){
      const token=await safe(()=>effects?.registerSnapshot?.(page.image));
      if(token){tokens.push(token);registered.push(token);}
      if(!current())return abandon();
    }
    if(tokens.length<(lastExposure?1:2)){if(current())returnPending=null;return abandon();}
    const context=compositionContext();
    const plan=returnCompositionPlan({
      sections:pages.map((page)=>page.label||''),
      snapshotTokens:tokens,lastExposure,
      epochMs:Date.now(),reducedMotion:reduced(),flashMode:context.flashMode,
    });
    if(nativeDesired())await safe(()=>effects?.prepareMedia?.({count:plan.surfaces.length}));
    if(!current())return abandon();
    const active={plan,purpose:'return',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
    composition=active;
    await runPlan(plan,{isCurrent:current});
    if(!current()||composition!==active)return abandon();
    markCompositionPresented(active);
    return {plan,scheduled:true};
  }

  // THE PHASES ARE BAKED ONCE AND KEPT.
  //
  // Registering the scroll frames at first use rather than per cue is what makes
  // the intrusion cheap: once these tokens exist, ANY composition can reference
  // them, so a pane in the middle of an ending can drop into the failing disk
  // without rasterising anything first.
  // Primed eagerly and read SYNCHRONOUSLY by the plan builders. Awaiting this
  // inside beginEnding put a microtask in front of `composition=active`, which
  // silently broke event queueing: compositionEvent called in the same tick as
  // beginEnding found no composition to queue against. Nothing on the hot path
  // may await ahead of that assignment.
  let sectorTokens=null;
  let sectorPhaseMode=null;
  let sectorPending=null;
  async function ensureSectorPhases(){
    const context=compositionContext(),mode=`${reduced()}:${context.flashMode}`;
    if(sectorTokens&&sectorPhaseMode===mode&&(!effects?.snapshotData||sectorTokens.every((token)=>effects.snapshotData(token))))return sectorTokens;
    if(sectorPending)return sectorPending;
    effects?.releaseSnapshots?.(sectorTokens||[]);
    sectorPending=(async()=>{
      // Twenty phases, six rows apart: enough churn that the offsets never read
      // still, and inside the 32-snapshot bank with the eight Source warning cards.
      const phases=sectorErrorPhases({count:20,rowsPerPhase:reduced()||context.flashMode!=='full'?1:6,width:640,height:432,seed:4417,reducedMotion:reduced(),flashMode:context.flashMode});
      const tokens=[];
      for(const phase of phases){
        const token=await safe(()=>effects?.registerSnapshot?.(phase));
        if(token)tokens.push(token);
      }
      sectorTokens=tokens.length?tokens:null;sectorPhaseMode=mode;
      return sectorTokens;
    })().finally(()=>{sectorPending=null;});
    return sectorPending;
  }

  async function beginSourceWarning(){
    if(source.warningStarted||sourceWarningSeen)return null;
    const owner=source,ownerEpoch=epoch;
    owner.warningStarted=true;sourceWarningSeen=true;
    const context=compositionContext();
    const identity=getSourceIdentity()||{};
    // THE MESSAGE COMES OUT OF THE FAILING DISK. Every frame is still the
    // ntfsclone terminal; the name and the warning gather in its cells as bits
    // (render/source-warning.js). They are this composition's own frames —
    // registered last, so the 32-snapshot bank keeps them — and all of them are
    // released when it retires.
    const baked=sourceWarningFrames({operatorName:identity.operatorName,permitted:identity.permitted===true,documentApi,reducedMotion:reduced(),flashMode:context.flashMode});
    const register=async(list=[])=>{const tokens=[];for(const frame of list){const token=await safe(()=>effects?.registerSnapshot?.(frame));if(token)tokens.push(token);}return tokens;};
    const preTokens=await register(baked.pre);
    const messageTokens=[];
    for(const frames of baked.messages||[])messageTokens.push(await register(frames));
    const warningTokens=[...preTokens,...messageTokens.flat()];
    if(source!==owner||epoch!==ownerEpoch){effects?.releaseSnapshots?.(warningTokens);return null;}
    const plan=sourceWarningCompositionPlan({preTokens,messageTokens,epochMs:Date.now(),reducedMotion:reduced(),flashMode:context.flashMode,runMs:SOURCE_FAULT_RUN_MS});
    const active={plan,purpose:'source-warning',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set(),warningTokens};
    composition=active;
    if(nativeDesired())effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
    await runPlan(plan);markCompositionPresented(active);
    if(composition!==active){effects?.releaseSnapshots?.(warningTokens);return null;}
    active.retireTimer=setTimeout(()=>{
      if(composition!==active)return;
      active.completed=true;simulation.hide();
      effects?.releaseSnapshots?.(warningTokens);
      void safe(()=>effects?.hideComposition?.({releaseSnapshots:false}));
    },Math.max(0,16500-(Date.now()-active.startedAt)));
    active.retireTimer.unref?.();
    return {plan,scheduled:true};
  }

  // The disk failing, as a screen of its own.
  async function beginSectorError(){
    if(nativeDesired())effects?.ensure?.({intensity:'hostile',fullscreen:getDisplayMode()==='game-mode',reducedMotion:reduced()});
    const tokens=await ensureSectorPhases();
    if(!tokens)return null;
    const context=compositionContext();
    const plan=sectorErrorCompositionPlan({phaseTokens:tokens,epochMs:Date.now(),reducedMotion:reduced(),flashMode:context.flashMode,runMs:SOURCE_FAULT_RUN_MS});
    if(!plan)return null;
    if(nativeDesired())await safe(()=>effects?.prepareMedia?.({count:plan.surfaces.length}));
    const active={plan,purpose:'sector',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
    composition=active;
    await runPlan(plan);
    markCompositionPresented(active);
    return {plan,scheduled:true};
  }

  // ONE PANE FALLS OFF THE DISK, UNDERNEATH WHATEVER ELSE IS SHOWING.
  //
  // Not a screen — an interruption. The composition already up keeps playing and
  // a single surface stops being its footage and starts being the failure.
  //
  // It goes through compositionEvent because that is the ONLY road: the
  // simulation exposes show/snap/coherence/freeze/trigger/hide and the effects
  // layer exposes triggerComposition, and neither has a public "assign this pane
  // now". Both fire named event cues, so the cue is baked into the plan when it
  // is compiled (sectorIntrusionCue) and fired by name here.
  async function intrudeSector(){
    if(!composition?.plan||composition.purpose==='sector')return false;
    return compositionEvent(SECTOR_INTRUSION_EVENT);
  }

  // The account has been read. The surfaces settle and go — they must not sit
  // over the stages that follow the report, which is what a composition with no
  // end does.
  async function finishReturn(){
    const pending=!!returnPending;
    returnGeneration+=1;returnPending=null;
    if(composition?.purpose!=='return')return pending;
    await restore('return-complete');
    return true;
  }

  function beginOpening(){
    // Bake the scroll phases now so an intrusion later costs nothing and the
    // plan builders can read the token without awaiting.
    void ensureSectorPhases();
    const generation=(frontEndLease?.generation||0)+1;
    frontEndLease={active:true,owner:'opening',generation,token:null,effectsToken:effects?.sessionToken?.()||null,quiesced:false};
    onState({type:'front-end-window-owner',owner:'opening',generation,token:null});
    frontEndReady=(async()=>{
      const active=await beginTransaction('opening-credits');
      if(!active)return null;
      let effectsToken=effects?.sessionToken?.()||null;
      if(nativeDesired()){
        effectsToken=effects?.ensure?.({intensity:'standard',fullscreen:false,reducedMotion:reduced()})||effectsToken;
      }
      if(frontEndLease?.active&&frontEndLease.generation===generation){
        frontEndLease.token=active?.token||null;
        frontEndLease.effectsToken=effectsToken||effects?.sessionToken?.()||null;
      }
      return active;
    })().catch(()=>null);
    return frontEndReady;
  }


  async function beginTitle({handoff=false}={}){
    const context=compositionContext();
    if(!context.introduced)return null;
    const owner=++titleGeneration;
    const canHandoff=!!handoff&&frontEndLease?.active&&frontEndLease.owner==='opening';
    let leaseGeneration=null;
    if(canHandoff){
      frontEndLease.owner='title';
      frontEndLease.generation+=1;
      const handoffGeneration=frontEndLease.generation;
      await frontEndReady;
      if(!frontEndLease?.active||frontEndLease.owner!=='title'||frontEndLease.generation!==handoffGeneration)return null;
      frontEndLease.token=transaction?.token||frontEndLease.token||null;
      frontEndLease.effectsToken=effects?.sessionToken?.()||frontEndLease.effectsToken||null;
      frontEndLease.quiesced=!!await safe(()=>effects?.quiesceComposition?.());
      frontEndLease.effectsToken=effects?.sessionToken?.()||frontEndLease.effectsToken||null;
      leaseGeneration=frontEndLease.generation;
      onState({type:'front-end-window-owner',owner:'title',generation:leaseGeneration,token:frontEndLease.token,handoff:true});
    }
    const plan=titleCompositionPlan({endingId:context.lastEndingId||'',epochMs:Date.now(),reducedMotion:reduced(),flashMode:context.flashMode});
    if(nativeDesired()){
      if(!canHandoff)effects?.ensure?.({intensity:'standard',fullscreen:false,reducedMotion:reduced()});
      await safe(()=>effects?.prepareMedia?.({count:plan.surfaces.length}));
    }
    if(owner!==titleGeneration)return null;
    await waitFn(420);
    if(owner!==titleGeneration)return null;
    if(canHandoff&&(!frontEndLease?.active||frontEndLease.owner!=='title'||frontEndLease.generation!==leaseGeneration))return null;
    const active={plan,purpose:'title',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
    composition=active;
    const result=await runPlan(plan,{compositionMode:canHandoff?'handoff':'cold',handoffDurationMs:reduced()?0:260});
    if(result)markCompositionPresented(active);
    return result;
  }

  async function finishTitle({windowPolicy='none',nextPlan=null}={}){
    titleGeneration+=1;
    if(frontEndLease?.active)frontEndLease.generation+=1;
    const active=composition?.purpose==='title'?composition:null;

    if(windowPolicy==='preserve'){
      if(active){
        await safe(()=>effects?.quiesceComposition?.());
        frontEndLease=frontEndLease||{active:true,token:transaction?.token||null,effectsToken:effects?.sessionToken?.()||null,generation:1};
        frontEndLease.owner='game';frontEndLease.active=true;frontEndLease.quiesced=true;
        onState({type:'front-end-window-owner',owner:'game',generation:frontEndLease.generation,token:frontEndLease.token,windowPolicy});
      }
      return !!active;
    }

    if(windowPolicy==='replace'&&nextPlan){
      if(active)await safe(()=>effects?.quiesceComposition?.());
      frontEndLease=frontEndLease||{active:true,token:transaction?.token||null,effectsToken:effects?.sessionToken?.()||null,generation:1};
      frontEndLease.owner='game';frontEndLease.active=true;frontEndLease.quiesced=false;
      const next={plan:nextPlan,purpose:'game',state:{},startedAt:Date.now(),completed:false,presented:false,pendingEvents:new Set()};
      composition=next;
      const result=await runPlan(nextPlan,{compositionMode:'handoff',handoffDurationMs:reduced()?0:260});
      if(result)markCompositionPresented(next);
      return !!result;
    }

    // Ordinary gameplay currently owns no secondary windows. This is the first
    // front-end boundary allowed to retire visible panes; the native pool stays
    // warm because restore() hides rather than closes it.
    if(active){
      simulation.snap(active.plan);
      await safe(()=>effects?.snapComposition?.(active.plan,{durationMs:360}));
      await waitFn(380);
    }
    return restore('title-exit');
  }

  // THE POOL SURVIVES THE CREDITS NOW.
  //
  // This closed it (`closePool:true` + `effects.end()`), which tore every
  // desktop surface down at the exact moment before the return report — so the
  // last screen of the game was the one screen the window system was guaranteed
  // to have abandoned. The credits still restore the main window and clear the
  // composition; the surfaces stay leased so beginReturn can use them without
  // rebuilding, which is a race Tauri loses (see the lifetime note in
  // personalized-window-effects).
  async function credits(){return restore('credits');}
  // Nothing calls a pool-close here on purpose: returnToTitle already runs
  // emergencyRestore({preservePuzzle:false}), which is the one path that destroys
  // the surfaces. The lease therefore runs ending -> credits -> return -> title,
  // and is torn down exactly once, at the end.
  async function emergencyRestore({preservePuzzle=true}={}){
    // Emergency cleanup is an escape hatch, not a combat choice. Forgive the
    // live projectile before its surfaces disappear; otherwise an invisible
    // exchange can keep counting and damage the player after the reset.
    const EventCtor=documentApi?.defaultView?.CustomEvent||globalThis.CustomEvent;
    if(EventCtor)keyTarget?.dispatchEvent?.(new EventCtor('chunk-surfer:fireball-forgive',{detail:{reason:'emergency-restore'}}));
    const puzzle=preservePuzzle&&composition?.purpose==='puzzle'&&!composition.completed
      ?{plan:composition.plan,startedAt:composition.startedAt}:null;
    await restore('emergency',{closePool:true});
    if(!puzzle)return true;
    composition={plan:puzzle.plan,purpose:'puzzle',state:{},startedAt:puzzle.startedAt,completed:false,settling:false,holdTimer:null,hintTimer:null,presented:true,pendingEvents:new Set()};
    armPuzzleHint(composition);
    onPuzzleState(true);return performPlan(puzzle.plan,{forceSimulate:true});
  }
  function suspend(){
    if(returnPending||composition?.plan?.cueId?.includes(':last-exposure')){
      // The main presenter owns the pause/focus clock. Optional images retire;
      // resuming must not replay their wall-clock score or install a late pane.
      void restore('last-exposure-suspend');return true;
    }
    if(composition?.purpose==='source-study'){holdComposition(true);return true;}
    if(sourceDesktop?.mode==='native'){
      sourceDesktop.suspended=true;
      void safe(()=>api.invoke('chunk_source_desktop_suspend',{token:sourceDesktop.token,suspended:true}));
      reportSourceDesktop(sourceDesktop);
    }
    void safe(()=>effects?.suspendSurfaces?.());
    if(effects?.debug?.()?.activeCompositionCue?.startsWith('practice:')){
      void safe(()=>effects?.hideComposition?.({releaseSnapshots:false}));
    }
    return true;
  }
  function interactSource(){
    // The Source warning is noninteractive. The retired "enter" pane used to
    // consume the first E even with no visible pane, stealing HUSH's prompt.
    return false;
  }

  const keyTarget=documentApi?.defaultView||globalThis.window;
  keyTarget?.addEventListener?.('keydown',(event)=>{
    if(event.key!=='Escape'||event.repeat)return;
    const now=Number(event.timeStamp)||Date.now();
    if(now-lastEscapeAt<=850){lastEscapeAt=-Infinity;void emergencyRestore();}
    else lastEscapeAt=now;
  },true);
  keyTarget?.addEventListener?.('chunk-surfer:window-pane-action',()=>{interactSource();});
  keyTarget?.addEventListener?.('chunk-surfer:window-media-moved',(event)=>{noteCompositionMove(event.detail||{});});
  keyTarget?.addEventListener?.('chunk-surfer:window-media-action',(event)=>{if(event.detail?.action==='escape')void emergencyRestore();});

  return{
    prepareBattle,fireballCast,damage,result,finishBattle,beginReturn,finishReturn,beginSectorError,beginSourceWarning,beginSourceContact,intrudeSector,sourceFrame,sourceFault,sourceDecay,leaveSource,beginEnding,beginOpening,beginTitle,finishTitle,credits,
    emergencyRestore,suspend,runPlan,showPracticeCue,showTakeoverPane,hideTakeoverPane,compositionEvent,interactSource,puzzleInteract,noteCompositionMove,beginStudy,endStudy,holdComposition,requestSourceRestRecorder,updateStudyFrames,updateStudyArchitecture,layoutStudyArchitecture,
    beginSourceDesktop,updateSourceDesktop,endSourceDesktop,sourceDesktopState,
    // TEARDOWN FOR A CUE A CALLER RAN ITSELF. runPlan was public and this was
    // not, so anything that showed clue surfaces had no supported way to take
    // them down again — which is most of why the box office cue was compiled,
    // spec-pinned, and never fired by anything in the game.
    restore,
    active:()=>!!transaction,
    debug:()=>({sourceDesktop:sourceDesktopState(),decay:{stage:decay.stage,active:!!decay.active,done:decay.done},transaction:transaction?{...transaction}:null,battle:battle?{battleId:battle.battleId,breached:battle.breached}:null,source:{...source},ending,composition:composition?{purpose:composition.purpose,cueId:composition.plan.cueId,completed:composition.completed}:null,frontEnd:frontEndLease?{...frontEndLease,effectsToken:effects?.sessionToken?.()||frontEndLease.effectsToken||null}:null}),
  };
}

import { isTauriRuntime } from './detect.js';

export const WINDOW_CHOREOGRAPHY_PRIMITIVES=Object.freeze([
  'Frame','Glide','Cinch','Bloom','Dock','Breach','Restore','Split','Cast',
  'Handoff','Orbit','Swarm','Recenter','Simulate',
]);

const BATTLE_PROFILES=Object.freeze({
  natatorium:Object.freeze({
    battleId:'natatorium',intensity:.18,activity:.18,intro:'rise',formation:'rise-drift',
    introFrom:{x:.50,y:1.12},damageAxis:'vertical',primitives:['Breach','Glide','Split','Cast'],
  }),
  hall:Object.freeze({
    battleId:'hall',intensity:.36,activity:.34,intro:'take-seat',formation:'seat-align',
    introFrom:{x:.78,y:.80},damageAxis:'lateral',primitives:['Breach','Dock','Glide','Split','Cast'],
  }),
  practice:Object.freeze({
    battleId:'practice',intensity:.52,activity:.52,intro:'rewind',formation:'retake-loop',
    introFrom:{x:.18,y:.50},damageAxis:'rewind',primitives:['Breach','Handoff','Glide','Split','Cast'],
  }),
  chapel:Object.freeze({
    battleId:'chapel',intensity:.78,activity:.82,intro:'descend',formation:'orbit-cross',
    introFrom:{x:.50,y:-.15},damageAxis:'constrict',primitives:['Breach','Dock','Orbit','Cinch','Split','Cast'],
  }),
  'source-final':Object.freeze({
    battleId:'source-final',intensity:1,activity:1,intro:'assemble',formation:'swarm-recombine',
    introFrom:{x:.50,y:.50},damageAxis:'unstable',primitives:['Handoff','Orbit','Cinch','Swarm','Split','Cast'],
  }),
});

const ENDING_PROFILES=Object.freeze({
  sacrifice:{primitive:'Cinch',resolution:'containment'},
  helped:{primitive:'Cinch',resolution:'containment'},
  inversion:{primitive:'Bloom',resolution:'ordinary-exterior'},
  drugged:{primitive:'Dock',resolution:'van-inert'},
  surfaced:{primitive:'Handoff',resolution:'two-names-returned'},
  'contact-won':{primitive:'Cinch',resolution:'failing-body-recorder'},
  'contact-lost':{primitive:'Handoff',resolution:'distant-dot'},
  'tower-won':{primitive:'Bloom',resolution:'exterior-doors'},
  'tower-lost':{primitive:'Swarm',resolution:'completed-peal'},
});

const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,Number(value)||0));
const safe=(task)=>Promise.resolve().then(task).catch(()=>null);
const stableId=(value='')=>String(value||'').replace(/[^a-z0-9:_-]/giu,'-').slice(0,96);
const wait=(ms)=>new Promise((resolve)=>setTimeout(resolve,ms));

export function battleChoreographyProfile(battleId=''){
  return BATTLE_PROFILES[String(battleId||'')]||null;
}

export function endingChoreographyProfile(endingId=''){
  const profile=ENDING_PROFILES[String(endingId||'')];
  return profile?Object.freeze({endingId:String(endingId),...profile}):null;
}

// The FOH threshold is the firewall. Progress, elapsed time and emergency-red
// metadata are deliberately ignored until the Source runtime says the body is
// physically in the approach. This keeps the page, both HUSH planes, Scene Dock
// and the real FOH door out of the compositor's state machine.
export function sourceLeakStage(frame={}){
  if(!frame?.approach)return Object.freeze({id:'sealed',active:false,progress:0,red:0});
  const elapsed=Math.max(0,Number(frame.elapsedSeconds)||0);
  const progress=clamp(frame.progress);
  const red=clamp(frame.redProgress);
  if(elapsed<10)return Object.freeze({id:'white',active:true,progress,red:0});
  if(progress<2/3)return Object.freeze({id:'red',active:true,progress,red});
  if(progress<.92)return Object.freeze({id:'swarm',active:true,progress,red});
  return Object.freeze({id:'proper',active:true,progress,red});
}

export function validateWindowChoreographyPlan(plan={}){
  const errors=[];
  if(plan.schema!==1)errors.push('schema');
  if(!stableId(plan.cueId))errors.push('cueId');
  if(!stableId(plan.sceneId))errors.push('sceneId');
  if(!Array.isArray(plan.primitives)||!plan.primitives.length)errors.push('primitives');
  else for(const primitive of plan.primitives)if(!WINDOW_CHOREOGRAPHY_PRIMITIVES.includes(primitive))errors.push(`primitive:${primitive}`);
  if(!Array.isArray(plan.mainFrame))errors.push('mainFrame');
  if(!Array.isArray(plan.surfaces)||plan.surfaces.length>4)errors.push('surfaces');
  for(const surface of plan.surfaces||[]){
    if(!stableId(surface.id))errors.push('surface.id');
    if(!Number.isFinite(Number(surface.x))||!Number.isFinite(Number(surface.y)))errors.push(`surface.position:${surface.id}`);
    if(!Number.isFinite(Number(surface.size))||Number(surface.size)<64||Number(surface.size)>320)errors.push(`surface.size:${surface.id}`);
  }
  return Object.freeze({ok:errors.length===0,errors:Object.freeze(errors)});
}

export function compileWindowChoreographyPlan({
  cueId,sceneId,primitives=['Frame'],mainFrame=[],surfaces=[],content='game-authored',
  focus='main',input='none',easing='out-cubic',interruptible=true,reducedMotion=false,
  fallback='simulate',restore='transaction',scope='battle',narrativeBlocking=false,nonblocking=true,
}={}){
  const plan=Object.freeze({
    schema:1,cueId:stableId(cueId),sceneId:stableId(sceneId),
    primitives:Object.freeze([...new Set(primitives)]),
    mainFrame:Object.freeze(mainFrame.map((keyframe)=>Object.freeze({
      dx:Number(keyframe.dx)||0,dy:Number(keyframe.dy)||0,
      scaleX:clamp(keyframe.scaleX??1,.55,1.35),scaleY:clamp(keyframe.scaleY??1,.55,1.35),
      durationMs:Math.max(0,Math.min(2200,Number(keyframe.durationMs)||0)),
      easing:String(keyframe.easing||easing),dock:String(keyframe.dock||'center'),
    }))),
    surfaces:Object.freeze(surfaces.slice(0,4).map((surface,index)=>Object.freeze({
      id:stableId(surface.id||`${cueId}:${index}`),index,
      x:clamp(surface.x,.02,.98),y:clamp(surface.y,.02,.98),
      size:Math.max(64,Math.min(320,Math.round(Number(surface.size)||160))),
      mode:String(surface.mode||'fragment'),title:String(surface.title||'').slice(0,48),
      text:String(surface.text||'').slice(0,320),palette:String(surface.palette||'black'),
      interactive:!!surface.interactive,
    }))),
    content,focus,input,easing,interruptible:!!interruptible,reducedMotion:!!reducedMotion,
    fallback,restore,scope,narrativeBlocking:!!narrativeBlocking,nonblocking:!!nonblocking,
  });
  const validation=validateWindowChoreographyPlan(plan);
  if(!validation.ok)throw new Error(`invalid window choreography plan: ${validation.errors.join(', ')}`);
  return plan;
}

function battleIntroPlan(profile,{sequence=0,reducedMotion=false}={}){
  const offset=profile.battleId==='natatorium'?{dx:0,dy:-18}
    :profile.battleId==='hall'?{dx:42,dy:0}
      :profile.battleId==='practice'?{dx:-30,dy:0}
        :profile.battleId==='chapel'?{dx:0,dy:28}:{dx:18,dy:-12};
  const surfaces=Array.from({length:profile.battleId==='source-final'?3:1},(_,index)=>({
    id:`${profile.battleId}:invader:${sequence}:${index}`,
    x:clamp(profile.introFrom.x+(index-1)*.16,.08,.92),
    y:clamp(profile.introFrom.y+(index-1)*.12,.08,.92),size:176,
    mode:'boss',palette:profile.battleId==='natatorium'?'water':'black',
    text:profile.intro.toUpperCase(),interactive:false,
  }));
  return compileWindowChoreographyPlan({
    cueId:`${profile.battleId}:invade:${sequence}`,sceneId:`battle:${profile.battleId}`,
    primitives:profile.primitives,scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[{...offset,durationMs:320+profile.intensity*260,easing:'out-cubic'}],surfaces,
  });
}

function battleDamagePlan(profile,{grade='light',origin={x:.5,y:.5},sequence=0,reducedMotion=false}={}){
  const heavy=grade==='heavy'||grade==='phase';
  const phase=grade==='phase';
  const x=clamp(origin?.x),y=clamp(origin?.y);
  const dx=profile.damageAxis==='lateral'?(x<.5?24:-24):profile.damageAxis==='rewind'?-18:(x-.5)*-28;
  const dy=profile.damageAxis==='vertical'?(y<.5?16:-16):(y-.5)*-18;
  const scale=phase?.86:heavy?.92:1;
  return compileWindowChoreographyPlan({
    cueId:`${profile.battleId}:damage:${sequence}`,sceneId:`battle:${profile.battleId}`,
    primitives:phase?['Dock','Cinch']:heavy?['Cinch']:['Glide'],scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[
      {dx,dy,scaleX:scale,scaleY:scale,durationMs:heavy?260:110,easing:'out-cubic'},
      {dx:0,dy:0,scaleX:1,scaleY:1,durationMs:heavy?360:160,easing:'in-out-cubic'},
    ],surfaces:[],
  });
}

function defeatPlan(battleId,sequence=0,reducedMotion=false){
  const fragments=Array.from({length:4},(_,index)=>({
    id:`${battleId}:defeat:${sequence}:${index}`,x:.2+index*.2,y:.34+(index%2)*.24,size:150,
    mode:'shatter',palette:'black',text:'',interactive:false,
  }));
  return compileWindowChoreographyPlan({
    cueId:`${battleId}:defeat:${sequence}`,sceneId:`battle:${battleId}`,
    primitives:['Split','Glide','Recenter'],scope:'battle',reducedMotion,
    mainFrame:reducedMotion?[]:[{dx:0,dy:34,scaleX:.94,scaleY:.94,durationMs:360}],surfaces:fragments,
  });
}

function sourcePlan(stage,sequence=0,reducedMotion=false){
  const counts={white:1,red:2,swarm:4,proper:3};
  const count=counts[stage.id]||0;
  const surfaces=Array.from({length:count},(_,index)=>({
    id:`source:${stage.id}:${sequence}:${index}`,
    x:clamp(.16+(index*.23)+(stage.id==='swarm'?(index%2)*.06:0),.08,.92),
    y:clamp(.28+((index*37)%3)*.22,.12,.88),
    size:stage.id==='proper'&&index===0?190:128+(index%2)*24,
    mode:stage.id==='proper'&&index===0?'narrative':'fragment',
    palette:stage.red>0?'red':'white',
    text:stage.id==='proper'&&index===0?'ENTER THE RETURN PATH':'',
    interactive:stage.id==='proper'&&index===0,
  }));
  const motion=stage.id==='white'||reducedMotion?[]
    :stage.id==='red'?[{dx:6,dy:-3,scaleX:.99,scaleY:.99,durationMs:520}]
      :stage.id==='swarm'?[{dx:-18,dy:8,scaleX:.95,scaleY:.95,durationMs:620}]
        :[{dx:24,dy:-12,scaleX:.91,scaleY:.91,durationMs:680}];
  return compileWindowChoreographyPlan({
    cueId:`source:${stage.id}:${sequence}`,sceneId:'source:white-crossing',
    primitives:stage.id==='white'?['Split']:stage.id==='red'?['Split','Glide','Cinch']
      :stage.id==='swarm'?['Split','Swarm','Handoff','Glide']:['Split','Handoff','Cinch'],
    scope:'source',reducedMotion,mainFrame:motion,surfaces,
    input:stage.id==='proper'?'pointer-or-main':'none',focus:'main',nonblocking:true,
  });
}

function endingPlan(profile,sequence=0,reducedMotion=false){
  const persistent=profile.endingId==='surfaced'?2:profile.endingId==='contact-lost'?4:0;
  return compileWindowChoreographyPlan({
    cueId:`ending:${profile.endingId}:${sequence}`,sceneId:`ending:${profile.endingId}`,
    primitives:[profile.primitive],scope:'ending',reducedMotion,
    mainFrame:reducedMotion?[]:[{
      dx:profile.primitive==='Dock'?120:profile.primitive==='Handoff'?-36:0,dy:profile.primitive==='Dock'?80:0,
      scaleX:profile.primitive==='Cinch'?.72:profile.endingId==='contact-lost'?.65:profile.primitive==='Bloom'?1.08:1,
      scaleY:profile.primitive==='Cinch'?.72:profile.endingId==='contact-lost'?.65:profile.primitive==='Bloom'?1.08:1,
      durationMs:900,easing:'in-out-cubic',
    }],
    surfaces:Array.from({length:persistent},(_,index)=>({
      id:`ending:${profile.endingId}:${index}`,x:.28+index*.18,y:.54+(index%2)*.12,size:132,
      mode:'ending',palette:'black',text:profile.resolution.toUpperCase(),interactive:false,
    })),
  });
}

function createSimulation(documentApi){
  let root=null;
  const ensure=()=>{
    if(root||!documentApi?.createElement)return root;
    root=documentApi.createElement('div');
    root.className='window-choreography-sim';
    root.setAttribute('aria-hidden','true');
    (documentApi.querySelector?.('#wrap')||documentApi.body)?.append?.(root);
    return root;
  };
  const clear=()=>{if(root)root.replaceChildren();};
  function show(plan){
    const host=ensure();if(!host)return false;
    clear();host.dataset.cue=plan.cueId;host.classList.add('active');
    for(const surface of plan.surfaces){
      const pane=documentApi.createElement('div');
      pane.className=`window-choreography-sim-pane palette-${surface.palette}`;
      pane.style.left=`${surface.x*100}%`;pane.style.top=`${surface.y*100}%`;
      pane.style.width=`${surface.size}px`;pane.style.height=`${surface.size}px`;
      pane.textContent=surface.text||'';host.append(pane);
    }
    return true;
  }
  function hide(){if(root){root.classList.remove('active');clear();}}
  return{show,hide,active:()=>!!root?.classList?.contains('active')};
}

export function createWindowChoreographyDirector({
  effects=null,runtimeApi=null,documentApi=globalThis.document,
  getEnabled=()=>true,getDisplayMode=()=> 'windowed',getReducedMotion=()=>false,
  tokenFactory=()=>`window-session-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  waitFn=wait,onState=()=>{},
}={}){
  let api=runtimeApi;
  let transaction=null;
  let battle=null;
  let source={stage:'sealed',sequence:0};
  let ending=null;
  let sequence=0;
  let lastEscapeAt=-Infinity;
  const simulation=createSimulation(documentApi);

  const reduced=()=>!!getReducedMotion();
  const nativeDesired=()=>!!getEnabled()&&!reduced()&&isTauriRuntime();
  async function loadApi(){
    if(api)return api;
    if(!nativeDesired())return null;
    try{api=await import('@tauri-apps/api/core');}catch(_){api=null;}
    return api;
  }
  async function beginTransaction(sceneId){
    if(transaction)return transaction;
    const token=stableId(tokenFactory());
    const nativeApi=await loadApi();
    const restoreGameMode=getDisplayMode()==='game-mode';
    let native=false;
    if(nativeApi?.invoke){
      const result=await safe(()=>nativeApi.invoke('chunk_window_choreography_begin',{request:{token,sceneId,restoreGameMode}}));
      native=!!result;
    }
    transaction={token,sceneId,native,restoreGameMode,cancelled:false};
    onState({type:'begin',...transaction});
    return transaction;
  }

  async function runPlan(plan,{forceSimulate=false}={}){
    const active=await beginTransaction(plan.sceneId);
    const useNative=active.native&&!forceSimulate;
    let nativeMoved=false,nativePanes=false;
    if(useNative&&api?.invoke&&plan.mainFrame.length){
      nativeMoved=!!await safe(()=>api.invoke('chunk_window_choreography_execute',{request:{
        token:active.token,cueId:plan.cueId,keyframes:plan.mainFrame,interruptible:plan.interruptible,
      }}));
    }
    if(useNative&&plan.surfaces.length){
      nativePanes=!!await safe(()=>effects?.showPanes?.(plan.surfaces,{token:effects?.sessionToken?.(),cueId:plan.cueId}));
    }else if(!plan.surfaces.length){
      await safe(()=>effects?.hidePanes?.());
      nativePanes=true;
    }
    const simulated=forceSimulate||!useNative||(plan.surfaces.length&&!nativePanes)||(plan.mainFrame.length&&!nativeMoved);
    if(simulated)simulation.show(plan);else simulation.hide();
    onState({type:'plan',plan,native:useNative&&!simulated,simulated});
    return{plan,native:useNative&&!simulated,simulated};
  }

  async function restore(reason='restore',{closePool=false}={}){
    const active=transaction;
    transaction=null;battle=null;ending=null;source={stage:'sealed',sequence:0};
    simulation.hide();
    await safe(()=>effects?.hidePanes?.());
    if(active?.native&&api?.invoke)await safe(()=>api.invoke('chunk_window_choreography_restore',{token:active.token}));
    if(closePool)await safe(()=>effects?.emergencyRestore?.({notify:false}));
    onState({type:'restore',reason,token:active?.token||null});
    return true;
  }

  function prepareBattle({battleId='',encounterId='',reducedMotion=false}={}){
    const profile=battleChoreographyProfile(battleId);
    battle=profile?{battleId:profile.battleId,encounterId,profile,sequence:0,breached:false,reducedMotion:!!reducedMotion}:null;
    return battle;
  }

  async function fireballCast({battleId='',windowLock=false}={}){
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile)return null;
    if(!battle)battle={battleId:profile.battleId,encounterId:battleId,profile,sequence:0,breached:false,reducedMotion:reduced()};
    // The first actual cast is the first breach. Merely entering a fight only
    // prewarms surfaces and never changes the desktop.
    if(battle.breached)return null;
    battle.breached=true;
    return runPlan(battleIntroPlan(profile,{sequence:battle.sequence++,reducedMotion:reduced()||battle.reducedMotion||windowLock}));
  }

  async function damage({battleId='',received=0,phase=false,origin=null,windowLock=false}={}){
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile||windowLock)return null;
    const grade=phase?'phase':Number(received)>=8?'heavy':'light';
    return runPlan(battleDamagePlan(profile,{grade,origin,sequence:sequence++,reducedMotion:reduced()}));
  }

  async function result({battleId='',result='abort'}={}){
    if(result!=='lose')return null;
    const profile=battle?.profile||battleChoreographyProfile(battleId);
    if(!profile)return null;
    const resolved=await runPlan(defeatPlan(profile.battleId,sequence++,reduced()));
    await waitFn(reduced()?180:720);
    await safe(()=>effects?.hidePanes?.());simulation.hide();
    return resolved;
  }

  async function finishBattle({result='abort'}={}){
    // A battle breach is one transaction. It is restored once, after win/loss
    // presentation (including defeat reconstruction), on every exit path.
    return restore(`battle:${result}`);
  }

  async function sourceFrame(frame={}){
    const stage=sourceLeakStage(frame);
    if(stage.id==='sealed'){
      // A stale Source transaction may exist after a god-menu jump or reload,
      // but the real page/dock/door chain must never inherit it.
      if(source.stage!=='sealed')await restore('source-threshold-exit');
      source={stage:'sealed',sequence:0};
      return stage;
    }
    if(stage.id===source.stage)return stage;
    source.stage=stage.id;
    await runPlan(sourcePlan(stage,source.sequence++,reduced()));
    return stage;
  }

  async function beginEnding(endingId=''){
    const profile=endingChoreographyProfile(endingId);
    if(!profile)return null;
    ending=profile;
    return runPlan(endingPlan(profile,sequence++,reduced()));
  }

  async function credits(){return restore('credits',{closePool:false});}
  async function emergencyRestore(){return restore('emergency',{closePool:true});}
  function suspend(){void safe(()=>effects?.suspendSurfaces?.());return true;}

  const keyTarget=documentApi?.defaultView||globalThis.window;
  keyTarget?.addEventListener?.('keydown',(event)=>{
    if(event.key!=='Escape'||event.repeat)return;
    const now=Number(event.timeStamp)||Date.now();
    if(now-lastEscapeAt<=850){lastEscapeAt=-Infinity;void emergencyRestore();}
    else lastEscapeAt=now;
  },true);

  return{
    prepareBattle,fireballCast,damage,result,finishBattle,sourceFrame,beginEnding,credits,
    emergencyRestore,suspend,runPlan,
    active:()=>!!transaction,
    debug:()=>({transaction:transaction?{...transaction}:null,battle:battle?{battleId:battle.battleId,breached:battle.breached}:null,source:{...source},ending}),
  };
}

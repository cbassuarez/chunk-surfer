import { makePracticeFightScene } from './practice-fight.js';
import { sourceDesktopInputActive } from './source-desktop-focus.js';
import { desktopParryCueFor } from './desktop-parry-cues.js';
import { makeBattlePreparation } from './battle-preparation.js';
import { preparationBattleTools } from './combat-operating-facts.js';
import { drawEncounterSplash } from '../render/encounter-view.js';
import { createHushBattleBody, fieldSignalCage } from '../render/hush-battle-body.js';
import { SOURCE_DESKTOP_BREACH_SECONDS, sourceDesktopFailureBeat } from './source-desktop-state.js';
import { paintSourceDesktopDiagnostic, sourceDesktopDiagnosticLayout } from '../render/source-desktop-view.js';
import { combatCheckpointSnapshot, restoreCombatCheckpoint } from './combat-checkpoint.js';
import { combatHandsSnapshot } from './combat-hands-state.js';
import { getMeta, getSave } from './save.js';
import { resolveFieldKit } from './field-kit.js';
// Player-paced signal combat: deterministic rules, ordinary actions staged over
// a readable 1.2-second beat and reactive strikes over a four-beat phrase — the opponent
// floats top-centre, the recordist's hands rise from the bottom foreground,
// and the command band underneath spells out what every move actually does.

import * as scenes from './scenes.js';
import { uiCellMetrics, uiSize, uiFill, uiText, uiStrokeRect, uiLine, uiDraw } from '../render/ui.js';
import { drawLocationIndicator, drawMachinePanel, drawVfdCounter, drawVfdText, machinePanelBody } from '../render/presentation.js';
import { UI_COLOR } from '../render/palette.js';
import { createSamDialogVoice, isVoiced } from '../audio/sam-voice.js';
import { TYPE_GAIN, TYPE_LEVEL } from '../audio/story-audio.js';
import { flashMode, shakeMode, textCps } from './access.js';
import { practiceInstrument } from './practice-room.js';
import { createPracticeClick, practiceTempo } from '../audio/practice-click.js';
import { activeInputPromptDevice, promptLine } from './bindings.js';
import {
  combatInjuryStage,
  drawBattleWipe,
  drawCombatActionTile,
  drawCombatGauge,
  drawCombatToolTile,
  drawCombatControlTabs,
  drawEnemyVoidStage,
  drawFirstPersonHands,
  drawHallApparitions,
  drawAttackNotes,
  drawFireballEngulf,
  drawOpponentCombatArt,
  drawSignalBeing,
  drawFireballCast,
  drawSubmergedBattleField,
  drawStanceTriangle,
  submergedBattleFrame,
  drawTurnGlyph,
} from '../render/combat-view.js';
import { combatHudLayout } from '../render/combat-hud-layout.js';
import {combatReadoutState,drawCombatReadouts} from '../render/combat-readouts.js';
import {drawHallRoster} from '../render/hall-roster.js';
import {combatStageOverlayLayout,fitBattleStageThoughts} from '../render/combat-stage-overlays.js';
import {
  COMBAT_ACTION,
  COMBAT_TOOL,
  PARRY_TIER,
  PARRY_TIERS,
  SOURCE_CHANNEL,
  availableCombatActions,
  availableCombatTools,
  combatIntentLookahead,
  combatMoveSubtext,
  combatApparitions,
  combatApparitionsSnapshot,
  combatPractice,
  combatMovesForTool,
  combatPrediction,
  combatResult,
  counterMovesForIntent,
  createCombatState,
  currentCombatIntent,
  predictedCombatIntent,
  reduceCombat,
  rivalCombatIntent,
  advanceEnemy,
  applyFireballImpact,
  applyFireballReturn,
  selectEnemyIntents,
  combatContinuationSnapshot,
  sourceDesktopFrame,
} from './combat-state.js';
import { readFidelity, thoughtTrace } from './thought-trace.js';
import { GRID, HIT_QUALITY, QUALITY_PRESENTATION } from './combat-damage.js';

import { visibleList } from './conversation.js';
import { TECHNIQUE_DEFS } from './combat-progression.js';
import {
  COMBAT_DIALOGUE_MIN_MANUAL_DWELL,
  battleDialoguePageView,
  battleLineAutoHoldSeconds,
  hardWrapBattleText,
  shouldAutoAdvanceBattleLine,
} from './combat-dialogue-model.js';
import { enemyAttackCue, enemyAttackShape, enemyAttackVoice, surferAggression } from '../audio/piano-weapon.js';
import { performanceIntrusionStage, reducePerformanceIntrusion } from './performance-intrusion.js';
import {
  PARRY_CONTACT_HOLD_SECONDS,
  PARRY_REACTION_SECONDS,
  isParryableEnemyAction,
  parryInputDecision,
  parryOpportunitySnapshot,
} from './combat-parry.js';
import { createBattleSubmersionController } from './battle-submersion.js';
import { createBattleWaterAudio } from '../audio/battle-water.js';
import { createFireballExchange, FIREBALL_RETURN_DAMAGE } from './fireball-exchange.js';
import { createFireballVoice } from '../audio/fireball-voice.js';
import { pressControl, releaseControl, cancelControlScope } from './control-feedback.js';
import { reviewKey, reviewText, registerReviewRegion } from './local-text-review.js';

// Five to eight seconds, cycling, so the clock is a rhythm rather than a number
// the player learns to count against.
const TURN_LIMIT_SECONDS = Object.freeze([7, 5, 8, 6, 7, 5, 6, 8]);

export function combatChoiceSeconds(state, turn = state?.turns || 0) {
  if (state?.definition?.kind === 'cathedral' && state.definition.untimedGuided
    && state.difficulty?.guidance === 'full') return null;
  return TURN_LIMIT_SECONDS[Math.abs(Math.floor(Number(turn) || 0)) % TURN_LIMIT_SECONDS.length];
}

export function cathedralCombatLayout({ cols = 80, rows = 40 } = {}) {
  const w=Math.max(36,cols-8),x=Math.floor((cols-w)/2);
  const panel=machinePanelBody(x-2,1,w+4,rows-2,{footer:'CONTROLS'});
  const layout=combatHudLayout({panel,mode:'command'});
  return {...panel,world:layout.stage,controls:layout.deck};
}

// Which techniques are fired as moves in the fight (vs passives that change the
// rules). Derived from the authored descriptor so new actives need no code here.
const ACTIVE_TECHNIQUE_IDS = new Set(TECHNIQUE_DEFS.filter((t) => t.active).map((t) => t.id));

export const ORDINARY_TURN_SECONDS = 1.2;

export function combatEnemyAttackAudioShape(shape = {}, presentation = null, submersion = null) {
  if (presentation?.mode !== 'submerged' || !submersion?.enabled || submersion.wetMix <= .001) return { ...shape };
  return { ...shape, lowpassHz: Math.max(120, Number(submersion.lowpassHz) || 720) };
}
// ── the parry window ────────────────────────────────────────────────────────
// The blow lands at IMPACT. From WINDOW_LO up to it you may guard; before that
// you are bracing at air.
//
// Two things were wrong with this and both were about the player never finding
// it. It was BINARY — land the window and you turned the blow entirely, miss it
// by a frame and you got NOTHING TO TURN — which teaches people not to reach for
// it at all. And its only announcement anywhere in the fight was one line of
// footer chrome, in the same slot that otherwise reads RESOLVING · [ENTER]
// FAST-FORWARD, so most players never learned the mechanic existed.
//
// It is graded now (see PARRY_TIERS in combat-state.js), and it takes over the
// command band while a real struck blow is incoming. See parryWindow() and the
// reaction branch of render().
const UTILITY_TURN_SECONDS = .82;
const CPS = 40;
const CHANNELS = Object.freeze([
  { id: SOURCE_CHANNEL.RESCUE, label: 'RETURN / RESCUE', glyph: '↩' },
  { id: SOURCE_CHANNEL.CONTAIN, label: 'ISOLATE / CONTAIN', glyph: '▣' },
  { id: SOURCE_CHANNEL.SUBMIT, label: 'OPEN / SUBMIT', glyph: '◇' },
]);
const originalTextOf = (line) => String(line?.text ?? line ?? '');
const textOf = (line) => line?.reviewFieldKeys?.text
  ? reviewText(line.reviewFieldKeys.text, originalTextOf(line)) : originalTextOf(line);
const leadOf = (line) => {
  const original = String(line?.lead || '');
  return (line?.reviewFieldKeys?.lead ? reviewText(line.reviewFieldKeys.lead, original) : original).trim();
};
const whoOf = (line) => line?.who || 'direction';
const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));
const lerp = (a, b, t) => Number(a || 0) + (Number(b || 0) - Number(a || 0)) * t;
const ease = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);

// Index the authored list before conditions hide any entries. Review copies
// carry presentation metadata; the battle document and its mechanics stay intact.
export function battleTextReviewLines(lines = [], { sceneId, nodeId } = {}) {
  return (Array.isArray(lines) ? lines : []).map((line, index) => {
    const original = line && typeof line === 'object' ? line : { text: originalTextOf(line) };
    const sourceId = original.sourceId || original.id || '';
    const context = { sceneId, nodeId, sourceId, index, collection: 'battle-lines' };
    const id = reviewKey({ ...context, field: 'target' });
    const reviewFieldKeys = { text: reviewKey({ ...context, field: 'text' }) };
    const fields = [{ key: reviewFieldKeys.text, label: original.who === 'me' ? 'Spoken utterance' : 'Battle dialogue', original: originalTextOf(original) }];
    if (original.lead != null) {
      reviewFieldKeys.lead = reviewKey({ ...context, field: 'lead' });
      fields.push({ key: reviewFieldKeys.lead, label: 'Lead-in', original: String(original.lead) });
    }
    return { ...original, reviewFieldKeys,
      reviewTarget: { id, sceneId, nodeId, sourceId, speaker: whoOf(original), fields } };
  });
}

export function battleThoughtReviewLine(line, { sceneId, nodeId } = {}) {
  const original = originalTextOf(line);
  // A computed trace can replace a row on the next beat. Its original text,
  // rather than its position in that transient list, identifies the variant.
  const context = { sceneId, nodeId, collection: `battle-thoughts:${line?.tone || 'thought'}` };
  const key = reviewKey({ ...context, field: 'text' }, original);
  return { ...line, reviewFieldKeys: { text: key }, reviewTarget: {
    id: reviewKey({ ...context, field: 'target' }, original), sceneId, nodeId,
    sourceId: '', speaker: 'you', fields: [{ key, label: 'Internal thought', original }],
  } };
}

function registerBattleReviewRow(line, displayed, x, y, width) {
  const shown = String(displayed || '').slice(0, Math.max(0, Math.floor(width)));
  if (line?.reviewTarget && shown.length) registerReviewRegion(line.reviewTarget, { x, y, w: shown.length, h: 1 });
}

export function combatDeckDirection(event = {}) {
  const action = String(event.controllerAction || '');
  if (action === 'move_left') return 'left';
  if (action === 'move_right') return 'right';
  if (action === 'move_up') return 'up';
  if (action === 'move_down') return 'down';
  const key = String(event.key || '').toLowerCase();
  if (key === 'arrowleft' || key === 'a') return 'left';
  if (key === 'arrowright' || key === 'd') return 'right';
  if (key === 'arrowup' || key === 'w') return 'up';
  if (key === 'arrowdown' || key === 's') return 'down';
  return null;
}

export function combatDeckNavigation({
  phase = 'tool', selectedTool = 0, selectedMove = 0, toolCount = 0, moveCount = 0,
} = {}, direction = null) {
  const next = { phase, selectedTool, selectedMove };
  if (direction === 'left' || direction === 'right') {
    const delta = direction === 'left' ? -1 : 1;
    const count = phase === 'move' ? moveCount : toolCount;
    if (count <= 0) return next;
    if (phase === 'move') next.selectedMove = (selectedMove + delta + count) % count;
    else {
      next.selectedTool = (selectedTool + delta + count) % count;
      next.selectedMove = 0;
    }
    return next;
  }
  if (direction === 'down' && phase === 'tool' && moveCount > 0) next.phase = 'move';
  else if (direction === 'up' && phase === 'move') next.phase = 'tool';
  return next;
}

function opponentArt(ref, combatId = '') {
  const id = typeof ref === 'string' ? ref : String(ref?.id || '');
  // Encounters without authored raster art get the procedural signal-being
  // instead of borrowing another opponent's portrait.
  return ['surfer', 'guard'].includes(id) ? ref : { procedural: true, id: String(combatId || 'signal') };
}

// How it went, in the words a recordist would use. This is the "IT WAS SUPER
// EFFECTIVE" slot: the player has to be able to tell, without reading a number,
// whether what they did worked — and if it did not, what the blow did instead.
export function strikeVerdict(last = {}, { parried = false } = {}) {
  if (parried || last.parried) return { text: 'TURNED BACK ON IT', role: 'ui-counter' };
  if (last.perfect) return { text: last.received > 0 ? 'COUNTERED · SOME GETS THROUGH' : 'COUNTERED · NOTHING GETS THROUGH', role: 'ui-counter' };
  if (last.snrTo === 'noise' && last.received) return { text: 'IT LANDS HARD · YOU ARE IN NOISE', role: 'ui-danger' };
  if (last.received > 1) return { text: 'IT LANDS HARD', role: 'ui-danger' };
  if (last.received) return { text: 'IT CONNECTS', role: 'ui-primary' };
  return { text: 'IT GLANCES OFF', role: 'ui-secondary' };
}

function turnDuration(actionId) {
  return [COMBAT_ACTION.TUNE, COMBAT_ACTION.END_TEMPO].includes(actionId)
    ? UTILITY_TURN_SECONDS
    : ORDINARY_TURN_SECONDS;
}

function playBridgeArc(pair) {
  const { ctx, destination } = pair || {};
  if (!ctx || !destination || ctx.state !== 'running') return;
  const seconds = .085;
  const buffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * seconds), ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let seed = 4417;
  for (let i = 0; i < data.length; i++) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const t = i / ctx.sampleRate;
    const envelope = Math.min(1, t / .0018) * Math.exp(-t * 72) * (1 - i / data.length);
    data[i] = ((seed / 4294967296 - .5) * .12 + Math.sin(2 * Math.PI * 210 * t) * .045) * envelope;
  }
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  source.connect(destination);
  source.onended = () => source.disconnect();
  source.start();
}

export function makeCombatScene({
  battle,
  playSound,
  fx,
  audio,
  getAudio,
  difficulty = null,
  // Keyed per run so the fight is deterministic within a night and different
  // between them. See the note at the call site in main.js.
  seed = 0,
  loadout = {},
  encounterIntro = false,
  preparation = null,
  getPreparedLoadout = null,
  resources = {},
  source = null,
  // Knowledge of what this player has already read, so a second run of a fight
  // is not the same thirty-seven presses as the first. Combat never had one;
  // conversation.js has had the acceleration since it shipped.
  replay = null,
  // What the opponent already knows about how this recordist plays, from
  // earlier in the night. Null for the bench drill, which remembers nothing.
  carriedRead = null,
  continuation = null,
  checkpoint = null,
  startingMovementIndex = 0,
  musicSession = null,
  // Source may replace a movement entrance with a playable piece of the night.
  // The hook receives a frozen combat checkpoint and an explicit resume verb;
  // returning true holds this scene in `interlude` until that verb is called.
  onMovementInterlude = null,
  onMovementCompleted = null,
  sourceDesktop = null,
  chapelDesktop = null,
  desktopParryCue = desktopParryCueFor(battle?.combat?.id),
  desktopParryCues = desktopParryCue ? [desktopParryCue] : [],
  hushBody = createHushBattleBody(battle),
  onCheckpoint = null,
  skipOpening = false,
  director = null,
  interference = null,
  practiceClues = null,
  environmentLighting = null,
  initialPerformanceIntrusion = 0,
  onPerformanceStage = () => {},
  onWin = () => {},
  onLose = () => {},
  onAbort = () => {},
  // The in-canvas half of the death composition. Returns a promise that settles
  // when the screen is done; main.js owns the snapshot and the scene, because
  // this module cannot see the renderer that took the picture.
  onDefeatScreen = null,
} = {}) {
  if (battle?.combat?.practice) return makePracticeFightScene({
    battle,seed,difficulty,loadout,resources,getAudio,audio,practiceClues,onWin,onLose,onAbort,encounterIntro,hushBody,
  });
  if (!battle?.combat) throw new Error(`missing signal combat definition: ${battle?.id || 'unknown'}`);
  const voice = createSamDialogVoice({ volume: 0.26, getAudio });
  voice.warm?.();
  const submersionController = createBattleSubmersionController({ presentation:battle.combat.presentation });
  let submersionSnapshot = submersionController.snapshot();
  const waterAudio = createBattleWaterAudio({ enabled:submersionSnapshot.enabled, getAudio });
  let state = createCombatState(battle.combat, {
    difficulty,
    seed,
    injuries: loadout.injuries,
    composure: loadout.composure ?? null,
    battery: resources.battery ?? loadout.battery,
    torchDrainScale: loadout.torchDrainScale,
    tools: loadout.tools,
    techniques: loadout.techniques,
    carriedRead,
    continuation,
    startingMovementIndex,
    source,
  });
  const restored = restoreCombatCheckpoint(battle.combat, checkpoint);
  if (restored) state = restored.state;
  const cathedral = battle.combat.kind === 'cathedral';
  const notifiedMovements = new Set(restored?.scene?.notifiedMovements || []);
  let phase = 'arrival';
  let queue = [];
  let cur = null;
  let currentReviewText = '', currentReviewLead = '', currentBarkReviewText = '';
  const reviewNodeForList = new Map([[battle.intro, 'intro'], [battle.win, 'win'], [battle.lose, 'lose']]);
  battle.combat.movements.forEach((entry, index) => {
    for (const channel of ['before', 'after', 'onListen']) {
      if (Array.isArray(entry[channel])) reviewNodeForList.set(entry[channel], `movement:${entry.id || index}:${channel}`);
    }
  });
  let typed = 0;
  let acc = 0;
  let held = 0;
  let lineDoneAt = null;
  let talkPage = 0;
  let confirmAdvanceLocked = false;
  let confirmLockedAt = -Infinity;
  let now = 0;
  let arrivalElapsed = 0;
  let handle = null;
  let onTalkEnd = () => {};
  let selectedTool = 0;
  let selectedMove = 0;
  let notice = '';
  // The state the moment the player committed — one whole turn may resolve over
  // two beats (player, then enemy), and the director/music must see the turn as
  // one span from here to the settled end.
  let turnStart = null;
  let presentedTutorialStep = null;
  let takeConfirmation = false;
  let resolution = null;
  let desktopElapsed = 0;
  let desktopReady = false;
  let desktopResume = null;
  let desktopStarted = false;
  let desktopCompleting = false, desktopInputReady = false;
  let checkpointElapsed = 0;

  function desktopFrame() {
    const frame = sourceDesktopFrame(state);
    if (!frame) return null;
    const intent = resolution?.side === 'enemy' ? resolution.intent : predictedCombatIntent(state);
    const reaction = parryWindow();
    const topScene = scenes.top({includeOverlay:true});
    return { ...frame, active:true, clock:now,
      commandMinHeight:uiCellMetrics().cellH * 24, commandMinWidth:Math.max(960,uiCellMetrics().cellW * 114),
      paused:(!!topScene && topScene !== scene) || (typeof document !== 'undefined' &&
        (document.hidden || (!chapelOffer && sourceDesktop?.mode?.()==='native' && !sourceDesktopInputActive(sourceDesktop)))),
      phase:phase === 'desktop-breach' ? 'dissolving' : frame.breached || desktopStarted ? 'desktop' : 'contained',
      transition:phase === 'desktop-breach' ? Math.min(1,desktopElapsed / SOURCE_DESKTOP_BREACH_SECONDS) : frame.breached ? 1 : 0,
      breach:phase === 'desktop-breach' ? {elapsed:desktopElapsed} : null,
      intent:{kind:intent?.kind || 'broadcast',progress:resolution ? Math.min(1,resolution.elapsed / resolution.duration) : 0},
      reaction:reaction ? {...reaction,progress:resolution ? Math.min(1,resolution.elapsed / resolution.duration) : 0} : null,
      toolId:resolution?.action?.tool || activeTool()?.id || '', actionId:resolution?.action?.id || '',
      reducedMotion:shakeMode() !== 'full', reduceFlash:flashMode() !== 'full',
    };
  }

  function persistCheckpoint() {
    checkpointElapsed = 0;
    if (cathedral) {
      const saved = cathedralCheckpoint();
      if (saved) onCheckpoint?.(saved);
    } else if (state.sourceDesktop) onCheckpoint?.({movementIndex:state.movementIndex,continuation:combatCheckpoint()});
  }

  function cathedralCheckpoint() {
    return combatCheckpointSnapshot(state, { phase, selectedTool, selectedMove, notice,
      resolution, turnStart, turnClock, takeConfirmation, now, turnCount, enemyBeatSeq,
      strike, readMissed, notifiedMovements: [...notifiedMovements], preparationDone });
  }

  function notifyCompletedMovements() {
    if (!cathedral) return;
    for (const id of state.completedMovements || []) {
      if (notifiedMovements.has(id)) continue;
      notifiedMovements.add(id);
      onMovementCompleted?.({ id, index: battle.combat.movements.findIndex((entry) => entry.id === id),
        cathedralPhase: battle.combat.cathedralPhase, checkpoint: cathedralCheckpoint() });
    }
  }

  function resumeDecision() {
    if (state.phase === 'enemy' && state.pendingEnemy) beginEnemyBeat();
    else beginToolSelection();
  }

  function beginDesktopBreach({restoring=false,fallbackMovementIndex=state.movementIndex,resume=null} = {}) {
    if (!sourceDesktop || phase === 'desktop-breach') return false;
    desktopStarted = true;
    phase = 'desktop-breach';
    desktopElapsed = restoring || shakeMode() !== 'full' ? SOURCE_DESKTOP_BREACH_SECONDS : 0;
    desktopReady = false;
    desktopCompleting=false;desktopInputReady=false;
    disarmTurnClock(); clearBark(); resetDeckControls();
    fireballExchange.cancel('source-desktop-breach');
    // The impact has become the peel. Frozen hit overlays must not return on
    // top of the command island when the held simulation resumes.
    fireballEngulf=null;impactFx=null;hitstop=0;popups=[];
    barGhost.composure=null;barGhost.coherence=null;
    state.last = {...state.last,desktopBreach:null};
    persistCheckpoint();
    notice = restoring ? 'SOURCE IS STILL OUTSIDE' : resume ? 'THE SHELL CANNOT HOLD THE CONTACT' : 'SHELTER LOST · THE FIGHT CONTINUES';
    desktopResume = () => {
      phase = 'tool';
      if (resume) resume();
      else if (!handleStateEndpoint(fallbackMovementIndex)) resumeDecision();
    };
    Promise.resolve(sourceDesktop.begin?.(desktopFrame())).catch(() => null).finally(() => {
      if (sceneEntered) desktopReady = true;
    });
    return true;
  }

  // The parry window for the beat currently resolving, or null when there is
  // nothing to parry. One function so the meter, the tile, the footer and the
  // key handler can never disagree about when the window is open or which grade
  // a press would earn.
  //
  // `parryWindowScale` (see COMBAT_RULES) widens the window by opening it
  // earlier. Seconds, grades, input grace, and the visible track all come from
  // one pure snapshot so there is no second, almost-matching UI definition.
  function parryWindow() {
    if (phase !== 'resolve' || !resolution) return null;
    if (director?.allowsParry?.() === false) return null;
    return parryOpportunitySnapshot({
      side: resolution.side,
      actionKind: resolution.action?.kind,
      elapsed: resolution.elapsed,
      duration: resolution.duration,
      windowScale: state.difficulty?.parryWindowScale,
      attempted: resolution.parryTried,
      buffered: resolution.parryBuffered,
      parried: resolution.parried,
      whiffed: resolution.parryWhiffed,
      tier: resolution.parryTier,
      impactFired: resolution.impactFired,
    });
  }

  function commitParry(tier = PARRY_TIER.LATE, surface = 'game') {
    if (!resolution || resolution.parryTried) return false;
    resolution.parryBuffered = false;
    resolution.parryTried = true;
    state = reduceCombat(state, { type: COMBAT_ACTION.PARRY, tier });
    resolution.after = state;
    resolution.parried = !!state.last?.parried;
    resolution.parryTier = state.last?.parryTier || tier;
    if (resolution.parried) {
      if (parryCues.get(resolution.intent?.id)?.ringing && !state.last.received) {
        state.ringing = resolution.before.ringing;
      }
      const weight = tier === PARRY_TIER.PERFECT ? .44
        : tier === PARRY_TIER.GOOD ? .30 : .18;
      fx?.flash?.(70, `rgba(120,220,255,${weight})`);
      audio?.menuMove?.();
    }
    if (chapelOffer) closeChapelOffer(chapelOffer.phase === 'live' && resolution.parried ? 'hit' : 'cancel', surface);
    persistCheckpoint();
    return true;
  }

  const parryCues = new Map(desktopParryCues.map(cue => [cue.attackId, cue]));
  const playedDesktopCues = new Set();
  let chapelOffer = null;
  let chapelLast = null;
  let chapelPrepared = false;
  let preparingDesktop = false;

  function prepareChapelDesktop() {
    if (!parryCues.size || chapelPrepared || preparingDesktop || !chapelDesktop?.isAvailable()) return;
    preparingDesktop = true;
    const cue = [...parryCues.values()].find(entry => entry.movementId === movement()?.id) || parryCues.values().next().value;
    void chapelDesktop.prepare(cue.theme).then(prepared => { chapelPrepared = prepared; }).finally(() => { preparingDesktop = false; });
  }

  function closeChapelOffer(outcome = 'cancel', surface = null) {
    const offer = chapelOffer;
    if (!offer) return;
    const { attackId, theme } = offer.cue;
    chapelLast = { attackId, outcome, surface };
    chapelOffer = null;
    void chapelDesktop.end(outcome);
    if (outcome === 'hit') resources.playDesktopParry?.({ theme, attackId, stage: outcome });
    if (outcome === 'miss' && resolution === offer.beat) resolution.desktopMissCue = offer.cue;
  }

  function offerChapelParry() {
    const cue = parryCues.get(resolution.intent?.id);
    if (!cue || playedDesktopCues.has(cue.attackId) || !chapelPrepared || !chapelDesktop.isAvailable()
      || !state.last?.enemyHits?.some(hit => hit.intentId === cue.attackId)
      || (state.result && !state.last?.sourceEnemyReaction?.lost)) return;
    // A projectile that has already launched owns its own answer. Reserve the
    // shared space only between casts, with the in-window guard always live.
    if (fireballExchange.snapshot().active) return;
    const reaction = parryWindow();
    if (!reaction) return;
    const offer = { cue, phase: 'opening', age: 0, response: 0, beat: resolution, start: reaction.openSeconds };
    chapelOffer = offer;
    void chapelDesktop.begin({
      attackId: cue.attackId,
      theme: cue.theme,
      responseSeconds: cue.responseSeconds,
      reducedMotion: shakeMode() !== 'full',
      reduceFlash: flashMode() !== 'full',
      onHit: () => {
        if (chapelOffer !== offer || offer.phase !== 'live' || resolution !== offer.beat) return;
        if (parryWindow()?.armed) commitParry(PARRY_TIER.GOOD, 'desktop');
      },
      onCancel: () => { if (chapelOffer === offer) closeChapelOffer(); },
    }).then(painted => {
      if (chapelOffer !== offer) return;
      if (!painted || resolution !== offer.beat || !chapelDesktop.isAvailable()) {
        closeChapelOffer();
        return;
      }
      offer.phase = 'live';
      playedDesktopCues.add(cue.attackId);
      resolution.elapsed = Math.max(resolution.elapsed, offer.start);
      resources.playDesktopParry?.({ theme: cue.theme, attackId: cue.attackId, stage: 'open' });
    });
  }

  function advanceChapelParry(dt) {
    const offer = chapelOffer;
    if (!offer) return dt;
    if (resolution !== offer.beat || !chapelDesktop.isAvailable()) {
      closeChapelOffer();
      return dt;
    }
    if (offer.phase === 'opening') {
      offer.age += dt;
      if (offer.age >= .65) {
        closeChapelOffer();
        return dt;
      }
      return Math.min(dt, Math.max(0, offer.start - resolution.elapsed));
    }
    offer.response += dt;
    const reaction = parryWindow();
    if (!reaction) {
      closeChapelOffer();
      return dt;
    }
    const approach = reaction.widthSeconds * .97;
    if (offer.response >= offer.cue.responseSeconds) {
      closeChapelOffer('miss');
      return dt;
    }
    // The desktop attack stretches the ordinary guard's approach. Its timing
    // grade and the in-window input stay live while the player reaches for it.
    return dt * approach / offer.cue.responseSeconds;
  }

  function attemptParry(event = {}) {
    // The painted desktop offer and the main controls share one last input
    // frame. Once the offer has missed, its returning strike is committed.
    if (resolution?.desktopMissCue) return true;
    const opportunity = parryWindow();
    if (!opportunity || resolution?.impactFired) return false;
    const keyboardPress = event.key === ' ' || event.key === 'Enter' || event.key === 'z';
    const decision = parryInputDecision(opportunity, {
      repeat: event.repeat,
      held: keyboardPress && confirmHeld,
    });
    if (decision === 'ignore') return true;
    if (keyboardPress) confirmHeld = true;
    if (decision === 'buffer') {
      resolution.parryBuffered = true;
      resolution.parryEarly = false;
      notice = 'CONTACT ARMED';
      audio?.menuMove?.();
      return true;
    }
    if (decision === 'parry') {
      commitParry(opportunity.tier);
      return true;
    }
    if (decision === 'miss') {
      resolution.parryTried = true;
      resolution.parryWhiffed = true;
      notice = 'MISSED CONTACT';
      return true;
    }
    resolution.parryEarly = true;
    notice = 'WAIT FOR CONTACT';
    return true;
  }
  // Rotates the adversary's piano voice within a movement's stem set, so
  // successive enemy beats don't repeat the same note.
  let enemyBeatSeq = 0;
  // What the surfer is hitting you with THIS beat, said out loud on the stage:
  // who, the blow, the instrument, and then whether it worked. Every enemy attack
  // is announced — the fight used to show numbers after the fact and expect the
  // player to work backwards from them to a move they never saw named.
  let strike = null;
  // Whether the recordist's last read missed. Set when a blow arrives that the
  // thought did not name, cleared once the next thought has owned up to it, so
  // the correction is said exactly once and by the person who was wrong.
  let readMissed = false;
  const integer = (value, fallback = 0) => (Number.isFinite(Number(value)) ? Math.floor(Number(value)) : fallback);
  // The exchange the fight is on, shown by the turn glyph. One per player+enemy
  // beat pair; incremented as each turn settles into the next.
  let turnCount = 1;
  let resultDelivered = false;
  let outcomeDispatched = false;
  let terminalAbortDelivered = false;
  let sceneEntered = false;
  let openingStarted = false;
  let musicBootResolved = !musicSession;
  // The wing's metronome, the clock in that room, and the tempo the six out on
  // the floor settle onto — see practice-click.js and practice-metronomes.js.
  let practiceClick = null;
  let musicFinished = false;
  let tabRows = [];
  let toolRows = [];
  let moveRows = [];
  // Inputs remember the cap they started on. Releasing over another tile, or
  // after the reducer has advanced the turn, must release the original switch.
  const heldControls = new Map();
  const controlInput = (e = {}) => e.type?.startsWith('pointer') || e.type === 'lostpointercapture'
    ? `pointer:${e.pointerId ?? 'primary'}`
    : e.controllerAction ? `controller:${e.controllerAction}` : `key:${e.code || e.key || ''}`;
  function pressDeckControl(id, e) {
    const input = controlInput(e);
    if (heldControls.get(input) === id) return;
    releaseDeckControl(e);
    heldControls.set(input, id);
    pressControl(id);
  }
  function releaseDeckControl(e) {
    const input = controlInput(e), id = heldControls.get(input);
    heldControls.delete(input);
    if (id && ![...heldControls.values()].includes(id)) releaseControl(id);
  }
  function resetDeckControls() {
    heldControls.clear();
    cancelControlScope('combat:');
  }
  let channelRows = [];
  let apparitionRows = [];
  let reactionRect = null;
  let fireballRect = null;
  let onSurfaceHit = null;
  let onSurfaceAcquire = null;
  let onSurfaceForgive = null;
  // Where and when a comet last landed on the frame. The engulf is drawn over
  // the whole panel from the bearing it came in on -- see drawFireballEngulf.
  let fireballEngulf = null;
  // THE TURN HAS A CLOCK NOW.
  //
  // Five to eight seconds to read the intent and answer it. Long enough to
  // think, short enough that you have to think on your feet; varied per turn so
  // the rhythm cannot be learned as a count. Let it run out and the beat is the
  // opponent's alone -- not a penalty applied to you, just the fight carrying
  // on without your answer, which is what a forfeit is.
  let turnClock = null;
  // A God review stop previews the Surfer's throw once at its movement.
  let previewSendBackSpent = false;
  let skipRect = null;
  let skipArmed = false;
  let regionRects = {};
  let introElapsed = 0;
  let preparationMenu = null, preparationStarted = false, preparationDone = !preparation;
  let readyElapsed = 0, entryConfirmLocked = false;
  let resultSurfacePending = false;
  let resultChoreographyPending = false;
  let hitstop = 0;
  let popups = [];
  let popupSeq = 0;
  let impactFx = null;
  let barGhost = { composure: null, coherence: null };
  let performanceIntrusion = Math.max(0,Math.min(.32,Number(initialPerformanceIntrusion)||0));
  let performanceStage = performanceIntrusionStage(performanceIntrusion);
  // A reprise returns as material, not as an absent loading screen. For one
  // short phrase the newly-written take remains visibly caught in the Surfer.
  let repriseReturnPulse = 0;
  let repriseReturnId = '';
  // The comets are pitched. See fireball-voice.js: a cast is an arpeggio, a
  // volley is that chord struck at once, a deflection answers a fifth up, and
  // the third one -- the one that arms the RETURN -- is the only resolved sound
  // anywhere in the exchange.
  const fireballVoice=createFireballVoice({getAudio});
  // `ray-3` is the third degree of the scale. The pitch belongs to the comet,
  // so answering the second one always answers it in the same place.
  const rayIndexOf=(rayId)=>Math.max(0,(Number(String(rayId||'').split('-')[1])||1)-1);
  const fireballExchange=createFireballExchange({
    battleId:battle.combat.id,
    reducedMotion:shakeMode()!=='full',
    manual:false,
    returnDamage:FIREBALL_RETURN_DAMAGE,
    beginCast:(event)=>interference?.beginFireballCast?.(event)||null,
    resolveCast:(event)=>interference?.resolveFireballCast?.(event),
    onReturn:({castId,damage,casterId})=>{
      fireballVoice.returned();
      return commitFireballReturn({castId,damage,casterId});
    },
    onImpact:({castId,rayId,damage})=>{
      const ray=fireballExchange.snapshot().active?.plan?.rays?.[rayIndexOf(rayId)];
      fireballEngulf={at:now,u:Math.max(0,Math.min(1,ray?.exit?.x??.5)),v:Math.max(0,Math.min(1,ray?.exit?.y??.5)),answered:false};
      fireballVoice.land(rayIndexOf(rayId));
      return commitFireballImpact({castId,damage});
    },
    onLaunch:({index,volley})=>fireballVoice.cast(index,{volley}),
    // Everything drawn outside the game window comes from this, once a frame,
    // for the whole volley. Nothing else opens, moves or closes a surface.
    onSync:(frame)=>interference?.syncFireballCast?.(frame)===true,
    // Where in the night this cast is. Sampled once per cast so the shoal's
    // behaviour is a staircase across turns rather than something that changes
    // under the player's hand mid-flight.
    getPressure:()=>({battleId:battle.combat.id,turn:state.turns}),
    // The stage band, as a fraction of the game window. Every ray coordinate is
    // relative to THIS rect, and anything drawing outside the window has to be
    // told so -- see the note on the plan's `stage` field.
    getStage:()=>{
      if(!fireballRect)return null;
      const {cols,rows}=uiSize();
      if(!cols||!rows)return null;
      return{
        x:fireballRect.x/cols,y:fireballRect.y/rows,
        w:fireballRect.w/cols,h:fireballRect.h/rows,
      };
    },
  });

  const movement = (index = state.movementIndex) => battle.combat.movements[index] || null;
  const stopVoice = () => { handle?.stop?.(); handle = null; };
  const isConfirmInput = (e = {}) => e.key === ' ' || e.key === 'Enter' || e.key === 'z' || e.controllerAction === 'confirm';

  function estimateDialogueViewport() {
    const { cols, rows } = uiSize();
    if (cathedral) return { width: Math.max(12, cols - 8), rows: 4 };
    // This mirrors the centred battle panel loosely enough for auto-advanced
    // authored barks; render() computes the exact viewport for player-visible
    // pagination.
    const panelW = Math.min(118, cols - 4);
    const width = Math.max(20, panelW - 4);
    const available = Math.max(2, Math.min(6, rows - 20));
    // A lead-in eats rows off the top and indents the body, so the paging maths
    // here has to know about it or the MORE state disagrees with what is drawn.
    const lead = leadOf(cur);
    if (!lead) return { width, rows: available };
    const leadRows = hardWrapBattleText(lead, width).length;
    return { width: Math.max(12, width - 2), rows: Math.max(1, available - leadRows) };
  }

  function currentBattleDialogueView({ width, rows } = {}) {
    const viewport = width && rows ? { width, rows } : estimateDialogueViewport();
    return battleDialoguePageView({
      text: textOf(cur),
      typed,
      width: viewport.width,
      maxRows: viewport.rows,
      page: talkPage,
    });
  }

  function tools() {
    const list = availableCombatTools(state);
    if (!director?.active?.()) return list;
    return list.map(tool => ({ ...tool,
      ready: director.filterMoves(combatMovesForTool(state, tool.id)).some(move => move.enabled),
    }));
  }
  function activeTool() { return tools()[selectedTool] || tools()[0] || { id: COMBAT_TOOL.SELF, label: 'HANDS' }; }
  function handsSnapshot({ injury = null, hurt = null, reaction = parryWindow() } = {}) {
    const visibleState = resolution && !resolution.impactFired ? resolution.before : state;
    return combatHandsSnapshot({
      selectedTool: activeTool().id,
      resolution,
      phase,
      time: now,
      injury: injury || combatInjuryStage({ composure: visibleState.composure,
        maxComposure: visibleState.maxComposure, injuries: state.injuries }),
      snr: state.snr,
      hurt: hurt ?? (impactFx?.received > 0 ? Math.max(0, 1 - (now - impactFx.at) / .35) : 0),
      hurtAge: impactFx?.received > 0 ? Math.max(0, now - impactFx.at) : null,
      parry: reaction,
      reducedMotion: shakeMode() !== 'full',
      wet: submersionSnapshot.enabled ? submersionSnapshot.wetMix : 0,
      cosmetics: resolveFieldKit(getSave().fieldKit, getMeta()).cosmetics,
      take: visibleState.take,
    });
  }
  function moves() {
    const list = combatMovesForTool(state, activeTool().id);
    return director?.active?.() ? director.filterMoves(list) : list;
  }

  function repairSelection() {
    const list = tools();
    selectedTool = Math.min(Math.max(0, selectedTool), Math.max(0, list.length - 1));
    selectedMove = Math.min(Math.max(0, selectedMove), Math.max(0, moves().length - 1));
  }

  // Deterministic per turn: a fight replayed from the same state gets the same
  // clock, and the length is not a coin flip the player can feel being tossed.
  function armTurnClock() {
    if (director?.pausesTurnClock?.()) { turnClock = null; return; }
    const limit = combatChoiceSeconds(state);
    if (limit == null) { turnClock = null; return; }
    turnClock = { limit, left:limit, expired:false };
  }

  function disarmTurnClock() { turnClock = null; }

  function forfeitTurn() {
    disarmTurnClock();
    notice = 'NO ANSWER · THE BEAT IS THEIRS';
    audio?.menuMove?.();
    fx?.flash?.(70, 'rgba(255,88,40,0.22)');
    turnStart = state;
    beginEnemyBeat();
  }

  function beginToolSelection() {
    if (!preparationDone && !preparationStarted) {
      preparationStarted = true;
      phase = 'prepare';
      disarmTurnClock();
      resetDeckControls();
      musicSession?.setDialogueActive?.(true);
      const openingState = (draft=null) => {
        const fresh=getPreparedLoadout?.()||loadout;
        return createCombatState(battle.combat, {
          difficulty,seed,injuries:fresh.injuries,composure:fresh.composure??null,
          battery:fresh.battery,torchDrainScale:fresh.torchDrainScale,
          tools:draft?preparationBattleTools(draft):fresh.tools,
          techniques:draft?draft.build.techniques:fresh.techniques,
          carriedRead,continuation,startingMovementIndex:state.movementIndex,source,
        });
      };
      preparationMenu = makeBattlePreparation({
        ...preparation, audio, title:battle.enemy,getOpeningState:openingState,
        onReady: ({confirmHeld}) => {
          if (!sceneEntered) return;
          state = openingState();
          preparationDone = true;
          preparationMenu = null;
          phase = 'ready'; readyElapsed = 0; entryConfirmLocked = confirmHeld;
          repairSelection();
        },
      });
      return;
    }
    if (sourceDesktop && battle.combat?.desktopOnCommit && !desktopStarted) {
      // Keep the title/preparation composition intact until the player is
      // READY. The failing desktop then opens before the first live decision.
      state.sourceDesktop = {...state.sourceDesktop,breached:true};
      if (beginDesktopBreach({resume:()=>beginToolSelection()})) return;
    }
    phase = 'tool';
    takeConfirmation = false;
    selectedMove = 0;
    state = director?.prepareState?.(state) || state;
    armTurnClock();
    repairSelection();
    const lesson = director?.step?.();
    if (lesson && (director?.guided?.() || lesson.id !== presentedTutorialStep)) {
      const preferred = director?.preferredAction?.(state);
      const targetTool = tools().findIndex(tool => tool.moves.includes(preferred));
      if (targetTool >= 0) {
        selectedTool = targetTool;
        selectedMove = Math.max(0, moves().findIndex(move => move.id === preferred));
        phase = 'move';
      }
    }
    presentedTutorialStep = lesson?.id || null;
    // The exchange is over and the beat is his again: this is where a bark
    // lands, on top of the deck he is already reading.
    nextBark();
    persistCheckpoint();
  }

  // A blocking block. The scene stops, the command deck goes away, and the
  // player reads at their own pace. `before`, `after`, the intro and the two
  // endings arrive this way.
  //
  // `when:` is honoured here and nowhere else in the fight — a line the flags
  // hide never enters the queue. The rule comes from conversation.js so that a
  // line cannot be invisible in a thought tree and visible in a battle.
  function speak(lines, then, nodeId = reviewNodeForList.get(lines) || 'dialogue') {
    queue = visibleList(battleTextReviewLines(lines, { sceneId: `battle:${battle.id}`, nodeId })).filter((line) => originalTextOf(line));
    onTalkEnd = then || (() => {});
    phase = 'talk';
    nextLine();
  }

  // ── barks ─────────────────────────────────────────────────────────────────
  // `on-listen` used to be concatenated onto `before` and delivered as the
  // second half of one block, which made the channel a fiction: a round
  // authored in three movements arrived as one wall of prose with the fight
  // waiting behind it.
  //
  // It means what it says now. These are the lines you hear WHILE the take is
  // running — barked between exchanges, one per exchange, over the top of the
  // command deck rather than in place of it. They do not block, they do not
  // hide the intent card, and they time out on their own.
  // The stable id of the line on screen, and whether this player has finished
  // reading it in an earlier run. Authored lines carry `sourceId` through
  // rehydration, so the key survives a rewrite of the surrounding tree.
  let activeLineId = null;
  let activeLineSeenBefore = false;
  let confirmHeld = false;

  let barkQueue = [];
  let bark = null;
  let barkHold = 0;

  function armBarks(m) {
    barkQueue = visibleList(battleTextReviewLines(m?.onListen, {
      sceneId: `battle:${battle.id}`, nodeId: `movement:${m?.id || state.movementIndex}:onListen`,
    })).filter((line) => originalTextOf(line));
    bark = null;
    barkHold = 0;
  }

  function nextBark() {
    // Never on the opening beat. The block that set the scene has only just
    // finished; a bark on top of it is the wall of prose again with extra steps.
    if (bark || !barkQueue.length || integer(state.turnsInMovement, 0) < 1) return;
    bark = barkQueue.shift();
    barkHold = battleLineAutoHoldSeconds({ ...bark, text: textOf(bark) });
    const who = whoOf(bark);
    const text = textOf(bark);
    currentBarkReviewText = text;
    if (bark.cue) fx?.cue?.(bark.cue, { group: 'battle' });
    if (text && isVoiced(who) && bark.voice !== false) voice.start(text, { speaker: who, rate: bark.rate || 1 });
  }

  function clearBark() { bark = null; barkHold = 0; }

  function nextLine() {
    stopVoice();
    audio?.stopTyping?.();
    cur = queue.shift() || null;
    typed = 0;
    acc = 0;
    held = 0;
    talkPage = 0;
    lineDoneAt = null;
    if (!cur) {
      musicSession?.setDialogueActive?.(false);
      onTalkEnd();
      return;
    }
    activeLineId = replay && (cur.sourceId || cur.id) ? `${battle.combat?.id || battle.id}:${cur.sourceId || cur.id}` : null;
    activeLineSeenBefore = activeLineId ? replay.lineStatus?.(activeLineId) === 'seen-before-run' : false;
    const who = whoOf(cur);
    const text = textOf(cur);
    currentReviewText = text;
    currentReviewLead = leadOf(cur);
    const spoken = text && isVoiced(who) && cur.voice !== false;
    musicSession?.setDialogueActive?.(!!spoken);
    // Grouped, so stopCueGroup('battle') reaches it. Ungrouped, a line's cue
    // outlived the fight that fired it.
    if (cur.cue) fx?.cue?.(cur.cue, { group: 'battle' });
    if (spoken) handle = voice.start(text, { speaker: who, rate: cur.rate || 1 });
    else if (text) audio?.startTyping?.({ gain: TYPE_GAIN * (TYPE_LEVEL[who === 'direction' ? 'direction' : 'thought'] || 1) });
  }

  function revealReviewedLine() {
    stopVoice();
    voice.stop?.();
    audio?.stopTyping?.();
    musicSession?.setDialogueActive?.(false);
    if (cur) {
      typed = textOf(cur).length;
      acc = 1e6;
      lineDoneAt = now;
      // A review reveal is not a normal completed reading or a replay assist.
      activeLineId = null;
    }
  }

  function refreshReviewedBattleText() {
    if (cur) {
      const text = textOf(cur), lead = leadOf(cur);
      if (text !== currentReviewText || lead !== currentReviewLead) {
        currentReviewText = text; currentReviewLead = lead;
        revealReviewedLine();
        talkPage = 0;
      }
    }
    if (bark) {
      const text = textOf(bark);
      if (text !== currentBarkReviewText) {
        currentBarkReviewText = text;
        voice.stop?.();
        barkHold = battleLineAutoHoldSeconds({ ...bark, text });
      }
    }
  }

  function combatCheckpoint() {
    // Enemy damage is computed ahead of its reaction phrase. Until contact or
    // a successful parry, preserve the pending blow so reloading cannot file a
    // shelter loss the player still has time to prevent. A real ranged impact
    // in that interval already changed the live pool and must remain durable.
    if (state.sourceDesktop && resolution?.side === 'enemy' && !resolution.impactFired
      && !resolution.parried && !resolution.rangedDuringReaction) {
      return combatContinuationSnapshot(resolution.before);
    }
    const saved = combatContinuationSnapshot(state);
    if (state.sourceDesktop && state.result) {
      // The result is durable before its outro or native restoration. Keep its
      // already-banked votes and metrics without nesting another continuation.
      const metrics = combatResult(state);
      delete metrics.continuation;
      saved.sourceTerminal = {version:1,definitionId:battle.combat.id,metrics,
        performanceIntrusion,performanceStage};
    }
    return saved;
  }

  function beginMovement(index = state.movementIndex, {resume=false} = {}) {
    prepareChapelDesktop();
    const next = movement(index);
    fireballExchange.setMovement({
      id:next?.id||'',index,
      title:next?.title||next?.label||next?.id||'',
    });
    submersionSnapshot = submersionController.setMovement(index);
    waterAudio.setPhase(submersionSnapshot);
    musicSession?.setSubmersion?.(submersionSnapshot);
    voice.setEnvironment?.(submersionSnapshot);
    playSound?.({ threat: next?.threat ?? .45 + index * .1 });
    void Promise.resolve(interference?.movement?.({
      id: next?.id || '',
      index,
      title: next?.title || next?.label || next?.id || '',
    })).catch(() => null);
    armBarks(next);
    if (resume) { resumeDecision(); return; }
    const lines = next?.before || [];
    if (lines.length) speak(lines, () => { beginToolSelection(); musicSession?.setDialogueActive?.(phase === 'prepare'); }, `movement:${next?.id || index}:before`);
    else { beginToolSelection(); musicSession?.setDialogueActive?.(phase === 'prepare'); }
  }

  function enterMovement(index = state.movementIndex, { sentBack: sentBackHandoff = false } = {}) {
    const next = movement(index);
    if (sourceDesktop && battle.combat?.desktopOnCommit && !desktopStarted && preparationDone) {
      // Presentation is part of the warned commitment, never a reward for
      // taking damage. This spends no cover, recovery, health or movement.
      state.sourceDesktop = {...state.sourceDesktop,breached:true};
      if (beginDesktopBreach({fallbackMovementIndex:index,resume:()=>beginMovement(index)})) return;
    }
    if (sourceDesktop && !previewSendBackSpent && Number.isInteger(battle.combat?.previewSendBackAt)
      && battle.combat.previewSendBackAt === index) {
      previewSendBackSpent = true;
      // The review stop previews presentation only; it never spends a real break.
      if (beginDesktopBreach({fallbackMovementIndex:index})) return;
    }
    // THE SURFER SENDS YOU BACK when you broke in this movement (combat-state
    // sendBackOnBreak marks the restart). A God review stop may preview it once.
    // Nothing else throws you: an ordinary movement just begins.
    // Handed in by handleStateEndpoint, which consumes the marker, so a later
    // beat that merges into the same `last` cannot throw you a second time.
    const sentBack = sentBackHandoff === true;
    const preview = !previewSendBackSpent && Number.isInteger(battle.combat?.previewSendBackAt)
      && battle.combat.previewSendBackAt === index;
    if (next && onMovementInterlude && (sentBack || preview)) {
      if (preview) previewSendBackSpent = true;
      phase = 'interlude';
      disarmTurnClock();
      clearBark();
      fireballExchange.cancel();
      let resumed = false;
      const resume = () => {
        if (resumed || !sceneEntered) return false;
        resumed = true;
        repriseReturnPulse = .84;
        repriseReturnId = next.id || '';
        notice = sentBack ? 'PUNCHED IN · FROM THE TOP' : 'TAKE ACCEPTED · SOURCE WRITE';
        fx?.glitch?.(.22, 150);
        beginMovement(index);
        return true;
      };
      const handled = onMovementInterlude({
        id: next.id || '',
        index,
        reason: sentBack ? 'sent-back' : 'preview',
        checkpoint: combatCheckpoint(),
        scheduleReturn: () => musicSession?.resumeReplayInterlude?.({ beats:4 }),
        resume,
      });
      if (handled) {
        // Ducked, not stopped: the throw is his music at you, not a silence.
        musicSession?.beginReplayInterlude?.({ duck: true });
        return;
      }
    }
    beginMovement(index);
  }

  function beginOpening() {
    if (!sceneEntered || openingStarted) return;
    if (encounterIntro && introElapsed < 1.54) return;
    openingStarted = true;
    if (restored) {
      preparationDone = true;
      const saved = restored.scene;
      selectedTool = saved.selectedTool || 0; selectedMove = saved.selectedMove || 0;
      notice = saved.notice || ''; now = saved.now || 0; turnCount = saved.turnCount || 1;
      enemyBeatSeq = saved.enemyBeatSeq || 0; strike = saved.strike || null;
      readMissed = !!saved.readMissed; takeConfirmation = !!saved.takeConfirmation;
      turnStart = saved.turnStart || null;
      notifyCompletedMovements();
      if (saved.phase === 'resolve' && saved.resolution) {
        resolution = saved.resolution; phase = 'resolve'; turnClock = null;
        repairSelection(); persistCheckpoint(); return;
      }
      if (state.result) { beginResultDelivery(); return; }
      if (state.last?.transition && handleStateEndpoint(state.movementIndex)) return;
      if (state.phase === 'enemy' && state.pendingEnemy) { beginEnemyBeat(); return; }
      phase = saved.phase === 'move' ? 'move' : 'tool';
      turnClock = saved.turnClock || null;
      if (!turnClock) armTurnClock();
      repairSelection(); persistCheckpoint(); return;
    }
    const terminal = continuation?.sourceTerminal;
    if (state.sourceDesktop && terminal?.version === 1 && terminal.definitionId === battle.combat.id
      && ['win','lose'].includes(terminal.metrics?.result)) {
      state.phase='done';state.pendingEnemy=null;state.committed=null;
      state.composure=Math.max(0,Math.min(state.maxComposure,integer(terminal.metrics.composure,state.composure)));
      state.last={...state.last,desktopBreach:null};
      state.result={...JSON.parse(JSON.stringify(terminal.metrics)),continuation:combatContinuationSnapshot(state)};
      performanceIntrusion=Math.max(0,Math.min(1,Number(terminal.performanceIntrusion)||0));
      performanceStage=performanceIntrusionStage(performanceIntrusion);
      persistCheckpoint();beginResultDelivery();return;
    }
    // Legacy sentBack-only continuations also retain their lost shelter. They
    // receive the same settled desktop restoration as current partial saves.
    if (continuation && state.sourceDesktop && (state.sourceDesktop.breached || battle.combat?.desktopOnCommit)) {
      const restoring=state.sourceDesktop.breached;
      state.sourceDesktop={...state.sourceDesktop,breached:true};
      if (beginDesktopBreach({restoring})) return;
    }
    if (continuation?.sourceCombat) {
      beginMovement(state.movementIndex,{resume:true}); return;
    }
    if (skipOpening) { enterMovement(state.movementIndex); return; }
    const opening = battle.intro || [];
    if (opening.length) speak(opening, () => enterMovement(0), 'intro');
    else enterMovement(0);
  }

  function finishMusic() {
    if (musicFinished) return;
    musicFinished = true;
    musicSession?.setDialogueActive?.(false);
    musicSession?.finish?.(state.result?.result || 'win');
  }

  function beginResultDelivery() {
    if (state.sourceDesktop) persistCheckpoint();
    const result = state.result?.result || 'win';
    submersionSnapshot = submersionController.beginResult(result);
    waterAudio.setPhase(submersionSnapshot);
    musicSession?.setSubmersion?.(submersionSnapshot);
    voice.setEnvironment?.(submersionSnapshot);
    if (result === 'win' && submersionSnapshot.enabled && !submersionSnapshot.settled) {
      resultSurfacePending = true;
      phase = 'submersion';
      return;
    }
    finishMusic();
    if(result==='lose'&&!resultChoreographyPending){
      resultChoreographyPending=true;
      phase='result-choreography';
      // BOTH HALVES START ON THE SAME FRAME.
      //
      // interference.result() throws the desktop panes; onDefeatScreen draws
      // the same edit inside the window. They are one composition, so they are
      // launched together and the result dialogue waits for whichever of them
      // is still going. The desktop half is deliberately non-blocking on its
      // own side (see window-choreography.js result()) — if it never opens a
      // surface, the canvas screen alone still holds the beat.
      Promise.all([
        Promise.resolve(interference?.result?.(result)).catch(()=>null),
        Promise.resolve(onDefeatScreen?.(combatResult(state) || {})).catch(()=>null),
      ]).catch(()=>null).finally(deliverResult);
      return;
    }
    deliverResult();
  }

  function deliverResult() {
    if (resultDelivered || (state.sourceDesktop && !sceneEntered)) return;
    resultDelivered = true;
    fx?.stopCues?.();   // the last blow does not outlive the fight
    const metrics = combatResult(state) || {};
    const legacyMetrics = {
      ...metrics,
      continuation: { ...(metrics.continuation || {}) },
      attempts: Math.max(1, Number(metrics.turns) || 1),
      playerHealth: metrics.composure,
      enemyHealth: 0,
      performanceIntrusion,
      performanceStage,
    };
    speak(metrics.result === 'win' ? battle.win : battle.lose, () => {
      stopVoice();
      audio?.stopTyping?.();
      Promise.resolve(sourceDesktop?.end?.(metrics.result)).catch(() => null).then(() => {
        if (state.sourceDesktop && !sceneEntered) return;
        return interference?.finish?.(metrics.result, legacyMetrics);
      }).catch(() => null).finally(() => {
        if (state.sourceDesktop) {
          if (!sceneEntered || outcomeDispatched) return;
          outcomeDispatched=true;
          scenes.remove(scene);
        } else scenes.pop();
        (metrics.result === 'win' ? onWin : onLose)(legacyMetrics);
      });
    }, metrics.result === 'win' ? 'win' : 'lose');
  }

  function syncResourceSpend(before, after) {
    const spent = Math.max(0, Number(after.torchSpent) - Number(before.torchSpent));
    if (spent > 0) resources.spendBattery?.(spent);
    if (after.last?.consumed) resources.consumeItem?.(after.last.consumed);
  }

  function spawnPopup(popup) {
    popupSeq += 1;
    popups.push({ ...popup, born: now + (popup.delay || 0), jx: ((popupSeq % 3) - 1) * 2 });
  }

  function fireImpact() {
    if (!resolution || resolution.impactFired) return;
    resolution.impactFired = true;
    persistCheckpoint();
    const before = resolution.before;
    const after = resolution.after;
    const last = after.last || {};
    const enemyBeatImpact = resolution.side === 'enemy';
    if (resolution.desktopMissCue && !resolution.parried) {
      const { theme, attackId } = resolution.desktopMissCue;
      resources.playDesktopParry?.({ theme, attackId, stage: 'miss' });
    }
    // The player's tool sound belongs to the player beat; the enemy beat is the
    // opponent's, so it plays no tool. dealt is zeroed for the enemy beat's
    // audio/fx because it carries over from the player step (see below).
    if (!enemyBeatImpact) {
      resources.playTool?.(resolution.action.tool, resolution.action.id);
      if (last.bridge?.route === 'rec') {
        resources.playTool?.(COMBAT_TOOL.RECORDER, COMBAT_ACTION.MONITOR);
        playBridgeArc(getAudio?.());
      }
    }
    const impactDealt = enemyBeatImpact ? 0 : (last.dealt || 0);
    resources.playImpact?.({
      dealt: impactDealt,
      received: last.received || 0,
      perfect: !!last.perfect,
    });
    impactFx = { at: now, dealt: impactDealt, received: last.received || 0 };
    // Hit-stop: the whole beat freezes for a few frames so the hit has weight.
    if (shakeMode() === 'full' && (impactDealt > 0 || last.received > 0)) {
      // Divided by GRID because damage numbers are five times what they were
      // when these coefficients were chosen; a critical would otherwise freeze
      // the beat for the whole cap every time.
      hitstop = Math.min(.15, .05 + (impactDealt * .012 + (last.received || 0) * .03) / GRID);
    }
    if (last.perfect && flashMode() === 'full') fx?.flash?.(60, 'rgba(255,214,120,0.30)');
    const enemyBeat = resolution.side === 'enemy';
    // The player beat shows what the player did to the enemy (coherence, heal);
    // the enemy beat shows what it did back (composure). `last.dealt` carries
    // over from the player step into the enemy-after state, so the side guard is
    // what stops the dealt popup firing twice.
    if (!enemyBeat && last.enemyDodge) {
      // The surfer turned your swing. No coherence lost; a parry nicks composure.
      spawnPopup({ text: last.enemyDodge.mode === 'parry' ? 'PARRIED' : 'DODGED', role: 'ui-danger', anchor: 'enemy' });
      if (last.enemyDodge.nick > 0) spawnPopup({ value: last.enemyDodge.nick, kind: 'received', anchor: 'hands', delay: .12 });
      fx?.flash?.(66, 'rgba(120,220,255,0.24)');
      fx?.shake?.(.2, 180);
    } else if (!enemyBeat && last.dealt > 0) {
      barGhost.coherence = { from: before.movementCoherence, at: now };
      spawnPopup({ value: last.dealt, kind: 'dealt', anchor: 'enemy' });
      // HOW WELL, not just how much. Damage is a band now (combat-damage.js) and
      // where the hit landed inside it is the feedback on how the beat was
      // played — so the tier is named, and the screen answers proportionally. A
      // CLEAN hit says nothing, because "clean" is the thing that needs no word.
      const grade = QUALITY_PRESENTATION[last.quality] || null;
      if (grade?.label) {
        spawnPopup({
          text: grade.label,
          role: last.quality === HIT_QUALITY.CRITICAL ? 'ui-amber'
            : last.quality === HIT_QUALITY.GRAZE ? 'ui-secondary' : 'ui-primary',
          anchor: 'enemy',
          delay: .08,
        });
      }
      const weight = grade?.weight ?? 1;
      fx?.flash?.(72, `rgba(255,180,55,${(0.38 * weight).toFixed(3)})`);
      fx?.glitch?.((.24 + Math.min(.32, last.dealt * .014)) * weight, 150);
      if (last.quality === HIT_QUALITY.CRITICAL && shakeMode() === 'full') fx?.shake?.(.28, 200);
    }
    if (enemyBeat && last.parried) {
      // Turned. No composure lost this beat — the blow's force went back as
      // coherence, and the guard reads cold-blue, not red.
      spawnPopup({ text: 'PARRIED', role: 'ui-blue', anchor: 'hands' });
      if (last.dealt > 0) {
        barGhost.coherence = { from: before.movementCoherence, at: now };
        spawnPopup({ value: last.dealt, kind: 'dealt', anchor: 'enemy', delay: .1 });
      }
      fx?.flash?.(80, 'rgba(120,220,255,0.42)');
    } else if (enemyBeat && last.received > 0) {
      barGhost.composure = { from: before.composure, at: now };
      // Chained hits each get their own popup, fanned out in time so a two-hit
      // enemy turn reads as two blows rather than one big number.
      const hits = last.enemyHits?.length ? last.enemyHits : [{ received: last.received }];
      hits.forEach((hit, i) => {
        if (hit.received > 0) spawnPopup({ value: hit.received, kind: 'received', anchor: 'hands', delay: i * .16 });
      });
      fx?.flash?.(90, 'rgba(154,20,30,0.48)');
      // /GRID: the coefficient predates the rescale (see combat-damage.js).
      fx?.shake?.(.26 + Math.min(.50, last.received * .11 / GRID), 220);
    }
    if (!enemyBeat && (last.composureTo ?? 0) > (last.composureFrom ?? 0)) {
      barGhost.composure = { from: last.composureFrom, at: now };
      spawnPopup({ value: last.composureTo - last.composureFrom, kind: 'heal', anchor: 'hands' });
    }
    if (last.perfect) spawnPopup({ text: 'NEGATED', role: 'ui-amber', anchor: 'hands' });
    if (!enemyBeat && last.bridge?.route === 'rec') {
      spawnPopup({ text: 'WIRE ARC → RECORDER', role: 'ui-amber', anchor: 'hands' });
    }
    if (after.take && !before.take && last.action === COMBAT_ACTION.MONITOR) {
      spawnPopup({ text: 'CAPTURED', role: 'ui-blue', anchor: 'enemy' });
    }
    if (enemyBeatImpact) {
      waterAudio.impact({
        received:Math.max(0,Number(last.received)||0),
        parried:!!last.parried,
      },submersionSnapshot);
      // Personalized bookkeeping may write asynchronously, but presentation is
      // never a combat fence.
      void Promise.resolve(interference?.impact?.({
        kind: resolution.action?.kind || null,
        perfect: !!last.perfect,
        parried: !!last.parried,
        received: Math.max(0, Number(last.received) || 0),
        transition: last.transition || null,
        windowLock:fireballCatchLocked(),
      })).catch(() => null);
    }
  }

  function fireballCatchLocked(){
    const snapshot=fireballExchange.snapshot();
    return !!snapshot.active?.rays?.some((ray)=>ray.state==='approach'&&ray.catchReady);
  }

  function finishResolution() {
    if (!resolution) return;
    // A player beat that deferred the enemy turn hands off to the enemy beat;
    // everything else (tempo, movement break, KO, or the finished enemy beat)
    // settles the whole turn.
    if (resolution.side === 'player' && state.phase === 'enemy' && !state.result) {
      const heldTool = resolution.heldTool || resolution.action.tool || activeTool().id;
      resolution = null;
      beginEnemyBeat(heldTool);
      return;
    }
    // Hall initiative is YOU → 01 → 02 → 03. Fireballs keep their own clock;
    // advancing an apparition neither creates nor cancels one.
    if (resolution.side === 'enemy' && state.apparitions && state.phase === 'enemy' && !state.result) {
      const heldTool = resolution.heldTool || activeTool().id;
      resolution = null;
      beginEnemyBeat(heldTool);
      return;
    }
    settleTurn();
  }

  function handleStateEndpoint(fallbackMovementIndex=state.movementIndex,{fromFireball=false}={}){
    notifyCompletedMovements();
    if (state.last?.desktopBreach && beginDesktopBreach({fallbackMovementIndex})) return true;
    if(state.result){
      if(!fromFireball)fireballExchange.cancel();
      const finished=movement(state.last?.transition?.from??fallbackMovementIndex);
      const tail=[...(finished?.after||[])];
      if(tail.length)speak(tail,beginResultDelivery,`movement:${finished?.id || fallbackMovementIndex}:after`);
      else beginResultDelivery();
      return true;
    }
    if(state.last?.transition?.to!=null){
      if(!fromFireball)fireballExchange.cancel();
      const old=movement(state.last.transition.from);
      // Sent back is not a movement ending: its closing lines belong to a finish.
      const closing=state.last.transition.sentBack?[]:(old?.after||[]);
      clearBark();
      resources.playImpact?.({transition:true});
      interference?.windowLock?.(fireballCatchLocked());
      void Promise.resolve(interference?.phaseBreak?.({
        from:state.last.transition.from,
        to:state.last.transition.to,
      })).catch(()=>null);
      barGhost.coherence=null;
      const sentBack=state.last.transition.sentBack===true;
      // Consumed here: enemy beats merge into `last` (combat-state advanceEnemy),
      // and a marker left behind would open the throw again on the next settle.
      state.last={...state.last,transition:null};
      const openNext=()=>enterMovement(state.movementIndex,{sentBack});
      if (closing.length) speak(closing, openNext);
      else openNext();
      return true;
    }
    return false;
  }

  // ONE ANSWER FOR A STRUCK COMET, WHEREVER THE CLICK CAME FROM.
  //
  // The in-canvas pointer and a click on an external cast surface are the same
  // act, so they say the same thing and make the same sound -- which is a fifth
  // above the note that comet was thrown at, except for the third one, which is
  // the tonic and the only time this exchange resolves.
  function announceFireballHit(result){
    const degree=rayIndexOf(result.rayId);
    if(result.returned)fireballVoice.arm();
    else fireballVoice.deflect(degree);
    notice=result.returned
      ? 'RETURN ARMED · RANGED IN FLIGHT'
      : `DEFLECT · RETURN ${result.charge}/${result.threshold}`;
    fx?.flash?.(55,result.returned?'rgba(120,220,255,0.30)':'rgba(255,188,52,0.20)');
  }

  function commitFireballReturn({castId='',damage=FIREBALL_RETURN_DAMAGE,casterId=null}={}){
    if(state.result)return false;
    const before=state;
    const coherenceFrom=state.movementCoherence;
    state=applyFireballReturn(state,{castId,damage,casterId});
    const dealt=Math.max(0,coherenceFrom-state.movementCoherence);
    if(dealt<=0)return false;
    notice=`RETURN · ${dealt} RANGED`;
    barGhost.coherence={from:coherenceFrom,at:now};
    spawnPopup({text:'RETURN',role:'ui-blue',anchor:'enemy'});
    spawnPopup({value:dealt,kind:'dealt',anchor:'enemy',delay:.08});
    resources.playImpact?.({dealt,received:0,perfect:true,ranged:true});
    fx?.flash?.(82,'rgba(120,220,255,0.42)');
    if(resolution){resolution.after=state;resolution.rangedDuringReaction=true;}
    persistCheckpoint();
    if(state.result||state.last?.transition?.to!=null){
      const fallback=before.movementIndex;
      resolution=null;
      turnStart=null;
      fx?.stopCues?.();
      handleStateEndpoint(fallback,{fromFireball:true});
    }
    return true;
  }

  // A COMET NOBODY TOUCHED LANDS ON YOU.
  //
  // The mirror of commitFireballReturn, and the reason the RETURN is worth
  // anything: ignoring a fireball used to be free, which made three clicks for
  // ten damage a bonus rather than a decision. Outside the turn, like the
  // return — no move consumed, no clock advanced.
  function commitFireballImpact({castId='',damage=0}={}){
    if(state.result)return false;
    const before=state;
    const composureFrom=state.composure;
    state=applyFireballImpact(state,{castId,damage});
    // A break that sends you back RAISES composure (half, from the top), so the
    // hit is read off the impact itself, and a sent-back break always hands off.
    const sentBack=!!(state.last?.desktopBreach || state.last?.transition?.sentBack)&&state.fireballImpact?.castId===String(castId||'');
    const received=Math.max(0,Number(state.fireballImpact?.received)||composureFrom-state.composure);
    if(received<=0&&!sentBack)return false;
    notice=`RANGED · ${received}`;
    barGhost.composure={from:composureFrom,at:now};
    spawnPopup({value:received,kind:'received',anchor:'player'});
    resources.playImpact?.({dealt:0,received,perfect:false,ranged:true});
    fx?.flash?.(70,'rgba(255,140,40,0.34)');
    if(shakeMode()==='full')fx?.shake?.(.4,180);
    if(resolution){resolution.after=state;resolution.rangedDuringReaction=true;}
    persistCheckpoint();
    if(state.result||state.last?.desktopBreach||state.last?.transition?.sentBack){
      const fallback=before.movementIndex;
      resolution=null;
      turnStart=null;
      fx?.stopCues?.();
      handleStateEndpoint(fallback,{fromFireball:true});
    }
    return true;
  }

  function settleTurn() {
    if (!resolution) return;
    const resolved = resolution;
    resolution = null;
    // The exchange is over, and so is the sound of it.
    fx?.stopCues?.();
    // The director and music read the turn as one span: from where the player
    // committed (turnStart) to the settled end-state.
    director?.advance?.(turnStart || resolved.before, state);
    turnStart = null;
    const last=state.last||{};
    const correct=last.perfect===true||last.parried===true||((Number(last.dealt)||0)>0&&(Number(last.received)||0)===0);
    const changed=reducePerformanceIntrusion(performanceIntrusion,{
      missed:(Number(last.received)||0)>0||!correct,
      correct,
      movementTransition:last.transition?.to!=null,
    });
    const previousStage=performanceStage;
    performanceIntrusion=changed.value;
    performanceStage=changed.stage;
    musicSession?.setIntrusion?.(performanceIntrusion);
    if(previousStage!==performanceStage)onPerformanceStage({
      battleId:battle.combat.id,value:performanceIntrusion,stage:performanceStage,previousStage,
    });
    // This exchange has settled; the next one is a new turn on the glyph.
    if (!state.result) turnCount += 1;
    if (!state.result) musicSession?.onCombatEvent?.({
      perfect: state.last?.perfect === true,
      transition: state.last?.transition || null,
      movementIndex: state.movementIndex,
    });

    if(handleStateEndpoint(resolved.before.movementIndex))return;
    beginToolSelection();
  }

  function execute(actionId) {
    if (phase !== 'move') return;
    const action = moves().find((entry) => entry.id === actionId);
    if (!action?.enabled) {
      notice = action?.reason || 'MOVE UNAVAILABLE';
      audio?.menuDenied?.();
      return;
    }
    const before = state;
    const next = reduceCombat(state, {
      type: actionId,
      replaceTake: actionId === COMBAT_ACTION.MONITOR && takeConfirmation,
    });
    if (next.last?.needsTakeConfirmation) {
      takeConfirmation = true;
      notice = 'TAKE SLOT OCCUPIED · CONFIRM MONITOR AGAIN TO REPLACE';
      audio?.menuMove?.();
      return;
    }
    takeConfirmation = false;
    disarmTurnClock();
    syncResourceSpend(before, next);
    turnStart = before;
    state = next;
    interference?.action?.(actionId);
    notice = state.last?.notice || '';
    audio?.menuConfirm?.();
    // THE FORK IS A SOUND BEFORE IT IS A MOVE.
    //
    // Fired here rather than at the settle below, because TUNE is free: it
    // returns from the reducer without an enemy phase, so the exchange-settled
    // event never runs for it. The stab has to land on the press.
    if (state.last?.tuned) musicSession?.onCombatEvent?.({ tuned: state.last.tuned });
    resolution = {
      before,
      after: state,
      action,
      side: 'player',
      heldTool: action.tool || activeTool().id,
      elapsed: 0,
      duration: turnDuration(actionId),
      impactFired: false,
    };
    phase = 'resolve';
    repairSelection();
    persistCheckpoint();
  }

  // The opponent's own beat. It runs when the player step deferred the enemy
  // turn (phase 'enemy'). A tempo action, completed movement, or KO can settle
  // directly; a perfect counter still hands over initiative because it blunts
  // the committed blow instead of deleting it.
  function beginEnemyBeat(heldTool = activeTool().id) {
    const before = state;
    const intents = selectEnemyIntents(state);
    const primary = intents[0] || null;
    // Did the recordist have this one wrong? Asked here, against the state the
    // blow is arriving out of, because advanceEnemy clears the misread when it
    // writes the next commitment — and the answer has to survive into the
    // thought that owns up to it a beat later.
    readMissed = !!before.misread && before.misread.id !== primary?.id;
    const next = advanceEnemy(state);
    state = next;
    notice = state.last?.notice || '';
    // The adversary's attack is an instrument: each movement has its own piano
    // voice, and a low-composure recordist hears the SCREAM instead. Fired here,
    // on the enemy beat, so the sound arrives with the blow.
    if (primary) {
      // The surfer sounds like what it is doing this beat — its intent's voice —
      // not a slot on a clock.
      const beat = enemyBeatSeq++;
      const cueId = enemyAttackCue({
        intentKind: primary.kind,
        beat,
        composure: next.composure,
        maxComposure: next.maxComposure,
        // In the practice wing the sound is the room bleeding through the
        // partition, not the shape of a blow. Null everywhere else, which leaves
        // the intent mapping exactly as it was.
        instrument: next.practice ? practiceInstrument(next.practice) : null,
      });
      // The blow is a chop off the surfer's take, and it is this beat's sound
      // and no longer: it is cut to half a bar on the way in (enemyAttackShape)
      // and it goes out on the battle voice group, which is cut when the turn
      // settles. A stem still ringing in the next exchange — or out past the end
      // of the fight — is the surfer playing at a fight that is over.
      // The chop carries the opponent's mood: a cornered surfer is louder and
      // holds the bite longer than one that is still taking your measure.
      const lean = surferAggression(state.difficulty?.composureBonus, before.stance?.id);
      if (cueId) {
        const shape=combatEnemyAttackAudioShape(
          {group:'battle',...enemyAttackShape(cueId,beat,Math.random,lean)},
          battle.combat.presentation,
          submersionSnapshot,
        );
        fx?.cue?.(cueId,shape);
      }
      strike = { ...enemyAttackVoice(primary.kind, cueId), label: `${primary.actorLabel ? `${primary.actorLabel} · ` : ''}${primary.label}`, kind: primary.kind };
    } else strike = null;
    resolution = {
      before,
      after: next,
      action: { id: 'enemy', tool: COMBAT_TOOL.SELF, label: `${primary?.actorLabel ? `${primary.actorLabel} · ` : ''}${primary?.label || 'INTENT'}`, kind: primary?.kind || null },
      intent:primary,
      side: 'enemy',
      heldTool,
      elapsed: 0,
      // Struck blows receive a four-beat reaction phrase. Other enemy actions
      // keep the ordinary duration; the score conductor itself is untouched.
      duration: isParryableEnemyAction(primary?.kind)
          ? PARRY_REACTION_SECONDS
          : ORDINARY_TURN_SECONDS * Math.max(1, next.last?.enemyHits?.length || 1),
      impactFired: false,
      parryBuffered: false,
      parryTried: false,
      parryWhiffed: false,
      parryEarly: false,
    };
    phase='resolve';
    offerChapelParry();
    persistCheckpoint();
  }

  function cycleChannel(delta) {
    if (!['tool', 'move'].includes(phase)) return;
    // Q/E is "pick the thing on the left of the stage", and no encounter has
    // both: the source battle arms a channel, the Hall picks one apparition.
    // Sharing the binding keeps the deck's shape identical everywhere.
    if (state.apparitions) {
      state = reduceCombat(state, { type: COMBAT_ACTION.TARGET, delta });
      notice = state.last.notice;
      audio?.menuMove?.();
      return;
    }
    if (!state.source) return;
    const at = CHANNELS.findIndex((entry) => entry.id === state.source.armed);
    const next = CHANNELS[(at + delta + CHANNELS.length) % CHANNELS.length];
    state = reduceCombat(state, { type: COMBAT_ACTION.CHANNEL, channel: next.id });
    persistCheckpoint();
    notice = state.last.notice;
    audio?.menuMove?.();
  }

  function navigateDeck(direction) {
    const before = { phase, selectedTool, selectedMove };
    const next = combatDeckNavigation({
      ...before,
      toolCount: tools().length,
      moveCount: moves().length,
    }, direction);
    phase = next.phase;
    selectedTool = next.selectedTool;
    selectedMove = next.selectedMove;
    if (phase === before.phase && selectedTool === before.selectedTool && selectedMove === before.selectedMove) return;
    takeConfirmation = false;
    audio?.menuMove?.();
    if (cathedral) persistCheckpoint();
  }

  function skipDrill() {
    if (!director?.active?.()) return false;
    director.skip();
    skipArmed = false;
    notice = 'DRILL SKIPPED · ALL MOVES OPEN';
    beginToolSelection();
    audio?.menuMove?.();
    return true;
  }

  function visualState() {
    if (!resolution) return {
      movementIndex: state.movementIndex,
      coherence: state.movementCoherence,
      maxCoherence: state.movementMaxCoherence,
      composure: state.composure,
      maxComposure: state.maxComposure,
      progress: 0,
    };
    const progress = ease(resolution.elapsed / resolution.duration);
    const transitioned = resolution.after.last?.transition != null;
    const body = resolution.impactFired ? state : resolution.before;
    return {
      movementIndex: resolution.before.movementIndex,
      coherence: lerp(
        resolution.before.movementCoherence,
        transitioned ? 0 : resolution.after.movementCoherence,
        progress,
      ),
      maxCoherence: resolution.before.movementMaxCoherence,
      composure: body.composure,
      maxComposure: body.maxComposure,
      progress,
    };
  }


  const scene = {
    id: `battle:${battle.id}`,
    blocksInput: true,
    blocksWorld: true,
    lensPreset: 'battle',
    conditionView() {
      const visible = resolution && !resolution.impactFired ? resolution.before : state;
      const reserve = state.techniques?.includes('deep-reserve') ? 2 * GRID : 0;
      const baseline = Math.max(1, Math.floor(Number(state.definition?.baseComposure) || 8 * GRID)
        + (Number(state.difficulty?.composureBonus) || 0) + reserve);
      return {composure:visible.composure, ceiling:visible.maxComposure,
        baseline:Math.max(baseline, visible.maxComposure), injuries:state.injuries,
        authored:!!state.sourceDesktop};
    },
    textReviewSuspend() { revealReviewedLine(); },
    textReviewResume() { refreshReviewedBattleText(); },
    cancelChapelDesktop() { closeChapelOffer(); },
    focus() { prepareChapelDesktop(); },

    // ESCAPE, BUT ONLY FOR THE ONE QUESTION.
    //
    // Escape opens the pause menu before any scene's key handler runs, unless
    // the top scene claims it (main.js, shouldOpenPauseForEvent) — so a fight
    // cannot simply handle Escape itself without taking pause away from the
    // whole battle. This claims it for exactly as long as the field case is
    // asking which tool to give up, which is the one place in a fight where
    // Escape obviously means "back out of this" rather than "stop playing".
    get handlesEscape() {
      return phase === 'prepare' && !!preparationMenu?.snapshot?.()?.replacing;
    },

    enter() {
      resetDeckControls();
      hushBody?.warm();
      if (typeof window !== 'undefined') window.addEventListener('blur', resetDeckControls);
      sceneEntered = true;
      prepareChapelDesktop();
      if (state.practice) {
        const rig = getAudio?.();
        practiceClick = createPracticeClick({ ctx: rig?.ctx, context: rig?.ctx, destination: rig?.destination });
        practiceClick.start();
      }
      void Promise.resolve(interference?.enter?.()).catch(() => null);
      // A fireball that has left the frame is on a cast surface, and clicking
      // that surface is the same act as clicking the comet on the stage. The
      // surface reports which ray was struck; nothing else about it is trusted
      // or needed. Bound for the life of the scene only — no fight ever hands a
      // click to the one after it.
      if (typeof window !== 'undefined') {
        onSurfaceHit = (event) => {
          if (!sceneEntered || state.result) return;
          if (!['tool', 'move', 'resolve'].includes(phase)) return;
          const result = fireballExchange.strike(event?.detail || {});
          if (result.hit) announceFireballHit(result);
        };
        window.addEventListener('chunk-surfer:fireball-hit', onSurfaceHit);
        onSurfaceAcquire=(event)=>{
          if(!sceneEntered||state.result||!['tool','move','resolve'].includes(phase))return;
          fireballExchange.acquire(event?.detail||{});
        };
        window.addEventListener('chunk-surfer:fireball-acquire',onSurfaceAcquire);
        onSurfaceForgive = (event) => {
          if(!sceneEntered)return;
          fireballExchange.cancel(event?.detail?.reason||'emergency-restore');
        };
        window.addEventListener('chunk-surfer:fireball-forgive',onSurfaceForgive);
      }
      phase = musicSession || encounterIntro ? 'arrival' : 'talk';
      if (!musicSession) { musicBootResolved = true; beginOpening(); return; }
      Promise.resolve(musicSession.start?.()).then((music) => {
        if (!sceneEntered) return;
        musicBootResolved = true;
        musicSession?.setIntrusion?.(performanceIntrusion);
        if (music?.phase !== 'arrival') beginOpening();
      }).catch((error) => {
        console.warn('battle music start failed', error);
        musicBootResolved = true;
        beginOpening();
      });
    },

    exit() {
      persistCheckpoint();
      hushBody?.dispose();
      closeChapelOffer();
      void chapelDesktop?.dispose();
      void Promise.resolve(sourceDesktop?.end?.(state.result?.result || 'abort')).catch(() => null);
      preparationMenu?.dispose(); preparationMenu = null;
      resetDeckControls();
      if (typeof window !== 'undefined') window.removeEventListener('blur', resetDeckControls);
      sceneEntered = false;
      if (onSurfaceHit && typeof window !== 'undefined') {
        window.removeEventListener('chunk-surfer:fireball-hit', onSurfaceHit);
        onSurfaceHit = null;
      }
      if(onSurfaceForgive&&typeof window!=='undefined'){
        window.removeEventListener('chunk-surfer:fireball-forgive',onSurfaceForgive);
        onSurfaceForgive=null;
      }
      if(onSurfaceAcquire&&typeof window!=='undefined'){
        window.removeEventListener('chunk-surfer:fireball-acquire',onSurfaceAcquire);
        onSurfaceAcquire=null;
      }
      stopVoice();
      audio?.stopTyping?.();
      fx?.stopCues?.();   // never let a stem the surfer was mid-swing with outlive the scene
      // A metronome ticking in a corridor he has left is the same failure as a
      // weapon stem outliving the fight.
      practiceClick?.stop();
      practiceClick = null;
      fireballExchange.stop();
      fireballVoice.dispose();
      waterAudio.stop();
      voice.dispose?.();
      if (!musicFinished) {
        if (state.result) finishMusic();
        else musicSession?.abort?.();
      }
      if (!resultDelivered && !state.result) onAbort();
      if (state.sourceDesktop && state.result && !outcomeDispatched && !terminalAbortDelivered) {
        terminalAbortDelivered=true;onAbort();
      }
      if (!resultDelivered && !state.result) void Promise.resolve(interference?.finish?.('abort', {})).catch(() => null);
    },

    battleView() {
      refreshReviewedBattleText();
      return {
        phase,
        dialogue: cur ? { text: textOf(cur), lead: leadOf(cur), typed, page: talkPage, reviewTarget: cur.reviewTarget } : null,
        bark: bark ? { text: textOf(bark), reviewTarget: bark.reviewTarget } : null,
        sourceDesktop:sourceDesktop ? { ...desktopFrame(),presentation:sourceDesktop.debug?.(),waiting:phase==='desktop-breach'&&(!desktopReady||desktopCompleting&&!desktopInputReady) } : null,
        chapelDesktop:chapelDesktop ? {
          phase:chapelOffer?.phase || 'idle', prepared:chapelPrepared, shown:playedDesktopCues.size > 0,
          theme:chapelOffer?.cue.theme || null,
          remaining:chapelOffer?.phase === 'live' ? Math.max(0, chapelOffer.cue.responseSeconds - chapelOffer.response) : null,
          last:chapelLast,
        } : null,
        checkpoint:cathedral ? cathedralCheckpoint() : combatCheckpoint(),
        preparation: preparationMenu?.snapshot() || null,
        preparationDone,
        introElapsed,
        state: JSON.parse(JSON.stringify(state)),
        intent: currentCombatIntent(state),
        // Both sides of the split, so a test can prove they are the same when
        // the read is good and prove they differ when it is not.
        predicted: predictedCombatIntent(state),
        lookahead: combatIntentLookahead(state),
        // What the recordist thinks is coming, as the card is currently saying
        // it. Exposed so the trace can be read back in tests without a canvas.
        thought: thoughtTrace(state, {
          intent: predictedCombatIntent(state),
          alternative: rivalCombatIntent(state),
          counters: counterMovesForIntent(state, predictedCombatIntent(state)),
          wrong: readMissed,
          fidelity: readFidelity(state),
          apparitions: combatApparitions(state),
        }),
        tools: tools(),
        moves: moves(),
        actions: availableCombatActions(state),
        prediction: combatPrediction(state),
        music: musicSession?.snapshot?.() || null,
        submersion: submersionSnapshot,
        waterAudio: waterAudio.snapshot(),
        presentation:battle.combat.presentation||null,
        performanceIntrusion,
        performanceStage,
        fireball:fireballExchange.snapshot(),
        selectedTool,
        selectedMove,
        hands: handsSnapshot(),
        notice,
        resolution: resolution ? {
          elapsed: resolution.elapsed,
          duration: resolution.duration,
          action: resolution.action.id,
          intentId: resolution.intent?.id || null,
          side: resolution.side,
          parry: parryWindow(),
        } : null,
        statePhase: state.phase,
        tutorial: director?.snapshot?.() || null,
        turnClock: turnClock ? { ...turnClock } : null,
        readouts:combatReadoutState(resolution&&!resolution.impactFired?resolution.before:state),
        inputRects: {
          tabs:tabRows.map(row=>({...row})),
          channels: channelRows.map(row => ({ ...row })),
          tools: toolRows.map(row => ({ ...row })),
          moves: moveRows.map(row => ({ ...row })),
          reaction: reactionRect ? { ...reactionRect } : null,
          projectiles: fireballRect ? { ...fireballRect } : null,
        },
        interlude: phase === 'interlude',
        repriseReturn:repriseReturnPulse>0?{id:repriseReturnId,left:repriseReturnPulse}:null,
      };
    },

    update(dt) {
      refreshReviewedBattleText();
      if (!chapelOffer && sourceDesktop?.mode?.() === 'native' && !sourceDesktopInputActive(sourceDesktop)) {
        sourceDesktop.frame?.({...desktopFrame(),paused:true}); return;
      }
      if (phase === 'desktop-breach') {
        if(!desktopCompleting){
          if (desktopReady) desktopElapsed = Math.min(SOURCE_DESKTOP_BREACH_SECONDS,desktopElapsed + Math.max(0,Math.min(.08,dt)));
          sourceDesktop?.frame?.(desktopFrame());
          if(desktopReady&&desktopElapsed>=SOURCE_DESKTOP_BREACH_SECONDS){
            if(sourceDesktop.completeBreach){
              desktopCompleting=true;
              Promise.resolve(sourceDesktop.completeBreach(desktopFrame())).then(usable=>{
                if(sceneEntered&&phase==='desktop-breach')desktopInputReady=usable!==false;
              }).catch(()=>{});
            }else desktopInputReady=true;
          }
        }
        if(desktopInputReady){const resume=desktopResume;desktopResume=null;resume?.();}
        return;
      }
      if (phase === 'prepare') { now += dt; preparationMenu?.update(dt); return; }
      if (phase === 'ready') {
        readyElapsed += Math.max(0, Math.min(.08, dt));
        if (readyElapsed >= .68) { musicSession?.setDialogueActive?.(false); beginToolSelection(); }
        return;
      }
      introElapsed += dt;
      repriseReturnPulse=Math.max(0,repriseReturnPulse-dt);
      if (practiceClick) {
        const wing = combatPractice(state);
        practiceClick.setRetakes(wing?.retakes || 0);
        practiceClick.setReturnLevel(wing ? Math.max(0, 1 - wing.listens / Math.max(1, wing.listensToStop)) : 0);
        practiceClick.tick();
      }
      // Advances through hitstop as well: the water is a place, not an
      // animation, and freezing a landed hit must not un-submerge the room.
      submersionSnapshot = submersionController.update(dt);
      waterAudio.setPhase(submersionSnapshot);
      musicSession?.setSubmersion?.(submersionSnapshot);
      voice.setEnvironment?.(submersionSnapshot);
      // The opening movement can announce the circuit a beat ahead of the
      // ordinary cast interval. Leave it room, without touching a live ray.
      const committed = currentCombatIntent(state)?.id;
      const movementId = movement()?.id;
      const holdingWindow = !!chapelOffer || (chapelPrepared && chapelDesktop.isAvailable()
        && [...parryCues.values()].some(cue => !playedDesktopCues.has(cue.attackId)
          && (committed === cue.attackId || (cue.movementId === movementId && state.turnsInMovement <= 2))));
      fireballExchange.update(dt, {
        enabled: !state.result && ['tool','move','resolve'].includes(phase),
        allowSpawn: !holdingWindow,
      });
      // Only while the deck is his and nothing else owns the screen. A bark, a
      // checkpoint or an authored line is not time the player was given.
      if(turnClock&&!state.result&&['tool','move'].includes(phase)&&!bark&&!cur){
        turnClock.left=Math.max(0,turnClock.left-dt);
        if(turnClock.left<=0){turnClock.expired=true;forfeitTurn();}
      }
      if (cathedral && ['tool', 'move', 'resolve'].includes(phase)) {
        checkpointElapsed += dt;
        if (checkpointElapsed >= .5) persistCheckpoint();
      }
      if (resultSurfacePending && submersionSnapshot.settled) {
        resultSurfacePending = false;
        finishMusic();
        deliverResult();
      }
      if (hitstop > 0) {
        // Frozen frames: the beat, the typewriter, and every animation clock
        // hold still so a landed hit visibly stops the world.
        hitstop = Math.max(0, hitstop - dt);
        return;
      }
      now += dt;
      const music = musicSession?.update?.() || null;
      // The child reprise still updates because scene stacks are composited
      // bottom-up. Nothing in the parent fight advances while it owns the
      // transport: no fireball, turn clock, dialogue, or resolution clock.
      if (phase === 'interlude') return;
      if (phase === 'arrival') {
        arrivalElapsed += dt;
        if ((musicBootResolved && music?.phase !== 'arrival') || arrivalElapsed >= 1.2) beginOpening();
        return;
      }
      if (phase === 'resolve' && resolution) {
        resolution.elapsed += advanceChapelParry(dt);
        const opportunity = parryWindow();
        if (opportunity?.buffered && opportunity.armed && !resolution.parryTried) {
          commitParry(PARRY_TIER.LATE);
        }
        if (opportunity && !resolution.parryWindowSignaled && opportunity.phase === 'open') {
          resolution.parryWindowSignaled = true;
          audio?.menuMove?.();
        }
        const impactAt = opportunity
          ? opportunity.impactSeconds + PARRY_CONTACT_HOLD_SECONDS
          : resolution.duration * .28;
        if (!resolution.impactFired && resolution.elapsed >= impactAt) fireImpact();
        if (resolution.elapsed >= resolution.duration) finishResolution();
        return;
      }
      if (bark) {
        barkHold -= dt;
        if (barkHold <= 0) clearBark();
      }
      if (!cur || phase !== 'talk') return;
      const text = textOf(cur);
      held += dt;
      if (handle) {
        typed = handle.done() ? text.length : Math.min(text.length, handle.charsFor());
      } else if (typed < text.length) {
        // Hold confirm on a line you finished in an earlier run and it comes in
        // fast — or instantly, if that is the setting. Only on a line you have
        // ALREADY read: a first read is never hurried.
        const mode = replay?.seenTextMode?.() || 'normal';
        const accelerating = confirmHeld && activeLineSeenBefore && mode !== 'normal';
        const scale = accelerating && mode === 'instant' ? 1e6 : accelerating ? 4 : 1;
        if (accelerating) replay?.noteSeenTextAssist?.();
        acc += dt * scale;
        typed = Math.min(text.length, Math.floor(acc * textCps(CPS) * (cur.rate || 1)));
        if (typed >= text.length) audio?.stopTyping?.();
      }
      // Battle dialogue is player-paced by default. Individual authored lines can
      // opt into cinematic auto-advance with auto:true / battleAuto:true /
      // advance:'auto', but the engine never advances ordinary story text on its
      // own and never silently discards wrapped overflow.
      if (typed >= text.length && (!handle || handle.done())) {
        if (activeLineId) { replay?.markLine?.(activeLineId); activeLineId = null; }
        if (lineDoneAt == null) lineDoneAt = now;
        else if (shouldAutoAdvanceBattleLine(cur) && now - lineDoneAt >= battleLineAutoHoldSeconds(cur)) {
          const view = currentBattleDialogueView();
          if (view.hasMore) {
            talkPage = view.page + 1;
            lineDoneAt = now;
          } else {
            nextLine();
          }
        }
      }
    },

    key(e) {
      refreshReviewedBattleText();
      if (phase === 'desktop-breach') return e.key !== 'Escape';
      if (phase === 'prepare') return preparationMenu?.key(e) ?? true;
      if (phase === 'ready' || (encounterIntro && phase === 'arrival')) return e.key !== 'Escape';
      if (entryConfirmLocked && isConfirmInput(e)) return true;
      const confirm = isConfirmInput(e);
      // Escape remains the run-level pause. The fight's semantic Back is the
      // controller binding (or X on keyboard), never Tab.
      const back = String(e.key || '').toLowerCase() === 'x' || e.controllerAction === 'back';
      if (phase === 'talk') {
        if (confirm) {
          if (!cur) return true;
          const text = textOf(cur);

          // A single physical press may reveal OR advance. Repeated keydown events
          // from a held confirm are ignored until keyup; controller-like confirm
          // pulses get a short time fallback so they cannot become permanently
          // locked if the platform never emits a keyup for synthetic actions.
          confirmHeld = true;
          // A held confirm on a line already read is an accelerator, not a
          // press. Let it through to the reveal loop rather than swallowing it.
          const replayMode = replay?.seenTextMode?.() || 'normal';
          if (typed < text.length && activeLineSeenBefore && replayMode !== 'normal') return true;

          if (confirmAdvanceLocked) {
            if (e.repeat || now - confirmLockedAt < Math.max(0.24, COMBAT_DIALOGUE_MIN_MANUAL_DWELL)) return true;
            confirmAdvanceLocked = false;
          }

          if (typed < text.length) {
            typed = text.length;
            acc = 1e6;
            handle?.finish?.();
            handle = null;
            audio?.stopTyping?.();
            lineDoneAt = now;
            confirmAdvanceLocked = true;
            confirmLockedAt = now;
            return true;
          }

          if (lineDoneAt == null) lineDoneAt = now;
          if (now - lineDoneAt < COMBAT_DIALOGUE_MIN_MANUAL_DWELL) return true;

          const view = currentBattleDialogueView();
          if (view.hasMore) {
            talkPage = view.page + 1;
            lineDoneAt = now;
            confirmAdvanceLocked = true;
            confirmLockedAt = now;
            audio?.menuMove?.();
            return true;
          }

          nextLine();
          confirmAdvanceLocked = true;
          confirmLockedAt = now;
        }
        return true;
      }
      if (phase === 'resolve') {
        // A parryable enemy strike owns confirm until contact. It cannot be
        // accidentally fast-forwarded out from under the player, and an early
        // press outside the small buffer teaches WAIT without spending the try.
        const opportunity = parryWindow();
        if (confirm && opportunity && !resolution.impactFired) return attemptParry(e);
        if (confirm && opportunity && resolution.impactFired) {
          finishResolution();
          return true;
        }
        if (confirm && resolution && resolution.elapsed >= .22) {
          if (!resolution.impactFired) fireImpact();
          finishResolution();
        }
        return true;
      }
      if (!['tool', 'move'].includes(phase)) return true;
      if (!back) skipArmed = false;
      const direction = combatDeckDirection(e);
      if (direction) navigateDeck(direction);
      else if (String(e.key || '').toLowerCase() === 'q' || e.controllerAction === 'tabPrev') cycleChannel(-1);
      else if (String(e.key || '').toLowerCase() === 'e' || e.controllerAction === 'tabNext') cycleChannel(1);
      else if (back && phase === 'move') navigateDeck('up');
      else if (back && phase === 'tool' && director?.active?.()) {
        // The drill can always be walked away from: one Back warns, two skip it.
        if (skipArmed) {
          skipDrill();
        } else {
          skipArmed = true;
          notice = 'BACK AGAIN TO SKIP THE DRILL';
          audio?.menuMove?.();
        }
      } else if (confirm && phase === 'move') {
        const move = moves()[selectedMove];
        if (move?.enabled) pressDeckControl(`combat:action:${move.id}`, e);
        execute(move?.id);
      }
      return true;
    },

    keyup(e) {
      if (isConfirmInput(e) || e.controllerAction === 'start') entryConfirmLocked = false;
      releaseDeckControl(e);
      if (isConfirmInput(e)) {
        confirmAdvanceLocked = false;
        confirmHeld = false;
        return phase === 'talk';
      }
      return false;
    },

    pointer(e) {
      if (phase === 'desktop-breach') return true;
      if (phase === 'prepare') return preparationMenu?.pointer(e) ?? true;
      if (phase === 'ready' || (encounterIntro && phase === 'arrival')) return true;
      if (e.type === 'pointercancel' && e.pointerId == null) {
        resetDeckControls();
        return true;
      }
      if (e.type === 'pointerup' || e.type === 'pointercancel' || e.type === 'lostpointercapture') {
        releaseDeckControl(e);
        return true;
      }
      if (e.type !== 'pointerdown') return true;
      if (e.button != null && e.button !== 0) return true;
      const x = Number(e.cellX);
      const y = Number(e.cellY);
      if(['tool','move','resolve'].includes(phase)&&fireballRect
        &&x>=fireballRect.x&&x<fireballRect.x+fireballRect.w
        &&y>=fireballRect.y&&y<fireballRect.y+fireballRect.h){
        const metrics=uiCellMetrics();
        const result=fireballExchange.click({
          x:(Number(e.cellX)-fireballRect.x)/Math.max(.001,fireballRect.w),
          y:(Number(e.cellY)-fireballRect.y)/Math.max(.001,fireballRect.h),
          aspect:(fireballRect.w*metrics.cellW)/Math.max(.001,fireballRect.h*metrics.cellH),
          ...(sourceDesktop?.mode?.()==='native'
            ? {radius:Math.max(.085,14/(fireballRect.h*metrics.cellH))} : {}),
        });
        if(result.hit){
          announceFireballHit(result);
          return true;
        }
      }
      if (phase === 'resolve' && reactionRect
        && x >= reactionRect.x && x < reactionRect.x + reactionRect.w
        && y >= reactionRect.y && y < reactionRect.y + reactionRect.h) {
        attemptParry({ key: 'pointer' });
        return true;
      }
      if (!['tool', 'move'].includes(phase)) return true;
      if (skipRect && x >= skipRect.x && x < skipRect.x + skipRect.w && y >= skipRect.y && y < skipRect.y + skipRect.h) {
        skipDrill();
        return true;
      }
      const tab=tabRows.find(row=>y>=row.y&&y<row.y+row.h&&x>=row.x&&x<row.x+row.w);
      if(tab){
        phase=tab.id;takeConfirmation=false;
        pressDeckControl(`combat:tab:${tab.id}`,e);audio?.menuMove?.();return true;
      }
      const section = apparitionRows.find((row) => y >= row.y && y < row.y + (row.h || 1) && x >= row.x && x < row.x + row.w);
      if (section) {
        state = reduceCombat(state, { type: COMBAT_ACTION.TARGET, targetId: section.id });
        notice = state.last.notice;
        audio?.menuMove?.();
        return true;
      }
      const channel = channelRows.find((row) => y >= row.y && y < row.y + (row.h || 1) && x >= row.x && x < row.x + row.w);
      if (channel) {
        state = reduceCombat(state, { type: COMBAT_ACTION.CHANNEL, channel: channel.id });
        persistCheckpoint();
        notice = state.last.notice;
        audio?.menuMove?.();
        return true;
      }
      const tool = toolRows.find((row) => y >= row.y && y < row.y + (row.h || 1) && x >= row.x && x < row.x + row.w);
      if (tool) {
        const entry = tools()[tool.index];
        if (entry?.ready !== false) pressDeckControl(`combat:tool:${entry?.id || 'self'}`, e);
        selectedTool = tool.index;
        selectedMove = 0;
        phase = 'tool';
        takeConfirmation = false;
        audio?.menuMove?.();
        return true;
      }
      const move = moveRows.find((row) => y >= row.y && y < row.y + (row.h || 1) && x >= row.x && x < row.x + row.w);
      if (move) {
        // CLICKING A MOVE IS ENTERING THE MOVE COLUMN.
        //
        // `execute` refuses anything that is not already phase 'move', and the
        // only thing that set that phase was the DOWN key -- so a click on a
        // move tile did nothing at all unless the player had first arrowed into
        // the row, which is precisely the keyboard-only feel this is meant to
        // stop. Pointing at a thing is a way of choosing it.
        selectedMove = move.index;
        phase = 'move';
        if (moves().find((entry) => entry.id === move.id)?.enabled) pressDeckControl(`combat:action:${move.id}`, e);
        execute(move.id);
      }
      return true;
    },

    render() {
      tabRows=[];
      refreshReviewedBattleText();
      preparationMenu?.visible(scenes.top({ includeOverlay:true }) === scene);
      if (phase === 'prepare') {
        // Preparation is the held encounter title, with the same opponent and
        // darkness behind the case. The live fight's meters/hands start at READY.
        drawEncounterSplash(battle,{phase:'versus',reducedMotion:true,showTitle:false,hushBody});
        return;
      }
      // The reprise is a real handoff to the room renderer. Leaving this panel
      // composited underneath the child scene makes the old fight read as the
      // replayed space and hides the very evidence Source is weaponising.
      if (phase === 'interlude') return;
      const { cols, rows } = uiSize();
      uiFill(0, 0, cols, rows, '#020203');
      const w = Math.max(36, cols - 8);
      const x = Math.floor((cols - w) / 2);
      const choosing = ['tool', 'move'].includes(phase);
      const parryPrompt = activeInputPromptDevice() === 'controller'
        ? promptLine([{ action: 'confirm', label: 'PARRY' }])
        : '[SPACE] PARRY';
      const footer = phase === 'interlude'
        ? 'SOURCE HAS THE TRANSPORT'
        : phase === 'desktop-breach'
          ? 'OUTPUT HELD · WAIT'
        : phase === 'prepare'
          ? 'TURNS PAUSED'
        : phase === 'ready'
          ? ''
        : phase === 'arrival'
          ? ''
        : phase === 'tool'
          ? activeInputPromptDevice() === 'controller'
            ? '[STICK / D-PAD ←→] TOOL · [↓] ACTIONS'
            : '[←→ / A D] TOOL · [↓ / S] ACTIONS'
          : phase === 'move'
            ? activeInputPromptDevice() === 'controller'
              ? `${promptLine([{ action: 'select', label: '←→ ATTACK' }, { action: 'confirm', label: 'ACT' }])} · [↑] TOOL`
              : '[←→ / A D] ATTACK · [ENTER] ACT · [↑ / W] TOOL'
            : phase === 'resolve'
              ? (() => {
                const opportunity = parryWindow();
                if (opportunity && !opportunity.spent) {
                  if (opportunity.buffered) return `CONTACT ARMED · ${parryPrompt}`;
                  if (chapelOffer?.phase === 'live') return `${chapelOffer.cue.gamePrompt} / ${parryPrompt}`;
                  return opportunity.armed
                    ? `${parryPrompt} · ${PARRY_TIERS[opportunity.tier]?.label || ''}`
                    : `WAIT FOR CONTACT · ${parryPrompt}`;
                }
                if (resolution?.parried) {
                  return `${PARRY_TIERS[resolution.parryTier]?.label || 'PARRIED'} · [ENTER] CONTINUE`;
                }
                if (opportunity) return 'MISSED CONTACT · [ENTER] CONTINUE';
                return 'RESOLVING · [ENTER] FAST-FORWARD';
              })()
              : promptLine([{ action: 'continue', label: 'CONTINUE' }]);
      const interferenceStatus = interference?.active?.() ? interference?.statusLine?.() : '';
      const panel = drawMachinePanel(x - 2, 1, w + 4, rows - 2, {
        label: 'SIGNAL COMBAT', source: state.source ? 'SOURCE' : 'FIELD', meter: true,
        footer: interferenceStatus ? `${footer} · ${interferenceStatus}` : footer,
      });
      skipRect = null;
      if (director?.active?.() && choosing) {
        const skipLabel = activeInputPromptDevice() === 'controller'
          ? skipArmed
            ? `${promptLine([{ action: 'back', label: 'AGAIN' }])} / CLICK TO SKIP`
            : `${promptLine([{ action: 'back', label: '×2' }])} / CLICK SKIP DRILL`
          : skipArmed ? 'BACK AGAIN / CLICK TO SKIP' : 'BACK×2 / CLICK SKIP DRILL';
        const skipX = x + w - skipLabel.length;
        const skipY = rows - 3;
        uiText(skipX, skipY, skipLabel, skipArmed ? 'ui-danger' : 'ui-amber', skipArmed ? .95 : .72);
        skipRect = { x: skipX, y: skipY, w: skipLabel.length, h: 1 };
      }
      const reaction = parryWindow();
      const hudMode = reaction ? 'reaction'
        : phase === 'talk' ? 'dialogue'
          : ['arrival','prepare','ready'].includes(phase) ? 'arrival' : 'command';
      const desktopIsland = sourceDesktop?.mode?.() === 'native';
      const layout = combatHudLayout({ panel, mode: hudMode, sourceActive: !!state.source, rosterActive: !!state.apparitions || !!state.practice, desktop:desktopIsland });
      const compact = layout.compact;
      reactionRect = null;
      const visual = visualState();
      const movementData = movement(visual.movementIndex) || movement();
      const art = opponentArt(
        cur?.art || movementData?.art || battle.art || battle.combat.art,
        battle.combat.id,
      );
      regionRects = {};

      // ── header: enemy name, signature rule, enemy phase pips ───────────────
      const enemyName = String(battle.enemy || battle.combat.enemy);
      if (compact&&!layout.dense) uiText(panel.x, panel.y, enemyName.slice(0, panel.w - 20), 'ui-danger');
      else if(!compact) drawVfdText(panel.x, panel.y, enemyName.slice(0, Math.max(6, Math.floor((panel.w - 24) / 2))), { scale: 2 });
      const signature = battle.combat.signature;
      if (signature?.label && !desktopIsland&&!layout.dense) {
        const tag = `SIGNATURE · ${signature.label}`;
        uiText(panel.x + Math.max(0, panel.w - tag.length), panel.y, tag, 'ui-amber', .66);
      }
      // Health snaps at the moment of impact and leaves ghost segments behind —
      // before the hit lands, the bars still show the pre-hit reading.
      const preImpact = !!resolution && !resolution.impactFired;
      const snap = preImpact ? resolution.before : state;
      const transitioned = !preImpact && resolution?.after?.last?.transition != null;
      const ghostFor = (record) => (record && now - record.at < .7
        ? { ghostFrom: record.from, ghostAge: now - record.at }
        : { ghostFrom: null, ghostAge: 0 });

      const movementCount = battle.combat.movements.length;
      const enemyBarY = layout.enemyGauge.y;
      drawCombatGauge({
        x: layout.enemyGauge.x, y: enemyBarY, w: layout.enemyGauge.w,
        value: transitioned ? 0 : snap.movementCoherence,
        max: snap.movementMaxCoherence,
        label: `${layout.dense?enemyName:movementData?.title || 'COHERENCE'} ${visual.movementIndex + 1}/${movementCount}`,
        tone: 'enemy',
        now,
        ...ghostFor(barGhost.coherence),
      });
      if(layout.returnMonitor.w >= 10){
        drawVfdText(layout.returnMonitor.x,enemyBarY,`RETURN ${performanceStage}`.slice(0,Math.floor(layout.returnMonitor.w)),{scale:1,role:performanceStage==='CORRECTION'?'ui-danger':'ui-amber'});
        drawLocationIndicator(layout.returnMonitor.x,enemyBarY+1,layout.returnMonitor.w,performanceIntrusion,{theme:performanceStage==='CORRECTION'?'red':'amber'});
      }

      // Whose beat it is + the exchange count, as a persistent glyph readout in
      // the header. The enemy beat is the opponent's turn; anything else is yours.
      if (layout.turn.w > 0) {
        drawTurnGlyph(layout.turn.x, enemyBarY, {
          active: resolution?.side === 'enemy' ? 'enemy' : 'player',
          turn: turnCount,
          reducedMotion: shakeMode() !== 'full',
          now,
        });
      }

      // ── the void stage: one continuous backdrop, opponent right-of-centre in
      // an oblique fight stance, hands rising from the near-left ──────────────
      const stageY = layout.stage.y;
      const stageH = layout.stage.h;
      const metrics = uiCellMetrics();
      const presentation = sourceDesktop?.frame?.(desktopFrame(),{
        x:panel.x*metrics.cellW,y:stageY*metrics.cellH,w:panel.w*metrics.cellW,h:stageH*metrics.cellH,
      });
      const sourceStage = !!presentation?.ready;
      const worldStage=cathedral;
      if (sourceStage || desktopIsland) hushBody?.desktop();
      if ((sourceStage||worldStage) && !desktopIsland) uiDraw(({ctx,dpr,cellW,cellH}) => ctx.clearRect(panel.x*cellW*dpr,stageY*cellH*dpr,panel.w*cellW*dpr,stageH*cellH*dpr));
      // The passive desktop is never an input target. Its ranged exchange has
      // a dedicated aperture in the command header, clear of the status line.
      fireballRect=desktopIsland
        ? {x:panel.x+panel.w*.62,y:panel.y+1.05,w:panel.w*.38,h:stageY+stageH-panel.y-1.05}
        : {x:panel.x,y:stageY,w:panel.w,h:stageH};
      const reducedMotion = shakeMode() !== 'full';
      const introP = Math.max(0, Math.min(1, encounterIntro ? (introElapsed - .38) / 1.16 : introElapsed / 1.05));
      const introIn = reducedMotion ? 1 : ease(introP);
      const dealtFlash = impactFx && impactFx.dealt > 0 ? Math.max(0, 1 - (now - impactFx.at) / .18) : 0;
      const hurtNow = impactFx && impactFx.received > 0 ? Math.max(0, 1 - (now - impactFx.at) / .35) : 0;
      const preparing = phase === 'prepare';
      const ew = state.apparitions?Math.min(68,panel.w*.60):Math.min(40, Math.floor(panel.w * (preparing ? .27 : .36)));
      const eh = Math.max(4, stageH - 1);
      const ex = state.apparitions?panel.x+panel.w*.38:panel.x + (preparing ? Math.floor(panel.w * .84 - ew / 2) : Math.floor(panel.w * .56 - ew / 2)) + Math.round((1 - introIn) * panel.w * .45);
      if (!sourceStage && !desktopIsland&&!worldStage) drawEnemyVoidStage(battle.combat.id, {
        x: panel.x, y: stageY, w: panel.w, h: stageH,
        enemyBox: { x: ex, w: ew },
        resolveProgress: visual.progress,
        reduceFlash: flashMode() !== 'full',
        environmentLighting,
      });
      // Whose turn it is, stated over the opponent it belongs to. The enemy beat
      // is the opponent's own turn now, so it gets a lit banner centred on the
      // being the moment control leaves the player.
      if (!sourceStage && !desktopIsland && resolution?.side === 'enemy') {
        const hits = resolution.after?.last?.enemyHits?.length || 1;
        const chained = hits > 1;
        const actorLabel = resolution.intent?.actorLabel || resolution.after?.last?.enemyActor?.label || 'ENEMY';
        const banner = chained ? `${actorLabel} TURN · CHAIN` : `${actorLabel} TURN`;
        uiText(ex + Math.floor((ew - banner.length) / 2), stageY, banner, 'ui-danger', .95);
        // What they are playing, made visible: notes come off the figure and keep
        // dancing for as long as the attack lasts. A chain throws more of them.
        // Seeded off the turn and the action so the swarm is stable frame to
        // frame instead of reshuffling every render.
        drawAttackNotes({
          x: ex, y: stageY + Math.min(1, stageH * .12), w: ew,
          h: Math.max(.1, stageH - Math.min(1, stageH * .12)),
          count: Math.min(9, 3 + hits * 2),
          now,
          seed: (state.turn || 0) * 31 + (resolution.action?.kind || '').length * 7 + hits,
          reducedMotion,
          alpha: .55 + (1 - visual.progress) * .45,
        });
      }
      const intentState = resolution?.before || state;
      // On the enemy beat, show the intent actually landing (a board-state
      // reaction may have overridden the cycle intent); otherwise show what the
      // player is bracing against.
      // Before the blow, this is the READ — what the recordist believes is
      // coming — because everything drawn from it is something they can see:
      // the thought trace, and the shape the opponent takes on the stage. On
      // the enemy beat it becomes the truth, which is how the misread is
      // revealed: the thing that arrives is not the thing that was drawn.
      const intent = resolution?.side === 'enemy'
        ? (resolution.intent||{ kind: resolution.action?.kind || currentCombatIntent(intentState)?.kind || null })
        : predictedCombatIntent(intentState);
      // THE HALL. One encounter has more than one thing in it, and a single
      // figure on the void stage cannot say so. The three bodies share the box
      // the being would have had, so the banner and attack notes still land.
      const apparitions = combatApparitions(snap);
      if (sourceStage || desktopIsland||worldStage) {
        // The borrowed Pressure rig owns this stage; its code-bearing shell is
        // the same finite shelter the combat reducer can spend or lose.
      } else if (apparitions) {
        drawHallApparitions(apparitions, {
          x: ex, y: stageY + 1, w: ew, h: Math.max(3, eh - 1),
          now, reducedMotion, captions:false,
          // They watch you. The lean follows the selected tool across the deck,
          // which is the only thing on screen that stands in for where he is.
          watch: Math.sin(now * .55) * .5,
          dim: transitioned ? .5 : 1,
        });
      } else if (art?.procedural || hushBody) {
        const cage = fieldSignalCage(battle);
        const stage = { x:ex, y:stageY, w:ew, h:eh };
        hushBody?.draw({ ...stage, x:ex + (reducedMotion ? 0 : dealtFlash * 1.4) }, {
          clip:{x:panel.x,y:stageY,w:panel.w,h:stageH}, clock:now,
          intentKind:intent?.kind, resolveProgress:visual.progress,
          reducedMotion, reduceFlash:flashMode()!=='full',
        });
        if (cage || !hushBody) drawSignalBeing(cage || battle.combat.id, {
          ...stage, cageOnly:!!cage,
          snr: state.snr,
          coherenceRatio: (transitioned ? 0 : snap.movementCoherence) / Math.max(1, snap.movementMaxCoherence),
          movementIndex: visual.movementIndex,
          intentKind: intent?.kind || null,
          now,
          resolveProgress: visual.progress,
          reducedMotion,
          oblique: -.05,
          hitFlash: dealtFlash,
          knock: dealtFlash * 1.4,
        });
      } else {
        drawOpponentCombatArt(art, {
          x: ex, y: stageY, w: ew, h: eh,
          coherence: transitioned ? 0 : snap.movementCoherence,
          maxCoherence: snap.movementMaxCoherence,
          snr: state.snr,
          resolveProgress: visual.progress,
          reduceFlash: flashMode() !== 'full',
          oblique: -.05,
          hitFlash: dealtFlash,
          knock: dealtFlash * 1.4,
        });
      }

      if(repriseReturnPulse>0){
        const strength=clamp(repriseReturnPulse/.84,0,1);
        const bands=reducedMotion?2:4;
        for(let band=0;band<bands;band+=1){
          const gy=stageY+1+((band*5+Math.floor(now*22))%Math.max(1,eh-1));
          const gw=Math.max(5,Math.floor(ew*(.28+strength*.42)));
          uiFill(ex+(band%2?Math.max(0,ew-gw):0),gy,gw,1,`rgba(255,58,42,${(.08+strength*.18).toFixed(3)})`);
        }
        const write='TAKE ACCEPTED // SOURCE WRITE';
        uiText(ex+Math.floor((ew-write.length)/2),Math.min(stageY+stageH-1,stageY+eh-1),write,'ui-danger',.62+strength*.38);
      }

      const fireball=fireballExchange.snapshot();
      // Drawn under the comets and over the room: the thing that arrived is in
      // front of the stage it crossed, and the next one is in front of it.
      drawFireballEngulf({
        x:panel.x,y:panel.y,w:panel.w,h:panel.h,
        at:fireballEngulf,now,reducedMotion,answered:!!fireballEngulf?.answered,
      });
      drawFireballCast({
        ...fireballRect,
        cast:fireball.active?.plan||null,
        flights:fireball.active?.rays||null,
        now,reducedMotion,externalPresented:!!fireball.active?.externalPresented,
      });

      const submerged=submergedBattleFrame({
        submersion:submersionSnapshot,
        presentation:battle.combat.presentation,
        movementIndex:visual.movementIndex,
        intent,
      });
      drawSubmergedBattleField({
        x:panel.x,y:panel.y,w:panel.w,h:panel.h,frame:submerged,now,reducedMotion,
        resolveProgress:visual.progress,
      });

      // Optical water treatment has already run. RETURN is type, so it stays on
      // the sharp HUD plane while the projectile itself refracts with the room.
      const returnLabel=fireball.returnReady
        ? 'RETURN / IN FLIGHT'
        : `RETURN ${fireball.charge}/${fireball.threshold}`;
      uiText(panel.x+Math.max(0,panel.w-returnLabel.length),desktopIsland?panel.y:stageY+.25,returnLabel,
        fireball.returnReady?'ui-counter':'ui-amber',fireball.charge||fireball.returnReady?1:.58);

      // THE CLOCK, WHERE HIS HANDS ARE.
      //
      // A bar rather than a number: the point is not how many seconds are left,
      // it is that they are going. Red for the last second and a half, which is
      // the only part anybody actually reads.
      if(turnClock&&['tool','move'].includes(phase)){
        const left=Math.max(0,turnClock.left),span=Math.max(.001,turnClock.limit);
        const width=Math.max(6,Math.min(18,Math.floor(panel.w*.22)));
        const filled=Math.max(0,Math.min(width,Math.round(width*(left/span))));
        const urgent=left<=1.5;
        const bar=`${'█'.repeat(filled)}${'·'.repeat(width-filled)}`;
        const blink=urgent&&!reducedMotion?(Math.floor(now*6)%2?1:.5):1;
        const clockX = desktopIsland ? layout.returnMonitor.x : state.sourceDesktop
          ? panel.x + Math.max(0,panel.w-returnLabel.length-width-3) : panel.x;
        uiText(clockX,desktopIsland?panel.y:stageY+.25,bar,urgent?'ui-danger':'ui-amber',blink);
      }

      const injury = combatInjuryStage({ composure: snap.composure, maxComposure: snap.maxComposure, injuries: state.injuries });
      const handFrame = handsSnapshot({ injury, hurt: hurtNow, reaction });
      const selectedToolId = handFrame.tool;
      const lh = Math.min(12, stageH);
      const rh = Math.min(9, Math.max(4, stageH - 2));
      const introDrop = (1 - introIn);
      if (!desktopIsland&&!worldStage) drawFirstPersonHands(selectedToolId, {
        stage: { x: panel.x, y: stageY, w: panel.w, h: stageH },
        left: {
          x: panel.x + Math.floor(panel.w * (state.apparitions?.04:.13)) - introDrop * panel.w * .35,
          y: stageY + stageH - lh + introDrop * lh * .7,
          w: Math.min(32, Math.floor(panel.w * .28)),
          h: lh,
        },
        right: {
          x: panel.x + Math.floor(panel.w * (state.apparitions?.22:.62)) - introDrop * panel.w * .18,
          y: stageY + stageH - rh + introDrop * rh * .9,
          w: Math.min(24, Math.floor(panel.w * .21)),
          h: rh,
        },
        ...handFrame,
      });

      // The spark starts at the handheld jumper and ends at the deck's input.
      // Reduced flash leaves the same route indication and take label.
      if (!desktopIsland && resolution?.side === 'player' && resolution.impactFired
        && resolution.after.last?.bridge?.route === 'rec' && flashMode() === 'full' && impactFx) {
        const spark = Math.max(0, 1 - (now - impactFx.at) / .17);
        if (spark > 0) {
          const x = panel.x + panel.w * (state.apparitions ? .27 : .68);
          const y = stageY + stageH - rh * .54;
          for (const [dx,dy] of [[2.6,-.75],[1.8,-1.4],[-2.2,-.45],[.7,-1.8]]) {
            uiLine(x,y,x+dx*.43,y+dy*.62,'#ffe19d',spark*.85,1.4);
            uiLine(x+dx*.43,y+dy*.62,x+dx,y+dy,'#e69a4b',spark*.67,.9);
          }
        }
      }

      // ── stage overlays: intent card (left) and stance triangle (right) ─────
      const showOverlays = !desktopIsland && !['arrival', 'talk', 'prepare', 'ready','desktop-breach'].includes(phase) && !reaction;
      const intentX = panel.x + 1;
      const intentW = Math.min(34, Math.floor(panel.w * .30));
      const overlay=combatStageOverlayLayout({stage:layout.stage,panel,compact,group:!!state.apparitions,phase});
      if (showOverlays) {
        if (phase === 'resolve' && resolution && overlay.rows) {
          const last = resolution.after.last || {};
          const impactLine = [
            last.dealt ? `-${last.dealt} COHERENCE` : '',
            last.received ? `-${last.received} COMPOSURE` : '',
            last.snrFrom !== last.snrTo ? `${String(last.snrFrom).toUpperCase()} → ${String(last.snrTo).toUpperCase()}` : '',
          ].filter(Boolean).join(' · ') || 'POSITION HELD';
          // ── the strike banner ──────────────────────────────────────────────
          // Every enemy blow says itself: WHO does WHAT, with WHICH instrument,
          // and then whether it worked. The fight used to print only the numbers
          // and leave the player to infer, from -1 COMPOSURE, which move they had
          // just been hit by — a move they had never seen named.
          if (resolution.side === 'enemy' && strike) {
            const who = String(battle.enemy || 'THE SIGNAL').toUpperCase();
            const verdict = strikeVerdict(last, { parried: resolution.parried });
            if(overlay.rows===1)uiText(intentX,overlay.top,`${strike.label} · ${verdict.text}`.slice(0,intentW),verdict.role,.95);
            else{
              drawVfdText(intentX,overlay.top,`${who} ${strike.verb}`.slice(0,intentW),{scale:1,role:'ui-danger'});
              const detail=overlay.rows>=4?1:0;
              if(detail)uiText(intentX,overlay.top+1,`${strike.label} · ${strike.instrument}`.slice(0,intentW),'ui-amber',.9);
              uiText(intentX,overlay.top+1+detail,verdict.text.slice(0,intentW),verdict.role,.95);
              if(overlay.rows>=3)uiText(intentX,overlay.top+2+detail,
                (readMissed&&overlay.rows<5?'NOT WHAT YOU READ':impactLine).slice(0,intentW),
                readMissed&&overlay.rows<5?'ui-danger':'ui-secondary',.8);
              if(readMissed&&overlay.rows>=5)uiText(intentX,overlay.top+4,'NOT WHAT YOU READ','ui-danger',.8);
            }
            // The blow that arrived was not the blow the recordist named. Said
            // plainly, at the moment it lands, so a misread reads as a thing
            // that happened rather than as the card having glitched.
          } else if (resolution.side === 'player' && last.bridge?.route === 'rec') {
            drawVfdText(intentX,overlay.top,'BYPASS ARC · RECORDER FIRED',{scale:1,role:'ui-amber'});
            if (overlay.rows>1) uiText(intentX,overlay.top+1,'CROSSED RETURN PRINTED','ui-blue',.8);
          } else if (last.perfect) {
            const scale=overlay.spacious?2:1;
            drawVfdText(intentX,overlay.top,'PERFECT RESPONSE',{scale,role:'ui-counter'});
            const why = `${resolution.action.label} COUNTERS ${String(intent?.kind || '').toUpperCase()} — HIT NEGATED · TEMPO OPENS`;
            if(overlay.rows>scale)uiText(intentX,overlay.top+scale,why.slice(0,intentW),'ui-amber',.8);
            if(overlay.rows>scale+1)uiText(intentX,overlay.top+scale+1,impactLine.slice(0,intentW),'ui-secondary',.75);
          } else {
            drawVfdText(intentX,overlay.top,impactLine.slice(0,intentW),{scale:1,role:last.received?'ui-primary':'ui-counter'});
          }
        } else if (intentState.tempo && overlay.rows) {
          const scale=overlay.spacious?2:1;
          drawVfdText(intentX,overlay.top,'TEMPO OPEN',{scale,role:'ui-counter'});
          if(overlay.rows>scale)uiText(intentX,overlay.top+scale,'FREE ACTION · THE SIGNAL WAITS'.slice(0,intentW),'ui-amber',.7);
          regionRects.tempo={x:intentX,y:overlay.top,w:intentW,h:Math.min(overlay.rows,scale+1)};
        } else if (intent && overlay.rows && ['full','trace'].includes(state.difficulty.guidance)) {
          // Not a readout. A guess — see thought-trace.js. The recordist says
          // what they reckon is coming and what they mean to do about it, and
          // how sure they sound is itself the information the old INTENT · KIND
          // · DMG · COUNTER card was spelling out in capitals.
          //
          // The counter no longer needs naming in prose: the move it points at
          // is already lit green in the command band, which is where the
          // player's hands are. The thought says why that tile is lit.
          const fidelity = readFidelity(intentState);
          const { lines: thought } = thoughtTrace(intentState, {
            intent,
            alternative: rivalCombatIntent(intentState),
            counters: counterMovesForIntent(intentState, intent),
            wrong: readMissed,
            fidelity,
            guidance: state.difficulty.guidance,
            stance: state.stance?.id || null,
            // Prevention only ever blunts the first hit of a chain, so a chained
            // blow slips a guard that would otherwise have covered it.
            chained: (selectEnemyIntents(intentState).length || 1) > 1,
            chargeReady: availableCombatActions(intentState).some((move) => move.special && move.enabled),
            apparitions,
          });
          const thoughtContext = { sceneId: `battle:${battle.id}`,
            nodeId: `movement:${movement(intentState.movementIndex)?.id || intentState.movementIndex}:intent:${intent.id || intent.kind}:phase:${intentState.phase || phase}` };
          const stageThought=thought.slice();
          if(state.enemyGuard){
            const guarding=state.enemyGuard.mode==='parry'?'turn':'slip';
            stageThought.push({text:`it's set to ${guarding} my swing.`,tone:'warn'});
          }
          let intentRow=0;
          for (const line of fitBattleStageThoughts(stageThought,overlay.rows)) {
            const role = line.tone === 'miss' || line.tone === 'warn' ? 'ui-danger'
              : line.tone === 'plan' ? 'ui-counter'
                : line.tone === 'stance' ? 'ui-amber' : 'ui-primary';
            const reviewed = battleThoughtReviewLine(line, thoughtContext);
            const displayed = textOf(reviewed).slice(0, intentW);
            uiText(intentX,overlay.top+intentRow,displayed,role,line.tone==='read'?.82:.95);
            registerBattleReviewRow(reviewed,displayed,intentX,overlay.top+intentRow,intentW);
            intentRow += 1;
          }
          // The surfer's guard is telegraphed here too, in the same voice:
          // swing into it and it slips or turns the hit, so the read is to set
          // up instead.
          regionRects.intent={x:intentX,y:overlay.top,w:intentW,h:intentRow};
        }

        const stW=overlay.stance.w;
        const stX=overlay.stance.x;
        const stY=stageY+1;
        const pendingShift = phase === 'move' ? moves()[selectedMove]?.stanceShift || null : null;
        const stanceId = String(state.stance?.id || 'reading').toUpperCase();
        if(overlay.stance.visible&&overlay.stance.named){
          const label=stW>=stanceId.length+9?`STANCE · ${stanceId}`:stanceId;
          uiText(stX,overlay.stance.y,label.slice(0,stW),'ui-amber',.75);
          regionRects.stance={...overlay.stance};
        } else if(overlay.stance.visible) {
          uiText(stX, stY, `SNR · ${stanceId}`.slice(0, stW), 'ui-label', .62);
          const stanceRect = drawStanceTriangle(stX, stY + 1, stW, { snr: state.snr, pendingShift, compact: false });
          regionRects.stance = { ...stanceRect, y: stY, h: stanceRect.h + 1 };
        }
      }

      // ── floating damage numbers ─────────────────────────────────────────────
      popups = popups.filter((popup) => now - popup.born < .95);
      for (const popup of desktopIsland ? [] : popups) {
        if (now < popup.born) continue; // staggered chain popup, not born yet
        const t = (now - popup.born) / .95;
        const rise = ease(Math.min(1, t * 1.3)) * 2.6;
        const alpha = t < .12 ? 1 : Math.max(0, 1 - (t - .12) / .88);
        const ax = (popup.anchor === 'enemy' ? ex + ew * .64 : panel.x + Math.floor(panel.w * .30)) + popup.jx;
        const ay = popup.anchor === 'enemy' ? stageY + 2.4 : stageY + stageH - 3.4;
        if (popup.value != null) {
          const punch = t < .12 ? 1.5 - (t / .12) * .5 : 1;
          const scale = (popup.kind === 'received' ? 1.35 : 1.05) * punch;
          const color = popup.kind === 'received' ? `rgba(255,86,80,${alpha.toFixed(3)})`
            : popup.kind === 'heal' ? `rgba(126,214,150,${alpha.toFixed(3)})`
              : `rgba(255,196,84,${alpha.toFixed(3)})`;
          drawVfdCounter(ax, ay - rise, String(popup.value), { scale, color });
        } else {
          uiText(ax, ay - rise, popup.text, popup.role || 'ui-amber', alpha);
        }
      }

      // ── the entry wipe: opponent clears in from one side, you from the other
      drawBattleWipe({ x: panel.x, y: stageY, w: panel.w, h: stageH, progress: introP, reducedMotion });
      if (state.sourceDesktop) {
        const shell = sourceDesktopFrame(state);
        const cover = `${'■'.repeat(shell.cover.count)}${'□'.repeat(Math.max(0,shell.cover.capacity-shell.cover.count))}${'×'.repeat(3-shell.cover.capacity)}`;
        const status = phase === 'desktop-breach' ? desktopReady ? 'SHELL DISSOLVING' : 'HOLDING THE FIGHT'
          : desktopIsland ? 'SOURCE / DESKTOP' : shell.breached ? 'SOURCE / IN WINDOW' : 'SOURCE / SHELTER';
        const read = desktopIsland ? ` · ${String(intent?.kind||'').toUpperCase()} / ${String(state.stance?.id||'reading').toUpperCase()}` : '';
        uiText(panel.x+1,stageY,`${status} · ${cover} · ${shell.cover.exposed?'EXPOSED':`GUARD ${shell.cover.guard}`}${read}`.slice(0,panel.w-2),'ui-amber',.94);
        if (desktopIsland && stageH > 1.8) uiText(panel.x+1,stageY+1,`${String(intent?.kind||'').toUpperCase()} · ${String(state.stance?.id||'reading').toUpperCase()} · ${String(state.snr||'').toUpperCase()}`.slice(0,panel.w-2),'ui-secondary',.76);
      }

      // ── the command band ────────────────────────────────────────────────────
      const cmdY = layout.playerGauge.y;
      const bottom = layout.contentBottom;
      uiLine(panel.x, cmdY - .4, panel.x + panel.w, cmdY - .4, UI_COLOR.frame, .55);
      drawCombatGauge({
        x: layout.playerGauge.x, y: cmdY, w: layout.playerGauge.w,
        value: snap.composure, max: snap.maxComposure,
        label: 'YOU · COMPOSURE',
        now,
        ...ghostFor(barGhost.composure),
      });
      drawCombatReadouts(layout,snap);
      for(const[id,cell]of Object.entries(layout.resourceCells))regionRects[id]=cell;
      const shortName=id=>id.split('.').pop().replaceAll('-', ' ').toUpperCase();
      const passives=state.techniques.filter(id=>!ACTIVE_TECHNIQUE_IDS.has(id));
      const actives=state.techniques.filter(id=>ACTIVE_TECHNIQUE_IDS.has(id));

      const interferenceLine = interference?.line?.();
      if (interferenceLine && !bark) {
        uiText(layout.body.x, layout.body.y, String(interferenceLine.text || '').slice(0, layout.body.w), interferenceLine.stage === 'handoff' ? 'ui-danger' : 'ui-amber', .92);
      }

      // A BARK, over the deck rather than in place of it.
      //
      // This is the whole point of the on-listen channel: the thing talks while
      // the take is running, and the player keeps their hands on the tools. So
      // it draws here — after the command band, before the deck is laid out —
      // and it takes one row it can have without hiding a move. It cannot
      // collide with the interference line above because that path returns.
      if (bark && phase !== 'talk') {
        const who = whoOf(bark);
        const prefix = who === 'direction' ? '' : `${who} — `;
        const spoken = `${prefix}${textOf(bark)}`;
        uiText(layout.detail.x, layout.detail.y, spoken.slice(0, layout.detail.w), who === 'direction' ? 'ui-secondary' : 'ui-primary', .88);
        registerBattleReviewRow(bark, textOf(bark), layout.detail.x + prefix.length, layout.detail.y, layout.detail.w - prefix.length);
      }

      if (phase === 'arrival') {
        return;
      }
      if (phase === 'desktop-breach') {
        toolRows=[];moveRows=[];channelRows=[];reactionRect=null;
        uiText(layout.body.x,layout.body.y,'YOUR PROGRESS HOLDS. THE SHELTER DOES NOT.'.slice(0,layout.body.w),'ui-primary',.9);
        uiText(layout.body.x,layout.body.y+1.3,'HOLD rebuilds surviving cover. EXPOSE spends it for a counter.'.slice(0,layout.body.w),'ui-secondary',.78);
        if(!desktopIsland){
          // The contained fallback fails across its output, not in a little
          // error card inside the opponent portrait. The ledger stays below it.
          const failure=sourceDesktopFailureBeat(desktopElapsed);
          if(failure.diagnostic>0)uiDraw(({ctx,dpr,cellW,cellH})=>{
            ctx.scale(dpr,dpr);
            const bounds=sourceDesktopDiagnosticLayout(cols*cellW,rows*cellH,{command:{y:layout.playerGauge.y*cellH}});
            paintSourceDesktopDiagnostic(ctx,bounds,{opacity:failure.diagnostic});
          });
        }
        return;
      }
      if (phase === 'prepare') return;
      if (phase === 'ready') {
        drawVfdText(panel.x + Math.max(0, (panel.w - 18) / 2), stageY + stageH * .5, 'YOUR TURN', {scale:2});
        return;
      }

      if (phase === 'talk' && cur) {
        // Dialogue gets a real command-card region during battles. Long lines are
        // paged with a visible MORE state instead of being silently dropped, and
        // the combat stage is slightly shorter while this card is active.
        const speakerY = layout.dialogue.y;
        const textY = speakerY + 1;
        const hintY = bottom;
        const maxTextRows = Math.max(2, Math.floor(hintY - textY));
        const dlgW = Math.max(20, panel.w - 2);
        const who = whoOf(cur);
        const text = textOf(cur);
        // A LEAD-IN. One utterance split across two registers: the first half
        // arrives as an unattributed fragment and the text finishes it.
        //
        // This used to be authored by putting the fragment in `who`, which made
        // it a SPEAKER — shouted in caps, hard-truncated at panel width with no
        // overflow mark, and knocked out of VOICED so the line typed instead of
        // speaking and the music never ducked for it. As its own field it keeps
        // a real speaker, and it wraps.
        const lead = leadOf(cur);
        const leadRows = lead ? hardWrapBattleText(lead, dlgW) : [];
        const bodyIndent = lead ? 2 : 0;
        const view = currentBattleDialogueView({
          width: Math.max(12, dlgW - bodyIndent),
          rows: Math.max(1, maxTextRows - leadRows.length),
        });

        uiText(panel.x, speakerY, who.toUpperCase().slice(0, panel.w), 'ui-label');
        leadRows.forEach((line, index) => {
          uiText(panel.x, textY + index, line.slice(0, dlgW), 'ui-secondary', .74);
          registerBattleReviewRow(cur, line, panel.x, textY + index, dlgW);
        });
        view.rows.forEach((line, index) => {
          uiText(panel.x + bodyIndent, textY + leadRows.length + index,
            line.slice(0, dlgW - bodyIndent), who === 'direction' ? 'ui-secondary' : 'ui-primary');
          registerBattleReviewRow(cur, line, panel.x + bodyIndent, textY + leadRows.length + index, dlgW - bodyIndent);
        });

        const done = typed >= text.length && (!handle || handle.done());
        const hint = view.hasMore
          ? `MORE ${view.page + 1}/${view.pageCount} · PRESS CONTINUE`
          : done ? 'PRESS CONTINUE' : '';
        if (hint) {
          uiText(
            panel.x + Math.max(0, panel.w - hint.length),
            hintY,
            hint.slice(0, panel.w),
            view.hasMore ? 'ui-amber' : 'ui-secondary',
            .72,
          );
        }
        return;
      }

      if (reaction && resolution) {
        // The reaction is the control surface now, not a tiny second action
        // card. The entire panel is also the pointer target for the same
        // semantic input used by Space and controller Confirm.
        const box = layout.reaction;
        reactionRect = box;
        toolRows = [];
        moveRows = [];
        channelRows = [];
        apparitionRows = [];
        uiFill(box.x, box.y, box.w, box.h, 'rgba(7,10,13,.94)');
        uiStrokeRect(box.x, box.y, box.w, box.h, reaction.armed ? UI_COLOR.amber : UI_COLOR.frame, reaction.armed ? .88 : .42, reaction.armed ? 1.6 : 1);
        const contentY = box.y + Math.max(.25, (box.h - 6.4) / 2);
        const incoming = `INCOMING — ${String(strike?.label || resolution.action?.label || 'CONTACT').toUpperCase()}`;
        drawVfdText(box.x + 1, contentY + .3, incoming.slice(0, Math.max(12, Math.floor(box.w * .66))), {
          scale: compact ? 1 : 1.35,
          role: reaction.armed || reaction.contact ? 'ui-danger' : 'ui-amber',
        });
        const promptX = box.x + Math.max(1, box.w - parryPrompt.length - 1);
        uiText(promptX, contentY + .47, parryPrompt, reaction.armed ? 'ui-counter' : 'ui-amber', reaction.armed ? 1 : .68);

        const trackX = box.x + 1;
        const trackW = Math.max(8, box.w - 2);
        const trackY = contentY + 3.05;
        const trackH = compact ? .95 : 1.25;
        const atX = (progress) => trackX + trackW * clamp(progress, 0, 1);
        const openX = atX(reaction.openProgress);
        const goodX = atX(reaction.goodProgress);
        const perfectX = atX(reaction.perfectProgress);
        const impactX = atX(reaction.impactProgress);
        const contactX = atX(reaction.contactEndProgress);
        uiText(trackX, trackY - 1, 'WAIT', 'ui-secondary', .5);
        uiText(openX, trackY - 1, 'TURN', 'ui-blue', .7);
        uiText(perfectX, trackY - 1, 'PERFECT', 'ui-counter', .9);
        uiFill(trackX, trackY, Math.max(0, openX - trackX), trackH, 'rgba(255,255,255,.045)');
        uiFill(openX, trackY, Math.max(0, goodX - openX), trackH, 'rgba(120,220,255,.15)');
        uiFill(goodX, trackY, Math.max(0, perfectX - goodX), trackH, 'rgba(120,220,255,.30)');
        uiFill(perfectX, trackY, Math.max(0, impactX - perfectX), trackH, 'rgba(120,220,255,.60)');
        uiFill(impactX, trackY, Math.max(.3, contactX - impactX), trackH, 'rgba(255,244,230,.75)');
        uiFill(contactX, trackY, Math.max(0, trackX + trackW - contactX), trackH, 'rgba(255,255,255,.035)');
        uiStrokeRect(trackX, trackY, trackW, trackH, UI_COLOR.frame, .55, 1);
        const headX = atX(reaction.progress);
        uiFill(headX - .22, trackY - .35, .5, trackH + .7, reaction.spent ? UI_COLOR.secondary : reaction.armed ? UI_COLOR.primary : UI_COLOR.amber);
        uiLine(impactX, trackY - .55, impactX, trackY + trackH + .55, UI_COLOR.danger, .82, 1.35);

        const result = resolution.parried
          ? `${PARRY_TIERS[resolution.parryTier]?.label || 'TURNED'} · TURNED`
          : resolution.impactFired || resolution.parryWhiffed
            ? 'MISSED CONTACT'
            : reaction.buffered
              ? 'HOLD — CONTACT ARMED'
              : reaction.armed
                ? `NOW — ${PARRY_TIERS[reaction.tier]?.label || 'PARRY'}`
                : resolution.parryEarly
                  ? 'WAIT FOR CONTACT · RELEASE AND PRESS AGAIN'
                  : 'HOLD — WAIT FOR CONTACT';
        const resultRole = resolution.parried ? 'ui-counter'
          : resolution.impactFired || resolution.parryWhiffed ? 'ui-danger'
            : reaction.armed ? 'ui-amber' : 'ui-secondary';
        uiText(box.x + 1, Math.min(box.y + box.h - 1.1, trackY + trackH + .85), result.slice(0, Math.max(1, Math.floor(box.w - 2))), resultRole, .95);
        regionRects.reaction = box;
        return;
      }

      // ── icon-forward command deck ─────────────────────────────────────────
      let listY = layout.channels.h ? layout.channels.y : layout.tools.y;
      channelRows = [];
      apparitionRows = [];
      // ── the Hall apparition target rail ───────────────────────────────────
      //
      // The channel row is Source-only, and no encounter has both — so the Hall
      // borrows the slot for three cards, one per body. Each card carries the
      // apparition's seat, role, health, and current defence, so the decision
      // of which person to target is made from what is on screen
      // now, so the decision of where to point is made from what is on screen
      // rather than from memory. Pointer and touch use the same body targets as
      // Q/E and controller shoulders.
      // ── the transport ─────────────────────────────────────────────────────
      //
      // The practice wing borrows the same slot the Hall roster and the Source
      // channels use. It draws the only three numbers in that room: where the
      // playhead is in the fragment, how many times he has taken it from the
      // top, and what he has managed to hear. There is no opponent gauge because
      // there is no opponent — the bar the file ends at is the whole of it.
      if (state.practice) {
        const wing = combatPractice(state);
        const cardH = Math.max(2.1, layout.channels.h - .55);
        uiFill(panel.x, listY, panel.w, cardH, 'rgba(255,255,255,.018)');
        uiStrokeRect(panel.x, listY, panel.w, cardH, UI_COLOR.frame, .22, 1);

        // The fragment, drawn as bars. The last one is the bar it ends at and it
        // is marked differently, because that is the one he cannot get past.
        const slotW = 2.4;
        const barsW = wing.bars * slotW;
        for (let index = 0; index < wing.bars; index += 1) {
          const bx = panel.x + .8 + index * slotW;
          const here = index + 1 === wing.bar;
          const last = index + 1 === wing.bars;
          const glyph = last ? '▌' : here ? '▐' : '│';
          const role = here ? 'ui-amber' : last ? 'ui-danger' : 'ui-label';
          uiText(bx, listY + .34, glyph, role, here ? 1 : last ? .7 : .4);
        }
        uiText(panel.x + .8, listY + 1.16,
          wing.atEnd ? 'THE FILE ENDS HERE' : `BAR ${wing.bar} OF ${wing.bars}`,
          wing.atEnd ? 'ui-danger' : 'ui-secondary', wing.atEnd ? .9 : .6);

        // THE CLICK, AND THE ONE THAT COMES BACK.
        //
        // Leila practised in here: "a click coming back through the partition.
        // Not enough to count cleanly. Enough to pull the stick out of your hand
        // if you listened to it." The room runs a metronome on the ordinary
        // battle grid, and a second mark sits behind it — the same click,
        // returning late off the partition.
        //
        // The return does not lie to him and it does not take anything: it is
        // simply louder than the grid until he understands the room, and it
        // fades as he does. Three passes at the bar and it is gone, which is
        // what "maintenance packed the grille twice" was always describing.
        const roomForClick = panel.w >= barsW + 30;
        const clickX = panel.x + panel.w - 12;
        if (roomForClick) {
        // The SAME clock the metronome is running on, rushed by exactly as much.
        // Two clocks would have the drawn beat and the heard beat disagreeing in
        // the one room whose whole subject is whether you can trust your time.
        const grid = 60 / practiceTempo(wing.retakes) * 4;
        const phase = reducedMotion ? 0 : (performance.now() / 1000 % grid) / grid;
        const beatOn = phase < .16;
        const returnLag = .085 / grid;                    // the partition, ~85ms behind
        const returnOn = phase >= returnLag && phase < returnLag + .16;
        const returnLevel = Math.max(0, 1 - wing.listens / Math.max(1, wing.listensToStop));
        uiText(clickX, listY + .34, 'CLICK', 'ui-label', .45);
        uiText(clickX + 6, listY + .34, beatOn ? '●' : '○', 'ui-amber', beatOn ? .95 : .3);
        if (returnLevel > 0) {
          uiText(clickX, listY + 1.16, 'RETURN', 'ui-label', .4 * returnLevel);
          uiText(clickX + 6, listY + 1.16, returnOn ? '●' : '○', 'ui-blue',
            (returnOn ? .8 : .25) * returnLevel);
        } else {
          uiText(clickX, listY + 1.16, 'RETURN GONE', 'ui-label', .35);
        }
        }

        // What it has cost and what the next one will. Printed before he presses
        // it, because the point is that he does it anyway.
        // The click only gets a corner if there is one to give it; on a narrow
        // deck the fragment and what he has heard come first.
        const textRight = panel.x + (roomForClick ? panel.w - 13 : panel.w - 1);
        const right = panel.x + Math.max(barsW + 3, panel.w * .40);
        const textW = Math.max(8, Math.floor(textRight - right));
        uiText(right, listY + .34, `FROM THE TOP  ${wing.retakes}`, 'ui-label', .6);
        uiText(right, listY + 1.16, (wing.heard.length
          ? wing.heard.map((pass) => pass.label).join(' · ')
          : 'NOTHING PLAYED BACK YET').slice(0, textW),
        wing.heard.length ? 'ui-blue' : 'ui-label', wing.heard.length ? .75 : .45);
        listY = layout.tools.y;
      }
      if (state.apparitions) {
        const selectedAction=phase==='move'?moves()[selectedMove]?.id:null;
        const snapshot=combatApparitionsSnapshot(snap,selectedAction);
        apparitionRows=drawHallRoster(snapshot,{...layout.channels,dense:layout.dense});
        listY=layout.tools.y;
      }
      if (state.source) {
        const prediction = combatPrediction(state);
        const channelGap = .8;
        const channelH = Math.max(.85,layout.channels.h-(layout.dense?.1:.55));
        const channelW = (panel.w - channelGap * (CHANNELS.length - 1)) / CHANNELS.length;
        CHANNELS.forEach((channel, index) => {
          const armed = channel.id === state.source.armed;
          const x = panel.x + index * (channelW + channelGap);
          uiFill(x, listY, channelW, channelH, armed ? 'rgba(242,168,30,.07)' : 'rgba(255,255,255,.018)');
          uiStrokeRect(x, listY, channelW, channelH, armed ? UI_COLOR.amber : UI_COLOR.frame, armed ? .72 : .2, armed ? 1.35 : 1);
          uiText(x + .7, listY + (layout.dense?.08:.38), `${channel.glyph} ${channel.label}`.slice(0, Math.max(1, Math.floor(channelW - 5))), armed ? 'ui-amber' : 'ui-secondary', armed ? .9 : .58);
          uiText(x + Math.max(1, channelW - 3), listY + (layout.dense?.08:.38), String(state.source.channels[channel.id]), armed ? 'ui-counter' : 'ui-label', armed ? 1 : .58);
          channelRows.push({ id: channel.id, x, y: listY, w: channelW, h: channelH });
        });
        if (!desktopIsland&&!layout.dense) uiText(panel.x, listY + channelH + .12, `SIGNAL ROUTE · ${prediction.outcome.toUpperCase()}`.slice(0, panel.w), 'ui-blue', .6);
        listY = layout.tools.y;
      }

      if(choosing){
        const tabs=drawCombatControlTabs({...layout.tabs,phase,toolLabel:activeTool().label});
        tabRows=[tabs.tools,tabs.actions];regionRects.tabs=layout.tabs;
      }
      const detailY = layout.detail.y;
      const centredWindow = (list, selected, visible) => {
        if (list.length <= visible) return { start: 0, items: list };
        const start = Math.min(Math.max(0, selected - Math.floor(visible / 2)), list.length - visible);
        return { start, items: list.slice(start, start + visible) };
      };

      toolRows = [];
      const toolList = tools();
      const toolGap = .65;
      const visibleToolCount = Math.max(1, Math.min(toolList.length, Math.floor((panel.w + toolGap) / 14)));
      const toolWindow = centredWindow(toolList, selectedTool, visibleToolCount);
      const toolW = (panel.w - toolGap * Math.max(0, toolWindow.items.length - 1)) / Math.max(1, toolWindow.items.length);
      const toolRect = layout.carousel;
      const showToolRow = phase === 'tool';
      if (showToolRow) {
        listY = toolRect.y;
        toolWindow.items.forEach((tool, slot) => {
          const index = toolWindow.start + slot;
          const x = panel.x + slot * (toolW + toolGap);
          drawCombatToolTile(tool, {
            x, y: listY, w: toolW, h: toolRect.h,
            selected: index === selectedTool,
            focused: phase === 'tool' && index === selectedTool,
          });
          toolRows.push({ index, x, y: listY, w: toolW, h: toolRect.h });
        });
        if (toolWindow.start > 0) uiText(panel.x + .2, listY + toolRect.h - .8, '◀', 'ui-secondary', .75);
        if (toolWindow.start + toolWindow.items.length < toolList.length) uiText(panel.x + panel.w - 1.2, listY + toolRect.h - .8, '▶', 'ui-secondary', .75);
        regionRects.tools = toolRect;
      }

      moveRows = [];
      const renderedMoves = phase === 'resolve' && resolution
        ? [{ ...resolution.action, enabled: true, detail: resolution.after.last?.notice || resolution.action.detail,
            ...(resolution.after.last?.bridge?.route === 'rec' ? { bridge:null, consumesTake:false, captures:true } : {}) }]
        : moves();
      const moveGap = .75;
      const visibleMoveCount = Math.max(1, Math.min(renderedMoves.length, Math.floor((panel.w + moveGap) / 17)));
      const moveWindow = centredWindow(renderedMoves, selectedMove, visibleMoveCount);
      const moveRect = layout.carousel;
      const moveY = moveRect.y;
      const moveW = (panel.w - moveGap * Math.max(0, moveWindow.items.length - 1)) / Math.max(1, moveWindow.items.length);
      const showMoveRow = phase !== 'tool';
      if (showMoveRow) {
        moveWindow.items.forEach((move, slot) => {
          const index = moveWindow.start + slot;
          const x = panel.x + slot * (moveW + moveGap);
          drawCombatActionTile(move, {
            x, y: moveY, w: moveW, h: moveRect.h,
            selected: index === selectedMove,
            focused: phase === 'move' && index === selectedMove,
            executing: phase === 'resolve' && resolution?.side === 'player' && resolution.action?.id === move.id,
          });
          moveRows.push({ id: move.id, index, x, y: moveY, w: moveW, h: moveRect.h });
        });
        if (moveWindow.start > 0) uiText(panel.x + .2, moveY + moveRect.h - .8, '◀', 'ui-secondary', .75);
        if (moveWindow.start + moveWindow.items.length < renderedMoves.length) uiText(panel.x + panel.w - 1.2, moveY + moveRect.h - .8, '▶', 'ui-secondary', .75);
        regionRects.moves = moveRect;
      }

      // ── detail, notice, drill callout ──────────────────────────────────────
      if (!bark) {
        const highlighted = phase === 'move'
          ? renderedMoves[selectedMove]
          : phase === 'resolve' && resolution ? resolution.action : null;
        const modifierNames = [...passives, ...actives].map(shortName);
        if (phase === 'tool') {
          const tool = activeTool();
          const summary = `TOOLS · ${tool.label} · ${tool.ready === false ? 'LOCKED' : 'READY'}${modifierNames.length ? ` · MOD ${modifierNames.join(' / ')}` : ''}`;
          uiText(layout.detail.x, detailY, summary.slice(0, layout.detail.w), tool.ready === false ? 'ui-danger' : 'ui-secondary', .64);
        } else if (highlighted) {
          const playerBridge = phase === 'resolve' && resolution?.side === 'player' ? resolution.after.last?.bridge : null;
          const long = playerBridge?.route === 'rec' ? 'BYPASS ARC · RECORDER FIRED · TAKE REPLACED'
            : highlighted.enabled === false
              ? `${highlighted.label} — ${highlighted.reason || 'UNAVAILABLE'}`
              : combatMoveSubtext(state, highlighted).long;
          const summary = `${long}${modifierNames.length ? ` · MOD ${modifierNames.join(' / ')}` : ''}`;
          uiText(layout.detail.x, detailY, summary.slice(0, layout.detail.w), highlighted.bridge?.chance || playerBridge?.route === 'rec' ? 'ui-amber' : 'ui-secondary', .72);
        }
      }

      if (director?.active?.() && choosing) {
        uiText(panel.x, bottom, String(director.prompt()).slice(0, panel.w), 'ui-counter', .92);
        const spotlight = director.spotlight?.();
        const target = spotlight ? regionRects[spotlight] : null;
        if (target) {
          const pulse = .30 + .35 * (0.5 + 0.5 * Math.sin(now * 3));
          uiStrokeRect(target.x - .4, target.y - .2, target.w + .8, target.h + .4, UI_COLOR.amber, pulse, 1);
        }
      } else if (notice && choosing) {
        const summary = takeConfirmation ? notice : `LAST · ${notice}`;
        uiText(panel.x, bottom, summary.slice(0, panel.w), takeConfirmation ? 'ui-danger' : 'ui-amber', .74);
      }
    },
  };

  return scene;
}

export const makeBattleScene = makeCombatScene;

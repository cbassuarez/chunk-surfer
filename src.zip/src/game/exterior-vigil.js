// THE CROWD, OVERHEARD.
//
// Three moments that happen because the player walked somewhere, said by the
// speech band rather than by a scene. Nothing here stops the world, nothing here
// takes the camera, and every one of them can be thrown away mid-sentence.
//
// ── why this is a director and not three sayAll() calls ─────────────────────
//
// Each moment is a CHAIN: a stage direction and then a thought that only makes
// sense after it. Two lines dispatched separately is two independent things that
// can each arrive at the wrong time, and the failure mode is specific and bad —
// the player walks away during the first sentence, and forty seconds later, in a
// corridor, alone, the second half of somebody else's conversation arrives.
//
// So the chain is one lease (game/speech.js). It carries a `valid` predicate
// that is re-checked before every sentence, and when the predicate fails the
// WHOLE dispatch is dropped, tail included. Five things fail it:
//
//   · the player left the moment's radius        (proximity)
//   · a conversation opened                       (nobody talks over a person)
//   · the render context / scene changed          (context key, from speech.js)
//   · a finale is running                         (the night has stopped being this)
//   · Escape                                      (the chain is escapable:true)
//
// Escape is the reason `escapable` is not merely inherited: cancelling the
// visible sentence has to cancel the pending one too, or [Esc] silently becomes
// "skip the direction and keep the punchline".
//
// The director is pure apart from the dispatch factory it is handed, so the spec
// drives it with a fake clock and a fake band.

import { VIGIL_MOMENTS } from '../data/exterior-vigil.js';

// A moment does not re-fire while the player is loitering inside it. It becomes
// available again only after they have been properly out of it — one radius
// further than the trigger — which is what stops a man standing on the boundary
// from re-triggering the crowd every few seconds.
export const VIGIL_REARM_FACTOR = 1.6;
// The whole chain has to get started within this, or it is stale: a line about
// what somebody near the folder just said is worthless nine seconds later.
export const VIGIL_MOMENT_MAX_WAIT_MS = 6_000;

const distance = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

export function createVigilAmbientDirector({
  moments = VIGIL_MOMENTS,
  createDispatch,
  // Everything the moment needs to know about the world that is not a position.
  // Returning true from any of these invalidates the running chain.
  isBlocked = () => false,
} = {}) {
  if (typeof createDispatch !== 'function') throw new TypeError('createVigilAmbientDirector needs createDispatch');
  const list = [...(moments || [])];
  // Fired-once bookkeeping is per session, not per save. These are ambience:
  // a player who reloads and walks back into the forecourt should hear it again,
  // and a player who walks a lap should not.
  const spent = new Set();
  const inside = new Set();
  let active = null;

  function inRadius(moment, x, y) {
    return distance(x, y, moment.at.x, moment.at.y) <= moment.radius;
  }
  function rearmed(moment, x, y) {
    return distance(x, y, moment.at.x, moment.at.y) > moment.radius * VIGIL_REARM_FACTOR;
  }

  function stop() {
    if (!active) return false;
    active.dispatch.cancel?.();
    active = null;
    return true;
  }

  function fire(moment, position) {
    // The lease's own validity closes over the LIVE position, not the position
    // at the moment of firing. That is the whole proximity contract: the tail
    // is spoken only while the player is still standing in the crowd.
    const dispatch = createDispatch({
      id: moment.id,
      context: 'auto',
      maxWaitMs: VIGIL_MOMENT_MAX_WAIT_MS,
      replace: true,
      interrupt: false,
      escapable: true,
      valid: () => {
        if (isBlocked()) return false;
        return inRadius(moment, position.x, position.y);
      },
    });
    for (const line of moment.lines) {
      dispatch.say(
        { who: line.who, text: line.text },
        { delayMs: line.delayMs || 0, gapMs: line.gapMs || 0 },
      );
    }
    spent.add(moment.id);
    active = { id: moment.id, dispatch };
    return active;
  }

  // `position` is a live object the caller keeps updating, in the same
  // yard-physical metres the moments are authored in.
  const position = { x: Infinity, y: Infinity };

  return {
    // Yard-physical metres. Returns the moment that fired this tick, or null.
    update({ x, y } = {}) {
      position.x = Number.isFinite(x) ? x : Infinity;
      position.y = Number.isFinite(y) ? y : Infinity;
      if (active && !active.dispatch.active?.()) active = null;
      const blocked = isBlocked();
      // WALKING OUT DROPS IT HERE, NOT WHEN THE BAND NEXT LOOKS.
      //
      // The lease's own `valid` would refuse the tail anyway — that is the
      // backstop, and it is what covers the frames between ticks — but leaving
      // the moment is a decision the director can see, and a chain that is over
      // should stop being a chain immediately rather than lingering as a
      // live-but-doomed dispatch that suppresses the next one.
      if (active) {
        const running = list.find((moment) => moment.id === active.id);
        if (blocked || !running || !inRadius(running, position.x, position.y)) stop();
      }
      let fired = null;
      for (const moment of list) {
        const here = inRadius(moment, position.x, position.y);
        if (inside.has(moment.id) && rearmed(moment, position.x, position.y)) {
          inside.delete(moment.id);
          // Leaving properly also clears the once-only mark, so a second visit
          // an hour later is allowed to be a first visit again.
          spent.delete(moment.id);
        }
        if (!here || blocked) continue;
        if (inside.has(moment.id) || spent.has(moment.id)) continue;
        inside.add(moment.id);
        if (active) continue;   // one crowd moment at a time, always
        fired = fire(moment, position);
      }
      return fired;
    },
    // An opened conversation, a scene change or a finale calls this. It drops
    // the tail as well as the sentence, which is the point.
    cancel() { return stop(); },
    snapshot() {
      return {
        active: active?.id || null,
        inside: [...inside],
        spent: [...spent],
      };
    },
  };
}

// The moments are authored in yard-physical metres; the runtime knows the yard
// island's logical origin. One conversion, here, so main.js does not carry the
// constant a second time.
export const VIGIL_YARD_LOGICAL_ORIGIN = Object.freeze({ x: 50, y: 200 });
export function vigilYardPhysical(logicalX, logicalY) {
  return {
    x: Number(logicalX) - VIGIL_YARD_LOGICAL_ORIGIN.x,
    y: Number(logicalY) - VIGIL_YARD_LOGICAL_ORIGIN.y,
  };
}

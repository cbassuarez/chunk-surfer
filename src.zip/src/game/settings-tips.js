//
//  settings-tips.js
//  
//
//  Created by Sebastian Suarez-Solis on 7/12/26.
//

// Footer copy for the AUDIOCORP service menu.
//
// Two lanes:
//   SETTING = explains the selected row.
//   PRO TIP = teaches the actual game.
//
// Keep tips non-spoilery, binding-tokenized, and stable over several seconds.
// Do not randomize per frame.

import { getSave } from './save.js';
import { formatBindingTip } from './bindings.js';

const TIP_MS = 9000;

const SETTING_HELP = Object.freeze({
  display: {
    phosphor: 'PHOSPHOR changes the VFD glass, phosphor, or filter look.',
    brightness: 'BRIGHTNESS changes the simulated display panel, not your monitor.',
    flicker: 'LOW flicker adds panel life. FULL makes the display less stable.',
    visualFx: 'VISUAL FX is the master switch for intense screen effects.',
    resetDisplaySettings: 'RESET DISPLAY SETTINGS restores window, UI, and render defaults.',
    default: 'Display settings change the service panel, not the save file.',
  },

  audio: {
    global: 'GLOBAL changes the final output level for the whole game.',
    dialog: 'SPOKEN / DIALOG controls voices, speech synthesis, and dialogue ticks.',
    sfx: 'SFX controls page turns, stabs, hushes, room tone, and object sounds.',
    music: 'MUSIC controls title and intro music only, not stabs or hushes.',
    backgroundAudio: 'BACKGROUND AUDIO can continue while you use another app, or pause until you return.',
    default: 'Separate audio levels let you tune the mix without changing the game.',
  },

  input: {
    controlMap: 'CONTROLLER shows the active controller and can disable controller input.',
    configureController: 'CONFIGURE CONTROLLER opens the button remapping surface.',
    controllerLookSensitivity: 'LOOK SENSITIVITY changes right-stick turning speed.',
    controllerMoveDeadzone: 'MOVE DEADZONE filters left-stick drift.',
    controllerLookDeadzone: 'LOOK DEADZONE filters right-stick drift.',
    controllerInvertLookY: 'INVERT LOOK Y reverses vertical right-stick look.',
    micInput: 'MIC INPUT can use the system default, an interface, or a virtual audio bus.',
    micChannel: 'MIC CHANNEL selects mono, left, or right input analysis for stereo devices.',
    resetInputBindings: 'RESET CONTROLLER restores the default controller settings.',
    testMic: 'TEST MIC shows live loudness without recording or routing audio.',
    rescanMic: 'RESCAN INPUTS refreshes connected microphones and virtual buses.',
    default: 'Input rows configure controller support and optional microphone use.',
  },

  profile: {
    profileStatus: 'FULL means every disclosed module is on. CUSTOM means at least one is off.',
    profileMaster: 'PROFILE MASTER applies the disclosed all-on or all-off choice in one action.',
    profileMicStatus: 'ROOM MICROPHONE measures loudness only during declared authored moments. It never records or recognizes speech.',
    profileSteam: 'STEAM DISPLAY NAME reads only the current persona name, never Steam ID, friends, or account lists.',
    profileOs: 'OS USERNAME is independent from Steam identity and can be revoked separately.',
    profileHost: 'COMPUTER NAME allows the local hostname to personalize inert presentation.',
    profileMicLabel: 'MICROPHONE LABEL uses the selected device label only after ordinary microphone permission exists.',
    profileMeasure: 'MEASUREMENT stores four bounded fictional dimensions, confidence, and sample count—not an event history.',
    profileAdaptive: 'ADAPTIVE DIFFICULTY may move one bounded band at safe checkpoints. Authored assistance and accessibility remain authoritative.',
    profileWindow: 'WINDOW CHOREOGRAPHY affects only game-owned windows and never runs during actionable input.',
    profileWindowIntensity: 'LOW stays in-frame. STANDARD permits restrained geometry. HOSTILE permits the complete authored architecture.',
    profileFiles: 'INTERFERENCE FILES are stored locally and contain limited session summaries and architectural history, not raw behavioral logs.',
    profileRetryMic: 'RETRY MICROPHONE launches the operating-system permission request again.',
    profileRestore: 'RESTORE WINDOWS aborts the active score, restores the main frame, and closes every echo pane.',
    profileOpenReturns: 'OPEN INTERFERENCE FOLDER reveals the local folder that contains Chunk Surfer’s interference files.',
    profileResetInference: 'RESET INFERRED PROFILE returns the four fictional response dimensions to neutral.',
    profileErase: 'ERASE ALL PROFILE DATA disables every module and deletes the profile, identity cache, masking key, and interference files.',
    default: 'This page controls every local psychological-profile module independently.',
  },

  access: {
    textRate: 'TEXT RATE changes how quickly unvoiced text types in.',
    instantText: 'INSTANT TEXT removes type-in delay.',
    flash: 'FLASH / STROBE reduces or disables intense flashes.',
    shake: 'SCREEN SHAKE can be lowered independently from other visual effects.',
    dread: 'DREAD SPIKES changes intensity, not story state.',
    default: 'ACCESS settings change presentation, not progression.',
  },

  challenge: {
    shift: 'CURRENT SHIFT is the rules profile selected when this run began.',
    'challenge:presencePressure': 'ENEMY PRESSURE changes how quickly threats move, how easily they hear you, and how long they keep tracking you.',
    'challenge:recordingForgiveness': 'RECORDING FORGIVENESS changes how minor handling noise affects an active take.',
    'challenge:combatAssistance': 'COMBAT ASSISTANCE changes intent guidance, Composure, guard strength, and enemy scripts.',
    'challenge:navigationSignal': 'NAVIGATION HELP changes how much route, room, distance, map, and waypoint information is shown.',
    'challenge:escapeTimer': 'ESCAPE TIME changes how long you have during timed escapes; OFF removes the timer.',
    'challenge:torchDrain': 'FLASHLIGHT DRAIN changes battery consumption, not light intensity.',
    'challenge:involuntaryBreath': 'INVOLUNTARY BREATHING changes whether panic can make your character breathe loudly without input.',
    certification: 'The DEAD AIR achievement is disabled for the run if a gameplay rule is made easier.',
    default: 'Challenge settings change gameplay pressure. Accessibility settings never affect the DEAD AIR achievement.',
  },

  game: {
    tutorialPrompts: 'TUTORIAL PROMPTS can be restored at any time.',
    objectiveHints: 'OBJECTIVE HINTS changes guidance only, not difficulty.',
    pauseOnBlur: 'PAUSE WHEN BLUR prevents stuck keys and accidental movement.',
    seenTextMode: 'Hold confirm to accelerate only dialogue already completed in an earlier run.',
    archiveSignals: 'UNSEEN CHOICE MARKERS mark choices you have not tried without revealing their outcomes.',
    condensedCheckIn: 'CONDENSED CHECK-IN shortens repeated administration on the next new run.',
    returnTitle: 'RETURN TO TITLE leaves the current run through the title screen.',
    resume: 'RESUME closes the service menu.',
    default: 'GAME settings affect guidance and pause behavior.',
  },

  memory: {
    autosave: 'AUTOSAVE is always on.',
    playTime: 'PLAY TIME is the current run time.',
    steps: 'STEPS counts movement in the current run.',
    area: 'CURRENT AREA is the last known area or room.',
    exportProfile: 'EXPORT PROFILE writes endings, achievements, knowledge, and preferences without the active run.',
    importProfile: 'IMPORT PROFILE merges permanent progress and never replaces the active run.',
    clearRun: 'CLEAR RUN resets the current run but keeps global memory.',
    clearMemory: 'CLEAR MEMORY removes run and meta memory.',
    default: 'MEMORY rows describe or clear saved state.',
  },

  system: {
    'about:version': 'VERSION helps identify the build when reporting a problem.',
    'about:build': 'BUILD identifies whether this is a local, web, or packaged release.',
    'about:website': 'WEBSITE opens the project page.',
    'about:report': 'REPORT A PROBLEM opens the issue/report page.',
    'about:copyright': 'COPYRIGHT identifies the game copyright notice.',
    'about:fps': 'FPS is a rough performance reading for this session.',
    'about:runtime': 'RUNTIME identifies whether this is the desktop or web build.',
    'about:copyReport': 'COPY DIAGNOSTIC REPORT copies non-spoiler support details.',
    'about:exportSave': 'EXPORT SAVE BACKUP downloads your save/profile data.',
    'about:restartAudio': 'RESTART AUDIO ENGINE rebuilds the audio path if sound gets stuck.',
    'about:credits': 'CREDITS opens the release record and project acknowledgements.',
    default: 'ABOUT shows version, support, and non-spoiler runtime information.',
  },
});

const PRO_TIPS = Object.freeze([
  {
    id: 'bag-waypoint',
    text: 'Mark locations in your bag with {mark} to see a waypoint.',
    tabs: ['input', 'game', 'memory', 'challenge'],
    when: ({ inGame }) => inGame,
  },
  {
    id: 'quiet-movement',
    text: 'Hold {quiet} to move quietly when the building is listening.',
    tabs: ['input', 'game', 'challenge'],
    when: ({ inGame }) => inGame,
  },
  {
    id: 'light-tradeoff',
    text: 'Your light helps you read the room, but it also changes what sees you.',
    tabs: ['display', 'input', 'game'],
    when: ({ inGame }) => inGame,
  },
  {
    id: 'listen-first',
    text: 'Listen before recording. A clean take starts with a quiet room.',
    tabs: ['audio', 'game', 'challenge'],
    when: ({ inGame }) => inGame,
  },
  {
    id: 'playback',
    text: 'Use {playback} after a take to hear what the tape kept.',
    tabs: ['audio', 'game'],
    when: ({ inGame, save }) => inGame && Array.isArray(save?.takes) && save.takes.length > 0,
  },
  {
    id: 'bag-review',
    text: 'The bag files notes under rooms. Unfiled pages may still matter.',
    tabs: ['input', 'memory', 'game'],
    when: ({ inGame }) => inGame,
  },
  {
    id: 'access',
    text: 'If motion or strobe effects feel sharp, lower them in ACCESS.',
    tabs: ['access', 'display'],
  },
  {
    id: 'objective-hints',
    text: 'OBJECTIVE HINTS changes guidance only; it does not change progression.',
    tabs: ['game'],
  },
  {
    id: 'mic-optional',
    text: 'The room mic is optional. The game remains playable without it.',
    tabs: ['input'],
  },
  {
    id: 'sfx-mix',
    text: 'If hushes or stabs feel too close, lower SFX before lowering GLOBAL.',
    tabs: ['audio', 'access'],
  },
  {
    id: 'settings-close',
    text: 'Press {menu} to leave the service menu and return to the field.',
    tabs: ['system', 'game'],
    when: ({ inGame }) => inGame,
  },
]);

function settingHelpTip(tabId, rowId) {
  const group = SETTING_HELP[tabId] || {};
  return group[rowId] || group.default || '';
}

function eligibleProTips({ tabId, rowId, inGame, save }) {
  const ctx = { tabId, rowId, inGame, save };

  const scoped = PRO_TIPS.filter((tip) => {
    if (tip.tabs && !tip.tabs.includes(tabId)) return false;
    if (tip.rows && !tip.rows.includes(rowId)) return false;
    if (tip.when && !tip.when(ctx)) return false;
    return true;
  });

  if (scoped.length) return scoped;

  return PRO_TIPS.filter((tip) => {
    if (tip.when && !tip.when(ctx)) return false;
    return true;
  });
}

function proTip({ tabId, rowId, inGame, nowMs }) {
  const save = getSave();
  const pool = eligibleProTips({ tabId, rowId, inGame, save });
  if (!pool.length) return '';

  const index = Math.floor((Number(nowMs) || 0) / TIP_MS) % pool.length;
  return formatBindingTip(pool[index].text);
}

export function settingsFooterTips({ tabId, rowId, inGame = false, nowMs = 0 } = {}) {
  return {
    help: settingHelpTip(tabId, rowId),
    pro: proTip({ tabId, rowId, inGame, nowMs }),
  };
}

export function clipTip(text, width) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  const n = Math.max(8, Math.floor(width || 40));
  return s.length <= n ? s : `${s.slice(0, Math.max(1, n - 1))}…`;
}

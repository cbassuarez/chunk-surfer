//
//  bag-model.js
//
//
//  Created by Sebastian Suarez-Solis on 7/12/26.
//

// Pure field-case model.
//
// Converts the game's small, irregular bag/job payloads into one stable shape
// for presentation and navigation. It deliberately knows nothing about scenes,
// canvas, key events, saves, or the world clock.

import {
  combatCompartment,
  isBattleGear,
  normalizeCombatLoadout,
} from './combat-loadout.js';
import {
  TECHNIQUE_DEFS,
  normalizeCombatBuild,
  techniqueAvailability,
} from './combat-progression.js';

export const EMPTY_JOB = Object.freeze({
  rooms: [],
  unfiled: [],
  done: 0,
  total: 5,
});

const KNOWN_GEAR = Object.freeze({
  light: {
    title: 'LIGHT',
    subtitle: 'FIELD TORCH',
    icon: 'light',
    status: ['READY', 'active'],
    description: 'Hand torch issued with the field kit.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'ILLUMINATION'], ['BATTLE', 'EXPOSE · DMG · COUNTERS CONCEAL · USES BATTERY']],
  },
  recorder: {
    title: 'RECORDER + HEADPHONES',
    subtitle: 'PORTABLE RECORDER',
    icon: 'recorder',
    status: ['READY', 'active'],
    description: 'Captures one uninterrupted minute of room tone.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'CAPTURE / MONITOR'], ['BATTLE', 'MONITOR CAPTURES A TAKE · PLAYBACK SPENDS IT · COUNTERS BROADCAST']],
  },
  interface: {
    title: 'BENT RIG INTERFACE',
    subtitle: 'CIRCUIT-BENT RETURN',
    icon: 'interface',
    status: ['READY', 'active'],
    description: 'A rewired return path capable of reversing a hostile signal.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'INVERT / FEEDBACK'], ['BATTLE', 'INVERT RETURNS A LOOP · SPENDS THE TAKE · COUNTERS LOOP']],
  },
  'tuning-fork': {
    title: 'TUNING FORK',
    subtitle: 'STEEL REFERENCE / A440',
    icon: 'tuning-fork',
    status: ['READY', 'active'],
    description: 'A stable reference tone carried into unstable rooms.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'TUNE / REVEAL'], ['BATTLE', 'TUNE IS FREE · REVEALS THE NEXT TWO INTENTS']],
  },
  map: {
    title: 'LOCATION INDICATOR',
    subtitle: 'BUILDING PLAN / CURRENT SLICE',
    icon: 'room',
    status: ['LIVE', 'active'],
    description: 'Tracks the current physical floor, marked destination, and nearby interference.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'LOCATION / BEARING']],
  },
  radio: {
    title: 'RADIO',
    subtitle: 'PORTABLE SET',
    icon: 'radio',
    status: ['LIVE', 'active'],
    description: 'Portable service radio assigned with the work order.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'CHECK-IN / FIELD CONTACT'], ['BATTLE', 'THROW VOICE · GUARD 2 · COUNTERS BROADCAST · ONCE PER FIGHT']],
  },
  coffee: {
    title: "THE GUARD'S COFFEE",
    subtitle: 'PAPER CUP',
    icon: 'coffee',
    status: ['GETTING COLD', 'metadata'],
    description: 'Coffee from the service booth. Still technically warm.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'STIMULANT'], ['BATTLE', 'STEADY HANDS · +3 COMPOSURE · ONE CUP']],
  },
  keyring: {
    title: 'STANDARD KEYRING',
    subtitle: 'FACILITIES KEYS',
    icon: 'keyring',
    status: ['CARRIED', 'dim'],
    description: 'The standard keyring supplied for the building.',
    facts: [['POSITION', 'CARRIED'], ['FUNCTION', 'ACCESS']],
  },
  'chapel-key': {
    title: 'CHAPEL KEY',
    subtitle: 'TAG C-17',
    icon: 'keyring',
    status: ['ADDED', 'complete'],
    description: 'A later-generation key tagged C-17.',
    facts: [['POSITION', 'KEYRING'], ['FUNCTION', 'CHAPEL ACCESS']],
  },
});

const GEAR_ALIAS = Object.freeze({
  'recorder-headphones': 'recorder',
  'recorder-+-headphones': 'recorder',
  'standard-keyring': 'keyring',
  'the-guards-coffee': 'coffee',
  torch: 'light',
});

const clampInt = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.floor(Number(v) || 0)));

export function slug(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[’']/g, '')
    .replace(/\+/g, ' + ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'entry';
}

function displayTitle(value = '') {
  return String(value || 'ENTRY').trim().toUpperCase();
}

function gearKey(raw) {
  const direct = slug(raw?.id || raw?.label || 'gear');
  return GEAR_ALIAS[direct] || direct;
}

function gearProfile(raw) {
  const key = gearKey(raw);
  const known = KNOWN_GEAR[key];
  if (known) return { key, ...known };

  return {
    key,
    title: displayTitle(raw?.label || raw?.id || 'GEAR'),
    subtitle: 'FIELD EQUIPMENT',
    icon: raw?.icon || 'unknown',
    status: ['CARRIED', 'dim'],
    description: 'Field equipment carried with the work order.',
    facts: [['POSITION', 'CARRIED']],
  };
}

function normalizeStatus(value, fallbackLabel, fallbackTone) {
  if (value && typeof value === 'object') {
    return {
      label: displayTitle(value.label || fallbackLabel),
      tone: value.tone || fallbackTone,
    };
  }

  return {
    label: displayTitle(value || fallbackLabel),
    tone: fallbackTone,
  };
}

export function normalizeEquipment(item, index = 0) {
  const raw = typeof item === 'string'
    ? { id: slug(item), label: item }
    : { ...(item || {}) };

  const profile = gearProfile(raw);
  const present = raw.present !== false;
  const [defaultStatus, defaultTone] = profile.status;
  const status = present
    ? normalizeStatus(raw.status || raw.value, defaultStatus, raw.statusTone || defaultTone)
    : normalizeStatus(raw.status || raw.value, 'EMPTY', raw.statusTone || 'danger');

  const facts = Array.isArray(raw.facts)
    ? raw.facts
    : profile.facts.map(([k, v]) => [k, k === 'POSITION' && !present ? (raw.location || 'NOT CARRIED') : v]);

  let primary = null;
  if (present && typeof raw.action === 'function') {
    const defaultLabel = profile.key === 'radio'
      ? 'SET DOWN'
      : profile.key === 'coffee'
        ? 'DRINK'
        : 'USE';

    const destructive = raw.destructive ?? (profile.key === 'radio' || profile.key === 'coffee');

    primary = {
      id: raw.actionId || (profile.key === 'radio' ? 'drop' : profile.key === 'coffee' ? 'consume' : 'activate'),
      label: displayTitle(raw.actionLabel || defaultLabel),
      destructive: !!destructive,
      confirm: destructive
        ? {
            title: displayTitle(raw.confirm?.title || (profile.key === 'radio' ? 'SET DOWN RADIO?' : 'DRINK THE COFFEE?')),
            body: displayTitle(raw.confirm?.body || (profile.key === 'radio'
              ? 'THE RADIO WILL REMAIN IN THIS ROOM.'
              : 'THIS CANNOT BE UNDONE.')),
          }
        : null,
    };
  }

  return {
    id: `gear:${profile.key || raw.id || index}`,
    sourceId: profile.key || raw.id,
    section: 'kit',
    kind: 'gear',
    title: displayTitle(raw.title || profile.title),
    subtitle: displayTitle(raw.subtitle || profile.subtitle),
    icon: raw.icon || profile.icon,
    present,
    status,
    description: String(raw.description || profile.description),
    facts,
    badges: Array.isArray(raw.badges) ? raw.badges : [],
    actions: { primary, secondary: null },
    source: raw,
  };
}

function roomState(room) {
  if (room?.recorded) return 'recorded';
  if (room?.current) return 'current';
  if (room?.marked) return 'marked';
  return room?.visited === false ? 'unvisited' : 'available';
}

function mapStatus(state) {
  switch (state) {
    case 'recorded': return { label: 'RECORDED', tone: 'complete', glyph: '✓' };
    case 'current': return { label: 'IN ROOM', tone: 'active', glyph: '●' };
    case 'marked': return { label: 'MARKED', tone: 'active', glyph: '◆' };
    case 'unvisited': return { label: 'UNVISITED', tone: 'dim', glyph: '◇' };
    default: return { label: 'AVAILABLE', tone: 'metadata', glyph: '◇' };
  }
}

export function normalizeRoom(room, index = 0, total = 5) {
  const raw = room || {};
  const roomId = raw.roomId || `room-${index + 1}`;
  const state = roomState(raw);
  const notes = Array.isArray(raw.notes) ? raw.notes : [];
  const status = mapStatus(state);
  const timestamp = raw.stamp || '--:--';

  return {
    id: `room:${roomId}`,
    section: 'map',
    kind: 'room',
    roomId,
    sequence: index + 1,
    title: displayTitle(raw.label || roomId),
    subtitle: `TAKE ${String(index + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`,
    icon: 'room',
    state,
    recorded: !!raw.recorded,
    marked: !!raw.marked,
    timestamp,
    noteCount: notes.length,
    status,
    description: String(raw.description || (index === 0
      ? "First room named on the client's recording manifest."
      : `Assigned recording room ${index + 1} of ${total}.`)),
    facts: [
      ['RECORDING', raw.recorded ? 'CAPTURED' : 'NOT CAPTURED'],
      ['FILES', String(notes.length).padStart(2, '0')],
      ['TIMESTAMP', timestamp],
    ],
    attached: notes[0] || null,
    actions: {
      primary: notes.length
        ? { id: 'read-attached', label: 'READ FILE', destructive: false }
        : null,
      secondary: {
        id: raw.marked ? 'unmark' : 'mark',
        label: raw.marked ? 'CLEAR WAYPOINT' : 'MARK WAYPOINT',
        destructive: false,
      },
    },
    source: raw,
  };
}

function firstBodyText(doc) {
  if (doc?.preview) return String(doc.preview);
  const body = Array.isArray(doc?.body) ? doc.body : [];

  for (const entry of body) {
    if (typeof entry === 'string' && entry.trim()) return entry.trim();
    if (entry?.raw && String(entry.raw).trim()) return String(entry.raw).trim();
  }

  return 'Collected paperwork from the building.';
}

function documentType(doc) {
  if (doc?.type) return displayTitle(doc.type);
  const id = String(doc?.id || '').toLowerCase();
  const title = String(doc?.title || '').toLowerCase();
  if (id.includes('work-order') || title.includes('work order')) return 'ARCHIVAL CAPTURE';
  if (id.includes('log') || title.includes('log')) return 'FIELD LOG';
  return 'COLLECTED DOCUMENT';
}

function documentIssued(doc) {
  if (doc?.issued) return String(doc.issued).toUpperCase();
  const m = String(doc?.title || '').match(/\b\d{1,2}:\d{2}\b/);
  return m ? m[0] : '--:--';
}

function documentBadges(doc) {
  const out = Array.isArray(doc?.badges) ? [...doc.badges] : [];
  if (doc?.unread) out.push('NEW');
  if (doc?.updated) out.push('UPDATED');
  if (doc?.newlyFiled) out.push('FILED');
  return [...new Set(out.map(displayTitle))];
}

export function normalizeFiles(job = EMPTY_JOB) {
  const files = [];
  const rooms = Array.isArray(job.rooms) ? job.rooms : [];

  for (const room of rooms) {
    for (const doc of Array.isArray(room.notes) ? room.notes : []) {
      files.push(normalizeFile(doc, {
        roomId: room.roomId,
        folder: room.label,
        marked: !!room.marked,
      }));
    }
  }

  for (const doc of Array.isArray(job.unfiled) ? job.unfiled : []) {
    files.push(normalizeFile(doc, {
      roomId: null,
      folder: 'UNFILED',
      marked: false,
    }));
  }

  return files;
}

function normalizeFile(doc, { roomId, folder, marked = false }) {
  const raw = doc || {};
  const title = displayTitle(raw.title || raw.id || 'DOCUMENT');
  const preview = firstBodyText(raw).replace(/\s+/g, ' ').trim();
  const read = raw.read === true;

  return {
    id: `file:${raw.id || slug(title)}`,
    section: 'files',
    kind: 'file',
    title,
    subtitle: documentType(raw),
    icon: 'file',
    roomId,
    folder: displayTitle(folder || 'UNFILED'),
    preview,
    status: { label: read ? 'READ' : 'FILED', tone: read ? 'dim' : 'metadata' },
    facts: [
      ['TYPE', documentType(raw)],
      ['FILED UNDER', displayTitle(folder || 'UNFILED')],
      ['ISSUED', documentIssued(raw)],
      ['STATUS', read ? 'READ' : 'FILED'],
    ],
    badges: documentBadges(raw),
    actions: {
      primary: { id: 'read', label: 'READ', destructive: false },
      secondary: roomId
        ? {
            id: marked ? 'unmark-room' : 'mark-room',
            label: marked ? 'CLEAR WAYPOINT' : `MARK ${displayTitle(folder)}`,
            destructive: false,
          }
        : null,
    },
    source: raw,
  };
}

export const BAG_SECTION_ALIASES = Object.freeze({ manifest: 'map' });

export function normalizeBagSectionId(sectionId) {
  return BAG_SECTION_ALIASES[sectionId] || sectionId;
}

// ── the SKILLS section ──────────────────────────────────────────────────────
// One column per branch, its techniques in tier order. Every entry carries the
// three things the screen has to be able to say without the player deducing
// anything: which of the three states it is in, what it does, and — when it is
// locked — what unlocks it BY NAME. "TIER I REQUIRED" told nobody anything.
function buildSkillsSection({ build, settledBuild = null, hasRig }) {
  const current = normalizeCombatBuild(build);
  const settled = normalizeCombatBuild(settledBuild ?? build);
  const nameOf = (id) => TECHNIQUE_DEFS.find((entry) => entry.id === id)?.label || '';
  const branchOrder = [...new Set(TECHNIQUE_DEFS.map((entry) => entry.branch))];
  const branches = branchOrder.map((branch) => ({
    id: branch,
    entries: TECHNIQUE_DEFS
      .filter((entry) => entry.branch === branch)
      .sort((a, b) => a.tier - b.tier)
      .map((entry) => {
        const availability = techniqueAvailability(current, entry.id, { hasRig });
        const owned = current.techniques.includes(entry.id);
        const pending = owned && !settled.techniques.includes(entry.id);
        return {
          id: `skill:${entry.id}`,
          techniqueId: entry.id,
          kind: 'skill',
          branch,
          tier: entry.tier,
          label: entry.label,
          detail: entry.detail,
          active: !!entry.active,
          special: !!entry.special,
          owned,
          pending,
          enabled: availability.enabled,
          state: pending ? 'pending' : owned ? 'owned' : availability.enabled ? 'affordable' : 'locked',
          // Named, not numbered.
          blockedBy: owned ? ''
            : availability.enabled ? ''
              : entry.requires && !current.techniques.includes(entry.requires)
                ? `LOCKED · FIT ${nameOf(entry.requires)} FIRST`
                : entry.requiresRig && !hasRig
                  ? 'LOCKED · NEEDS THE BENT RIG FROM THE PLANT ROOM'
                  : current.unspent <= 0 ? 'NEEDS A PIN · NONE SPARE'
                    : String(availability.reason || 'LOCKED'),
          buyPrompt: 'TAKES EFFECT WHEN THE CASE CLOSES',
          actions: {
            primary: (!owned && availability.enabled)
              ? { id: 'fit-skill', label: 'CHOOSE', destructive: false }
              : null,
          },
        };
      }),
  }));
  const maxTier = branches.reduce((max, branch) => Math.max(max, ...branch.entries.map((e) => e.tier)), 1);
  return {
    id: 'skills',
    label: 'SKILLS',
    countLabel: current.unspent
      ? `${current.unspent} PIN${current.unspent === 1 ? '' : 'S'}${current.techniques.length - settled.techniques.length ? ` · ${current.techniques.length - settled.techniques.length} CHOSEN` : ''}`
      : current.techniques.length - settled.techniques.length
        ? `${current.techniques.length - settled.techniques.length} CHOSEN`
        : `${current.techniques.length} INSTALLED`,
    entries: branches.flatMap((branch) => branch.entries),
    tree: {
      branches,
      maxTier,
      pins: {
        earned: current.pinsEarned,
        spent: current.pinsSpent,
        unspent: current.unspent,
        pending: Math.max(0, current.techniques.length - settled.techniques.length),
      },
    },
  };
}

export function buildBagModel({ equipment = [], job = EMPTY_JOB, map = null, loadout = null, build = null, settledBuild = null, hasRig = false } = {}) {
  const safeJob = {
    ...EMPTY_JOB,
    ...(job || {}),
    rooms: Array.isArray(job?.rooms) ? job.rooms : [],
    unfiled: Array.isArray(job?.unfiled) ? job.unfiled : [],
  };

  const normalizedLoadout = normalizeCombatLoadout(loadout);
  const kit = (Array.isArray(equipment) ? equipment : []).map(normalizeEquipment).map((entry) => {
    const battleCapable = entry.source?.battleCapable ?? isBattleGear(entry.sourceId);
    const compartment = battleCapable ? combatCompartment(normalizedLoadout, entry.sourceId) : 'storage';
    const topIndex = normalizedLoadout.top.indexOf(entry.sourceId);
    const compartmentLabel = compartment === 'top'
      ? `READY NOW ${topIndex + 1}/${normalizedLoadout.capacity}`
      : battleCapable ? 'BAG STORAGE / NOT READY' : 'BAG STORAGE';
    return {
      ...entry,
      battleCapable,
      compartment,
      topIndex,
      facts: [['COMPARTMENT', compartmentLabel], ...entry.facts],
      badges: [compartment === 'top' ? `READY ${topIndex + 1}` : 'STORAGE', ...entry.badges],
      actions: {
        ...entry.actions,
        secondary: battleCapable && entry.present
          ? {
              id: compartment === 'top' ? 'move-storage' : 'move-top',
              label: compartment === 'top' ? 'CLEAR READY SLOT' : 'PUT IN READY NOW',
              destructive: false,
            }
          : null,
        // Tray order is the in-fight tool rail order. One "move up" is a
        // complete reorder primitive — walk a tool down by lifting the one below
        // it — and it only exists for gear that has somewhere above to go.
        tertiary: compartment === 'top' && entry.present && topIndex > 0
          ? { id: 'reorder-up', label: 'MOVE UP', destructive: false }
          : null,
      },
    };
  }).sort((a, b) => {
    if (a.compartment !== b.compartment) return a.compartment === 'top' ? -1 : 1;
    if (a.compartment === 'top') return a.topIndex - b.topIndex;
    return 0;
  });
  const total = Math.max(0, Number(safeJob.total) || safeJob.rooms.length || 0);
  const mapEntries = safeJob.rooms.map((room, index) => {
    const entry = normalizeRoom(room, index, total || safeJob.rooms.length || 5);
    const space = map?.spaces?.find((candidate) => candidate.roomId === entry.roomId) || null;
    return space ? {
      ...entry,
      floorId: space.floorId,
      mapPosition: space.position,
      current: !!space.current,
      marked: !!space.waypoint,
      state: space.objective?.state || entry.state,
      status: mapStatus(space.objective?.state || entry.state),
      source: { ...entry.source, mapSpace: space },
    } : entry;
  });
  const files = normalizeFiles(safeJob);
  const done = clampInt(safeJob.done, 0, total || Math.max(0, safeJob.done || 0));

  return {
    sections: [
      { id: 'kit', label: 'KIT', countLabel: `${kit.filter((e) => e.present && e.compartment === 'top').length}/${normalizedLoadout.capacity}`, entries: kit },
      { id: 'map', label: 'MAP', countLabel: `${done}/${total}`, entries: mapEntries, map },
      { id: 'files', label: 'FILES', countLabel: String(files.length).padStart(2, '0'), entries: files },
      buildSkillsSection({ build, settledBuild, hasRig }),
    ],
    progress: { done, total },
    loadout: normalizedLoadout,
    job: safeJob,
    map,
  };
}

export function bagSection(model, sectionId) {
  const normalized = normalizeBagSectionId(sectionId);
  return model?.sections?.find((section) => section.id === normalized) || null;
}

export function bagEntry(model, sectionId, entryId) {
  return bagSection(model, sectionId)?.entries?.find((entry) => entry.id === entryId) || null;
}

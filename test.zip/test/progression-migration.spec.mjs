import assert from 'node:assert/strict';

class MemoryStorage {
  constructor(seed = {}) { this.map = new Map(Object.entries(seed)); }
  getItem(key) { return this.map.has(key) ? this.map.get(key) : null; }
  setItem(key, value) { this.map.set(key, String(value)); }
  removeItem(key) { this.map.delete(key); }
}

const legacyMeta = {
  version: 1,
  endingsSeen: ['sacrifice', 'sacrifice', 'unknown'],
  hushMet: true,
  leftMidRun: true,
  runs: 3,
  lastSeenAt: 123,
};
const legacySave = {
  version: 2,
  flags: { prologueDone: true },
  area: 'main_b3',
  px: 9,
  py: 12,
  takes: ['main_b3'],
  items: ['chapel_key'],
  steps: 44,
  settings: { volume: 0.5, instantText: true, controllerBindings: { interact: 'button2', menu: 'button9' } },
};

globalThis.localStorage = new MemoryStorage({
  'chunk-surfer:meta:v1': JSON.stringify(legacyMeta),
  'chunk-surfer:save:v2': JSON.stringify(legacySave),
});

const saveApi = await import('../src/game/save.js');
const loaded = saveApi.saveLoad();
assert.equal(loaded.meta.version, 2);
assert.deepEqual(loaded.meta.endingsSeen, ['sacrifice']);
assert.equal(loaded.meta.hushMet, true);
assert.equal(loaded.meta.leftMidRun, true);
assert.equal(loaded.meta.stats.runsStarted, 3);
assert.equal(loaded.save.version, 4);
assert.equal(loaded.save.flags.prologueDone, true);
assert.equal(loaded.save.area, 'main_b3');
assert.deepEqual(loaded.save.takes, ['main_b3']);
assert.deepEqual(loaded.save.items, ['chapel_key']);
assert.equal(loaded.save.settings.volume, 0.5);
assert.equal(loaded.save.settings.instantText, true);
assert.equal(loaded.save.settings.dialog, 1);
assert.equal(loaded.save.settings.monitorGain, 1);
assert.equal(loaded.save.settings.hushAudioDistortion, 'full');
assert.equal(loaded.save.settings.controller.bindings.interact.id, 'west');
assert.equal(loaded.save.settings.controller.bindings.menu.id, 'menu');
assert.equal(loaded.save.hushAudio, null);
assert.equal(loaded.save.run.status, 'active');
assert.equal(loaded.save.run.replay.isReplay, true);
assert.equal(globalThis.localStorage.getItem('chunk-surfer:meta:v2') != null, true);
assert.equal(globalThis.localStorage.getItem('chunk-surfer:save:v4') != null, true);

// Corrupt new-version records repair safely and strip unknown achievements.
globalThis.localStorage.setItem('chunk-surfer:meta:v2', JSON.stringify({
  version: 2,
  achievements: { ACH_FIRST_TAKE: { unlockedAt: 1 }, ACH_FAKE: { unlockedAt: 1 } },
  endingsSeen: 'not-an-array',
}));
globalThis.localStorage.setItem('chunk-surfer:save:v4', JSON.stringify({
  version: 4,
  settings: null,
  hushAudio: 'corrupt',
  run: {
    id: 'run_bad',
    status: 'active',
    rules: {
      startedPreset: 'fake-mode',
      currentPreset: 'fake-mode',
      values: { escapeTimer: 'impossible', presencePressure: 'severe' },
    },
    integrity: { deadAir: { startedEligible: false, eligible: true, invalidations: [] } },
  },
}));
const repaired = saveApi.saveLoad();
assert.deepEqual(repaired.meta.endingsSeen, []);
assert.ok(repaired.meta.achievements.ACH_FIRST_TAKE);
assert.equal(repaired.meta.achievements.ACH_FAKE, undefined);
assert.equal(repaired.save.run.rules.startedPreset, 'contract');
assert.equal(repaired.save.run.rules.currentPreset, 'contract');
assert.equal(repaired.save.run.rules.values.escapeTimer, 'standard');
assert.equal(repaired.save.run.rules.values.presencePressure, 'severe');
assert.equal(repaired.save.run.integrity.deadAir.eligible, false);
assert.equal(repaired.save.run.integrity.deadAir.invalidations.at(-1).reason, 'REPAIRED_INVALID_CERTIFICATION');
assert.equal(repaired.save.hushAudio, null);

// Bounded semantic HUSH state survives; runtime AudioNodes and buffers never
// enter the save schema.
globalThis.localStorage.setItem('chunk-surfer:save:v4', JSON.stringify({
  ...repaired.save,
  hushAudio: {
    schema: 1,
    audition: {
      interest: .4,
      certainty: .5,
      rawAudio: [1, 2, 3],
      noiseMemory: [{ kind: 'footstep_walk', sampleId: null, position: { x: 1, y: 2 }, rawBuffer: 'forbidden' }],
    },
    mischief: { cueCounts: { 'mischief.monitor-return': 1 } },
  },
}));
const hushState = saveApi.saveLoad().save.hushAudio;
assert.equal(hushState.schema, 1);
assert.equal(hushState.audition.interest, .4);
assert.equal(hushState.mischief.cueCounts['mischief.monitor-return'], 1);
assert.equal(hushState.audition.rawAudio, undefined);
assert.equal(hushState.audition.noiseMemory[0].rawBuffer, undefined);

console.log('progression migration tests ok');

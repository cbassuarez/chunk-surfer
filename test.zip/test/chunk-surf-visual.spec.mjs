import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { CHUNK_SURF_ROOMS } from '../src/data/chunk-surf-script.js';
import { CELL, MATERIAL, ZONE } from '../src/data/floorplan/legend.js';
import {
  SOURCE_APPROACH_CELLS,
  SOURCE_TIERS,
  SOURCE_TIER_BY_ID,
  sourceFeatureAt,
  sourceTierAt,
} from '../src/data/source-level.js';
import {
  freshChunkSurfState,
  reduceChunkSurf,
} from '../src/game/chunk-surf-state.js';
import {
  SOURCE_ATLAS,
  SOURCE_ARCH_MAX_INSTANCES,
  SOURCE_ARCH_TILE_CELLS,
  SOURCE_PLAN_SNAP,
  SOURCE_LANDMARK_OFFSETS,
  SOURCE_PLAN_WINDOW,
  SOURCE_SEEDED_STRUCTURE_COUNT,
  createSourceSpaceRuntime,
  sourceLandscapePlanOrigin,
  sourceLandscapeFloorAt,
  sourceStructureCollisionAt,
  sourceStructurePlacements,
  sourceStructureRouteClearance,
  validateSourceAtlas,
} from '../src/game/source-space-runtime.js';
// The field's own origin in these fixtures, and the final page derived from the
// real landmark table. These were absolute literals (-564, -566) that the red
// approach moved by SOURCE_APPROACH_CELLS.
const FIELD_ORIGIN={x:0,y:-252};
const FINAL_PAGE={
  x:FIELD_ORIGIN.x+SOURCE_LANDMARK_OFFSETS['final-page'].x,
  y:FIELD_ORIGIN.y+SOURCE_LANDMARK_OFFSETS['final-page'].y,
};
const FIELD_DEPTH=Math.abs(SOURCE_TIERS.filter((tier)=>tier.field).at(-1).to);


function hash(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function hallState(distance = 0) {
  let state = freshChunkSurfState({ seed: 4417, returnPoint: { x: 86, y: 58 } });
  state = reduceChunkSurf(state, { type: 'SOURCE_ENTERED', returnPoint: state.returnPoint });
  return reduceChunkSurf(state, { type: 'HALL_ADVANCED', distance });
}

function landscapeState(){
  let state=hallState(112);
  state=reduceChunkSurf(state,{type:'HAYSTACK_REACHED',origin:{x:0,y:-224},slot:0});
  state=reduceChunkSurf(state,{type:'HAYSTACK_PAGE_FOUND',landscapeOrigin:{x:0,y:-252}});
  return reduceChunkSurf(state,{type:'TRANSFORMATION_COMPLETED'});
}

function fullyOpenLandscapeState(){
  let state=landscapeState();
  state=reduceChunkSurf(state,{type:'SOURCE_LIFT_COMPLETED',id:'lift-fork',checkpointId:'landing-fork'});
  for(const id of ['fork-room','recordist-loop','body-room'])state=reduceChunkSurf(state,{type:'LANDMARK_VISITED',id});
  return state;
}

assert.equal(validateSourceAtlas(SOURCE_ATLAS).ok, true);
assert.equal(SOURCE_ATLAS.schemaVersion, 3);
assert.equal(SOURCE_ATLAS.exactSource, true);
assert.equal(SOURCE_ATLAS.stats.sectors, 8);
assert.doesNotMatch(JSON.stringify(SOURCE_ATLAS), /https?:\/\//i);
assert.doesNotMatch(JSON.stringify(SOURCE_ATLAS), /\/Users\//);
assert.doesNotMatch(JSON.stringify(SOURCE_ATLAS), /\b(process\.env|import\.meta\.env)\b/);
assert.ok(Object.keys(SOURCE_ATLAS.symbols).length>0&&SOURCE_ATLAS.references.length>0,'the atlas includes provenance-safe symbol relationships');
assert.ok(SOURCE_ATLAS.references.every((reference)=>SOURCE_ATLAS.entries[reference.entryId]?.hash===reference.hash),'every reference edge points back to an exact validated line');
assert.ok(CHUNK_SURF_ROOMS.every((room) => !('lines' in room) && !('tunedLines' in room)), 'visible pseudo-code was removed from authored narrative data');

const mainSource=await readFile(resolve('src/main.js'),'utf8');
const rendererSource=await readFile(resolve('src/render/r3d.js'),'utf8');
assert.match(mainSource,/tickHushAudio\(dt\);\s*tickChunkSurfOffer\(\);\s*tickSourceSpace\(dt\);/,'chapel Source offer is evaluated in the live world loop');
assert.match(mainSource,/function tickChunkSurfOffer\(\)\{[\s\S]*?return false;[\s\S]*?\}/,'proximity polling cannot auto-enter Source Space');
assert.match(mainSource,/ENTER SOURCE/,'the chapel threshold exposes an explicit Source interaction');
{
  const drawStoryHudStart=mainSource.indexOf('function drawStoryHud(){');
  assert.ok(drawStoryHudStart>=0,'drawStoryHud is present');

  const drawStoryHudEnd=mainSource.indexOf(
    '\nfunction ',
    drawStoryHudStart+'function drawStoryHud(){'.length,
  );
  assert.ok(
    drawStoryHudEnd>drawStoryHudStart,
    'drawStoryHud has a bounded top-level function body',
  );

  const drawStoryHudSource=mainSource.slice(drawStoryHudStart,drawStoryHudEnd);
  const sourceBranch=drawStoryHudSource.indexOf('if(usingSourceSpace()){');
  const sourceHud=drawStoryHudSource.indexOf('drawSourceHud(cols,rows);',sourceBranch);
  const sourceReturn=drawStoryHudSource.indexOf('return;',sourceHud);

  assert.ok(sourceBranch>=0,'Source owns a dedicated drawStoryHud branch');
  assert.ok(sourceHud>sourceBranch,'Source draws its dedicated HUD inside that branch');
  assert.ok(sourceReturn>sourceHud,'Source exits drawStoryHud after its dedicated HUD');

  for(const [surface,needle] of [
    ['recording overlay','if(REC.isRecording())'],
    ['battery UI','const b=REC.batteryLevel();'],
    ['building navigator','const guidance=currentStoryGuidanceFrame();'],
    ['takes UI','drawTakeRail('],
  ]){
    const index=drawStoryHudSource.indexOf(needle);
    assert.ok(index<0||sourceReturn<index,`Source returns before the ${surface}`);
  }
}assert.match(mainSource,/const pressureRemainsLive=topSourceScene\?\.sourcePressureLive===true;/,'Source scenes can explicitly keep chapter pressure live');
assert.match(mainSource,/if\(SPEECH\.isSpeaking\(\)\|\|\(scenes\.blocksInput\(\)&&!pressureRemainsLive\)\)chunkSurfRuntime\.protectMoment/,'dialogue and ordinary blocking handoffs suspend Source pursuit without turning a Source page into safety');
assert.doesNotMatch(mainSource,/tuneSourceFocused|\.tuneFocused\(|\.recordFocused\(|source-tune/,
  'Source has no tuning or landmark-recording runtime verb');
assert.match(mainSource,/if\(bare && is\('KeyF','f'\)\)\{\s*e\.preventDefault\(\);\s*toggleTorchAction\(\);\s*return;/,
  'F always reaches the torch in Source and the building');
assert.match(mainSource,/if\(usingSourceSpace\(\)\)\{[\s\S]*?Source is navigated, not sampled[\s\S]*?return;\s*\}/,
  'R performs no local landmark capture in Source');
assert.match(mainSource,/textSpace:\s*sourceTextSpaceActive\(\)/,'only Source Space proper selects the clear text renderer');
assert.match(mainSource,/function sourceTextSpaceActive\(\)\{[\s\S]*chunkSurfRuntime\.textSpaceActive/,'the runtime owns the physical landing to text-field boundary');
// The endpoint is a fork now — CONTACT ends in Source, CHAPEL walks back to the
// screen, and everything else crosses to the tower — so the completion card's
// onDone is the resolved route rather than one named function. Assert the fork
// resolves and that the tower crossing is still the default leg.
assert.match(mainSource,/const route=completion\.route\|\|finalState\.finale\?\.route;[\s\S]*?:\s*beginSourceTowerTransition;/,'the completed Source endpoint resolves one leaving route');
assert.match(mainSource,/presentFinale\(lines,\{slate,replayId:'chunk-surf-complete',onDone:leave\}\)/,'and the completion card owns the frame before it');
// THE ENDPOINT ROUTE NO LONGER DATAMOSHES. It is walked (CHUNK_SURF_PHASE.BELLS),
// so the contract is that main.js hands over to the belfry from a completed
// chapter rather than starting an encoder effect over a warp.
// (The datamosh renderer itself stays: the haystack still uses it, which is a
// different beat and an honest one.)
const towerHandover=mainSource.slice(
  mainSource.indexOf('function beginSourceTowerTransition()'),
  mainSource.indexOf('function resumeSourceTowerTransitionFromSave()'),
);
assert.ok(towerHandover.length>200,'the tower handover is where it is expected to be');
assert.doesNotMatch(towerHandover,/Datamosh/,'the tower crossing is a place, not an encoder effect');
assert.match(mainSource,/function beginSourceTowerTransition\(\)\{[\s\S]*?GOD_LOCATION_HOOKS\['cathedral-belfry'\]/,'and it hands over into the real bell chamber');
{
  const r3dFrameStart=rendererSource.indexOf('export function r3dFrame(state) {');
  assert.ok(r3dFrameStart>=0,'r3dFrame is present');

  const r3dFrameEnd=rendererSource.indexOf(
    '\nexport function r3dCanvas()',
    r3dFrameStart,
  );
  assert.ok(
    r3dFrameEnd>r3dFrameStart,
    'r3dFrame has a bounded top-level function body',
  );

  const r3dFrameSource=rendererSource.slice(r3dFrameStart,r3dFrameEnd);
  const textSpaceBranch=r3dFrameSource.indexOf('if (textSpaceActive) {');
  const textSpaceDraw=r3dFrameSource.indexOf('drawTextSpace(',textSpaceBranch);
  const textSpaceReturn=r3dFrameSource.indexOf('return;',textSpaceDraw);
  const reactionDiffusion=r3dFrameSource.indexOf(
    '// reaction-diffusion: 2 steps/frame',
    textSpaceReturn,
  );
  const pixelMesh=r3dFrameSource.indexOf(
    'runPixelMeshPass(',
    textSpaceReturn,
  );

  assert.ok(
    textSpaceBranch>=0,
    'Text Space owns a dedicated r3dFrame branch',
  );
  assert.ok(
    textSpaceDraw>textSpaceBranch,
    'Text Space resolves through drawTextSpace',
  );
  assert.ok(
    textSpaceReturn>textSpaceDraw,
    'Text Space returns after its compositor',
  );
  assert.ok(
    reactionDiffusion>textSpaceReturn,
    'Source Space exits before the normal material stack',
  );
  assert.ok(
    pixelMesh>textSpaceReturn,
    'Source Space exits before the normal pixel-mesh pass',
  );
}
{
  const drawTextSpaceStart=rendererSource.indexOf('function drawTextSpace(');
  assert.ok(drawTextSpaceStart>=0,'drawTextSpace is present');

  const drawTextSpaceEnd=rendererSource.indexOf(
    '\nconst DATAMOSH_FRAG=',
    drawTextSpaceStart,
  );
  assert.ok(
    drawTextSpaceEnd>drawTextSpaceStart,
    'drawTextSpace has a bounded function body',
  );

  const drawTextSpaceSource=rendererSource.slice(
    drawTextSpaceStart,
    drawTextSpaceEnd,
  );

  assert.match(
    drawTextSpaceSource,
    /const\s+([A-Za-z_$][\w$]*)\s*=\s*runSourceFaultPass\(sceneTex,\s*now\);\s*const\s+([A-Za-z_$][\w$]*)\s*=\s*runDatamoshPass\(\1,\s*now\);\s*presentTexture\(\2\);/,
    'the Text Space target is faulted, datamoshed, and presented in order',
  );
}
assert.match(rendererSource,/uHushScreen[\s\S]*uRain[\s\S]*moon/,'Text Space owns literal HUSH and weather composition');
assert.match(rendererSource,/uSunrise/,'the text-space shader owns the deterministic sunrise look');
assert.match(mainSource,/r3dSetSourceScene\(scene\)/,'Source rendering is submitted as one keyed static and dynamic payload');

for (const entry of Object.values(SOURCE_ATLAS.entries)) {
  const file = await readFile(resolve(entry.file), 'utf8');
  const exact = file.split(/\r?\n/)[entry.line - 1];
  assert.equal(exact, entry.text, `${entry.file}:${entry.line} is exact`);
  assert.equal(hash(exact), entry.hash, `${entry.file}:${entry.line} hash matches`);
  assert.ok(entry.tokens.every((token) => exact.slice(token.start, token.end) === token.text), 'token offsets refer to exact text');
}

{
  const runtime = createSourceSpaceRuntime({ initialState: hallState(0) });
  const plan = runtime.geometry.renderPlanFor(0, 0);
  assert.equal(plan.w, SOURCE_PLAN_WINDOW);
  assert.equal(plan.h, SOURCE_PLAN_WINDOW);
  assert.equal(Math.abs(plan.originX % SOURCE_PLAN_SNAP), 0);
  assert.equal(Math.abs(plan.originY % SOURCE_PLAN_SNAP), 0);
  for (const [x, y] of [[0, 0], [5, -40], [-5, -80], [7, -20]]) {
    const localX = Math.floor(x - plan.originX), localY = Math.floor(y - plan.originY);
    const flags = plan.rgba[(localY * plan.w + localX) * 4 + 2];
    assert.equal(Boolean(flags & 1), runtime.geometry.isSolid(x, y), `render/collision parity at ${x},${y}`);
  }
  assert.equal(runtime.geometry.zoneAt(0, -50), ZONE.sourceSpace);
}

{
  const runtime=createSourceSpaceRuntime({initialState:hallState(0)});
  const sheets=runtime.propInstances(0,0);
  assert.deepEqual(runtime.textInstances({px:0,py:0}),[],'the long hall never uses Source Space text geometry');
  assert.ok(sheets.length>=180,'the regular 3D hall begins full of real sheet meshes');
  assert.ok(sheets.every((entry)=>entry.mesh==='loose_note'&&entry.matrix?.length===16),'every hall page is a rendered 3D sheet');
  assert.ok(sheets.some((entry)=>Math.abs(entry.matrix[12])>2.8),'sheet meshes reach both physical walls');
  assert.ok(sheets.some((entry)=>entry.matrix[13]>4),'sheet meshes occupy the ceiling as well as the floor');
  assert.ok(runtime.probe().pageCount>=260,'the dense sheet field exists before hall progression');
}

{
  const runtime=createSourceSpaceRuntime({initialState:fullyOpenLandscapeState()});
  const architecture=[
    ...runtime.textInstances({px:0,py:FIELD_ORIGIN.y+SOURCE_TIER_BY_ID.fork.from-8}),
    ...runtime.textInstances({px:0,py:FIELD_ORIGIN.y+SOURCE_LANDMARK_OFFSETS['recordist-loop'].y}),
    ...runtime.textInstances({px:FINAL_PAGE.x,py:FINAL_PAGE.y}),
  ];
  // The long-hall page sheets end, but the open field surfaces the cathédrale
  // engloutie: real building meshes (vaults, bells, pews, the organ) leaking up
  // through the code, denser toward the end. They render via renderPropPass and
  // are composited by the text-space shader (solid stone half made of source).
  const leaked=[
    [0,FIELD_ORIGIN.y+SOURCE_TIER_BY_ID.fork.from-8],
    [0,FIELD_ORIGIN.y+SOURCE_TIER_BY_ID.trace.from-20],
    [0,FIELD_ORIGIN.y+SOURCE_TIER_BY_ID.return.from-20],
    [40,FIELD_ORIGIN.y+SOURCE_LANDMARK_OFFSETS['body-room'].y],
    [-40,FIELD_ORIGIN.y+SOURCE_LANDMARK_OFFSETS['surfer-origin'].y],
  ].flatMap(([x,y])=>runtime.propInstances(x,y,{time:2}));
  assert.ok(leaked.length>0,'the open field surfaces drowned architecture as real meshes');
  assert.ok(leaked.some((entry)=>['chapel_vault','pew','altar_table','lectern','tower_bell_01','tower_bell_04','tower_frame','organ_console','organ_pipes','grand_piano','hall_structure','chapel_inner_screen'].includes(entry.mesh)),'real building geometry surfaces through the field (cathédrale engloutie)');
  assert.ok(leaked.every((entry)=>typeof entry.mesh==='string'&&entry.matrix?.length===16),'every surfaced/drift piece is a placed mesh');
  assert.ok(architecture.length>=450,'the authored causeways are densely described by overlapping source geometry');
  assert.ok(['ramp','frame','span','monolith','pillar','endpoint','reference'].every((surface)=>architecture.some((entry)=>entry.semantic===`text-architecture:${surface}`)), 'ramps, references, and large-scale structures are all built from source text');
  assert.ok(architecture.filter((entry)=>entry.overlapLayer!=='base').length>=180,'offset source layers overlap across the map');
  assert.ok(architecture.filter((entry)=>entry.redacted).length>=30,'selected source tokens are visibly redacted');
  for(const entry of architecture){
    const source=SOURCE_ATLAS.entries[entry.sourceId];
    assert.ok(source,`${entry.id} retains atlas provenance`);
    assert.equal(entry.sourceFile,source.file);
    assert.equal(entry.sourceLine,source.line);
    assert.equal(entry.sourceHash,source.hash);
    if(entry.semantic==='text-architecture:reference')assert.ok(source.tokens.some((token)=>token.kind==='identifier'&&token.text===entry.text),'reference architecture displays an exact identifier token');
    else if(entry.redacted) assert.notEqual(entry.text,source.text,'a redacted display line differs from its protected source');
    else assert.equal(entry.text,source.text,'unredacted architecture displays exact repository source');
    assert.doesNotMatch(entry.text,/https?:\/\//i);
    assert.doesNotMatch(entry.text,/\/Users\//);
  }
  assert.ok(architecture.every((entry)=>entry.matrix?.length===16&&[...entry.matrix].every(Number.isFinite)),'all text architecture uses complete finite matrices');
  // Sampled on the deepest field tier itself. -320 was on it before the red
  // approach pushed every tier below the arrival out by SOURCE_APPROACH_CELLS;
  // afterwards it landed two tiers short and asserted the wrong ground.
  const finalTier=SOURCE_TIERS.filter((tier)=>tier.field).at(-1);
  assert.ok(sourceLandscapeFloorAt(0,(finalTier.from+finalTier.to)/2)>12,
    'the terminal occupies the top of a substantial final ramp');
// THE FIELD IS TIERED NOW, so "walkable everywhere" is no longer the contract —
// it was the reason the space had no level design in it. The contract is that
// every cliff is crossable BY A FEATURE and that open ground stays walkable, so
// the player is constrained but never stuck. See data/source-level.js.
for(let depth=0;depth<FIELD_DEPTH-1;depth+=1){
  const a=sourceLandscapeFloorAt(0,-depth),b=sourceLandscapeFloorAt(0,-depth-1);
  if(Math.abs(b-a)<=.45)continue;
  assert.ok(sourceFeatureAt(0,-depth)||sourceFeatureAt(0,-depth-1),
    `the spine has a cliff at depth ${depth} with no ladder or chute on it`);
}
// And the spine really is tiered, or none of the gating means anything.
// Probe each field tier at its own middle rather than at fixed depths.
assert.ok(new Set(SOURCE_TIERS.filter((tier)=>tier.field)
  .map((tier)=>sourceTierAt((tier.from+tier.to)/2).id)).size===4,
  'the critical spine no longer crosses four tiers');
  assert.ok(runtime.geometry.cellAt(FINAL_PAGE.x,FINAL_PAGE.y),'the final horizon is reachable');
  // The field is now one open, freely-roamable ground (Oblivion-style) — off the
  // routes is walkable, not an invisible causeway wall. The routes survive only
  // as brighter path material for wayfinding; the only hard edge is the field's
  // own perimeter, rendered as a visible wall of code.
  assert.ok(runtime.geometry.cellAt(20,FIELD_ORIGIN.y+(SOURCE_TIER_BY_ID.trace.from+SOURCE_TIER_BY_ID.trace.to)/2),'off-route space remains open except where authored solid architecture occupies it');
  assert.equal(runtime.geometry.cellAt(40,FIELD_ORIGIN.y-184-SOURCE_APPROACH_CELLS),null,'the colossal percussion shelf is physically present in off-route space');
  assert.equal(runtime.geometry.cellAt(0,-900),null,'beyond the field perimeter there is no ground (sky, not corridor)');
}

{
  const first=sourceStructurePlacements(4417),again=sourceStructurePlacements(4417),other=sourceStructurePlacements(4418);
  assert.deepEqual(first,again,'giant placement is exactly deterministic for a run seed');
  assert.notDeepEqual(first.filter((entry)=>entry.seeded),other.filter((entry)=>entry.seeded),'another run seed changes only the field scatter');
  assert.equal(first.filter((entry)=>entry.hero).length,5,'five authored hero compositions anchor the landscape');
  assert.equal(first.filter((entry)=>entry.seeded).length,SOURCE_SEEDED_STRUCTURE_COUNT,'exactly fourteen seeded giants are accepted');
  assert.ok(first.filter((entry)=>entry.kind==='fractured-bust').length<=2,'fractured scatter stays rare');
  assert.ok(first.every((entry)=>sourceStructureRouteClearance(entry)>0),'every giant collider clears the authored walking routes');
  assert.ok(sourceStructureCollisionAt(first,-24,-30-SOURCE_APPROACH_CELLS),'the west stand gate has a real footprint');
  assert.equal(sourceStructureCollisionAt(first,0,-30-SOURCE_APPROACH_CELLS),null,'the stand gate leaves its central approach open');
}

{
  const runtime=createSourceSpaceRuntime({initialState:fullyOpenLandscapeState()});
  const expected=sourceLandscapePlanOrigin({x:0,y:-252});
  const near=runtime.geometry.renderPlanFor(0,-252);
  const far=runtime.geometry.renderPlanFor(120,FIELD_ORIGIN.y+(SOURCE_TIER_BY_ID.return.from+SOURCE_TIER_BY_ID.return.to)/2);
  assert.equal(near,far,'ordinary landscape movement never rebuilds or recentres the raster plan');
  assert.deepEqual({x:near.originX,y:near.originY},expected);
  assert.ok(near.originX<=-180&&near.originX+near.w>=180,'the anchored plan covers the complete landscape width');
  assert.ok(near.originY<=FIELD_ORIGIN.y-FIELD_DEPTH&&near.originY+near.h>=FIELD_ORIGIN.y+18,'the anchored plan covers the complete landscape depth');

  const batchY=FIELD_ORIGIN.y+SOURCE_TIER_BY_ID.trace.from-20;
  const before=runtime.sourceScene({px:127,py:batchY,time:0});
  const after=runtime.sourceScene({px:129,py:batchY,time:0});
  assert.equal(SOURCE_ARCH_TILE_CELLS,128);
  assert.ok(before.staticBatches.length>1&&after.staticBatches.length>1,'text architecture is delivered in bounded world batches');
  assert.ok(before.staticInstances.length<=SOURCE_ARCH_MAX_INSTANCES&&after.staticInstances.length<=SOURCE_ARCH_MAX_INSTANCES);
  assert.equal(new Set(before.staticInstances.map((entry)=>entry.id)).size,before.staticInstances.length,'resident tiles never duplicate an authored source panel');
  const beforeById=new Map(before.staticInstances.map((entry)=>[entry.id,entry]));
  for(const entry of after.staticInstances){
    const prior=beforeById.get(entry.id);
    if(prior)assert.deepEqual([...entry.matrix],[...prior.matrix],`${entry.id} never moves when residency changes`);
  }
  const beforeKeys=new Set(before.staticBatches.map((batch)=>batch.key));
  const afterKeys=new Set(after.staticBatches.map((batch)=>batch.key));
  const changed=[...before.staticBatches.filter((batch)=>!afterKeys.has(batch.key)),...after.staticBatches.filter((batch)=>!beforeKeys.has(batch.key))];
  const playerMetres={x:129*CELL,z:batchY*CELL};
  for(const batch of changed){
    const bx=Math.max(batch.bounds.minX,Math.min(playerMetres.x,batch.bounds.maxX));
    const bz=Math.max(batch.bounds.minZ,Math.min(playerMetres.z,batch.bounds.maxZ));
    assert.ok(Math.hypot(bx-playerMetres.x,bz-playerMetres.z)>90,'tiles enter or leave only beyond the prop render radius');
  }
}

{
  let state=hallState(112);
  state=reduceChunkSurf(state,{type:'HAYSTACK_REACHED',origin:{x:0,y:-224},slot:3});
  const runtime=createSourceSpaceRuntime({initialState:state});
  const sheets=runtime.propInstances(0,-224);
  assert.deepEqual(runtime.textInstances({px:0,py:-224}),[],'the haystack remains in the physical renderer');
  assert.equal(sheets.filter((entry)=>entry.interactiveId==='source-page').length,1,'exactly one real sheet mesh is interactive');
  const searchable=sheets.find((entry)=>entry.interactiveId==='source-page');
  const camera=runtime.geometry.logicalToPhysical(0,-224);
  assert.ok(Math.hypot(searchable.matrix[12]-camera.x*CELL,searchable.matrix[14]-camera.z*CELL)<=12,'interactive sheet is rendered near the haystack player in physical space');
}

{
  let state=hallState(112);
  state=reduceChunkSurf(state,{type:'HAYSTACK_REACHED',origin:{x:0,y:-224},slot:0});
  state=reduceChunkSurf(state,{type:'HAYSTACK_PAGE_FOUND',landscapeOrigin:{x:0,y:-252}});
  const runtime=createSourceSpaceRuntime({initialState:state});
  const before=runtime.geometry.logicalToPhysical(0,-238);
  runtime.tick(5.5,{px:0,py:-238,facing:0});
  const after=runtime.geometry.logicalToPhysical(0,-238);
  assert.deepEqual({x:after.x,z:after.z},{x:before.x,z:before.z},'transformation never teleports the player');
  assert.equal(runtime.state().phase,'landscape');
  assert.ok([MATERIAL.serviceConcrete,MATERIAL.sourceField,MATERIAL.sourcePath,MATERIAL.sourceFault].includes(runtime.geometry.materialAt(0,-250)));
}

{
  let state=landscapeState();
  for(const event of [
    {type:'LANDMARK_VISITED',id:'fork-room'},
    {type:'LANDMARK_VISITED',id:'recordist-loop'},
    {type:'LANDMARK_VISITED',id:'body-room'},
    {type:'FINAL_REACHED'},
  ])state=reduceChunkSurf(state,event);
  let completed=null;
  const runtime=createSourceSpaceRuntime({initialState:state,onComplete:(result,snapshot)=>{completed={result,snapshot};}});
  const endpoint={x:FINAL_PAGE.x,y:FINAL_PAGE.y-2,facing:0};
  runtime.setPlayerPosition(endpoint);
  assert.equal(runtime.finalEncounterRequest()?.adapter,null,'the terminal endpoint does not force signal combat');
  assert.equal(runtime.finalEncounterRequest()?.battleAvailable,false,'a no-contact route exposes no battle fault');
  assert.equal(runtime.finalEncounterRequest()?.normalExitAvailable,true);
  // The normal route no longer ends the chapter where it leaves the field: it
  // walks off into the HORIZON, and the exit chosen THERE is what completes
  // Source and hands the snapshot on. Two beats, still no contact and no combat.
  const resolved=runtime.completeNormalExit();
  assert.equal(resolved.handled,true,'the normal route leaves Source Space without contact or combat');
  assert.equal(resolved.horizon,true,'and it leaves into the horizon');
  assert.equal(runtime.state().phase,'horizon');
  assert.equal(runtime.state().completed,false,'the chapter is not over until the horizon is answered');
  assert.equal(runtime.chooseHorizonExit('chapel').handled,true);
  assert.equal(runtime.state().completed,true);
  assert.ok(completed?.snapshot?.sourceIds?.length,'endpoint completion produces the snapshot consumed by the datamosh route');
}

console.log('chunk-surf 3d source-space specs passed');
